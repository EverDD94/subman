'import "pkg:/source/enums/AnimationControl.bs"
'import "pkg:/source/enums/AnimationState.bs"
'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/ItemType.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/TaskControl.bs"
'import "pkg:/source/utils/misc.bs"


sub init()
    m.selectedOptions = []
    m.tagFilter = ""
    m.top.filter = "All"
    m.originalOptions = {}
    m.tooManyTagsError = false
    m.tooManyResultsText = m.top.findNode("tooManyResultsText")
    m.tooManyResultsText.font.size = 30
    m.noTagsError = false
    m.noResultsText = m.top.findNode("noResultsText")
    m.noResultsText.font.size = 30
    m.tagSearchButton = m.top.findNode("tagSearchButton")
    m.tagSearchButton.background = "#3D63E0"
    m.tagSearchButton.color = "#161A22"
    m.tagSearchButton.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    m.tagSearchButton.focusColor = "#ffffff"
    m.submitButton = m.top.findNode("submitButton")
    m.submitButton.background = "#3D63E0"
    m.submitButton.color = "#161A22"
    m.submitButton.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    m.submitButton.focusColor = "#ffffff"
    m.scrollBarThumbSlideAnimation = m.top.findnode("scrollBarThumbSlideAnimation")
    m.scrollBarThumbSlideInterpolator = m.top.findnode("scrollBarThumbSlideInterpolator")
    m.scrollBar = m.top.findnode("scrollBar")
    m.thumb = m.top.findnode("thumb")
    m.thumbStep = 0
    m.scrollBar.opacity = .75
    m.scrollBar.color = "0x00000077"
    m.thumb.color = "#aaaaaa"
    overlay = m.top.findNode("overlay")
    overlay.color = "#161A22"
    background = m.top.findNode("background")
    background.color = "#161A22"
    headerText = m.top.findNode("headerText")
    headerText.font.size = 45
    headerBorder = m.top.findNode("headerBorder")
    headerBorder.color = "#3D63E0"
    m.filterMenu = m.top.findNode("filterMenu")
    m.filterMenu.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    m.filterMenu.focusFootprintBlendColor = "#9DB4FF"
    m.filterMenu.focusedColor = "#ffffff"
    m.filterOptionsBackdrop = m.top.findNode("filterOptionsBackdrop")
    m.filterOptionsBackdrop.color = "#aaaaaa"
    m.filterOptionsMenu = m.top.findNode("filterOptionsMenu")
    m.filterOptionsMenu.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    m.filterOptionsMenu.focusFootprintBlendColor = "#9DB4FF"
    m.filterOptionsMenu.focusedColor = "#ffffff"
    m.filterMenu.observeField("itemFocused", "onFilterFocusChange")
    m.filterOptionsMenu.observeField("itemFocused", "onFilterOptionsFocusChange")
    m.filterNames = []
    ' Animation
    m.showChecklistAnimation = m.top.findNode("showChecklistAnimation")
    m.hideChecklistAnimation = m.top.findNode("hideChecklistAnimation")
end sub

sub onFilterOptionsFocusChange()
    m.scrollBarThumbSlideInterpolator.keyValue = [
        m.thumb.translation
        [
            0
            m.thumbStep * m.filterOptionsMenu.itemFocused
        ]
    ]
    m.scrollBarThumbSlideAnimation.control = "start"
end sub

sub showChecklist()
    if m.filterOptionsMenu.opacity = 0
        if m.showChecklistAnimation.state = "stopped"
            m.showChecklistAnimation.control = "start"
        end if
    end if
end sub

sub hideChecklist()
    if m.filterOptionsMenu.opacity = 1
        if m.hideChecklistAnimation.state = "stopped"
            m.hideChecklistAnimation.control = "start"
        end if
    end if
end sub

sub onFilterFocusChange()
    if not isFilterMenuDataValid()
        hideChecklist()
        return
    end if
    filterName = chainlookup(m.filterMenu.content.getChild(m.filterMenu.itemFocused), "Name")
    if isStringEqual(filterName, "tags")
        if not isStringEqual(m.filterOptionsMenu.vertFocusAnimationStyle, "floatingFocus")
            m.filterOptionsMenu.vertFocusAnimationStyle = "floatingFocus"
        end if
        m.tagSearchButton.visible = true
        m.filterOptionsMenu.translation = [
            900
            280
        ]
        m.filterOptionsMenu.numRows = 5
        m.filterOptionsBackdrop.height = 425
        m.filterOptionsBackdrop.translation = [
            855
            260
        ]
        if m.tooManyTagsError
            m.tooManyResultsText.visible = true
            m.scrollBar.visible = false
            hideChecklist()
        else if m.noTagsError
            m.noResultsText.visible = true
            m.scrollBar.visible = false
            hideChecklist()
        else
            if isValidAndNotEmpty(m.tagFilter)
                if m.filterOptionsMenu.content.getChildCount() > 5
                    m.scrollBar.visible = true
                end if
            end if
        end if
    else
        if not isStringEqual(m.filterOptionsMenu.vertFocusAnimationStyle, "fixedFocusWrap")
            m.filterOptionsMenu.vertFocusAnimationStyle = "fixedFocusWrap"
        end if
        m.tagSearchButton.visible = false
        m.filterOptionsMenu.translation = [
            900
            200
        ]
        m.filterOptionsMenu.numRows = 6
        m.filterOptionsBackdrop.height = 505
        m.filterOptionsBackdrop.translation = [
            855
            180
        ]
        m.tooManyResultsText.visible = false
        m.noResultsText.visible = false
        m.scrollBar.visible = false
    end if
    if m.filterMenu.content.getChild(m.filterMenu.itemFocused).getChildCount() > 0
        showChecklist()
    else
        hideChecklist()
    end if
    ' No need to reset the filter options if nothing changed
    if isStringEqual(chainLookup(m.filterOptionsMenu, "content.name"), m.filterMenu.content.getChild(m.filterMenu.itemFocused).name)
        return
    end if
    m.filterOptionsMenu.content = m.filterMenu.content.getChild(m.filterMenu.itemFocused)
    if isValid(m.filterMenu.content.getChild(m.filterMenu.itemFocused).checkedState)
        m.filterOptionsMenu.checkedState = m.filterMenu.content.getChild(m.filterMenu.itemFocused).checkedState
    else
        m.filterOptionsMenu.checkedState = []
    end if
end sub

' Check if data for Filter Menu is valid
function isFilterMenuDataValid() as boolean
    if not isValid(m.filterMenu) or not isValid(m.filterMenu.content) or not isValid(m.filterMenu.itemFocused)
        return false
    end if
    if not isValid(m.filterMenu.content.getChild(m.filterMenu.itemFocused))
        return false
    end if
    return true
end function

sub calculateButtonThumbProperties()
    if not isValid(m.scrollBar) then
        return
    end if
    if not isChainValid(m.filterOptionsMenu, "content") then
        return
    end if
    if m.filterOptionsMenu.content.getChildCount() < 6
        m.scrollBar.visible = false
        return
    else
        m.scrollBar.visible = true
    end if
    m.thumbStep = (m.scrollBar.height - m.thumb.height) / (m.filterOptionsMenu.content.getChildCount() - 1)
end sub

sub processTagSearch()
    filteredTags = []
    m.noTagsError = false
    m.noResultsText.visible = false
    m.tooManyTagsError = false
    m.tooManyResultsText.visible = false
    filterItem = m.top.options.filter[m.filterMenu.itemFocused]
    dataSource = (function(filterItem)
            __bsConsequent = filterItem.data
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return filterItem.options
            end if
        end function)(filterItem)
    for each filterItemOption in dataSource
        tag = toString(filterItemOption)
        if LCase(tag).Instr(m.tagFilter) > -1
            filteredTags.push(filterItemOption)
            if filteredTags.count() > 50
                if isValidAndNotEmpty(m.tagFilter)
                    m.tooManyTagsError = true
                    m.tooManyResultsText.visible = true
                    m.scrollBar.visible = false
                    hideChecklist()
                    entry = CreateObject("roSGNode", "OptionNode")
                    entry.title = filterItem.Title
                    entry.name = filterItem.Name
                    entry.delimiter = filterItem.Delimiter
                    m.filterMenu.content.replaceChild(entry, m.filterMenu.itemFocused)
                    m.filterOptionsMenu.content = m.filterMenu.content.getChild(m.filterMenu.itemFocused)
                end if
                return
            end if
        end if
    end for
    if filteredTags.count() = 0
        m.noTagsError = true
        m.noResultsText.visible = true
        m.scrollBar.visible = false
        hideChecklist()
        entry = CreateObject("roSGNode", "OptionNode")
        entry.title = filterItem.Title
        entry.name = filterItem.Name
        entry.delimiter = filterItem.Delimiter
        m.filterMenu.content.replaceChild(entry, m.filterMenu.itemFocused)
        m.filterOptionsMenu.content = m.filterMenu.content.getChild(m.filterMenu.itemFocused)
        return
    end if
    entry = CreateObject("roSGNode", "OptionNode")
    entry.title = filterItem.Title
    entry.name = filterItem.Name
    entry.delimiter = filterItem.Delimiter
    checkedState = []
    for each filterItemOption in filteredTags
        entryOption = entry.CreateChild("ContentNode")
        entryOption.title = toString(filterItemOption)
        if isValidAndNotEmpty(m.selectedOptions)
            checkedState.push(inArray(m.selectedOptions, toString(filterItemOption)))
        end if
    end for
    m.filterMenu.content.replaceChild(entry, m.filterMenu.itemFocused)
    m.filterOptionsMenu.content = m.filterMenu.content.getChild(m.filterMenu.itemFocused)
    m.top.filteredOptions = filteredTags
    m.top.filteredOptionsCheckedState = checkedState
    m.filterOptionsMenu.checkedState = checkedState
    calculateButtonThumbProperties()
    showChecklist()
    m.tagSearchButton.focus = false
    m.filterOptionsMenu.setFocus(true)
end sub

sub optionsSet()
    ' Filter Tab
    if isValid(m.top.options.filter)
        filterContent = CreateObject("roSGNode", "ContentNode")
        index = 0
        m.selectedFilterIndex = 0
        for each filterItem in m.top.options.filter
            entry = filterContent.CreateChild("OptionNode")
            entry.title = filterItem.Title
            entry.name = filterItem.Name
            entry.delimiter = filterItem.Delimiter
            if isValid(filterItem.options)
                if isStringEqual(entry.name, "Tags")
                    filteredTags = []
                    m.noTagsError = false
                    for each filterItemOption in filterItem.options
                        tag = toString(filterItemOption)
                        if LCase(tag).Instr(m.tagFilter) > -1
                            filteredTags.push(filterItemOption)
                            if filteredTags.count() > 50
                                if isValidAndNotEmpty(m.tagFilter)
                                    m.tooManyTagsError = true
                                end if
                                exit for
                            end if
                        end if
                    end for
                    if filteredTags.count() <= 50
                        m.tooManyTagsError = false
                        for each filterItemOption in filteredTags
                            entryOption = entry.CreateChild("ContentNode")
                            entryOption.title = toString(filterItemOption)
                        end for
                        calculateButtonThumbProperties()
                    end if
                    entry.checkedState = filterItem.checkedState
                else
                    for each filterItemOption in filterItem.options
                        entryOption = entry.CreateChild("ContentNode")
                        entryOption.title = toString(filterItemOption)
                    end for
                    entry.checkedState = filterItem.checkedState
                end if
            end if
            m.filterNames.push(filterItem.Name)
            if isValid(filterItem.selected) and filterItem.selected
                m.selectedFilterIndex = index
            end if
            index = index + 1
        end for
        m.filterMenu.content = filterContent
        m.filterMenu.checkedItem = m.selectedFilterIndex
    else
        filterContent = CreateObject("roSGNode", "ContentNode")
        entry = filterContent.CreateChild("ContentNode")
        entry.title = tr("All")
        m.filterNames.push("All")
        m.filterMenu.content = filterContent
        m.filterMenu.checkedItem = 0
    end if
    m.originalOptions = {
        filterData: m.top.options
        filter: m.top.filter
        filterOptions: m.top.filterOptions
    }
    m.filterMenu.jumpToItem = 0
    group = m.global.sceneManager.callFunc("getActiveScene")
    group.lastFocus = m.filterMenu
end sub

sub ShowKeyboard()
    dialog = createObject("roSGNode", "StandardKeyboardDialog")
    dialog.title = tr("Search tags")
    dialog.buttons = [
        tr("OK")
        tr("Cancel")
    ]
    dialog.text = m.tagFilter
    palette = createObject("roSGNode", "RSGPalette")
    palette.colors = {
        DialogBackgroundColor: "#161A22"
    }
    dialog.palette = palette
    m.top.getscene().dialog = dialog
    m.dialog = dialog
    dialog.observeField("buttonSelected", "onDialogButton")
end sub

function onDialogButton()
    d = m.dialog
    button_text = d.buttons[d.buttonSelected]
    if button_text = tr("OK")
        m.tagFilter = d.text
        processTagSearch()
        m.dialog.close = true
        return true
    else if button_text = tr("Cancel")
        m.dialog.close = true
        return true
    else
        return false
    end if
end function

function onKeyEvent(key as string, press as boolean) as boolean
    ' User pressed OK from inside the filter's options
    if key = "OK"
        if m.filterOptionsMenu.isInFocusChain()
            filterName = chainlookup(m.filterMenu.content.getChild(m.filterMenu.itemFocused), "Name")
            if isStringEqual(filterName, "tags")
                if m.filterOptionsMenu.checkedState.count() > 50 then
                    return false
                end if
            end if
            m.selectedOptions = []
            for i = 0 to m.filterOptionsMenu.checkedState.count() - 1
                if m.filterOptionsMenu.checkedState[i]
                    selectedFilterContent = m.filterOptionsMenu.content.getChild(i)
                    if not isValidAndNotEmpty(selectedFilterContent) then
                        continue for
                    end if
                    selectedValue = toString(selectedFilterContent.title)
                    selectedValue = selectedValue.replace("Photo Album", "photoalbum")
                    m.selectedOptions.push(selectedValue)
                end if
            end for
            if m.selectedOptions.Count() > 0
                m.filterMenu.checkedItem = m.filterMenu.itemFocused
                m.selectedFilterIndex = m.filterMenu.itemFocused
                m.top.filter = m.filterMenu.content.getChild(m.filterMenu.itemFocused).Name
                newFilter = {}
                newFilter[m.top.filter] = m.selectedOptions.join(m.filterMenu.content.getChild(m.filterMenu.itemFocused).delimiter)
                m.top.filterOptions = newFilter
            else
                m.filterMenu.checkedItem = 0
                m.selectedFilterIndex = 0
                m.top.filter = m.filterNames[0]
                m.top.filterOptions = {}
            end if
            m.filterMenu.content.getChild(m.filterMenu.itemFocused).checkedState = m.filterOptionsMenu.checkedState
            return true
        end if
    end if
    if not press then
        return false
    end if
    if key = "right"
        if not m.filterMenu.isInFocusChain() then
            return false
        end if
        ' Handle Filter screen
        if not isFilterMenuDataValid() then
            return false
        end if
        ' If filter has no options, select it
        if m.filterMenu.content.getChild(m.filterMenu.itemFocused).getChildCount() = 0
            if m.tagSearchButton.visible
                m.tagSearchButton.focus = true
                m.tagSearchButton.setFocus(true)
                return true
            end if
            return true
        end if
        ' Selected filter has options, move cursor to it
        m.filterOptionsMenu.setFocus(true)
        m.filterMenu.setFocus(false)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.filterOptionsMenu
        return true
    end if
    if key = "down"
        if m.tagSearchButton.isInFocusChain()
            if m.filterOptionsMenu.content.getChildCount() = 0 then
                return false
            end if
            m.tagSearchButton.focus = false
            m.filterOptionsMenu.setFocus(true)
            return true
        end if
        if m.filterMenu.isInFocusChain()
            m.submitButton.focus = true
            m.submitButton.setfocus(true)
            return true
        end if
    end if
    if key = "up"
        if m.filterOptionsMenu.isInFocusChain()
            m.tagSearchButton.focus = true
            m.tagSearchButton.setfocus(true)
            return true
        end if
        if m.submitButton.isInFocusChain()
            m.submitButton.focus = false
            m.filterMenu.setfocus(true)
            return true
        end if
    end if
    if key = "back"
        if isValidAndNotEmpty(m.originalOptions)
            m.top.filter = m.originalOptions.LookupCI("filter")
            m.top.filterOptions = m.originalOptions.LookupCI("filterOptions")
            m.top.options = m.originalOptions.LookupCI("filterData")
        end if
        m.top.visible = false
        m.tagSearchButton.visible = false
        m.tagSearchButton.focus = false
        m.submitButton.focus = false
        m.filterMenu.jumpToItem = 0
        return true
    end if
    if key = "left"
        if m.tagSearchButton.visible
            m.tagSearchButton.focus = false
            m.filterMenu.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.filterMenu
            return true
        end if
        ' User wants to escape filter options
        if m.filterOptionsMenu.isInFocusChain()
            m.filterOptionsMenu.setFocus(false)
            m.filterMenu.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.filterMenu
            return true
        end if
    end if
    if key = "OK"
        if m.submitButton.isInFocusChain()
            if not isStringEqual(m.top.filter, "Tags")
                m.tagFilter = ""
                m.top.filteredOptionsCheckedState = []
            end if
            m.originalOptions = {
                filterData: m.top.options
                filter: m.top.filter
                filterOptions: m.top.filterOptions
            }
            m.noTagsError = false
            m.noResultsText.visible = false
            m.top.visible = false
            m.submitButton.focus = false
            m.filterMenu.jumpToItem = 0
            m.top.filteredOptionsCheckedState = m.filterOptionsMenu.checkedState
        end if
        if m.tagSearchButton.isInFocusChain()
            ShowKeyboard()
        end if
        if m.filterMenu.isInFocusChain()
            ' Handle Filter screen
            if not isFilterMenuDataValid() then
                return false
            end if
            ' If filter has no options, select it
            if m.filterMenu.content.getChild(m.filterMenu.itemFocused).getChildCount() = 0
                filterName = chainlookup(m.filterMenu.content.getChild(m.filterMenu.itemFocused), "Name")
                if isStringEqual(filterName, "tags")
                    m.tagSearchButton.focus = true
                    m.tagSearchButton.setfocus(true)
                    return true
                end if
                m.filterMenu.checkedItem = m.filterMenu.itemFocused
                m.selectedFilterIndex = m.filterMenu.itemFocused
                m.top.filter = m.filterNames[m.selectedFilterIndex]
                m.top.filterOptions = {}
                return true
            end if
            ' Selected filter has options, move cursor to it
            m.filterOptionsMenu.setFocus(true)
            m.filterMenu.setFocus(false)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.filterOptionsMenu
            return true
        end if
        return true
    end if
    return false
end function
'//# sourceMappingURL=./LibraryFilterDialog.brs.map