'import "pkg:/source/enums/KeyCode.bs"

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if not m.top.isInFocusChain() then
        return false
    end if
    if key <> "down" then
        return false
    end if
    if m.top.content = invalid then
        return false
    end if
    itemCount = m.top.content.getChildCount()
    focusedIndex = m.top.itemFocused
    numColumns = m.top.numColumns
    if itemCount <= 0 then
        return false
    end if
    if focusedIndex < 0 then
        return false
    end if
    if numColumns <= 0 then
        return false
    end if
    nextRowStart = (Fix(focusedIndex / numColumns) + 1) * numColumns
    sameColumnNextRowIndex = focusedIndex + numColumns
    if nextRowStart < itemCount and sameColumnNextRowIndex >= itemCount
        ' Jump directly to the last item in a short next row.
        m.top.jumpToItem = itemCount - 1
        return true
    end if
    return false
end function
'//# sourceMappingURL=./LibraryItemGrid.brs.map