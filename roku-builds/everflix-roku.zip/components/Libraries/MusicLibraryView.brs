'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/Image.bs"
'import "pkg:/source/enums/AnimationControl.bs"
'import "pkg:/source/enums/AnimationState.bs"
'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/DropdownMenuID.bs"
'import "pkg:/source/enums/ExitDirection.bs"
'import "pkg:/source/enums/ImageLayout.bs"
'import "pkg:/source/enums/ItemType.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/SearchButtonState.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/enums/TaskControl.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/deviceCapabilities.bs"
'import "pkg:/source/utils/misc.bs"

sub setupNodes()
    m.toggleDropdownOptionsAnimation = m.top.findNode("toggleDropdownOptionsAnimation")
    m.dropdownOptionsMove = m.top.findNode("dropdownOptionsMove")
    m.chipsRowMove = m.top.findNode("chipsRowMove")
    m.chipsRow = m.top.findNode("chipsRow")
    m.itemGridMove = m.top.findNode("itemGridMove")
    m.genreListMove = m.top.findNode("genreListMove")
    m.dropdownOptionsFade = m.top.findNode("dropdownOptionsFade")
    m.options = m.top.findNode("options")
    m.itemGrid = m.top.findNode("itemGrid")
    m.emptyText = m.top.findNode("emptyText")
    m.backdropImage = m.top.findNode("backdropImage")
    m.selectedArtistName = m.top.findNode("selectedArtistName")
    m.selectedArtistCreditedFor = m.top.findNode("selectedArtistCreditedFor")
    m.selectedArtistSongCount = m.top.findNode("selectedArtistSongCount")
    m.selectedArtistAlbumCount = m.top.findNode("selectedArtistAlbumCount")
    m.selectedArtistGenres = m.top.findNode("selectedArtistGenres")
    m.artistLogo = m.top.findNode("artistLogo")
    m.alpha = m.top.findNode("alpha")
    m.alphaMenu = m.alpha.findNode("alphaMenu")
    m.overhang = m.top.getScene().findNode("overhang")
    m.genreList = m.top.findNode("genrelist")
    m.dropdownOptionGroup = m.top.findNode("dropdownOptionGroup")
    m.dropdownOptionGroup.observeFieldScoped("showOptions", "onShowOptionsChange")
    m.dropdownOptionGroup.observeFieldScoped("exit", "onExit")
    m.dropdownOptionGroup.observeFieldScoped("searchTerm", "onDropdownOptionGroupSearchTermChanged")
end sub

sub onShowOptionsChange()
    m.options.visible = true
    m.options.findNode("filterMenu").setFocus(true)
    group = m.global.sceneManager.callFunc("getActiveScene")
    group.lastFocus = m.options
end sub

sub onExit()
    m.global.sceneManager.unobserveFieldScoped("returnData")
    dropdownExitDirection = m.dropdownOptionGroup.exit
    if dropdownExitDirection = 1
        alphaDisplayed = m.alpha.callFunc("getDisplay")
        if alphaDisplayed
            m.top.alphaActive = true
            m.alphaMenu.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.alphaMenu
        else
            m.librarySettings.setFocus(true)
            m.librarySettings.highlighted = true
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.librarySettings
        end if
        return
    end if
    if dropdownExitDirection = 0
        if m.loadedItems = 0 then
            return
        end if
        m.itemGrid.setFocus(m.itemGrid.opacity = 1)
        m.genreList.setFocus(m.genreList.opacity = 1)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.itemGrid
    end if
end sub

sub onReturnData()
    m.global.sceneManager.unobserveFieldScoped("returnData")
    selectedOptionData = m.global.sceneManager.returnData
    if not isValidAndNotEmpty(selectedOptionData) then
        return
    end if
    optionType = chainLookup(selectedOptionData, "id")
    if isStringEqual(optionType, "librarySortOrder")
        onSortOrderChange(selectedOptionData)
        return
    end if
    if isStringEqual(optionType, "librarySortBy")
        onSortChange(selectedOptionData)
        return
    end if
    if isStringEqual(optionType, "libraryView")
        onViewChange(selectedOptionData)
        return
    end if
end sub

sub init()
    m.top.imageDisplayMode = "scaleToZoom"
    m.top.showItemTitles = "showonhover"
    setupNodes()
    m.bypassSearchEvent = false
    m.itemGrid.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    m.genrelist.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    m.overhang.isVisible = false
    m.options.observeField("visible", "onOptionsVisibleChange")
    m.loadedRows = 0
    m.loadedItems = 0
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    m.genreData = CreateObject("roSGNode", "ContentNode")
    m.genreList.observeField("itemSelected", "onGenreItemSelected")
    m.genreList.observeField("itemFocused", "onGenreItemFocused")
    m.genreList.content = m.genreData
    m.itemGrid.observeField("itemFocused", "onItemFocused")
    m.itemGrid.observeField("itemSelected", "onItemSelected")
    'Item sort - maybe load defaults from user prefs?
    m.sortField = "SortName"
    m.sortAscending = true
    m.filter = "All"
    m.loadItemsTask = createObject("roSGNode", "LoadItemsTask2")
    m.loadArtistStatsTask = createObject("roSGNode", "MusicArtistStatsTask")
    m.getFiltersTask = createObject("roSGNode", "GetFiltersTask")
    m.artistStatsCache = {}
    m.selectedArtistStatsId = ""
    m.selectedArtistStatsFilter = ""
    'set inital counts for overhang before content is loaded.
    m.loadItemsTask.observeField("content", "ItemDataLoaded")
    m.loadArtistStatsTask.observeField("content", "ArtistStatsLoaded")
    m.loadItemsTask.totalRecordCount = 0
end sub

sub onSortChange(sortChoice)
    if not isChainValid(sortChoice, "name") then
        return
    end if
    if isStringEqual(sortChoice.LookupCI("name"), m.sortField) then
        return
    end if
    m.dropdownOptionGroup.callfunc("setFocus", "sortButton", false)
    m.itemGrid.setFocus(m.itemGrid.opacity = 1)
    m.genreList.setFocus(m.genreList.opacity = 1)
    m.sortField = sortChoice.LookupCI("name")
    m.dropdownOptionGroup.callfunc("setText", "sortButton", tr(sortChoice.LookupCI("title")))
    m.dropdownOptionGroup.callfunc("setSortAscending", true)
    m.sortAscending = true
    set_user_setting("display." + m.settingID + ".sortField", m.sortField)
    m.loadedRows = 0
    m.loadedItems = 0
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    loadInitialItems()
end sub

sub onViewChange(viewChoice)
    if not isChainValid(viewChoice, "name") then
        return
    end if
    if isStringEqual(viewChoice.LookupCI("name"), m.view) then
        return
    end if
    m.dropdownOptionGroup.callfunc("setFocus", "viewButton", false)
    m.itemGrid.setFocus(m.itemGrid.opacity = 1)
    m.genreList.setFocus(m.genreList.opacity = 1)
    m.view = viewChoice.LookupCI("name")
    m.dropdownOptionGroup.callfunc("setText", "viewButton", tr(viewChoice.LookupCI("title")))
    set_user_setting("display." + m.settingID + ".landing", m.view)
    ' Reset any filtering or search terms
    m.bypassSearchEvent = true
    m.top.searchTerm = ""
    m.top.alphaSelected = ""
    m.loadItemsTask.NameStartsWith = " "
    m.loadItemsTask.searchTerm = ""
    m.filter = "All"
    m.filterOptions = {}
    m.sortField = "SortName"
    m.sortAscending = true
    ' Reset view to defaults
    set_user_setting("display." + m.settingID + ".sortField", m.sortField)
    set_user_setting("display." + m.settingID + ".sortAscending", "true")
    set_user_setting("display." + m.settingID + ".filter", m.filter)
    set_user_setting("display." + m.settingID + ".filterOptions", FormatJson(m.filterOptions))
    m.getFiltersTask.control = "RUN"
    m.loadedRows = 0
    m.loadedItems = 0
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    loadInitialItems()
end sub

sub onSortOrderChange(sortOrderChoice)
    if not isChainValid(sortOrderChoice, "name") then
        return
    end if
    if m.sortAscending = isStringEqual(sortOrderChoice.LookupCI("name"), "ascending") then
        return
    end if
    m.dropdownOptionGroup.callfunc("setFocus", "sortOrderButton", false)
    m.itemGrid.setFocus(m.itemGrid.opacity = 1)
    m.genreList.setFocus(m.genreList.opacity = 1)
    m.sortAscending = isStringEqual(sortOrderChoice.LookupCI("name"), "Ascending")
    m.dropdownOptionGroup.callfunc("setSortAscending", m.sortAscending)
    m.dropdownOptionGroup.callfunc("setText", "sortOrderButton", tr(sortOrderChoice.LookupCI("title")))
    set_user_setting("display." + m.settingID + ".sortAscending", m.sortAscending.toStr())
    m.loadedRows = 0
    m.loadedItems = 0
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    loadInitialItems()
end sub

sub OnScreenHidden()
    if not m.overhang.isVisible
        m.overhang.disableMoveAnimation = true
        m.overhang.isVisible = true
        m.overhang.disableMoveAnimation = false
    end if
end sub

sub OnScreenShown()
    m.overhang.isVisible = false
    if isValid(m.top.lastFocus)
        m.top.lastFocus.setFocus(true)
    else
        m.top.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.top
    end if
end sub

'
'Load initial set of Data
sub loadInitialItems()
    m.loadItemsTask.control = "STOP"
    startLoadingSpinner(false)
    m.dropdownOptionGroup.parentItemID = m.top.parentItem.Id
    if LCase(m.top.parentItem.json.Type) = "collectionfolder"
        m.top.HomeLibraryItem = m.top.parentItem.Id
    end if
    if m.dropdownOptionGroup.opacity < 1
        toggleDropdownOptions(true)
    end if
    if isValid(m.top.parentItem.json.jumpToFilter)
        m.settingID = "jumpToFilter"
    else
        m.settingID = m.top.parentItem.Id
    end if
    m.sortField = m.global.session.user.settings["display." + m.settingID + ".sortField"]
    m.sortAscending = m.global.session.user.settings["display." + m.settingID + ".sortAscending"]
    m.filter = m.global.session.user.settings["display." + m.settingID + ".filter"]
    m.filterOptions = m.global.session.user.settings["display." + m.settingID + ".filterOptions"]
    m.view = m.global.session.user.settings["display." + m.settingID + ".landing"]
    if not isValidAndNotEmpty(m.sortField) then
        m.sortField = "SortName"
    end if
    if not isValidAndNotEmpty(m.filter) then
        m.filter = "All"
    end if
    if not isValidAndNotEmpty(m.filterOptions) then
        m.filterOptions = "{}"
    end if
    if not isValidAndNotEmpty(m.view) then
        m.view = "ArtistsPresentation"
    end if
    if not isValid(m.sortAscending) then
        m.sortAscending = true
    end if
    if not isStringEqual(type(m.sortAscending), "roBoolean") then
        m.sortAscending = true
    end if
    m.dropdownOptionGroup.callfunc("setSortAscending", m.sortAscending)
    ' We're inside a genre
    if isStringEqual(m.top.parentItem.json.type, "musicgenre")
        if not isStringEqual(m.view, "albums") then
            m.view = "albums"
        end if
    end if
    m.filterOptions = ParseJson(m.filterOptions)
    m.top.showItemTitles = m.global.session.user.settings["itemgrid.gridTitles"]
    m.loadItemsTask.searchTerm = m.top.searchTerm
    m.emptyText.visible = false
    m.loadItemsTask.sortField = m.sortField
    m.loadItemsTask.sortAscending = m.sortAscending
    m.loadItemsTask.filter = m.filter
    m.loadItemsTask.filterOptions = m.filterOptions
    m.loadItemsTask.startIndex = 0
    ' Load Item Types
    if getCollectionType() = "music"
        m.loadItemsTask.itemType = "MusicArtist"
        m.loadItemsTask.itemId = m.top.parentItem.Id
    end if
    ' By default we load artist grid view
    m.loadItemsTask.view = "Artists"
    m.loadItemsTask.genreIds = ""
    m.itemGrid.numRows = "4"
    m.dropdownOptionGroup.translation = "[100, 60]"
    m.chipsRow.translation = "[100, 200]"
    if m.dropdownOptionGroup.opacity < 1
        m.itemGrid.translation = "[100, 120]"
    else
        m.itemGrid.translation = "[100, 260]"
    end if
    m.dropdownOptionsMove.keyValue = "[[100, 60], [100, 0]]"
    m.chipsRowMove.keyValue = "[[100, 200], [100, 60]]"
    m.itemGridMove.keyValue = "[[100, 260], [100, 120]]"
    m.emptyText.translation = "[0, 540]"
    ' We're inside a genre
    if isStringEqual(m.top.parentItem.json.type, "musicgenre")
        m.loadItemsTask.itemType = "MusicAlbum"
        m.loadItemsTask.recursive = true
        m.loadItemsTask.genreIds = m.top.parentItem.id
        m.loadItemsTask.itemId = m.top.parentItem.parentFolder
    end if
    if isStringEqual(m.view, "albums")
        m.loadItemsTask.itemType = "MusicAlbum"
        m.top.imageDisplayMode = "scaleToFit"
    else if isStringEqual(m.view, "albumartistsgrid")
        m.loadItemsTask.itemType = "AlbumArtists"
    else if isStringEqual(m.view, "albumartistspresentation")
        m.emptyText.translation = "[0, 750]"
        m.loadItemsTask.itemType = "AlbumArtists"
        m.itemGrid.translation = "[100, 730]"
        m.itemGrid.numRows = "2"
        m.dropdownOptionGroup.translation = "[100, 540]"
        m.chipsRow.translation = "[100, 680]"
        if m.dropdownOptionGroup.opacity < 1
            m.itemGrid.translation = "[100, 580]"
        else
            m.itemGrid.translation = "[100, 730]"
        end if
        m.dropdownOptionsMove.keyValue = "[[100, 540], [100, 480]]"
        m.chipsRowMove.keyValue = "[[100, 680], [100, 540]]"
        m.itemGridMove.keyValue = "[[100, 740], [100, 600]]"
    else if isStringEqual(m.view, "ArtistsPresentation")
        m.emptyText.translation = "[0, 750]"
        m.itemGrid.translation = "[100, 730]"
        m.itemGrid.numRows = "2"
        m.dropdownOptionGroup.translation = "[100, 540]"
        m.chipsRow.translation = "[100, 680]"
        if m.dropdownOptionGroup.opacity < 1
            m.itemGrid.translation = "[100, 580]"
        else
            m.itemGrid.translation = "[100, 730]"
        end if
        m.dropdownOptionsMove.keyValue = "[[100, 540], [100, 480]]"
        m.chipsRowMove.keyValue = "[[100, 680], [100, 540]]"
        m.itemGridMove.keyValue = "[[100, 740], [100, 600]]"
    else if isStringEqual(m.view, "genres")
        m.loadItemsTask.itemType = ""
        m.loadItemsTask.recursive = true
        m.loadItemsTask.view = "Genres"
        clearMusicArtistPresentation()
    end if
    setColumnSizes()
    m.loadItemsTask.control = "RUN"
    m.getFiltersTask.observeField("filters", "FilterDataLoaded")
    m.getFiltersTask.params = {
        userid: m.global.session.user.id
        parentid: m.top.parentItem.Id
    }
    m.getFiltersTask.control = "RUN"
end sub

sub setColumnSizes()
    numberOfColumns = chainLookupReturn(m.global.session, "user.settings.numberOfColumnsSquare", "6")
    imageWidthData = val(chainLookupReturn(m.global.session, "user.settings.numberOfColumnsSquareData", "270"))
    defaultSize = [
        imageWidthData
        imageWidthData
    ]
    m.itemGrid.itemSize = defaultSize
    m.itemGrid.rowHeights = [
        defaultSize[1]
    ]
    m.itemGrid.numRows = abs(1230 / (defaultSize[1] + m.itemGrid.itemSpacing[1]))
    m.itemGrid.numColumns = numberOfColumns
    m.genreList.itemSize = defaultSize
    m.genreList.rowHeights = [
        defaultSize[1]
    ]
    m.genreList.numRows = abs(1230 / (defaultSize[1] + m.itemGrid.itemSpacing[1]))
    m.genreList.numColumns = numberOfColumns
    m.loadItemsTask.numberOfColumns = numberOfColumns
end sub

'
'Check if options updated and any reloading required
sub onOptionsVisibleChange()
    if m.options.visible then
        return
    end if
    reload = false
    ' Nothing changed
    if isStringEqual(m.options.filter, m.filter)
        if AssocArrayEqual(m.options.filterOptions, m.filterOptions)
            m.dropdownOptionGroup.callfunc("setFocus", "filterButton", true)
            return
        end if
    end if
    m.global.sceneManager.observeFieldScoped("returnData", "onReturnData")
    if m.options.filter <> m.filter
        m.filter = m.options.filter
        reload = true
        set_user_setting("display." + m.settingID + ".filter", m.options.filter)
    end if
    if not isValid(m.options.filterOptions)
        m.filterOptions = {}
    end if
    if not AssocArrayEqual(m.options.filterOptions, m.filterOptions)
        m.filterOptions = m.options.filterOptions
        reload = true
        set_user_setting("display." + m.settingID + ".filterOptions", FormatJson(m.options.filterOptions))
    end if
    if reload
        m.loadedRows = 0
        m.loadedItems = 0
        m.data = CreateObject("roSGNode", "ContentNode")
        m.itemGrid.content = m.data
        loadInitialItems()
    end if
    m.dropdownOptionGroup.callfunc("setFocus", "filterButton", false)
    m.itemGrid.setFocus(m.itemGrid.opacity = 1)
    m.genreList.setFocus(m.genreList.opacity = 1)
    group = m.global.sceneManager.callFunc("getActiveScene")
    if m.itemGrid.opacity = 1 then
        group.lastFocus = m.itemGrid
    else
        group.lastFocus = m.genreList
    end if
end sub

'
' Filter Data Loaded Event Handler
sub FilterDataLoaded(msg)
    options = setMusicOptions()
    data = msg.GetData()
    m.getFiltersTask.unobserveField("filters")
    if not isValid(data) then
        return
    end if
    ' Add Music filters from the API data
    if inArray([
        "musicartist"
        "albumartists"
    ], LCase(m.loadItemsTask.itemType))
        if isValid(data.genres)
            options.filter.push({
                "Title": tr("Genres")
                "Name": "Genres"
                "Options": data.genres
                "Delimiter": "|"
                "CheckedState": []
            })
        end if
    end if
    if LCase(m.loadItemsTask.itemType) = "musicalbum"
        if isValid(data.genres)
            options.filter.push({
                "Title": tr("Genres")
                "Name": "Genres"
                "Options": data.genres
                "Delimiter": "|"
                "CheckedState": []
            })
        end if
        if isValid(data.Years)
            options.filter.push({
                "Title": tr("Years")
                "Name": "Years"
                "Options": data.Years
                "Delimiter": ","
                "CheckedState": []
            })
        end if
    end if
    setSelectedOptions(options)
    m.options.options = options
end sub

' Data to display when options button selected
sub setSelectedOptions(options)
    ' Set selected view option
    for each o in options.views
        if isStringEqual(o.Name, m.view)
            m.dropdownOptionGroup.callfunc("setText", "viewButton", tr(o.LookupCI("title")))
            o.Selected = true
        end if
    end for
    ' Set selected sort option
    for each o in options.sort
        if isStringEqual(o.Name, m.sortField)
            m.dropdownOptionGroup.callfunc("setText", "sortButton", tr(o.LookupCI("title")))
            o.Selected = true
        end if
    end for
    ' Set selected filter
    for each o in options.filter
        if isStringEqual(o.Name, m.filter)
            o.Selected = true
            m.dropdownOptionGroup.callfunc("setText", "filterButton", tr(o.LookupCI("title")))
            m.options.filter = o.Name
            displayChip = false
            if not isAllValid([
                o.options
                m.filterOptions
            ])
                displayChip = true
            else if o.options.Count() = 0 or m.filterOptions.Count() = 0
                displayChip = true
            end if
            if isStringEqual(tr(o.LookupCI("title")), tr("All"))
                displayChip = false
            end if
            if displayChip
                m.chipsRow.callfunc("addChip", "filter", "", tr(o.LookupCI("title")))
            else
                m.chipsRow.callfunc("removeChip", "filter")
            end if
        end if
        ' Select selected filter options
        if isValid(o.options) and isValid(m.filterOptions)
            if o.options.Count() > 0 and m.filterOptions.Count() > 0
                if LCase(o.Name) = LCase(m.filterOptions.keys()[0])
                    selectedFilterOptions = m.filterOptions[m.filterOptions.keys()[0]].split(o.delimiter)
                    m.chipsRow.callfunc("addChip", "filter", tr(o.LookupCI("title")), selectedFilterOptions.join(", "))
                    checkedState = []
                    for each availableFilterOption in o.options
                        matchFound = false
                        for each selectedFilterOption in selectedFilterOptions
                            if LCase(toString(availableFilterOption).trim()) = LCase(selectedFilterOption.trim())
                                matchFound = true
                            end if
                        end for
                        checkedState.push(matchFound)
                    end for
                    o.checkedState = checkedState
                end if
            end if
        end if
    end for
    m.options.options = options
    m.dropdownOptionGroup.callfunc("setOptionData", options)
    m.dropdownOptionGroup.callfunc("setText", "sortOrderButton", (function(__bsCondition, tr)
            if __bsCondition then
                return tr("Ascending")
            else
                return tr("Descending")
            end if
        end function)(m.sortAscending, tr))
end sub

' Set Music view, sort, and filter options
function setMusicOptions() as object
    options = {
        filter: []
    }
    options.views = [
        {
            "Title": tr("Artists (Presentation)")
            "Name": "ArtistsPresentation"
            "Track": {
                "description": tr("Artists (Presentation)")
            }
        }
        {
            "Title": tr("Artists (Grid)")
            "Name": "ArtistsGrid"
            "Track": {
                "description": tr("Artists (Grid)")
            }
        }
        {
            "Title": tr("Album Artists (Presentation)")
            "Name": "AlbumArtistsPresentation"
            "Track": {
                "description": tr("Album Artists (Presentation)")
            }
        }
        {
            "Title": tr("Album Artists (Grid)")
            "Name": "AlbumArtistsGrid"
            "Track": {
                "description": tr("Album Artists (Grid)")
            }
        }
        {
            "Title": tr("Albums")
            "Name": "Albums"
            "Track": {
                "description": tr("Albums")
            }
        }
        {
            "Title": tr("Genres")
            "Name": "Genres"
            "Track": {
                "description": tr("Genres")
            }
        }
    ]
    options.sort = [
        {
            "Title": tr("TITLE")
            "Name": "SortName"
            "Track": {
                "description": tr("TITLE")
            }
        }
        {
            "Title": tr("DATE_ADDED")
            "Name": "DateCreated,SortName"
            "Track": {
                "description": tr("DATE_ADDED")
            }
        }
        {
            "Title": tr("DATE_PLAYED")
            "Name": "DatePlayed,SortName"
            "Track": {
                "description": tr("DATE_PLAYED")
            }
        }
        {
            "Title": tr("RELEASE_DATE")
            "Name": "PremiereDate,SortName"
            "Track": {
                "description": tr("RELEASE_DATE")
            }
        }
        {
            "Title": tr("Random")
            "Name": "Random"
            "Track": {
                "description": tr("Random")
            }
        }
    ]
    options.filter = [
        {
            "Title": tr("All")
            "Name": "All"
            "Track": {
                "description": tr("All")
            }
        }
        {
            "Title": tr("Favorites")
            "Name": "Favorites"
            "Track": {
                "description": tr("Favorites")
            }
        }
    ]
    if inArray([
        "musicartist"
        "albumartists"
    ], LCase(m.loadItemsTask.itemType))
        options.sort = [
            {
                "Title": tr("TITLE")
                "Name": "SortName"
                "Track": {
                    "description": tr("TITLE")
                }
            }
            {
                "Title": tr("DATE_ADDED")
                "Name": "DateCreated,SortName"
                "Track": {
                    "description": tr("DATE_ADDED")
                }
            }
            {
                "Title": tr("Random")
                "Name": "Random"
                "Track": {
                    "description": tr("Random")
                }
            }
        ]
    end if
    if isStringEqual(m.top.parentItem.json.type, "musicgenre")
        options.views = [
            {
                "Title": tr("Albums")
                "Name": "Albums"
                "Track": {
                    "description": tr("Albums")
                }
            }
        ]
    end if
    if isStringEqual(m.view, "genres")
        options.sort = [
            {
                "Title": tr("TITLE")
                "Name": "SortName"
                "Track": {
                    "description": tr("TITLE")
                }
            }
            {
                "Title": tr("Random")
                "Name": "Random"
                "Track": {
                    "description": tr("Random")
                }
            }
        ]
        options.filter = [
            {
                "Title": tr("All")
                "Name": "All"
                "Track": {
                    "description": tr("All")
                }
            }
        ]
    end if
    if isStringEqual(m.view, "albums")
        options.sort = [
            {
                "Title": tr("TITLE")
                "Name": "SortName"
                "Track": {
                    "description": tr("TITLE")
                }
            }
            {
                "Title": tr("Album Artist")
                "Name": "AlbumArtist,SortName"
                "Track": {
                    "description": tr("Album Artist")
                }
            }
            {
                "Title": tr("DATE_ADDED")
                "Name": "DateCreated,SortName"
                "Track": {
                    "description": tr("DATE_ADDED")
                }
            }
            {
                "Title": tr("RELEASE_DATE")
                "Name": "ProductionYear,SortName"
                "Track": {
                    "description": tr("RELEASE_DATE")
                }
            }
            {
                "Title": tr("Random")
                "Name": "Random"
                "Track": {
                    "description": tr("Random")
                }
            }
        ]
    end if
    return options
end function

' Return parent collection type
function getCollectionType() as string
    if m.top.parentItem.collectionType = invalid
        return LCase(m.top.parentItem.Type)
    else
        return LCase(m.top.parentItem.CollectionType)
    end if
end function

'
'Handle loaded data, and add to Grid
sub ItemDataLoaded(msg)
    itemData = msg.GetData()
    m.chipsRow.callfunc("setTotalCount", (bslib_toString(m.loadItemsTask.totalRecordCount) + " items"))
    if not isValidAndNotEmpty(itemData)
        stopLoadingSpinner()
        return
    end if
    if LCase(m.loadItemsTask.view) = "genres"
        for each item in itemData
            m.genreData.appendChild(item)
        end for
        m.itemGrid.opacity = "0"
        m.genreList.opacity = "1"
        m.itemGrid.setFocus(false)
        m.genreList.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.genreList
        m.loadedItems = m.genreList.content.getChildCount()
        m.loadedRows = m.loadedItems / m.genreList.numColumns
        if m.loadedItems = 0
            m.emptyText.text = tr("NO_ITEMS").Replace("%1", m.top.parentItem.Type)
            m.emptyText.visible = true
            m.global.sceneManager.observeFieldScoped("returnData", "onReturnData")
            m.dropdownOptionGroup.callfunc("setFocus", "voiceBox", true)
            m.dropdownOptionGroup.callfunc("setSearchBackground", 0)
        end if
        stopLoadingSpinner()
        return
    end if
    ' keep focus on alpha menu if it's active
    if m.top.alphaActive
        m.alphaMenu.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.alphaMenu
    else
        m.itemGrid.opacity = "1"
        m.genreList.opacity = "0"
        m.alphaMenu.setFocus(false)
        m.itemGrid.setFocus(true)
        m.genreList.setFocus(false)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.itemGrid
    end if
    m.data.appendChildren(itemData)
    'Update the stored counts
    m.loadedItems = m.itemGrid.content.getChildCount()
    m.loadedRows = m.loadedItems / m.itemGrid.numColumns
    'If there are no items to display, show message
    if m.loadedItems = 0
        m.artistLogo.visible = false
        m.selectedArtistName.visible = false
        m.selectedArtistGenres.visible = false
        m.selectedArtistCreditedFor.visible = false
        m.selectedArtistSongCount.visible = false
        m.selectedArtistAlbumCount.visible = false
        m.emptyText.text = tr("NO_ITEMS").Replace("%1", m.top.parentItem.Type)
        m.emptyText.visible = true
        m.global.sceneManager.observeFieldScoped("returnData", "onReturnData")
        m.dropdownOptionGroup.callfunc("setFocus", "voiceBox", true)
        m.dropdownOptionGroup.callfunc("setSearchBackground", 0)
    end if
    stopLoadingSpinner()
end sub

'
'Set Selected Artist Name
sub SetName(artistName as string)
    m.selectedArtistName.text = artistName
end sub

'
'Set Selected Artist Song Count
sub SetSongCount(totalCount)
    if not isValid(totalCount)
        m.selectedArtistSongCount.visible = false
        m.selectedArtistSongCount.text = ""
        return
    end if
    m.selectedArtistSongCount.text = getFormattedMusicCountText(totalCount, "Song", "Songs")
    m.selectedArtistSongCount.visible = true
end sub

'
'Set Selected Artist Album Count
sub SetAlbumCount(totalCount)
    if not isValid(totalCount)
        m.selectedArtistAlbumCount.visible = false
        m.selectedArtistAlbumCount.text = ""
        return
    end if
    m.selectedArtistAlbumCount.text = getFormattedMusicCountText(totalCount, "Album", "Albums")
    m.selectedArtistAlbumCount.visible = true
end sub

sub SetCreditedArtistCounts(songCount, albumCount)
    setSelectedArtistStatsLayout(true)
    m.selectedArtistCreditedFor.text = tr("Credited for:")
    m.selectedArtistCreditedFor.visible = true
    m.selectedArtistSongCount.text = getFormattedMusicCountText(songCount, "Song", "Songs")
    m.selectedArtistSongCount.visible = true
    m.selectedArtistAlbumCount.text = getFormattedMusicCountText(albumCount, "Album", "Albums")
    m.selectedArtistAlbumCount.visible = true
end sub

sub setSelectedArtistStatsLayout(useCreditedLayout as boolean)
    m.selectedArtistCreditedFor.visible = false
    m.selectedArtistCreditedFor.text = ""
    if useCreditedLayout
        m.selectedArtistSongCount.translation = "[140, 300]"
        m.selectedArtistAlbumCount.translation = "[140, 340]"
        m.selectedArtistGenres.translation = "[120, 380]"
        return
    end if
    m.selectedArtistSongCount.translation = "[120, 270]"
    m.selectedArtistAlbumCount.translation = "[120, 310]"
    m.selectedArtistGenres.translation = "[120, 350]"
end sub

sub clearSelectedArtistDetails()
    m.loadArtistStatsTask.control = "STOP"
    m.loadArtistStatsTask.content = {}
    m.selectedArtistStatsId = ""
    m.selectedArtistStatsFilter = ""
    m.artistLogo.visible = false
    m.artistLogo.uri = ""
    m.selectedArtistName.visible = false
    m.selectedArtistName.text = ""
    m.selectedArtistGenres.visible = false
    m.selectedArtistGenres.text = ""
end sub

function showFocusedMusicDetailsFromGrid(focusedItem) as boolean
    if not isMusicArtistPresentationView() then
        return false
    end if
    if not m.itemGrid.isinFocusChain() then
        return false
    end if
    if not isChainValid(focusedItem, "json") then
        return false
    end if
    itemData = focusedItem.json
    clearSelectedArtistDetails()
    if isValid(itemData.Genres)
        SetGenres(itemData.Genres)
        m.selectedArtistGenres.visible = true
    else
        SetGenres([])
    end if
    if isValid(itemData.Name)
        SetName(itemData.Name)
        m.selectedArtistName.visible = false
    else
        SetName("")
    end if
    if isValid(itemData.Id)
        loadSelectedArtistStats(itemData.Id)
        ShowLogoOrName(itemData, m.artistLogo, m.selectedArtistName)
    else if isValidAndNotEmpty(m.selectedArtistName.text)
        m.selectedArtistName.visible = true
    end if
    if isStringEqual(m.view, "ArtistsPresentation") or isStringEqual(m.view, "AlbumArtistsPresentation")
        m.backdropImage.callfunc("changeImage", (function(focusedItem)
                __bsConsequent = focusedItem.backdropUrl
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(focusedItem))
    end if
    return true
end function

function isMusicArtistPresentationView() as boolean
    return isStringEqual(m.view, "ArtistsPresentation") or isStringEqual(m.view, "AlbumArtistsPresentation")
end function

function getSelectedArtistStatsFilter() as string
    if isStringEqual(m.view, "AlbumArtistsPresentation") then
        return "AlbumArtistIds"
    end if
    return "ArtistIds"
end function

function getArtistStatsCacheKey(artistId as string, artistStatsFilter as string) as string
    return artistStatsFilter + ":" + artistId
end function

sub clearSelectedArtistCounts()
    setSelectedArtistStatsLayout(false)
    m.selectedArtistSongCount.visible = false
    m.selectedArtistSongCount.text = ""
    m.selectedArtistAlbumCount.visible = false
    m.selectedArtistAlbumCount.text = ""
end sub

sub loadSelectedArtistStats(artistId as string)
    artistStatsFilter = getSelectedArtistStatsFilter()
    m.selectedArtistStatsId = artistId
    m.selectedArtistStatsFilter = artistStatsFilter
    clearSelectedArtistCounts()
    cacheKey = getArtistStatsCacheKey(artistId, artistStatsFilter)
    if m.artistStatsCache.DoesExist(cacheKey)
        applySelectedArtistStats(m.artistStatsCache[cacheKey])
        return
    end if
    m.loadArtistStatsTask.control = "STOP"
    m.loadArtistStatsTask.content = {}
    m.loadArtistStatsTask.artistId = artistId
    m.loadArtistStatsTask.artistStatsFilter = artistStatsFilter
    m.loadArtistStatsTask.control = "RUN"
end sub

sub ArtistStatsLoaded(msg)
    stats = msg.GetData()
    if not isValid(stats) then
        return
    end if
    if not isValidAndNotEmpty(stats.id) then
        return
    end if
    if not isValidAndNotEmpty(stats.artistStatsFilter) then
        return
    end if
    m.loadArtistStatsTask.control = "STOP"
    m.artistStatsCache.AddReplace(getArtistStatsCacheKey(stats.id, stats.artistStatsFilter), stats)
    if not isStringEqual(stats.id, m.selectedArtistStatsId) then
        return
    end if
    if not isStringEqual(stats.artistStatsFilter, m.selectedArtistStatsFilter) then
        return
    end if
    ' Alpha focus keeps the last artist presentation visible while its stats finish loading.
    if not m.itemGrid.isinFocusChain() and not m.alphaMenu.isinFocusChain() then
        return
    end if
    if not isMusicArtistPresentationView() then
        return
    end if
    applySelectedArtistStats(stats)
end sub

function getFormattedMusicCountText(totalCount, singularLabel as string, pluralLabel as string) as string
    if not isValid(totalCount) then
        return ""
    end if
    label = pluralLabel
    if totalCount = 1 then
        label = singularLabel
    end if
    return totalCount.ToStr().trim() + " " + tr(label)
end function

sub applySelectedArtistStats(stats)
    if isStringEqual(stats.artistStatsFilter, "ArtistIds") and isValid(stats.songCount) and isValid(stats.albumCount)
        SetCreditedArtistCounts(stats.songCount, stats.albumCount)
        return
    end if
    setSelectedArtistStatsLayout(false)
    if isValid(stats.songCount)
        SetSongCount(stats.songCount)
    else
        SetSongCount(invalid)
    end if
    if isValid(stats.albumCount)
        SetAlbumCount(stats.albumCount)
    else
        SetAlbumCount(invalid)
    end if
end sub

'
'Set Selected Artist Genres
sub SetGenres(artistGenres)
    m.selectedArtistGenres.text = artistGenres.join(", ")
end sub

sub clearMusicArtistPresentation()
    m.artistLogo.visible = false
    m.artistLogo.uri = ""
    m.selectedArtistName.visible = false
    m.selectedArtistName.text = ""
    m.selectedArtistGenres.visible = false
    m.selectedArtistGenres.text = ""
    m.selectedArtistSongCount.visible = false
    m.selectedArtistSongCount.text = ""
    m.selectedArtistAlbumCount.visible = false
    m.selectedArtistAlbumCount.text = ""
    m.backdropImage.callfunc("clearImage", invalid)
end sub

'
'Handle new item being focused
sub onItemFocused()
    focusedRow = m.itemGrid.currFocusRow
    if m.itemGrid.isinFocusChain() or m.dropdownOptionGroup.isinFocusChain()
        if focusedRow = 0
            if m.dropdownOptionGroup.opacity < 1
                toggleDropdownOptions(true)
            end if
        else if focusedRow > 0
            if m.dropdownOptionGroup.opacity > 0
                toggleDropdownOptions(false)
            end if
        end if
    end if
    itemInt = m.itemGrid.itemFocused
    ' If no selected item, set background to parent backdrop
    if itemInt = -1
        return
    end if
    m.artistLogo.visible = false
    m.selectedArtistName.visible = false
    m.selectedArtistGenres.visible = false
    m.selectedArtistCreditedFor.visible = false
    m.selectedArtistSongCount.visible = false
    m.selectedArtistAlbumCount.visible = false
    ' Load more data if focus is within last 5 rows, and there are more items to load
    if focusedRow >= m.loadedRows - 5 and m.loadeditems < m.loadItemsTask.totalRecordCount
        loadMoreData()
    end if
    focusedItem = getItemFocused()
    m.selectedFavoriteItem = focusedItem
    if isStringEqual(m.view, "albums") or isStringEqual(m.top.parentItem.json.type, "musicgenre")
        return
    end if
    if isStringEqual(m.view, "artistsgrid")
        return
    end if
    if isStringEqual(m.view, "albumartistsgrid")
        return
    end if
    showFocusedMusicDetailsFromGrid(focusedItem)
end sub

sub setFieldText(field, value)
    node = m.top.findNode(field)
    if node = invalid or value = invalid then
        return
    end if
    ' Handle non strings... Which _shouldn't_ happen, but hey
    if type(value) = "roInt" or type(value) = "Integer"
        value = str(value)
    else if type(value) = "roFloat" or type(value) = "Float"
        value = str(value)
    else if type(value) <> "roString" and type(value) <> "String"
        value = ""
    end if
    node.text = value
end sub

'
'Load next set of items
sub loadMoreData()
    if isStringEqual(m.loadItemsTask.state, "RUN") then
        return
    end if
    startLoadingSpinner(false)
    m.loadItemsTask.startIndex = m.loadedItems
    m.loadItemsTask.control = "RUN"
end sub

'
'Item Selected
sub onItemSelected()
    m.top.selectedItem = m.itemGrid.content.getChild(m.itemGrid.itemSelected)
end sub

'
'Returns Focused Item
function getItemFocused()
    if m.itemGrid.isinFocusChain() and isValid(m.itemGrid.itemFocused)
        return m.itemGrid.content.getChild(m.itemGrid.itemFocused)
    else if m.genreList.isinFocusChain() and isValid(m.genreList.itemFocused)
        return m.genreList.content.getChild(m.genreList.itemFocused)
    end if
    return invalid
end function

'
'Genre Item Selected
sub onGenreItemSelected()
    m.top.selectedItem = m.genreList.content.getChild(m.genreList.itemSelected)
end sub

'
'Genre Item Focused
sub onGenreItemFocused()
    focusedRow = m.genreList.currFocusRow
    if m.genreList.isinFocusChain()
        if focusedRow = 0
            if m.dropdownOptionGroup.opacity < 1
                toggleDropdownOptions(true)
            end if
        else if focusedRow > 0
            if m.dropdownOptionGroup.opacity > 0
                toggleDropdownOptions(false)
            end if
        end if
    end if
    ' Load more data if focus is within last 5 rows, and there are more items to load
    if focusedRow >= m.loadedRows - 5 and m.loadeditems < m.loadItemsTask.totalRecordCount
        loadMoreData()
    end if
end sub

sub toggleDropdownOptions(runInReverse = false as boolean)
    m.dropdownOptionsFade.reverse = runInReverse
    m.dropdownOptionsMove.reverse = runInReverse
    m.itemGridMove.reverse = runInReverse
    m.chipsRowMove.reverse = runInReverse
    m.genreListMove.reverse = runInReverse
    if not isStringEqual(m.toggleDropdownOptionsAnimation.state, "running")
        m.toggleDropdownOptionsAnimation.control = "start"
    end if
end sub

sub processDropdownState(searchTerm as string)
    if not isStringEqual(searchTerm, "")
        resetDropdownsToDefaultState()
        setDropdownDisabledState(true)
        return
    end if
    setDropdownDisabledState(false)
end sub

sub setDropdownDisabledState(disabledState = false as boolean)
    m.dropdownOptionGroup.callfunc("setDisabled", "sortButton", disabledState)
    m.dropdownOptionGroup.callfunc("setDisabled", "sortOrderButton", disabledState)
    m.dropdownOptionGroup.callfunc("setDisabled", "filterButton", disabledState)
end sub

sub resetDropdownsToDefaultState()
    m.filter = "All"
    m.filterOptions = {}
    if isStringEqual(getCollectionType(), "boxset")
        m.sortField = "PremiereDate,SortName"
    else if isStringEqual(getCollectionType(), "mylist")
        m.sortField = "OrderAdded"
    else
        m.sortField = "SortName"
    end if
    m.sortAscending = true
    ' Reset view to defaults
    set_user_setting("display." + m.settingID + ".sortField", m.sortField)
    set_user_setting("display." + m.settingID + ".sortAscending", "true")
    set_user_setting("display." + m.settingID + ".filter", m.filter)
    set_user_setting("display." + m.settingID + ".filterOptions", FormatJson(m.filterOptions))
    if not isStringEqual(m.view, "Genres")
        set_user_setting(("display." + bslib_toString(m.top.mediaType) + "library.defaultview"), m.view)
    end if
    m.getFiltersTask.control = "RUN"
end sub

sub onDropdownOptionGroupSearchTermChanged()
    m.top.searchTerm = m.dropdownOptionGroup.searchTerm
end sub

sub onSearchTermChanged()
    searchTerm = m.top.searchTerm.trim()
    if not isValid(searchTerm) then
        return
    end if
    ' If user searched for a letter, selected it from the alpha menu
    if searchTerm.len() = 1
        alphaMenu = m.top.findNode("alphaMenu")
        intConversion = searchTerm.ToInt() ' non numeric input returns as 0
        if searchTerm = "0" or (isValid(intConversion) and intConversion <> 0)
            alphaMenu.jumpToItem = 0
        else
            ' loop through each option until we find a match
            for i = 1 to alphaMenu.numRows - 1
                alphaMenuOption = alphaMenu.content.getChild(i)
                if isStringEqual(alphaMenuOption.TITLE, searchTerm)
                    alphaMenu.jumpToItem = i
                    exit for
                end if
            end for
        end if
        m.dropdownOptionGroup.callfunc("setSearchHintText", "")
        m.top.alphaSelected = searchTerm
        m.dropdownOptionGroup.callfunc("setSearchBackground", 1)
        return
    end if
    if isStringEqual(m.loadItemsTask.searchTerm, m.top.searchTerm) then
        return
    end if
    m.dropdownOptionGroup.callfunc("setSearchBackground", 1)
    processDropdownState(m.top.searchTerm)
    m.dropdownOptionGroup.callfunc("setSearchHintText", m.top.searchTerm)
    if isValidAndNotEmpty(m.top.searchTerm)
        m.chipsRow.callfunc("removeChip", "filter")
        m.chipsRow.callfunc("addChip", "search", tr("Search Term"), m.top.searchTerm)
    else
        m.chipsRow.callfunc("removeChip", "search")
    end if
    if m.bypassSearchEvent
        m.bypassSearchEvent = false
        return
    end if
    m.loadedRows = 0
    m.loadedItems = 0
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    m.genreData = CreateObject("roSGNode", "ContentNode")
    m.genreList.content = m.genreData
    loadInitialItems()
end sub

sub alphaSelectedChanged()
    ' Prevent voicebox change double firing
    if isStringEqual(m.top.searchTerm, "")
        ' Allow user to toggle by clicking letter twice
        if isStringEqual(m.loadItemsTask.nameStartsWith, m.top.alphaSelected)
            m.top.alphaSelected = ""
        end if
    end if
    clearSelectedArtistDetails()
    clearSelectedArtistCounts()
    m.loadItemsTask.control = "STOP"
    m.loadedRows = 0
    m.loadedItems = 0
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    m.genreData = CreateObject("roSGNode", "ContentNode")
    m.genreList.content = m.genreData
    if isValidAndNotEmpty(m.top.alphaSelected)
        m.chipsRow.callfunc("addChip", "startswith", tr("Starts With"), m.top.alphaSelected)
    else
        m.chipsRow.callfunc("removeChip", "startswith")
    end if
    m.loadItemsTask.nameStartsWith = m.top.alphaSelected
    m.dropdownOptionGroup.callfunc("setText", "voiceBox", "")
    m.top.searchTerm = ""
    loadInitialItems()
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if isStringEqual(key, "up")
        if m.itemGrid.isinFocusChain() or m.genreList.isinFocusChain()
            ' In case user quickly moves out of grid without focused row getting updated
            if m.dropdownOptionGroup.opacity < 1
                toggleDropdownOptions(true)
            end if
            if m.genreList.isinFocusChain() then
                activeGrid = m.genreList
            else
                activeGrid = m.itemGrid
            end if
            overhangButton = m.dropdownOptionGroup.callfunc("getOverhangingButton", activeGrid.numColumns, activeGrid.currFocusColumn)
            m.global.sceneManager.observeFieldScoped("returnData", "onReturnData")
            if overhangButton.isSubType("VoiceTextEditBox")
                m.dropdownOptionGroup.callfunc("setSearchBackground", 0)
            else
                m.dropdownOptionGroup.callfunc("setFocus", overhangButton.id, true)
            end if
            overhangButton.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = overhangButton
            return true
        end if
    end if
    if isStringEqual(key, "options")
        focusedItem = getItemFocused()
        if not isValid(focusedItem) then
            return false
        end if
        popupTitle = focusedItem.LookupCI("title")
        if isValid(popupTitle)
            if isChainValid(focusedItem, "json.AlbumArtist")
                popupTitle = (bslib_toString(chainLookup(focusedItem, "json.AlbumArtist")) + " - " + bslib_toString(popupTitle))
            end if
        end if
        if isStringEqual(focusedItem.LookupCI("type"), "musicalbum")
            dialogData = [
                tr("Play Album")
                tr("Shuffle Play Album")
                tr("Instant Mix Album")
                tr("Add To Playlist")
            ]
            m.global.sceneManager.callFunc("optionDialog", "libraryitem", (function(popupTitle, tr)
                    __bsConsequent = popupTitle
                    if __bsConsequent <> invalid then
                        return __bsConsequent
                    else
                        return tr("Options")
                    end if
                end function)(popupTitle, tr), [], dialogData, {
                id: focusedItem.LookupCI("id")
            })
        end if
        return true
    end if
    if isStringEqual(key, "back")
        ' If user pressed back whole scrolled down the grid, reset to item 1
        if m.itemGrid.isinFocusChain() or m.genreList.isinFocusChain()
            if m.itemGrid.isinFocusChain() then
                gridComponent = m.itemGrid
            else
                gridComponent = m.genreList
            end if
            if gridComponent.itemFocused = 0
                reclaimResources()
                m.global.sceneManager.callfunc("popScene")
                return true
            end if
            gridComponent.jumpToItem = 0
            return true
        end if
        reclaimResources()
        m.global.sceneManager.callfunc("popScene")
        return true
    end if
    if key = "left"
        if m.itemGrid.isinFocusChain()
            m.top.alphaActive = true
            m.itemGrid.setFocus(false)
            m.alphaMenu.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.alphaMenu
            return true
        else if m.genreList.isinFocusChain()
            m.top.alphaActive = true
            m.genreList.setFocus(false)
            m.alphaMenu.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.alphaMenu
            return true
        end if
    else if key = "right" and m.alpha.isinFocusChain()
        m.top.alphaActive = false
        m.alphaMenu.setFocus(false)
        if m.loadedItems = 0
            m.global.sceneManager.observeFieldScoped("returnData", "onReturnData")
            m.dropdownOptionGroup.callfunc("setFocus", "voiceBox", true)
            m.dropdownOptionGroup.callfunc("setSearchBackground", 0)
        else
            m.itemGrid.setFocus(m.itemGrid.opacity = 1)
            m.genreList.setFocus(m.genreList.opacity = 1)
            group = m.global.sceneManager.callFunc("getActiveScene")
            if m.itemGrid.opacity = 1 then
                group.lastFocus = m.itemGrid
            else
                group.lastFocus = m.genreList
            end if
        end if
        return true
    else if key = "play"
        if toggleAudioMiniPlayerPlayback() then
            return true
        end if
        itemToPlay = getItemFocused()
        if itemToPlay <> invalid
            m.top.quickPlayNode = itemToPlay
            return true
        end if
    end if
    return false
end function

sub reclaimResources()
    m.loadItemsTask.control = "STOP"
    m.loadItemsTask.content = []
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    m.genreData = CreateObject("roSGNode", "ContentNode")
    m.genreList.content = m.genreData
    m.global.sceneManager.unobserveFieldScoped("returnData")
end sub
'//# sourceMappingURL=./MusicLibraryView.brs.map