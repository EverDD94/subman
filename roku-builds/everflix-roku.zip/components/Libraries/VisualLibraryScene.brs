'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/Image.bs"
'import "pkg:/source/enums/AnimationControl.bs"
'import "pkg:/source/enums/AnimationState.bs"
'import "pkg:/source/enums/CollectionType.bs"
'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/DropdownMenuID.bs"
'import "pkg:/source/enums/ExitDirection.bs"
'import "pkg:/source/enums/ImageLayout.bs"
'import "pkg:/source/enums/ItemType.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/SearchButtonState.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/enums/TaskControl.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/deviceCapabilities.bs"
'import "pkg:/source/utils/misc.bs"





sub setupNodes()
    m.top.imageDisplayMode = "scaleToZoom"
    m.top.showItemTitles = "showonhover"
    m.librarySettings = m.top.findNode("librarySettings")
    m.librarySettings.observeFieldScoped("selected", "onLibrarySettingsSelected")
    m.librarySettings.highlightBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    m.toggleDropdownOptionsAnimation = m.top.findNode("toggleDropdownOptionsAnimation")
    m.dropdownOptionsMove = m.top.findNode("dropdownOptionsMove")
    m.chipsRowMove = m.top.findNode("chipsRowMove")
    m.itemGridMove = m.top.findNode("itemGridMove")
    m.genreListMove = m.top.findNode("genreListMove")
    m.dropdownOptionsFade = m.top.findNode("dropdownOptionsFade")
    m.options = m.top.findNode("options")
    m.itemGrid = m.top.findNode("itemGrid")
    m.backdropImage = m.top.findNode("backdropImage")
    m.emptyText = m.top.findNode("emptyText")
    m.selectedItemName = m.top.findNode("selectedItemName")
    m.selectedItemOverview = m.top.findNode("selectedItemOverview")
    m.selectedItemProductionYear = m.top.findNode("selectedItemProductionYear")
    m.selectedItemOfficialRating = m.top.findNode("selectedItemOfficialRating")
    m.itemLogo = m.top.findNode("itemLogo")
    m.alpha = m.top.findNode("alpha")
    m.alphaMenu = m.alpha.findNode("alphaMenu")
    m.communityRatingGroup = m.top.findNode("communityRatingGroup")
    m.criticRatingIcon = m.top.findNode("criticRatingIcon")
    m.criticRatingGroup = m.top.findNode("criticRatingGroup")
    m.overhang = m.top.getScene().findNode("overhang")
    m.genreList = m.top.findNode("genrelist")
    m.infoGroup = m.top.findNode("infoGroup")
    m.star = m.top.findNode("star")
    m.chipsRow = m.top.findNode("chipsRow")
    m.dropdownOptionGroup = m.top.findNode("dropdownOptionGroup")
    m.dropdownOptionGroup.observeFieldScoped("showOptions", "onShowOptionsChange")
    m.dropdownOptionGroup.observeFieldScoped("exit", "onExit")
    m.dropdownOptionGroup.observeFieldScoped("searchTerm", "onDropdownOptionGroupSearchTermChanged")
end sub

sub onShowOptionsChange()
    m.options.visible = true
    m.options.findNode("filterMenu").setFocus(true)
    group = m.global.sceneManager.callFunc("getActiveScene")
    group.lastFocus = m.options
end sub

sub onExit()
    m.global.sceneManager.unobserveFieldScoped("returnData")
    dropdownExitDirection = m.dropdownOptionGroup.exit
    if dropdownExitDirection = 1
        alphaDisplayed = m.alpha.callFunc("getDisplay")
        if alphaDisplayed
            m.top.alphaActive = true
            m.alphaMenu.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.alphaMenu
        else
            m.librarySettings.setFocus(true)
            m.librarySettings.highlighted = true
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.librarySettings
        end if
        return
    end if
    if dropdownExitDirection = 0
        if m.loadedItems = 0 then
            return
        end if
        m.itemGrid.setFocus(m.itemGrid.opacity = 1)
        m.genreList.setFocus(m.genreList.opacity = 1)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.itemGrid
    end if
end sub

sub onReturnData()
    m.global.sceneManager.unobserveFieldScoped("returnData")
    selectedOptionData = m.global.sceneManager.returnData
    if not isValidAndNotEmpty(selectedOptionData) then
        return
    end if
    optionType = chainLookup(selectedOptionData, "id")
    if isStringEqual(optionType, "librarySortOrder")
        onSortOrderChange(selectedOptionData)
        return
    end if
    if isStringEqual(optionType, "librarySortBy")
        onSortChange(selectedOptionData)
        return
    end if
    if isStringEqual(optionType, "libraryView")
        onViewChange(selectedOptionData)
        return
    end if
end sub

sub init()
    m.favoritesOptionText = tr("Add To Favorites")
    m.showOptionMenu = false
    m.itemGridCounter = 0
    m.disabledReason = ""
    m.top.optionsAvailable = false
    setupNodes()
    m.bypassSearchEvent = false
    m.itemGrid.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    m.genreList.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    m.overhang.isVisible = false
    m.options.observeField("visible", "onOptionsVisibleChange")
    m.loadedRows = 0
    m.loadedItems = 0
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.observeField("itemFocused", "onItemFocused")
    m.itemGrid.observeFieldScoped("itemSelected", "onItemSelected")
    m.itemGrid.content = m.data
    m.genreData = CreateObject("roSGNode", "ContentNode")
    m.genreList.observeFieldScoped("itemFocused", "onGenreItemFocused")
    m.genreList.observeFieldScoped("itemSelected", "onGenreItemSelected")
    m.genreList.content = m.genreData
    'Item sort
    m.sortField = "SortName"
    m.sortAscending = true
    m.filter = "All"
    m.filterOptions = {}
    m.view = "presentation"
    m.loadItemsTask1 = createObject("roSGNode", "LoadItemsTask")
    m.isInMyListTask = createObject("roSGNode", "LoadItemsTask")
    m.isInMyListTask.itemsToLoad = "isInMyList"
    m.loadItemsTask = createObject("roSGNode", "LoadItemsTask2")
    m.getFiltersTask = createObject("roSGNode", "GetFiltersTask")
    'set inital counts for overhang before content is loaded.
    m.loadItemsTask.observeField("content", "ItemDataLoaded")
    m.loadItemsTask.totalRecordCount = 0
end sub

sub OnScreenHidden()
    if not m.overhang.isVisible
        m.overhang.disableMoveAnimation = true
        m.overhang.isVisible = true
        m.overhang.disableMoveAnimation = false
    end if
end sub

sub OnScreenShown()
    redrawItems()
    m.overhang.isVisible = false
    m.showOptionMenu = false
    group = m.global.sceneManager.callFunc("getActiveScene")
    if isValid(m.top.lastFocus)
        m.top.lastFocus.setFocus(true)
        group.lastFocus = m.top.lastFocus
        focusedItem = getItemFocused()
        if isValid(focusedItem)
            m.loadItemsTask1.itemId = focusedItem.LookupCI("id")
            m.loadItemsTask1.observeField("content", "onItemDataLoaded")
            m.loadItemsTask1.itemsToLoad = "metaData"
            m.loadItemsTask1.control = "RUN"
        end if
    else
        m.top.setFocus(true)
        group.lastFocus = m.top
    end if
end sub

sub onItemDataLoaded()
    itemData = m.loadItemsTask1.content
    m.loadItemsTask1.unobserveField("content")
    m.loadItemsTask1.control = "STOP"
    m.loadItemsTask1.content = []
    if not isValidAndNotEmpty(itemData) then
        return
    end if
    focusedItem = getItemFocused()
    if not isValid(focusedItem) then
        return
    end if
    focusedItem.callFunc("setWatched", chainLookupReturn(itemData[0], "json.UserData.Played", false), chainLookupReturn(itemData[0], "json.UserData.UnplayedItemCount", 0))
    if chainLookupReturn(itemData[0], "json.UserData.IsFavorite", false) then
        m.favoritesOptionText = tr("Remove From Favorites")
    else
        m.favoritesOptionText = tr("Add To Favorites")
    end if
    if m.showOptionMenu
        m.isInMyListTask.observeField("content", "onMyListLoaded")
        m.isInMyListTask.control = "RUN"
    end if
end sub

sub redrawItems()
    ' If user has not set a library level setting, check the user level setting
    if isChainValid(m.global.session, ("user.settings." + bslib_toString(m.top.parentItem.id) + "-useLandscapeImages"))
        useLandscapeImages = chainLookupReturn(m.global.session, ("user.settings." + bslib_toString(m.top.parentItem.id) + "-useLandscapeImages"), false)
        if useLandscapeImages then
            posterOrientation = "landscape"
        else
            posterOrientation = "default"
        end if
    else
        posterOrientation = chainLookupReturn(m.global, "session.user.settings.libraryPosterOrientation", "default")
    end if
    if isStringEqual(posterOrientation, "default")
        if inArray([
            "photo"
            "photoalbum"
            "musicvideo"
            "mylist"
        ], m.top.mediaType)
            setColumnSizes("landscape")
        else if isStringEqual(m.view, "Episodes")
            setColumnSizes("landscape")
        else
            setColumnSizes("portrait")
        end if
    else
        setColumnSizes(posterOrientation)
    end if
    itemGridContent = m.data.getChildren(-1, 0)
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    m.data.appendChildren(itemGridContent)
    ' Reset cursor back to its previous location
    m.itemGrid.jumpToItem = m.itemGrid.itemFocused
    genreContent = m.genreData.getChildren(-1, 0)
    m.genreData = CreateObject("roSGNode", "ContentNode")
    m.genreList.content = m.genreData
    m.genreData.appendChildren(genreContent)
    ' Reset cursor back to its previous location
    m.genreList.jumpToRowItem = m.genreList.rowItemSelected
end sub

'
'Load initial set of Data
sub loadInitialItems()
    m.loadItemsTask.control = "STOP"
    startLoadingSpinner(false)
    m.dropdownOptionGroup.parentItemID = m.top.parentItem.Id
    if isStringEqual(m.view, "presentation")
        m.backdropImage.callfunc("changeImage", (function(m)
                __bsConsequent = m.top.parentItem.backdropUrl
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(m))
    end if
    if m.dropdownOptionGroup.opacity < 1
        toggleDropdownOptions(true)
    end if
    m.sortField = m.global.session.user.settings["display." + m.top.parentItem.Id + ".sortField"]
    m.filter = m.global.session.user.settings["display." + m.top.parentItem.Id + ".filter"]
    m.filterOptions = m.global.session.user.settings["display." + m.top.parentItem.Id + ".filterOptions"]
    m.view = m.global.session.user.settings["display." + m.top.parentItem.Id + ".landing"]
    m.sortAscending = m.global.session.user.settings["display." + m.top.parentItem.Id + ".sortAscending"]
    ' If user has not set a preferred view for this folder, check if they've set a default view
    if not isValid(m.view)
        settingName = ("display." + bslib_toString(m.top.mediaType) + "library.defaultview")
        if isStringEqual(m.top.mediaType, "photoalbum")
            settingName = ("display." + bslib_toString("photo") + "library.defaultview")
        end if
        m.view = m.global.session.user.settings[settingName]
    end if
    ' Boxsets are sorted by Premiere Data by default
    if not isValidAndNotEmpty(m.sortField)
        if isStringEqual(getCollectionType(), "boxset")
            m.sortField = "PremiereDate,SortName"
        else if isStringEqual(getCollectionType(), "mylist")
            m.sortField = "OrderAdded"
        else
            m.sortField = "SortName"
        end if
    end if
    if not isValidAndNotEmpty(m.filter) then
        m.filter = "All"
    end if
    if not isValidAndNotEmpty(m.filterOptions) then
        m.filterOptions = "{}"
    end if
    if not isValidAndNotEmpty(m.view) then
        m.view = "presentation"
    end if
    if not isValid(m.sortAscending) then
        m.sortAscending = true
    end if
    if not isStringEqual(type(m.sortAscending), "roBoolean") then
        m.sortAscending = true
    end if
    m.dropdownOptionGroup.callfunc("setSortAscending", m.sortAscending)
    ' If view is not valid, use default view
    if not inArray([
        "presentation"
        "grid"
        "Genres"
        "Episodes"
    ], m.view) then
        m.view = "presentation"
    end if
    if isValid(m.top.parentItem.parentFolder)
        if not inArray([
            "presentation"
            "grid"
        ], m.view) then
            m.view = "presentation"
        end if
    end if
    m.filterOptions = ParseJson(m.filterOptions)
    m.loadItemsTask.searchTerm = m.top.searchTerm
    m.loadItemsTask.sortField = m.sortField
    m.loadItemsTask.sortAscending = m.sortAscending
    m.loadItemsTask.filter = m.filter
    m.loadItemsTask.filterOptions = m.filterOptions
    m.loadItemsTask.startIndex = 0
    m.loadItemsTask.studioIds = ""
    m.loadItemsTask.view = ""
    m.loadItemsTask.passToItem = {
        libraryID: m.top.parentItem.id
    }
    if isStringEqual(m.view, "Genres")
        m.loadItemsTask.view = "Genres"
        m.loadItemsTask.genreIds = m.top.parentItem.id
        m.loadItemsTask.itemId = m.top.parentItem.parentFolder
        m.loadItemsTask.studioIds = m.top.parentItem.Id
        if isStringEqual(m.top.mediaType, "musicvideo")
            m.loadItemsTask.recursive = true
        end if
    else if isStringEqual(m.view, "presentation")
        m.loadItemsTask.itemId = m.top.parentItem.Id
        m.loadItemsTask.studioIds = ""
        m.loadItemsTask.genreIds = ""
    else if isStringEqual(m.view, "grid")
        m.loadItemsTask.itemId = m.top.parentItem.Id
        m.loadItemsTask.studioIds = ""
        m.loadItemsTask.genreIds = ""
    else if isStringEqual(m.view, "Episodes")
        m.loadItemsTask.itemId = m.top.parentItem.Id
        m.loadItemsTask.studioIds = ""
        m.loadItemsTask.genreIds = ""
        if isStringEqual(m.loadItemsTask.sortField, "SortName")
            m.loadItemsTask.sortField = "SeriesSortName,SortName"
        end if
    end if
    if inArray([
        "boxset"
        "photo"
        "photoalbum"
        "musicvideo"
    ], m.top.mediaType)
        m.loadItemsTask.recursive = false
        if isStringEqual(m.top.mediaType, "musicvideo")
            ' Sort folders to the top of results
            m.loadItemsTask.sortField = (bslib_toString(m.sortField))
            m.loadItemsTask.itemType = (bslib_toString("musicvideo") + "," + bslib_toString("folder"))
            m.loadItemsTask.passToItem.addreplace("collectionType", "musicvideo")
        end if
        if isStringEqual(m.top.mediaType, "boxset")
            if not isStringEqual(m.top.parentItem.LookupCI("type"), "boxset")
                if m.loadItemsTask.searchTerm <> ""
                    m.loadItemsTask.itemType = "boxset"
                    m.loadItemsTask.recursive = true
                end if
            else
                if isValid(m.top.parentItem.parentFolder)
                    m.dropdownOptionGroup.callfunc("disableSearch", tr("Search is unavailable because the API does not support searching inside boxsets."))
                end if
            end if
        end if
    else if isStringEqual(m.view, "Episodes")
        m.loadItemsTask.recursive = true
        m.loadItemsTask.itemType = "episode"
    else
        m.loadItemsTask.itemType = m.top.mediaType
    end if
    ' We're in a genre sub folder
    if isValid(m.top.parentItem.parentFolder) and not isStringEqual(getCollectionType(), "boxset")
        if not inArray([
            "photoalbum"
            "musicvideo"
        ], m.top.mediaType)
            m.loadItemsTask.passToItem = {
                libraryID: m.top.parentItem.libraryID
            }
            m.loadItemsTask.itemId = m.top.parentItem.parentFolder
            m.loadItemsTask.genreIds = m.top.parentItem.id
        end if
    end if
    ' We're inside a music video genre sub folder
    if isStringEqual(m.top.mediaType, "musicvideo")
        if isStringEqual(chainLookup(m.top.parentItem, "itemType"), (bslib_toString("musicvideo") + "," + bslib_toString("folder")))
            m.loadItemsTask.itemId = m.top.parentItem.id
            m.loadItemsTask.genreIds = m.top.parentItem.id
            m.loadItemsTask.itemType = "musicvideo"
            m.loadItemsTask.recursive = true
        end if
    end if
    m.dropdownOptionGroup.translation = "[100, 540]"
    m.chipsRow.translation = "[100, 680]"
    if m.dropdownOptionGroup.opacity < 1
        m.itemGrid.translation = "[100, 520]"
    else
        m.itemGrid.translation = "[100, 740]"
    end if
    m.dropdownOptionsMove.keyValue = "[[100, 540], [100, 480]]"
    m.chipsRowMove.keyValue = "[[100, 680], [100, 540]]"
    m.itemGridMove.keyValue = "[[100, 740], [100, 600]]"
    m.emptyText.translation = "[0, 750]"
    m.itemGrid.itemSpacing = "[20, 20]"
    m.itemGrid.numRows = 3
    m.selectedItemOverview.visible = true
    m.infoGroup.visible = true
    m.top.showItemTitles = "hidealways"
    m.itemLogo.visible = false
    m.emptyText.visible = false
    if isStringEqual(m.view, "grid")
        m.top.showItemTitles = m.global.session.user.settings["itemgrid.gridTitles"]
        m.backdropImage.callfunc("clearImage", invalid)
        m.itemLogo.visible = false
        if m.dropdownOptionGroup.opacity < 1
            m.itemGrid.translation = "[100, 60]"
        else
            m.itemGrid.translation = "[100, 260]"
        end if
        m.dropdownOptionsMove.keyValue = "[[100, 60], [100, 0]]"
        m.chipsRowMove.keyValue = "[[100, 200], [100, 60]]"
        m.itemGridMove.keyValue = "[[100, 260], [100, 120]]"
        m.emptyText.translation = "[0, 540]"
        m.dropdownOptionGroup.translation = "[100, 60]"
        m.chipsRow.translation = "[100, 200]"
        m.itemGrid.numRows = "3"
        m.selectedItemOverview.visible = false
        m.selectedItemName.visible = false
        m.infoGroup.visible = false
    else if isStringEqual(m.view, "Episodes")
        m.top.showItemTitles = m.global.session.user.settings["itemgrid.gridTitles"]
        m.backdropImage.callfunc("clearImage", invalid)
        m.itemLogo.visible = false
        if m.dropdownOptionGroup.opacity < 1
            m.itemGrid.translation = "[100, 60]"
        else
            m.itemGrid.translation = "[100, 260]"
        end if
        m.dropdownOptionsMove.keyValue = "[[100, 60], [100, 0]]"
        m.chipsRowMove.keyValue = "[[100, 200], [100, 60]]"
        m.itemGridMove.keyValue = "[[100, 260], [100, 120]]"
        m.emptyText.translation = "[0, 540]"
        m.dropdownOptionGroup.translation = "[100, 60]"
        m.chipsRow.translation = "[100, 200]"
        m.itemGrid.numRows = "3"
        m.selectedItemOverview.visible = false
        m.selectedItemName.visible = false
        m.infoGroup.visible = false
    else if isStringEqual(m.view, "Genres")
        m.top.showItemTitles = m.global.session.user.settings["itemgrid.gridTitles"]
        m.backdropImage.callfunc("clearImage", invalid)
        m.itemLogo.visible = false
        if m.dropdownOptionGroup.opacity < 1
            m.itemGrid.translation = "[100, 60]"
        else
            m.itemGrid.translation = "[100, 260]"
        end if
        m.dropdownOptionsMove.keyValue = "[[100, 60], [100, 0]]"
        m.chipsRowMove.keyValue = "[[100, 200], [100, 60]]"
        m.itemGridMove.keyValue = "[[100, 260], [100, 120]]"
        m.emptyText.translation = "[0, 540]"
        m.dropdownOptionGroup.translation = "[100, 60]"
        m.chipsRow.translation = "[100, 200]"
        m.itemGrid.numRows = "3"
        m.selectedItemOverview.visible = false
        m.selectedItemName.visible = false
        m.infoGroup.visible = false
    end if
    if isStringEqual(m.top.mediaType, "mylist")
        m.dropdownOptionGroup.callfunc("disableSearch", tr("Search is unavailable because the API does not support searching inside My List."))
        m.itemGrid.itemComponentName = "GridItemMedium"
        m.itemGrid.itemSize = "[400, 330]"
        m.itemGrid.rowHeights = "[330]"
        m.itemGrid.itemSpacing = "[40, 20]"
        m.itemGrid.numColumns = 4
        m.top.imageDisplayMode = "scaleToZoom"
    end if
    if isStringEqual(m.top.mediaType, "musicvideo")
        m.itemGrid.itemComponentName = "GridItemMedium"
        m.itemGrid.itemSize = "[400, 330]"
        m.itemGrid.rowHeights = "[330]"
        m.itemGrid.itemSpacing = "[40, 20]"
        m.itemGrid.numColumns = 4
        m.top.imageDisplayMode = "scaleToZoom"
        m.genreList.itemComponentName = "GridItemMedium"
        m.genreList.rowItemSize = "[[400, 330]]"
        m.genreList.rowHeights = "[360]"
    end if
    if inArray([
        "photo"
        "photoalbum"
    ], m.top.mediaType)
        m.itemGrid.itemComponentName = "GridItemMedium"
        m.itemGrid.itemSize = "[400, 330]"
        m.itemGrid.rowHeights = "[330]"
        m.itemGrid.itemSpacing = "[40, 20]"
        m.itemGrid.numColumns = 4
        m.top.imageDisplayMode = "scaleToZoom"
        m.genreList.itemComponentName = "GridItemMedium"
        m.genreList.rowItemSize = "[[400, 330]]"
        m.genreList.rowHeights = "[360]"
    end if
    alphaDisplayed = m.alpha.callFunc("getDisplay")
    if isStringEqual(m.view, "Episodes")
        m.itemGrid.itemComponentName = "GridItemMedium"
        m.itemGrid.itemSize = "[400, 330]"
        m.itemGrid.rowHeights = "[330]"
        m.itemGrid.itemSpacing = "[40, 20]"
        m.itemGrid.numColumns = 4
        m.top.imageDisplayMode = "scaleToZoom"
        if alphaDisplayed
            m.alpha.callFunc("setDisplay", false)
        end if
    else
        if not alphaDisplayed
            m.alpha.callFunc("setDisplay", true)
        end if
    end if
    ' If user has not set a library level setting, check the user level setting
    if isChainValid(m.global.session, ("user.settings." + bslib_toString(m.top.parentItem.id) + "-useLandscapeImages"))
        useLandscapeImages = chainLookupReturn(m.global.session, ("user.settings." + bslib_toString(m.top.parentItem.id) + "-useLandscapeImages"), false)
        if useLandscapeImages then
            posterOrientation = "landscape"
        else
            posterOrientation = "default"
        end if
    else
        posterOrientation = chainLookupReturn(m.global, "session.user.settings.libraryPosterOrientation", "default")
    end if
    if isStringEqual(posterOrientation, "default")
        if inArray([
            "photo"
            "photoalbum"
            "musicvideo"
            "mylist"
        ], m.top.mediaType)
            setColumnSizes("landscape")
        else if isStringEqual(m.view, "Episodes")
            setColumnSizes("landscape")
        else
            setColumnSizes("portrait")
        end if
    else
        setColumnSizes(posterOrientation)
    end if
    m.loadItemsTask.control = "RUN"
    m.getFiltersTask.observeField("filters", "FilterDataLoaded")
    m.getFiltersTask.params = {
        userid: m.global.session.user.id
        parentid: m.top.parentItem.Id
        includeitemtypes: m.loadItemsTask.itemType
    }
    m.getFiltersTask.control = "RUN"
end sub

sub setColumnSizes(layout = "portrait" as string)
    if isStringEqual(layout, "portrait")
        numberOfColumns = chainLookupReturn(m.global.session, "user.settings.numberOfColumnsPortrait", "7")
        imageWidthData = val(chainLookupReturn(m.global.session, "user.settings.numberOfColumnsPortraitData", "230"))
    else
        numberOfColumns = chainLookupReturn(m.global.session, "user.settings.numberOfColumnsLandscape", "4")
        imageWidthData = val(chainLookupReturn(m.global.session, "user.settings.numberOfColumnsLandscapeData", "418"))
    end if
    if isStringEqual(m.top.showItemTitles, "hidealways")
        if isStringEqual(layout, "portrait") then
            aspectRatio = 1.52173
        else
            aspectRatio = .56307
        end if
    else
        if isStringEqual(layout, "portrait") then
            aspectRatio = 1.69565
        else
            aspectRatio = .66307
        end if
    end if
    defaultSize = [
        imageWidthData
        CInt(imageWidthData * aspectRatio)
    ]
    m.itemGrid.itemSize = defaultSize
    m.itemGrid.rowHeights = [
        defaultSize[1]
    ]
    m.itemGrid.numRows = abs(1230 / (defaultSize[1] + m.itemGrid.itemSpacing[1]))
    m.itemGrid.numColumns = numberOfColumns
    m.genreList.itemSize = [
        1900
        defaultSize[1] + 30
    ]
    m.genreList.rowItemSize = [
        defaultSize
    ]
    m.genreList.rowHeights = [
        defaultSize[1] + 30
    ]
    m.genreList.numRows = abs(1180 / (defaultSize[1] + m.genreList.itemSpacing[1]))
    m.loadItemsTask.numberOfColumns = numberOfColumns
end sub

function setOptions() as object
    if isStringEqual(m.top.mediaType, "movie")
        return setMovieOptions()
    end if
    if isStringEqual(m.top.mediaType, "boxset")
        return setMovieOptions()
    end if
    if isStringEqual(m.top.mediaType, "mylist")
        return setMovieOptions()
    end if
    if isStringEqual(m.top.mediaType, "series")
        return setSeriesOptions()
    end if
    if isStringEqual(m.top.mediaType, "musicvideo")
        return setMusicVideoOptions()
    end if
    if inArray([
        "photo"
        "photoalbum"
    ], m.top.mediaType)
        return setPhotoOptions()
    end if
    return {
        filter: []
    }
end function

' Set view, sort, and filter options
function setMovieOptions() as object
    options = {
        filter: []
    }
    options.views = [
        {
            "Title": tr("Presentation")
            "Name": "presentation"
            "Track": {
                "description": tr("Presentation")
            }
        }
        {
            "Title": tr("Grid")
            "Name": "grid"
            "Track": {
                "description": tr("Grid")
            }
        }
    ]
    if not isStringEqual(m.top.mediaType, "mylist")
        options.views.push({
            "Title": tr("Genres")
            "Name": "Genres"
            "Track": {
                "description": tr("Genres")
            }
        })
    end if
    options.sort = [
        {
            "Title": tr("TITLE")
            "Name": "SortName"
            "Track": {
                "description": tr("TITLE")
            }
        }
        {
            "Title": tr("Community Rating")
            "Name": "CommunityRating,SortName"
            "Track": {
                "description": tr("Community Rating")
            }
        }
        {
            "Title": tr("Critics Rating")
            "Name": "CriticRating,SortName"
            "Track": {
                "description": tr("Critics Rating")
            }
        }
        {
            "Title": tr("DATE_ADDED")
            "Name": "DateCreated,SortName"
            "Track": {
                "description": tr("DATE_ADDED")
            }
        }
        {
            "Title": tr("DATE_PLAYED")
            "Name": "DatePlayed,SortName"
            "Track": {
                "description": tr("DATE_PLAYED")
            }
        }
        {
            "Title": tr("Parental Rating")
            "Name": "OfficialRating,SortName"
            "Track": {
                "description": tr("Parental Rating")
            }
        }
        {
            "Title": tr("PLAY_COUNT")
            "Name": "PlayCount,SortName"
            "Track": {
                "description": tr("PLAY_COUNT")
            }
        }
        {
            "Title": tr("RELEASE_DATE")
            "Name": "PremiereDate,SortName"
            "Track": {
                "description": tr("RELEASE_DATE")
            }
        }
        {
            "Title": tr("RUNTIME")
            "Name": "Runtime,SortName"
            "Track": {
                "description": tr("RUNTIME")
            }
        }
        {
            "Title": tr("Random")
            "Name": "Random"
            "Track": {
                "description": tr("Random")
            }
        }
    ]
    options.filter = [
        {
            "Title": tr("All")
            "Name": "All"
        }
        {
            "Title": tr("Played")
            "Name": "Played"
        }
        {
            "Title": tr("Unplayed")
            "Name": "Unplayed"
        }
        {
            "Title": tr("Resumable")
            "Name": "Resumable"
        }
        {
            "Title": tr("Favorites")
            "Name": "Favorites"
        }
    ]
    if inArray([
        "boxset"
        "boxsets"
    ], getCollectionType())
        options.views = [
            {
                "Title": tr("Presentation")
                "Name": "presentation"
                "Track": {
                    "description": tr("Presentation")
                }
            }
            {
                "Title": tr("Grid")
                "Name": "grid"
                "Track": {
                    "description": tr("Grid")
                }
            }
        ]
    end if
    if inArray([
        "mylist"
    ], getCollectionType())
        options.sort.unshift({
            "Title": tr("Order Added")
            "Name": "OrderAdded"
            "Track": {
                "description": tr("Order Added")
            }
        })
    end if
    if isStringEqual(m.view, "genres")
        options.sort = [
            {
                "Title": tr("TITLE")
                "Name": "SortName"
                "Track": {
                    "description": tr("TITLE")
                }
            }
        ]
        options.filter = [
            {
                "Title": tr("All")
                "Name": "All"
            }
        ]
    end if
    ' If we're in a genre subfolder
    if isValid(m.top.parentItem.parentFolder)
        options.views = [
            {
                "Title": tr("Presentation")
                "Name": "presentation"
                "Track": {
                    "description": tr("Presentation")
                }
            }
            {
                "Title": tr("Grid")
                "Name": "grid"
                "Track": {
                    "description": tr("Grid")
                }
            }
        ]
    end if
    return options
end function

function setMusicVideoOptions() as object
    options = {
        filter: []
    }
    options.views = [
        {
            "Title": tr("Presentation")
            "Name": "presentation"
            "Track": {
                "description": tr("Presentation")
            }
        }
        {
            "Title": tr("Grid")
            "Name": "grid"
            "Track": {
                "description": tr("Grid")
            }
        }
        {
            "Title": tr("Genres")
            "Name": "Genres"
            "Track": {
                "description": tr("Genres")
            }
        }
    ]
    options.sort = [
        {
            "Title": tr("TITLE")
            "Name": "SortName"
            "Track": {
                "description": tr("TITLE")
            }
        }
        {
            "Title": tr("Community Rating")
            "Name": "CommunityRating,SortName"
            "Track": {
                "description": tr("Community Rating")
            }
        }
        {
            "Title": tr("Critics Rating")
            "Name": "CriticRating,SortName"
            "Track": {
                "description": tr("Critics Rating")
            }
        }
        {
            "Title": tr("DATE_ADDED")
            "Name": "DateCreated,SortName"
            "Track": {
                "description": tr("DATE_ADDED")
            }
        }
        {
            "Title": tr("DATE_PLAYED")
            "Name": "DatePlayed,SortName"
            "Track": {
                "description": tr("DATE_PLAYED")
            }
        }
        {
            "Title": tr("Folders")
            "Name": "IsFolder,SortName"
            "Track": {
                "description": tr("Folders")
            }
        }
        {
            "Title": tr("Parental Rating")
            "Name": "OfficialRating,SortName"
            "Track": {
                "description": tr("Parental Rating")
            }
        }
        {
            "Title": tr("PLAY_COUNT")
            "Name": "PlayCount,SortName"
            "Track": {
                "description": tr("PLAY_COUNT")
            }
        }
        {
            "Title": tr("RELEASE_DATE")
            "Name": "PremiereDate,SortName"
            "Track": {
                "description": tr("RELEASE_DATE")
            }
        }
        {
            "Title": tr("RUNTIME")
            "Name": "Runtime,SortName"
            "Track": {
                "description": tr("RUNTIME")
            }
        }
        {
            "Title": tr("Random")
            "Name": "Random"
            "Track": {
                "description": tr("Random")
            }
        }
    ]
    options.filter = [
        {
            "Title": tr("All")
            "Name": "All"
        }
        {
            "Title": tr("Played")
            "Name": "Played"
        }
        {
            "Title": tr("Unplayed")
            "Name": "Unplayed"
        }
        {
            "Title": tr("Resumable")
            "Name": "Resumable"
        }
        {
            "Title": tr("Favorites")
            "Name": "Favorites"
        }
    ]
    if isStringEqual(m.view, "genres")
        options.sort = [
            {
                "Title": tr("TITLE")
                "Name": "SortName"
                "Track": {
                    "description": tr("TITLE")
                }
            }
        ]
        options.filter = [
            {
                "Title": tr("All")
                "Name": "All"
            }
        ]
    end if
    ' If we're in a genre subfolder
    if isValid(m.top.parentItem.parentFolder)
        options.views = [
            {
                "Title": tr("Presentation")
                "Name": "presentation"
                "Track": {
                    "description": tr("Presentation")
                }
            }
            {
                "Title": tr("Grid")
                "Name": "grid"
                "Track": {
                    "description": tr("Grid")
                }
            }
        ]
    end if
    return options
end function

function setPhotoOptions() as object
    options = {
        filter: []
    }
    options.views = [
        {
            "Title": tr("Presentation")
            "Name": "presentation"
            "Track": {
                "description": tr("Presentation")
            }
        }
        {
            "Title": tr("Grid")
            "Name": "grid"
            "Track": {
                "description": tr("Grid")
            }
        }
    ]
    options.sort = [
        {
            "Title": tr("TITLE")
            "Name": "SortName"
            "Track": {
                "description": tr("TITLE")
            }
        }
        {
            "Title": tr("DATE_ADDED")
            "Name": "DateCreated,SortName"
            "Track": {
                "description": tr("DATE_ADDED")
            }
        }
        {
            "Title": tr("Folders")
            "Name": "IsFolder,SortName"
            "Track": {
                "description": tr("Folders")
            }
        }
        {
            "Title": tr("Random")
            "Name": "Random"
            "Track": {
                "description": tr("Random")
            }
        }
    ]
    options.filter = [
        {
            "Title": tr("All")
            "Name": "All"
        }
        {
            "Title": tr("Favorites")
            "Name": "Favorites"
        }
        {
            "Title": tr("Item Type")
            "Name": "includeItemTypes"
            "Options": [
                "Photo"
                "Photo Album"
                "Video"
            ]
            "Delimiter": ","
            "CheckedState": []
        }
    ]
    return options
end function

function setSeriesOptions() as object
    options = {
        filter: []
    }
    options.views = [
        {
            "Title": tr("Presentation")
            "Name": "presentation"
            "Track": {
                "description": tr("Presentation")
            }
        }
        {
            "Title": tr("Grid")
            "Name": "grid"
            "Track": {
                "description": tr("Grid")
            }
        }
        {
            "Title": tr("Genres")
            "Name": "Genres"
            "Track": {
                "description": tr("Genres")
            }
        }
        {
            "Title": tr("Episodes")
            "Name": "Episodes"
            "Track": {
                "description": tr("Episodes")
            }
        }
    ]
    options.sort = [
        {
            "Title": tr("TITLE")
            "Name": "SortName"
            "Track": {
                "description": tr("TITLE")
            }
        }
        {
            "Title": tr("Community Rating")
            "Name": "CommunityRating,SortName"
            "Track": {
                "description": tr("Community Rating")
            }
        }
        {
            "Title": tr("Date Show Added")
            "Name": "DateCreated,SortName"
            "Track": {
                "description": tr("Date Show Added")
            }
        }
        {
            "Title": tr("Date Episode Added")
            "Name": "DateLastContentAdded,SortName"
            "Track": {
                "description": tr("Date Episode Added")
            }
        }
        {
            "Title": tr("DATE_PLAYED")
            "Name": "SeriesDatePlayed,SortName"
            "Track": {
                "description": tr("DATE_PLAYED")
            }
        }
        {
            "Title": tr("OFFICIAL_RATING")
            "Name": "OfficialRating,SortName"
            "Track": {
                "description": tr("OFFICIAL_RATING")
            }
        }
        {
            "Title": tr("RELEASE_DATE")
            "Name": "PremiereDate,SortName"
            "Track": {
                "description": tr("RELEASE_DATE")
            }
        }
        {
            "Title": tr("Random")
            "Name": "Random"
            "Track": {
                "description": tr("Random")
            }
        }
    ]
    options.filter = [
        {
            "Title": tr("All")
            "Name": "All"
        }
        {
            "Title": tr("Played")
            "Name": "Played"
        }
        {
            "Title": tr("Unplayed")
            "Name": "Unplayed"
        }
        {
            "Title": tr("Favorites")
            "Name": "Favorites"
        }
    ]
    if isStringEqual(m.view, "genres")
        options.sort = [
            {
                "Title": tr("TITLE")
                "Name": "SortName"
                "Track": {
                    "description": tr("TITLE")
                }
            }
        ]
        options.filter = [
            {
                "Title": tr("All")
                "Name": "All"
            }
        ]
    end if
    ' If we're in a genre subfolder
    if isValid(m.top.parentItem.parentFolder)
        options.views = [
            {
                "Title": tr("Presentation")
                "Name": "presentation"
                "Track": {
                    "description": tr("Presentation")
                }
            }
            {
                "Title": tr("Grid")
                "Name": "grid"
                "Track": {
                    "description": tr("Grid")
                }
            }
        ]
    end if
    return options
end function

' Return parent collection type
function getCollectionType() as string
    return (function(m)
            __bsConsequent = m.top.parentItem.collectionType
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return m.top.parentItem.Type
            end if
        end function)(m)
end function

' Data to display when options button selected
sub setSelectedOptions(options)
    ' Set selected view option
    for each o in options.views
        if o.Name = m.view
            m.dropdownOptionGroup.callfunc("setText", "viewButton", tr(o.LookupCI("title")))
            o.Selected = true
        end if
    end for
    ' Set selected sort option
    for each o in options.sort
        if o.Name = m.sortField
            m.dropdownOptionGroup.callfunc("setText", "sortButton", tr(o.LookupCI("title")))
            o.Selected = true
        end if
    end for
    ' Set selected filter
    for each o in options.filter
        haveSelectedFilterOptions = false
        if o.Name = m.filter
            o.Selected = true
            m.dropdownOptionGroup.callfunc("setText", "filterButton", tr(o.LookupCI("title")))
            m.options.filter = o.Name
            displayChip = false
            if not isAllValid([
                o.options
                m.filterOptions
            ])
                displayChip = true
            else if o.options.Count() = 0 or m.filterOptions.Count() = 0
                displayChip = true
            end if
            if isStringEqual(tr(o.LookupCI("title")), tr("All"))
                displayChip = false
            end if
            if isValid(o.options) and isValid(m.filterOptions)
                if o.options.Count() > 0 and m.filterOptions.Count() > 0
                    if LCase(o.Name) = LCase(m.filterOptions.keys()[0])
                        haveSelectedFilterOptions = true
                    end if
                end if
            end if
            if displayChip
                m.chipsRow.callfunc("addChip", "filter", "", tr(o.LookupCI("title")))
            else
                if not haveSelectedFilterOptions
                    m.chipsRow.callfunc("removeChip", "filter")
                end if
            end if
        end if
        ' Select selected filter options
        if haveSelectedFilterOptions
            selectedFilterOptions = m.filterOptions[m.filterOptions.keys()[0]].split(o.delimiter)
            m.chipsRow.callfunc("addChip", "filter", tr(o.LookupCI("title")), selectedFilterOptions.join(", "))
            checkedState = []
            for each availableFilterOption in o.options
                matchFound = false
                for each selectedFilterOption in selectedFilterOptions
                    if LCase(toString(availableFilterOption).trim()) = LCase(selectedFilterOption.trim())
                        matchFound = true
                    end if
                end for
                checkedState.push(matchFound)
            end for
            o.checkedState = checkedState
        end if
    end for
    m.options.options = options
    m.dropdownOptionGroup.callfunc("setOptionData", options)
    m.dropdownOptionGroup.callfunc("setText", "sortOrderButton", (function(__bsCondition, tr)
            if __bsCondition then
                return tr("Ascending")
            else
                return tr("Descending")
            end if
        end function)(m.sortAscending, tr))
end sub

'
' Logo Image Loaded Event Handler
sub FilterDataLoaded(msg)
    options = setOptions()
    data = msg.GetData()
    m.getFiltersTask.unobserveField("filters")
    if not isValid(data) then
        return
    end if
    ' Add filters from the API data
    if inArray([
        "presentation"
        "grid"
    ], m.view)
        options.filter.push({
            "Title": tr("Features")
            "Name": "Features"
            "Options": [
                "Subtitles"
                "Special Features"
                "Theme Song"
                "Theme Video"
            ]
            "Delimiter": "|"
            "CheckedState": []
        })
        if isValidAndNotEmpty(data.genres)
            options.filter.push({
                "Title": tr("Genres")
                "Name": "Genres"
                "Options": data.genres
                "Delimiter": "|"
                "CheckedState": []
            })
        end if
        if isValidAndNotEmpty(data.OfficialRatings)
            options.filter.push({
                "Title": tr("Parental Ratings")
                "Name": "OfficialRatings"
                "Options": data.OfficialRatings
                "Delimiter": "|"
                "CheckedState": []
            })
        end if
        if isValidAndNotEmpty(data.Years)
            options.filter.push({
                "Title": tr("Years")
                "Name": "Years"
                "Options": data.Years
                "Delimiter": ","
                "CheckedState": []
            })
        end if
        if isValidAndNotEmpty(data.Tags)
            ' If we already have tag filter data, reuse it
            if isValidAndNotEmpty(m.options.LookupCI("filteredOptions"))
                options.filter.push({
                    "Title": tr("Tags")
                    "Name": "Tags"
                    "data": data.Tags
                    "Options": m.options.LookupCI("filteredOptions")
                    "Delimiter": "|"
                    "CheckedState": m.options.LookupCI("filteredOptionsCheckedState")
                })
            else
                options.filter.push({
                    "Title": tr("Tags")
                    "Name": "Tags"
                    "Options": data.Tags
                    "Delimiter": "|"
                    "CheckedState": []
                })
            end if
        end if
    end if
    setSelectedOptions(options)
end sub

'
'Handle loaded data, and add to Grid
sub ItemDataLoaded(msg)
    itemData = msg.GetData()
    m.chipsRow.callfunc("setTotalCount", (bslib_toString(m.loadItemsTask.totalRecordCount) + " items"))
    if not isValidAndNotEmpty(itemData)
        stopLoadingSpinner()
        if m.itemGrid.content.getChildCount() = 0
            showNoResultsText()
        end if
        return
    end if
    m.dropdownOptionGroup.canExitDown = true
    if isStringEqual(m.view, "Genres")
        ' Reset genre list data
        m.genreData.removeChildren(m.genreData.getChildren(-1, 0))
        for each item in itemData
            m.genreData.appendChild(item)
        end for
        m.loadedItems = m.genreData.getChildCount()
        m.itemGrid.opacity = 0
        m.genreList.opacity = 1
        m.genreList.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.genreList
        stopLoadingSpinner()
        ' Return focus to options menu if it was opened while library was loading
        if m.options.visible
            m.options.setFocus(true)
            group.lastFocus = m.options
        end if
        if m.loadedItems = 0
            m.backdropImage.callfunc("clearImage", invalid)
            m.emptyText.text = tr("No items found. Try adjusting your selected filters.")
            m.emptyText.visible = true
            m.global.sceneManager.observeFieldScoped("returnData", "onReturnData")
            m.dropdownOptionGroup.canExitDown = false
            m.dropdownOptionGroup.callfunc("setFocus", "voiceBox", true)
            m.dropdownOptionGroup.callfunc("setSearchBackground", 0)
        end if
        return
    end if
    ' keep focus on alpha menu if it's active
    if m.top.alphaActive
        m.alphaMenu.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.alphaMenu
    else
        m.itemGrid.opacity = "1"
        m.genreList.opacity = "0"
        m.alphaMenu.setFocus(false)
        m.itemGrid.setFocus(true)
        m.genreList.setFocus(false)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.itemGrid
    end if
    if m.data.getChildCount() = 0
        m.itemGrid.jumpToItem = 0
    end if
    m.data.appendChildren(itemData)
    'Update the stored counts
    m.loadedItems = m.itemGrid.content.getChildCount()
    m.loadedRows = m.loadedItems / m.itemGrid.numColumns
    onItemFocused()
    'If there are no items to display, show message
    if m.loadedItems = 0
        showNoResultsText()
    end if
    stopLoadingSpinner()
    ' Return focus to options menu if it was opened while library was loading
    if m.options.visible
        m.options.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.options
    end if
end sub

sub showNoResultsText()
    m.selectedItemOverview.visible = false
    m.infoGroup.visible = false
    m.itemLogo.visible = false
    m.itemLogo.uri = ""
    m.selectedItemName.visible = false
    SetName("")
    SetOverview("")
    SetOfficialRating("")
    SetProductionYear("")
    setFieldText("runtime", "")
    setFieldText("communityRating", "")
    setFieldText("criticRatingLabel", "")
    m.criticRatingIcon.uri = ""
    m.star.uri = ""
    m.backdropImage.callfunc("clearImage", invalid)
    m.emptyText.text = tr("No items found. Try adjusting your selected filters.")
    m.emptyText.visible = true
    if m.top.alphaActive
        m.global.sceneManager.unobserveFieldScoped("returnData")
        m.dropdownOptionGroup.callfunc("setSearchBackground", 1)
        m.alphaMenu.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.alphaMenu
        return
    end if
    m.global.sceneManager.observeFieldScoped("returnData", "onReturnData")
    m.dropdownOptionGroup.canExitDown = false
    m.dropdownOptionGroup.callfunc("setFocus", "voiceBox", true)
    m.dropdownOptionGroup.callfunc("setSearchBackground", 0)
end sub

'
'Set Selected Name
sub SetName(itemName as string)
    m.selectedItemName.text = itemName
end sub

'
'Set Selected Overview
sub SetOverview(itemOverview as string)
    m.selectedItemOverview.text = itemOverview
end sub

'
'Set Selected OfficialRating
sub SetOfficialRating(itemOfficialRating as string)
    m.selectedItemOfficialRating.text = itemOfficialRating
end sub

'
'Set Selected ProductionYear
sub SetProductionYear(itemProductionYear)
    m.selectedItemProductionYear.text = itemProductionYear
end sub

sub toggleDropdownOptions(runInReverse = false as boolean)
    m.dropdownOptionsFade.reverse = runInReverse
    m.dropdownOptionsMove.reverse = runInReverse
    m.chipsRowMove.reverse = runInReverse
    m.itemGridMove.reverse = runInReverse
    m.genreListMove.reverse = runInReverse
    if not isStringEqual(m.toggleDropdownOptionsAnimation.state, "running")
        m.toggleDropdownOptionsAnimation.control = "start"
    end if
end sub

'
'Handle new item being focused
sub onItemFocused()
    focusedRow = m.itemGrid.currFocusRow
    if m.itemGrid.isinFocusChain() or m.dropdownOptionGroup.isinFocusChain()
        if focusedRow = 0
            if m.dropdownOptionGroup.opacity < 1
                toggleDropdownOptions(true)
            end if
        else if focusedRow > 0
            if m.dropdownOptionGroup.opacity > 0
                toggleDropdownOptions(false)
            end if
        end if
    end if
    itemInt = m.itemGrid.itemFocused
    ' If no selected item, set background to parent backdrop
    if itemInt = -1
        return
    end if
    m.itemLogo.visible = false
    m.selectedItemName.visible = false
    ' Load more data if focus is within last 5 rows, and there are more items to load
    if focusedRow >= m.loadedRows - 5 and m.loadeditems < m.loadItemsTask.totalRecordCount
        loadMoreData()
    end if
    m.communityRatingGroup.visible = false
    m.criticRatingGroup.visible = false
    if not isStringEqual(m.view, "presentation")
        return
    end if
    focusedItem = getItemFocused()
    if not isChainValid(focusedItem, "json")
        return
    end if
    itemData = focusedItem.json
    m.star.uri = "pkg:/images/sharp_star_white_18dp.png"
    if m.global.session.user.settings["ui.itemdetail.showRatings"]
        if isValid(itemData.communityRating)
            setFieldText("communityRating", int(itemData.communityRating * 10) / 10)
            m.communityRatingGroup.visible = true
        end if
        if isValid(itemData.CriticRating)
            setFieldText("criticRatingLabel", itemData.criticRating)
            tomato = "pkg:/images/rotten.png"
            if itemData.CriticRating > 60
                tomato = "pkg:/images/fresh.png"
            end if
            m.criticRatingIcon.uri = tomato
            m.criticRatingGroup.visible = true
        end if
    end if
    if isValid(itemData.Name)
        SetName(itemData.Name)
    else
        SetName("")
    end if
    if isValid(itemData.Overview)
        SetOverview(itemData.Overview)
    else
        SetOverview("")
    end if
    if isValid(itemData.ProductionYear)
        SetProductionYear(str(itemData.ProductionYear))
    else
        SetProductionYear("")
    end if
    if type(itemData.RunTimeTicks) = "LongInteger"
        setFieldText("runtime", stri(getRuntime(itemData.RunTimeTicks)) + " mins")
    else
        setFieldText("runtime", "")
    end if
    if isValid(itemData.OfficialRating)
        SetOfficialRating(itemData.OfficialRating)
    else
        SetOfficialRating("")
    end if
    ShowLogoOrName(itemData, m.itemLogo, m.selectedItemName)
    ' Set Background to item backdrop
    if isStringEqual(m.view, "presentation")
        if isValidAndNotEmpty(focusedItem.backdropUrl)
            m.backdropImage.callfunc("changeImage", focusedItem.backdropUrl)
        else if isValidAndNotEmpty(focusedItem.posterUrl)
            ' We have a poster image URL, request a new one at a higher resolution
            m.backdropImage.callfunc("changeImage", api_items_GetImageURL(focusedItem.id, "primary", 0, {
                "maxHeight": 700
                "maxWidth": 1100
            }))
        end if
    end if
end sub

function getRuntime(runTimeTicks) as integer
    return round(runTimeTicks / 600000000.0)
end function

function round(f as float) as integer
    ' BrightScript only has a "floor" round
    ' This compares floor to floor + 1 to find which is closer
    m = int(f)
    n = m + 1
    x = abs(f - m)
    y = abs(f - n)
    if y > x
        return m
    else
        return n
    end if
end function

sub setFieldText(field, value)
    node = m.top.findNode(field)
    if node = invalid or value = invalid then
        return
    end if
    ' Handle non strings... Which _shouldn't_ happen, but hey
    if type(value) = "roInt" or type(value) = "Integer"
        value = str(value)
    else if type(value) = "roFloat" or type(value) = "Float"
        value = str(value)
    else if type(value) <> "roString" and type(value) <> "String"
        value = ""
    end if
    node.text = value
end sub

'
'Load next set of items
sub loadMoreData()
    if isStringEqual(m.loadItemsTask.state, "RUN") then
        return
    end if
    startLoadingSpinner(false)
    m.loadItemsTask.startIndex = m.loadedItems
    m.loadItemsTask.control = "RUN"
end sub

'
'Item Selected
sub onItemSelected()
    m.top.selectedItem = m.itemGrid.content.getChild(m.itemGrid.itemSelected)
    m.top.selectedItem = invalid
end sub

'
'Returns Focused Item
function getItemFocused()
    if m.itemGrid.isinFocusChain() and isValid(m.itemGrid.itemFocused)
        return m.itemGrid.content.getChild(m.itemGrid.itemFocused)
    else if m.genreList.isinFocusChain() and isValid(m.genreList.rowItemFocused)
        return m.genreList.content.getChild(m.genreList.rowItemFocused[0]).getChild(m.genreList.rowItemFocused[1])
    end if
    return invalid
end function

'
'Genre Item Selected
sub onGenreItemSelected()
    m.top.selectedItem = m.genreList.content.getChild(m.genreList.rowItemSelected[0]).getChild(m.genreList.rowItemSelected[1])
    m.top.selectedItem = invalid
end sub

'
'Genre Item Focused
sub onGenreItemFocused()
    focusedRow = m.genreList.currFocusRow
    if m.genreList.isinFocusChain()
        if focusedRow = 0
            if m.dropdownOptionGroup.opacity < 1
                toggleDropdownOptions(true)
            end if
        else if focusedRow > 0
            if m.dropdownOptionGroup.opacity > 0
                toggleDropdownOptions(false)
            end if
        end if
    end if
end sub

sub processDropdownState(searchTerm as string)
    if not isStringEqual(searchTerm, "")
        resetDropdownsToDefaultState()
        setDropdownDisabledState(true)
        return
    end if
    setDropdownDisabledState(false)
end sub

sub setDropdownDisabledState(disabledState = false as boolean)
    m.dropdownOptionGroup.callfunc("setDisabled", "sortButton", disabledState)
    m.dropdownOptionGroup.callfunc("setDisabled", "sortOrderButton", disabledState)
    m.dropdownOptionGroup.callfunc("setDisabled", "filterButton", disabledState)
end sub

sub resetDropdownsToDefaultState()
    m.filter = "All"
    m.filterOptions = {}
    if isStringEqual(getCollectionType(), "boxset")
        m.sortField = "PremiereDate,SortName"
    else if isStringEqual(getCollectionType(), "mylist")
        m.sortField = "OrderAdded"
    else
        m.sortField = "SortName"
    end if
    ' Set selected sort option
    for each o in m.options.options.sort
        if o.Name = m.sortField
            m.dropdownOptionGroup.callfunc("setText", "sortButton", tr(o.LookupCI("title")))
            o.Selected = true
        end if
    end for
    m.sortAscending = true
    m.dropdownOptionGroup.callfunc("setSortAscending", true)
    ' Reset view to defaults
    set_user_setting("display." + m.top.parentItem.Id + ".sortField", m.sortField)
    set_user_setting("display." + m.top.parentItem.Id + ".sortAscending", "true")
    set_user_setting("display." + m.top.parentItem.Id + ".filter", m.filter)
    set_user_setting("display." + m.top.parentItem.Id + ".filterOptions", FormatJson(m.filterOptions))
    if not isStringEqual(m.view, "Genres")
        set_user_setting(("display." + bslib_toString(m.top.mediaType) + "library.defaultview"), m.view)
    end if
    m.dropdownOptionGroup.callfunc("setText", "sortOrderButton", tr("Ascending"))
    m.dropdownOptionGroup.callfunc("setText", "filterButton", tr("All"))
    m.getFiltersTask.control = "RUN"
end sub

sub onDropdownOptionGroupSearchTermChanged()
    m.top.searchTerm = m.dropdownOptionGroup.searchTerm
end sub

sub onSearchTermChanged()
    searchTerm = m.top.searchTerm.trim()
    if not isValid(searchTerm) then
        return
    end if
    ' If user searched for a letter, selected it from the alpha menu
    if searchTerm.len() = 1
        alphaMenu = m.top.findNode("alphaMenu")
        intConversion = searchTerm.ToInt() ' non numeric input returns as 0
        if searchTerm = "0" or (isValid(intConversion) and intConversion <> 0)
            alphaMenu.jumpToItem = 0
        else
            ' loop through each option until we find a match
            for i = 1 to alphaMenu.numRows - 1
                alphaMenuOption = alphaMenu.content.getChild(i)
                if isStringEqual(alphaMenuOption.TITLE, searchTerm)
                    alphaMenu.jumpToItem = i
                    exit for
                end if
            end for
        end if
        m.dropdownOptionGroup.callfunc("setSearchHintText", "")
        m.top.alphaSelected = searchTerm
        m.dropdownOptionGroup.callfunc("setSearchBackground", 1)
        return
    end if
    if isStringEqual(m.loadItemsTask.searchTerm, m.top.searchTerm) then
        return
    end if
    m.dropdownOptionGroup.callfunc("setSearchBackground", 1)
    processDropdownState(m.top.searchTerm)
    m.dropdownOptionGroup.callfunc("setSearchHintText", m.top.searchTerm)
    if isValidAndNotEmpty(m.top.searchTerm)
        m.chipsRow.callfunc("removeChip", "filter")
        m.chipsRow.callfunc("addChip", "search", tr("Search Term"), m.top.searchTerm)
    else
        m.chipsRow.callfunc("removeChip", "search")
    end if
    if m.bypassSearchEvent
        m.bypassSearchEvent = false
        return
    end if
    m.loadedRows = 0
    m.loadedItems = 0
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    m.genreData = CreateObject("roSGNode", "ContentNode")
    m.genreList.content = m.genreData
    loadInitialItems()
end sub

sub alphaSelectedChanged()
    ' Prevent voicebox change double firing
    if isStringEqual(m.top.searchTerm, "")
        ' Allow user to toggle by clicking letter twice
        if isStringEqual(m.loadItemsTask.nameStartsWith, m.top.alphaSelected)
            m.top.alphaSelected = ""
        end if
    end if
    m.loadItemsTask.control = "STOP"
    m.loadedRows = 0
    m.loadedItems = 0
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    m.genreData = CreateObject("roSGNode", "ContentNode")
    m.genreList.content = m.genreData
    if isValidAndNotEmpty(m.top.alphaSelected)
        m.chipsRow.callfunc("addChip", "startswith", tr("Starts With"), m.top.alphaSelected)
    else
        m.chipsRow.callfunc("removeChip", "startswith")
    end if
    m.loadItemsTask.nameStartsWith = m.top.alphaSelected
    m.dropdownOptionGroup.callfunc("setText", "voiceBox", "")
    m.top.searchTerm = ""
    loadInitialItems()
end sub

'
'Check if options updated and any reloading required
sub onOptionsVisibleChange()
    if m.options.visible then
        return
    end if
    reload = false
    ' Nothing changed
    if isStringEqual(m.options.filter, m.filter)
        if AssocArrayEqual(m.options.filterOptions, m.filterOptions)
            m.dropdownOptionGroup.callfunc("setFocus", "filterButton", true)
            return
        end if
    end if
    m.global.sceneManager.observeFieldScoped("returnData", "onReturnData")
    if m.options.filter <> m.filter
        m.filter = m.options.filter
        reload = true
        set_user_setting("display." + m.top.parentItem.Id + ".filter", m.options.filter)
    end if
    if not isValid(m.options.filterOptions)
        m.filterOptions = {}
    end if
    if not AssocArrayEqual(m.options.filterOptions, m.filterOptions)
        m.filterOptions = m.options.filterOptions
        reload = true
        set_user_setting("display." + m.top.parentItem.Id + ".filterOptions", FormatJson(m.options.filterOptions))
    end if
    if reload
        m.loadedRows = 0
        m.loadedItems = 0
        m.data = CreateObject("roSGNode", "ContentNode")
        m.itemGrid.content = m.data
        loadInitialItems()
    end if
    m.dropdownOptionGroup.callfunc("setFocus", "filterButton", false)
    m.itemGrid.setFocus(m.itemGrid.opacity = 1)
    m.genreList.setFocus(m.genreList.opacity = 1)
    group = m.global.sceneManager.callFunc("getActiveScene")
    if m.itemGrid.opacity = 1 then
        group.lastFocus = m.itemGrid
    else
        group.lastFocus = m.genreList
    end if
end sub

sub onSortChange(sortChoice)
    if not isChainValid(sortChoice, "name") then
        return
    end if
    if isStringEqual(sortChoice.LookupCI("name"), m.sortField) then
        return
    end if
    m.dropdownOptionGroup.callfunc("setFocus", "sortButton", false)
    m.itemGrid.setFocus(m.itemGrid.opacity = 1)
    m.genreList.setFocus(m.genreList.opacity = 1)
    m.sortField = sortChoice.LookupCI("name")
    m.dropdownOptionGroup.callfunc("setText", "sortButton", tr(sortChoice.LookupCI("title")))
    m.dropdownOptionGroup.callfunc("setSortAscending", true)
    m.sortAscending = true
    set_user_setting("display." + m.top.parentItem.Id + ".sortField", m.sortField)
    m.loadedRows = 0
    m.loadedItems = 0
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    loadInitialItems()
end sub

sub onViewChange(viewChoice)
    if not isChainValid(viewChoice, "name") then
        return
    end if
    if isStringEqual(viewChoice.LookupCI("name"), m.view) then
        return
    end if
    m.dropdownOptionGroup.callfunc("setFocus", "viewButton", false)
    ' If we're moving to or from the episodes view, we must recreate the item grid to change the itemComponentName property
    if inArray([
        m.view
        viewChoice.LookupCI("name")
    ], "Episodes")
        m.top.removeChild(m.itemGrid)
        ' The slide up animation will fail if the new itemGrid ID isn't unique /shrug
        m.itemGridCounter++
        createItemGrid(("itemGrid" + bslib_toString(m.itemGridCounter)))
    end if
    m.view = viewChoice.LookupCI("name")
    m.dropdownOptionGroup.callfunc("setText", "viewButton", tr(viewChoice.LookupCI("title")))
    set_user_setting("display." + m.top.parentItem.Id + ".landing", m.view)
    ' Reset any filtering or search terms
    m.bypassSearchEvent = true
    m.top.searchTerm = ""
    m.top.alphaSelected = ""
    m.loadItemsTask.NameStartsWith = " "
    m.loadItemsTask.searchTerm = ""
    m.filter = "All"
    m.filterOptions = {}
    if isStringEqual(getCollectionType(), "boxset")
        m.sortField = "PremiereDate,SortName"
    else if isStringEqual(getCollectionType(), "mylist")
        m.sortField = "OrderAdded"
    else
        m.sortField = "SortName"
    end if
    m.sortAscending = true
    m.dropdownOptionGroup.callfunc("setSortAscending", true)
    ' Reset view to defaults
    set_user_setting("display." + m.top.parentItem.Id + ".sortField", m.sortField)
    set_user_setting("display." + m.top.parentItem.Id + ".sortAscending", "true")
    set_user_setting("display." + m.top.parentItem.Id + ".filter", m.filter)
    set_user_setting("display." + m.top.parentItem.Id + ".filterOptions", FormatJson(m.filterOptions))
    if not isStringEqual(m.view, "Genres")
        set_user_setting(("display." + bslib_toString(m.top.mediaType) + "library.defaultview"), m.view)
    end if
    m.getFiltersTask.control = "RUN"
    m.loadedRows = 0
    m.loadedItems = 0
    m.itemGrid.setFocus(m.itemGrid.opacity = 1)
    m.genreList.setFocus(m.genreList.opacity = 1)
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    loadInitialItems()
end sub

sub createItemGrid(itemGridID = "itemGrid" as string)
    m.itemGrid = createObject("rosgnode", "LibraryItemGrid")
    m.itemGrid.id = itemGridID
    m.itemGrid.itemSpacing = "[20, 20]"
    m.itemGrid.vertFocusAnimationStyle = "fixed"
    m.itemGrid.observeField("itemFocused", "onItemFocused")
    m.itemGrid.observeFieldScoped("itemSelected", "onItemSelected")
    m.itemGrid.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    if isStringEqual(m.view, "Episodes")
        m.itemGrid.itemComponentName = "GridItemMedium"
    else
        m.itemGrid.itemComponentName = "GridItemSmall"
    end if
    m.top.insertChild(m.itemGrid, 1)
    m.itemGridMove.fieldToInterp = (bslib_toString(m.itemGrid.id) + ".translation")
end sub

sub onSortOrderChange(sortOrderChoice)
    if not isChainValid(sortOrderChoice, "name") then
        return
    end if
    if m.sortAscending = isStringEqual(sortOrderChoice.LookupCI("name"), "ascending") then
        return
    end if
    m.dropdownOptionGroup.callfunc("setFocus", "sortOrderButton", false)
    m.itemGrid.setFocus(m.itemGrid.opacity = 1)
    m.genreList.setFocus(m.genreList.opacity = 1)
    m.sortAscending = isStringEqual(sortOrderChoice.LookupCI("name"), "Ascending")
    m.dropdownOptionGroup.callfunc("setSortAscending", m.sortAscending)
    m.dropdownOptionGroup.callfunc("setText", "sortOrderButton", tr(sortOrderChoice.LookupCI("title")))
    set_user_setting("display." + m.top.parentItem.Id + ".sortAscending", m.sortAscending.toStr())
    m.loadedRows = 0
    m.loadedItems = 0
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    loadInitialItems()
end sub

sub onLibrarySettingsSelected()
    m.global.sceneManager.callFunc("librarySettingDialog", tr("Library Settings"))
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if isStringEqual(key, "down")
        if m.alphaMenu.isinFocusChain()
            if m.alphaMenu.itemFocused = m.alphaMenu.numRows - 1
                m.librarySettings.setFocus(true)
                m.librarySettings.highlighted = true
                return true
            end if
        end if
        if m.librarySettings.isinFocusChain()
            alphaDisplayed = m.alpha.callFunc("getDisplay")
            if not alphaDisplayed then
                return true
            end if
            m.librarySettings.highlighted = false
            m.alphaMenu.setFocus(true)
            m.alphaMenu.jumpToItem = 0
            return true
        end if
    end if
    if isStringEqual(key, "up")
        if m.alphaMenu.isinFocusChain()
            if m.alphaMenu.itemFocused = 0
                m.librarySettings.setFocus(true)
                m.librarySettings.highlighted = true
                return true
            end if
        end if
        if m.librarySettings.isinFocusChain()
            alphaDisplayed = m.alpha.callFunc("getDisplay")
            if not alphaDisplayed then
                return true
            end if
            m.librarySettings.highlighted = false
            m.alphaMenu.setFocus(true)
            m.alphaMenu.jumpToItem = m.alphaMenu.numRows - 1
            return true
        end if
        if m.itemGrid.isinFocusChain() or m.genreList.isinFocusChain()
            ' In case user quickly moves out of grid without focused row getting updated
            if m.dropdownOptionGroup.opacity < 1
                toggleDropdownOptions(true)
            end if
            if m.genreList.isinFocusChain() then
                activeGrid = m.genreList
            else
                activeGrid = m.itemGrid
            end if
            if m.genreList.isinFocusChain() then
                numColumns = m.genreList.content.getChild(0).getChildCount()
            else
                numColumns = m.itemGrid.numColumns
            end if
            overhangButton = m.dropdownOptionGroup.callfunc("getOverhangingButton", numColumns, activeGrid.currFocusColumn)
            m.global.sceneManager.observeFieldScoped("returnData", "onReturnData")
            if overhangButton.isSubType("VoiceTextEditBox")
                m.dropdownOptionGroup.callfunc("setSearchBackground", 0)
            else
                m.dropdownOptionGroup.callfunc("setFocus", overhangButton.id, true)
            end if
            overhangButton.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = overhangButton
            return true
        end if
    end if
    if isStringEqual(key, "back")
        ' If user pressed back whole scrolled down the grid, reset to item 1
        if m.itemGrid.isinFocusChain() or m.genreList.isinFocusChain()
            if m.itemGrid.isinFocusChain() then
                gridComponent = m.itemGrid
            else
                gridComponent = m.genreList
            end if
            if gridComponent.itemFocused = 0
                reclaimResources()
                m.global.sceneManager.callfunc("popScene")
                return true
            end if
            gridComponent.jumpToItem = 0
            return true
        end if
        reclaimResources()
        m.global.sceneManager.callfunc("popScene")
        return true
    end if
    if isStringEqual(key, "play")
        itemToPlay = getItemFocused()
        if isValid(itemToPlay)
            ' If user presses play on a photo, load it normally instead of using quickplay so they can start a slideshow
            if isStringEqual("photo", chainLookupReturn(itemToPlay, "type", ""))
                m.itemGrid.itemSelected = m.itemGrid.itemFocused
                return true
            end if
            m.top.quickPlayNode = itemToPlay
            return true
        end if
    end if
    if isStringEqual(key, "left")
        alphaDisplayed = m.alpha.callFunc("getDisplay")
        if not alphaDisplayed
            if not m.librarySettings.highlighted
                m.librarySettings.setFocus(true)
                m.librarySettings.highlighted = true
            end if
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.librarySettings
            return true
        end if
        if m.itemGrid.isinFocusChain()
            m.top.alphaActive = true
            m.itemGrid.setFocus(false)
            m.alphaMenu.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.alphaMenu
            return true
        else if m.genreList.isinFocusChain()
            m.top.alphaActive = true
            m.genreList.setFocus(false)
            m.alphaMenu.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.alphaMenu
            return true
        end if
    end if
    if isStringEqual(key, "right")
        if m.alpha.isinFocusChain() or m.librarySettings.isinFocusChain()
            m.librarySettings.highlighted = false
            m.top.alphaActive = false
            m.alphaMenu.setFocus(false)
            if m.loadedItems = 0
                m.global.sceneManager.observeFieldScoped("returnData", "onReturnData")
                m.dropdownOptionGroup.callfunc("setFocus", "voiceBox", true)
                m.dropdownOptionGroup.callfunc("setSearchBackground", 0)
            else
                m.itemGrid.setFocus(m.itemGrid.opacity = 1)
                m.genreList.setFocus(m.genreList.opacity = 1)
                group = m.global.sceneManager.callFunc("getActiveScene")
                if m.itemGrid.opacity = 1 then
                    group.lastFocus = m.itemGrid
                else
                    group.lastFocus = m.genreList
                end if
            end if
            return true
        end if
    end if
    if isStringEqual(key, "options")
        m.showOptionMenu = true
        focusedItem = getItemFocused()
        if not isValid(focusedItem) then
            return false
        end if
        m.loadItemsTask1.itemId = focusedItem.LookupCI("id")
        m.loadItemsTask1.observeField("content", "onItemDataLoaded")
        m.loadItemsTask1.itemsToLoad = "metaData"
        m.loadItemsTask1.control = "RUN"
        return true
    end if
    return false
end function

sub onMyListLoaded()
    isInMyListData = m.isInMyListTask.content
    m.isInMyListTask.unobserveField("content")
    m.isInMyListTask.content = []
    m.isInMyListTask.control = "STOP"
    if not isValidAndNotEmpty(isInMyListData) then
        return
    end if
    focusedItem = getItemFocused()
    if not isValid(focusedItem) then
        return
    end if
    dialogData = []
    if inArray([
        "boxset"
        "boxsets"
    ], getCollectionType())
        dialogData.push(tr("Shuffle Play Collection"))
    end if
    if isInMyListData[0] then
        myListOption = tr("Remove From My List")
    else
        myListOption = tr("Add To My List")
    end if
    dialogData.push(myListOption)
    dialogData.push(m.favoritesOptionText)
    dialogData.push(tr("Add To Playlist"))
    paramData = {
        id: focusedItem.LookupCI("id")
    }
    if isChainValid(focusedItem, "watched")
        if focusedItem.watched
            dialogData.push(tr("Mark As Unplayed"))
        else
            dialogData.push(tr("Mark As Played"))
        end if
    end if
    if inArray([
        "episode"
        "season"
    ], focusedItem.LookupCI("type"))
        dialogData.push(tr("Go To Series"))
        dialogData.push(tr("Go To Season"))
        paramData.SeasonId = focusedItem.json.LookupCI("SeasonId")
        paramData.SeriesId = focusedItem.json.LookupCI("SeriesId")
    end if
    m.global.sceneManager.callFunc("optionDialog", "libraryitem", (function(focusedItem, tr)
            __bsConsequent = focusedItem.LookupCI("title")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return tr("Options")
            end if
        end function)(focusedItem, tr), [], dialogData, paramData)
end sub

sub reclaimResources()
    m.loadItemsTask.control = "STOP"
    m.loadItemsTask.content = []
    m.data = CreateObject("roSGNode", "ContentNode")
    m.itemGrid.content = m.data
    m.genreData = CreateObject("roSGNode", "ContentNode")
    m.genreList.content = m.genreData
    m.global.sceneManager.unobserveFieldScoped("returnData")
end sub
'//# sourceMappingURL=./VisualLibraryScene.brs.map