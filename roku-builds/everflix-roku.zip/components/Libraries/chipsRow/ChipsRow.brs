'import "pkg:/source/enums/AnimationControl.bs"
'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/DropdownMenuID.bs"
'import "pkg:/source/enums/ExitDirection.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/SearchButtonState.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.totalCount = m.top.findNode("totalCount")
    m.chips = m.top.findNode("chips")
end sub

sub setTotalCount(countValue)
    if not isValid(m.totalCount) then
        return
    end if
    m.totalCount.text = toString(countValue)
    m.totalCount.callFunc("show")
end sub

sub addChip(chipID, title, textValue)
    if not isStringEqual(title, "")
        title = (bslib_toString(title) + ": ")
    end if
    filterChip = m.top.findNode(chipID)
    if not isValid(filterChip)
        filterChip = CreateObject("roSGNode", "Chip")
        filterChip.fontSize = "25"
        filterChip.height = "50"
        filterChip.width = "300"
        filterChip.text = (bslib_toString(title) + bslib_toString(textValue))
        filterChip.id = chipID
        filterChip.color = "#ffffff"
        filterChip.background = "0xFFFFFF50"
        m.chips.appendChild(filterChip)
        filterChip.callFunc("show")
        return
    end if
    filterChip.text = (bslib_toString(title) + bslib_toString(textValue))
end sub

sub removeChip(chipID)
    filterChip = m.top.findNode(chipID)
    if not isValid(filterChip) then
        return
    end if
    filterChip.callFunc("remove")
end sub
'//# sourceMappingURL=./ChipsRow.brs.map