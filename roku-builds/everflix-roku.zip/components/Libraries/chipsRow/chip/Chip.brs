'import "pkg:/source/enums/AnimationControl.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.buttonBackground = m.top.findNode("buttonBackground")
    m.buttonText = m.top.findNode("buttonText")
    m.toggleAnimation = m.top.findNode("toggleAnimation")
    m.backgroundFade = m.top.findNode("backgroundFade")
    m.textFade = m.top.findNode("textFade")
    m.backgroundHeight = m.top.findNode("backgroundHeight")
    m.textHeight = m.top.findNode("textHeight")
    m.top.observeField("background", "onBackgroundChanged")
    m.top.observeField("color", "onColorChanged")
    m.top.observeField("text", "onTextChanged")
    m.top.observeField("height", "onHeightChanged")
    m.top.observeField("width", "onWidthChanged")
    m.top.observeField("fontSize", "onFontSizeChanged")
end sub

sub onHeightChanged()
    m.backgroundHeight.keyValue = [
        m.top.height
        0
    ]
    m.textHeight.keyValue = [
        m.top.height
        0
    ]
end sub

sub show()
    if m.buttonBackground.opacity <> 0 then
        return
    end if
    m.backgroundFade.reverse = true
    m.textFade.reverse = true
    m.backgroundHeight.reverse = true
    m.textHeight.reverse = true
    m.toggleAnimation.control = "start"
end sub

sub remove()
    if m.buttonBackground.opacity = 0 then
        return
    end if
    m.backgroundFade.reverse = false
    m.textFade.reverse = false
    m.backgroundHeight.reverse = false
    m.textHeight.reverse = false
    m.toggleAnimation.control = "start"
    m.toggleAnimation.observeFieldScoped("state", "onHideAnimationCompleted")
end sub

sub onHideAnimationCompleted()
    if not isStringEqual(m.toggleAnimation.state, "stopped") then
        return
    end if
    m.top.getParent().removeChild(m.top)
end sub

sub onFontSizeChanged()
    if m.top.fontSize > 0
        m.buttonText.font.size = m.top.fontSize
    end if
end sub

sub onBackgroundChanged()
    m.buttonBackground.blendColor = m.top.background
    m.top.unobserveField("background")
end sub

sub onColorChanged()
    m.buttonText.color = m.top.color
    m.top.unobserveField("color")
end sub

sub onTextChanged()
    m.buttonText.text = m.top.text
end sub

sub onWidthChanged()
    m.buttonBackground.width = m.top.width
    m.buttonText.maxWidth = m.top.width
end sub
'//# sourceMappingURL=./Chip.brs.map