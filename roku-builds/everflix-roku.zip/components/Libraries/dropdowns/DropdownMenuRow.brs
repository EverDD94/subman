'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/DropdownMenuID.bs"
'import "pkg:/source/enums/ExitDirection.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/SearchButtonState.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.searchButtonDisabled = false
    m.sortAscending = true
    m.voiceBox = m.top.findNode("voiceBox")
    m.voiceBoxBackground = m.top.findNode("voiceBoxBackground")
    m.voiceBox.observeFieldScoped("text", "onvoiceFilter")
    if not m.global.device.hasVoiceRemote
        m.voiceBox.backgroundUri = "pkg:/images/transparent.png"
        m.voiceBox.translation = "[15, 0]"
        m.voiceBox.width = m.voiceBox.width - 15
    else
        searchPoster = m.voiceBox.getChild(0)
        if isChainValid(searchPoster, "bitmap")
            searchPoster.bitmap = ""
            searchPoster.blendColor = "#ffffff"
        end if
        searchText = m.voiceBox.getChild(1)
        if isChainValid(searchText, "height")
            searchText.vertAlign = "bottom"
            searchText.height = 37
        end if
        m.micIcon = m.voiceBox.getChild(6)
        if isValid(m.micIcon)
            m.micIcon.observeFieldScoped("blendColor", "onMicIconBlendColorChange")
        end if
    end if
    m.sortButton = m.top.findNode("sortButton")
    m.sortButton.textColor = "#161A22"
    m.sortButton.focusTextColor = "#ffffff"
    m.sortButton.background = "#ffffff"
    m.sortButton.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    m.sortOrderButton = m.top.findNode("sortOrderButton")
    m.sortOrderButton.textColor = "#161A22"
    m.sortOrderButton.focusTextColor = "#ffffff"
    m.sortOrderButton.background = "#ffffff"
    m.sortOrderButton.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    m.filterButton = m.top.findNode("filterButton")
    m.filterButton.textColor = "#161A22"
    m.filterButton.focusTextColor = "#ffffff"
    m.filterButton.background = "#ffffff"
    m.filterButton.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    m.viewButton = m.top.findNode("viewButton")
    m.viewButton.textColor = "#161A22"
    m.viewButton.focusTextColor = "#ffffff"
    m.viewButton.background = "#ffffff"
    m.viewButton.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    setSearchBackground(1)
end sub

sub onMicIconBlendColorChange()
    ' DARKGREY: 269488383
    ' WHITE: -1
    ' LIGHTGREY: -1431655681
    ' HIGHLIGHT: -9934849
    if m.voiceBoxBackground.blendColor = -9934849
        if m.micIcon.blendColor <> -1
            m.micIcon.blendColor = "#ffffff"
        end if
    else
        if m.micIcon.blendColor <> 269488383
            m.micIcon.blendColor = "#161A22"
        end if
    end if
end sub

sub setSearchHintText(value as string)
    if isStringEqual(value, "") then
        m.voiceBox.hintText = tr("Press OK to type")
    else
        m.voiceBox.hintText = value
    end if
end sub

sub onvoiceFilter()
    onVoiceEnabledChange()
    if not isValidAndNotEmpty(m.voiceBox.text) then
        return
    end if
    unfocusAllButtons(invalid)
    searchTerm = m.voiceBox.text.trim()
    if isStringEqual(searchTerm, "reset search") then
        searchTerm = ""
    end if
    if isStringEqual(searchTerm, "clear search") then
        searchTerm = ""
    end if
    m.voiceBox.unObserveFieldScoped("text")
    ' Voice input sets the text, but we don't want the text value set since it messes up
    ' moving focus from the box to other controls (it moves through each letter without any real visual change)
    m.voiceBox.text = ""
    m.voiceBox.observeFieldScoped("text", "onvoiceFilter")
    m.top.searchTerm = searchTerm
end sub

sub setText(nodeID as string, textValue as string)
    textNode = m.top.findNode(nodeID)
    if isValid(textNode)
        textNode.text = textValue
    end if
end sub

sub setDisabled(nodeID as string, value as boolean)
    buttonNode = m.top.findNode(nodeID)
    if isValid(buttonNode)
        buttonNode.disabled = value
    end if
end sub

' Using the user's cursor position, determine which dropdown is above them
function getOverhangingButton(numColumns as integer, currFocusColumn as integer)
    if numColumns = 4
        shortButtonList = [
            m.voiceBox
            m.sortButton
            m.filterButton
            m.viewButton
        ]
        return shortButtonList[currFocusColumn]
    end if
    buttonList = [
        m.voiceBox
        m.sortButton
        m.sortOrderButton
        m.filterButton
        m.viewButton
    ]
    columnDisplacement = (numColumns / buttonList.count())
    calculatedButtonIndex = CInt(((currFocusColumn + 1) / columnDisplacement) - 1)
    if calculatedButtonIndex < 0 then
        calculatedButtonIndex = 0
    end if
    if calculatedButtonIndex >= buttonList.count() then
        calculatedButtonIndex = buttonList.count() - 1
    end if
    return buttonList[calculatedButtonIndex]
end function

sub setFocus(nodeID as string, value as boolean)
    buttonNode = m.top.findNode(nodeID)
    if isValid(buttonNode)
        buttonNode.focus = value
        buttonNode.setFocus(value)
        if value
            group = m.global.sceneManager.callFunc("getActiveScene")
            if isValid(group)
                group.lastFocus = buttonNode
            end if
        end if
    end if
end sub

' _ is an unused param. It exists only because unfocusAllButtons is exposed
' ref: https://github.com/rokucommunity/brighterscript/blob/master/docs/callfunc-operator.md#callfunc-evaluation-with-no-arguments
sub unfocusAllButtons(_ as dynamic)
    setSearchBackground(1)
    m.sortButton.focus = false
    m.sortOrderButton.focus = false
    m.filterButton.focus = false
    m.viewButton.focus = false
end sub

sub setSearchBackground(state)
    if state = 0
        if m.searchButtonDisabled
            m.voiceBox.textColor = "#777777"
            m.voiceBox.hintTextColor = "#777777"
            m.voiceBoxBackground.blendColor = "#161A22"
            return
        end if
        m.voiceBox.textColor = "#ffffff"
        m.voiceBox.hintTextColor = "#ffffff"
        m.voiceBoxBackground.blendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
        return
    end if
    if state = 2
        m.voiceBox.textColor = "#161A22"
        m.voiceBox.hintTextColor = "#161A22"
        m.voiceBoxBackground.blendColor = "#777777"
        return
    end if
    m.voiceBox.textColor = "#777777"
    m.voiceBox.hintTextColor = "#777777"
    m.voiceBoxBackground.blendColor = "#ffffff"
end sub

sub setOptionData(optionData)
    m.optionData = optionData
end sub

sub setSortAscending(sortAscending as boolean)
    m.sortAscending = sortAscending
end sub

' VoiceTextEditBox.voiceEnabled doesn't have alwaysNotify enabled
' To trigger a change event, we must change the value to something else, then back to the value we want
sub onVoiceEnabledChange()
    m.voiceBox.voiceEnabled = m.searchButtonDisabled
    m.voiceBox.voiceEnabled = not m.searchButtonDisabled
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if not m.top.isinFocusChain() then
        return false
    end if
    if isStringEqual(key, "down")
        if not m.top.canExitDown then
            return false
        end if
        unfocusAllButtons(invalid)
        m.top.exit = 0
        return true
    end if
    if isStringEqual(key, "left")
        if m.voiceBox.isinFocusChain()
            unfocusAllButtons(invalid)
            m.top.exit = 1
            return true
        end if
        if m.sortButton.isinFocusChain()
            m.voiceBox.setFocus(true)
            setSearchBackground(0)
            m.sortButton.focus = false
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.voiceBox
            return true
        end if
        if m.sortOrderButton.isinFocusChain()
            m.sortButton.focus = true
            m.sortButton.setFocus(true)
            m.sortOrderButton.focus = false
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.sortButton
            return true
        end if
        if m.filterButton.isinFocusChain()
            m.filterButton.focus = false
            m.sortOrderButton.focus = true
            m.sortOrderButton.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.sortOrderButton
            return true
        end if
        if m.viewButton.isinFocusChain()
            m.viewButton.focus = false
            m.filterButton.focus = true
            m.filterButton.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.filterButton
            return true
        end if
        return false
    end if
    if isStringEqual(key, "right")
        if m.voiceBox.isinFocusChain()
            setSearchBackground(1)
            m.sortButton.focus = true
            m.sortButton.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.sortButton
            return true
        end if
        if m.sortButton.isinFocusChain()
            m.sortButton.focus = false
            m.sortOrderButton.focus = true
            m.sortOrderButton.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.sortOrderButton
            return true
        end if
        if m.sortOrderButton.isinFocusChain()
            m.sortOrderButton.focus = false
            m.filterButton.focus = true
            m.filterButton.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.filterButton
            return true
        end if
        if m.filterButton.isinFocusChain()
            m.filterButton.focus = false
            m.viewButton.focus = true
            m.viewButton.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = m.viewButton
            return true
        end if
        return false
    end if
    if isStringEqual(key, "OK")
        if m.voiceBox.isinFocusChain()
            if m.searchButtonDisabled
                m.global.sceneManager.callFunc("standardDialog", "Search Unavailable", {
                    data: [
                        ("<p>" + bslib_toString(m.disabledReason) + "</p>")
                    ]
                })
                return false
            end if
            buttonData = [
                tr("Search")
            ]
            if isStringEqual(m.voiceBox.hintText.trim(), tr("Press OK to type")) then
                hintText = ""
            else
                hintText = m.voiceBox.hintText
            end if
            m.global.sceneManager.callFunc("keyboardDialog", "searchLibrary", tr("Search this library"), [
                ""
            ], buttonData, hintText, m.top.parentItemID)
            return true
        end if
        if m.sortButton.isinFocusChain()
            if m.sortButton.disabled then
                return false
            end if
            sortData = {
                data: m.optionData.sort
            }
            m.global.sceneManager.callFunc("radioDialog", tr("Sort By"), sortData, invalid, "librarySortBy")
            return true
        end if
        if m.sortOrderButton.isinFocusChain()
            if m.sortOrderButton.disabled then
                return false
            end if
            sortOrderData = {
                data: [
                    {
                        Title: tr("Ascending")
                        Name: "ascending"
                        Track: {
                            description: tr("Ascending")
                        }
                    }
                    {
                        Title: tr("Descending")
                        Name: "descending"
                        Track: {
                            description: tr("Descending")
                        }
                    }
                ]
            }
            if m.sortAscending
                sortOrderData.data[0].selected = true
            else
                sortOrderData.data[1].selected = true
            end if
            m.global.sceneManager.callFunc("radioDialog", tr("Sort Order"), sortOrderData, invalid, "librarySortOrder")
            return true
        end if
        if m.filterButton.isinFocusChain()
            if m.filterButton.disabled then
                return false
            end if
            m.top.showOptions = true
            return true
        end if
        if m.viewButton.isinFocusChain()
            viewData = {
                data: m.optionData.views
            }
            m.global.sceneManager.callFunc("radioDialog", tr("TAB_VIEW"), viewData, invalid, "libraryView")
            return true
        end if
        return false
    end if
    return false
end function

sub disableSearch(disabledReason as string)
    m.disabledReason = disabledReason
    m.searchButtonDisabled = true
    m.voiceBox.voiceEnabled = false
    setSearchHintText(tr("Search Unavailable"))
    setSearchBackground(2)
end sub
'//# sourceMappingURL=./DropdownMenuRow.brs.map