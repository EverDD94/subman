'import "pkg:/source/utils/misc.bs"

sub init()
    m.buttonBackground = m.top.findNode("buttonBackground")
    m.buttonText = m.top.findNode("buttonText")
    m.top.observeField("background", "onBackgroundChanged")
    m.top.observeField("color", "onColorChanged")
    m.top.observeField("text", "onTextChanged")
    m.top.observeField("height", "onHeightChanged")
    m.top.observeField("width", "onWidthChanged")
    m.top.observeField("focus", "onFocusChanged")
    m.top.observeField("fontSize", "onFontSizeChanged")
    m.top.observeField("primary", "paint")
    paint()
end sub

sub onFontSizeChanged()
    if m.top.fontSize > 0
        m.buttonText.font.size = m.top.fontSize
    end if
end sub

sub onFocusChanged()
    paint()
end sub

' Everflix pills everywhere, whatever colours the old Jellyfin screens ask for:
' white with black text when focused, otherwise glass (or blue for the main action) with light text
sub paint()
    if m.top.focus
        m.buttonBackground.blendColor = "0xFFFFFFFF"
        m.buttonText.color = "0x000000FF"
    else if m.top.primary
        m.buttonBackground.blendColor = "0x3D63E0FF"
        m.buttonText.color = "0xFFFFFFFF"
    else
        m.buttonBackground.blendColor = "0xFFFFFF26"
        m.buttonText.color = "0xF4F2EEFF"
    end if
end sub

sub onBackgroundChanged()
    paint()
end sub

sub onColorChanged()
    paint()
end sub

sub onTextChanged()
    m.buttonText.text = m.top.text
end sub

sub onHeightChanged()
    m.buttonBackground.height = m.top.height
    m.buttonText.height = m.top.height
end sub

sub onWidthChanged()
    m.buttonBackground.width = m.top.width
    m.buttonText.width = m.top.width
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if key = "right" and m.top.focus
        m.top.escape = "right"
    end if
    if key = "left" and m.top.focus
        m.top.escape = "left"
    end if
    return false
end function
'//# sourceMappingURL=./StandardButton.brs.map