' captionShadow.bs
' Visual effects for caption text: per-line background and outline/shadow
' Ratios relative to fontSize for consistent outline across text sizes
' 8.5 and 6 were chosen based on visual testing to create a balanced outline effect (WAF)
 ' ~8.5% fontSize for cardinal directions
 ' ~6% fontSize for diagonals
 ' Matches lg.translation in captionTask.bs
sub createShadowLabels(rect as object, styledText as string, drawingStyles as object, textEffect as string, bgColor as string)
    fontSize = drawingStyles["default"].fontSize
    outlineStep = Int(fontSize * 0.085)
    outlineDiag = Int(fontSize * 0.06)
    if isStringEqual(textEffect, "None") or isStringEqual(textEffect, "Default")
        ' No shadow labels - Roku's Default visually produces no visible effect, so we treat it as None
        return
    else if isStringEqual(textEffect, "Raised")
        ' Shadow above and to the left, giving the text a raised appearance
        offsets = [
            [
                5 - outlineStep
                5
            ]
            [
                5
                5 - outlineStep
            ]
            [
                5 - outlineDiag
                5 - outlineDiag
            ]
        ]
    else if isStringEqual(textEffect, "Depressed")
        ' Shadow below and to the right, giving the text a depressed appearance
        offsets = [
            [
                5 + outlineStep
                5
            ]
            [
                5
                5 + outlineStep
            ]
            [
                5 + outlineDiag
                5 + outlineDiag
            ]
        ]
    else if isStringEqual(textEffect, "Drop shadow (left)")
        ' Single diagonal shadow to the bottom-left
        offsets = [
            [
                5 - outlineDiag
                5 + outlineDiag
            ]
        ]
    else if isStringEqual(textEffect, "Drop shadow (right)")
        ' Single diagonal shadow to the bottom-right
        offsets = [
            [
                5 + outlineDiag
                5 + outlineDiag
            ]
        ]
    else
        ' Uniform and any unrecognized value
        ' 4 cardinals (large step) + 4 diagonals (small step) = uniform outline
        ' Offset base [5,5] compensates for lg.translation = [5,5] in captionTask.bs
        ' so shadow labels align with the main text label
        offsets = [
            [
                5
                5 - outlineStep
            ]
            [
                5
                5 + outlineStep
            ]
            [
                5 - outlineStep
                5
            ]
            [
                5 + outlineStep
                5
            ]
            [
                5 - outlineDiag
                5 - outlineDiag
            ]
            [
                5 + outlineDiag
                5 - outlineDiag
            ]
            [
                5 - outlineDiag
                5 + outlineDiag
            ]
            [
                5 + outlineDiag
                5 + outlineDiag
            ]
        ]
    end if
    ' Use grey shadow when background is fully opaque black, Roku default behavior
    shadowColor = "0x000000CC"
    if isStringEqual(bgColor, "0x000000FF")
        shadowColor = "0x808080CC"
    end if
    shadowDrawingStyles = {}
    for each key in drawingStyles.keys()
        style = drawingStyles[key]
        shadowDrawingStyles[key] = {
            "fontUri": style.fontUri
            "fontSize": style.fontSize
            "color": shadowColor
        }
    end for
    for each offset in offsets
        lbl = CreateObject("roSGNode", "MultiStyleLabel")
        lbl.drawingStyles = shadowDrawingStyles
        lbl.text = styledText
        lbl.horizAlign = "center"
        lbl.translation = offset
        ' Append after backgrounds, before lg is moved to top in captionTask.bs
        rect.appendchild(lbl)
    end for
end sub

sub createCueBackgroundBox(rect as object, lg as object, styledText as string, drawingStyles as object, bgColor as string, lineHeights as object)
    ' Skip if background is fully transparent
    if bgColor.right(2) = "00" then
        return
    end if
    ' Reconstruct line fragments from styledText — splitting on \n while preserving open tags across lines
    lineFragments = reconstructFragments(styledText)
    ' Verify the tree is ready and get a reference to the main label for measurement
    mainLabel = invalid
    for i = 0 to lg.getChildCount() - 1
        if isStringEqual(lg.getChild(i).subtype(), "MultiStyleLabel")
            mainLabel = lg.getChild(i)
            exit for
        end if
    end for
    if not isValid(mainLabel) then
        return
    end if
    ' Determine which height to use (same for all lines)
    lineHeight = 0
    if lineFragments.count() = 1
        lineHeight = lineHeights.single
    else
        lineHeight = lineHeights.multi
    end if
    ' Measure per-line widths
    lineWidths = []
    for each line in lineFragments
        tempLabel = CreateObject("roSGNode", "MultiStyleLabel")
        tempLabel.drawingStyles = drawingStyles
        tempLabel.text = line
        lg.appendchild(tempLabel)
        br = tempLabel.boundingRect()
        lineWidths.push(br.width)
        lg.removeChild(tempLabel)
    end for
    maxWidth = 0
    for each w in lineWidths
        if w > maxWidth
            maxWidth = w
        end if
    end for
    fontSize = drawingStyles["default"].fontSize
    bgPadding = Int(fontSize * 0.085) + 1
    ' Last line uses singleLineHeight since there's no next line's leading to reserve
    ' bgPadding applied vertically too (top of first line, bottom of last) so it covers shadow spillover on all sides, not just left/right
    lastLineIndex = lineFragments.count() - 1
    for i = 0 to lastLineIndex
        isFirstLine = (i = 0)
        isLastLine = (i = lastLineIndex)
        boxHeight = lineHeight
        if isLastLine and lineFragments.count() > 1
            boxHeight = lineHeights.single
        end if
        extraTop = 0
        if isFirstLine
            extraTop = bgPadding
        end if
        extraBottom = 0
        if isLastLine
            extraBottom = bgPadding
        end if
        bg = CreateObject("roSGNode", "Rectangle")
        bg.height = boxHeight + extraTop + extraBottom
        bg.color = bgColor
        bg.width = lineWidths[i] + (bgPadding * 2)
        bg.translation = [
            (maxWidth - lineWidths[i]) / 2 + 5 - bgPadding
            i * lineHeight + 5 - extraTop
        ]
        rect.insertChild(bg, 0)
    end for
end sub

function createWindowBackground(id as string, styledText as string, textY as integer, bgColor as string, lineHeights as object) as object
    if not isValid(bgColor) then
        return invalid
    end if
    if isStringEqual(bgColor.right(2), "00") then
        return invalid
    end if
    lineCount = styledText.split(chr(10)).count()
    totalHeight = lineHeights.single
    if lineCount > 1
        totalHeight = lineHeights.multi * lineCount
    end if
    windowBg = CreateObject("roSGNode", "Rectangle")
    windowBg.addreplace("id", id + "_window")
    windowBg.color = bgColor
    windowBg.width = 1536
    windowBg.height = totalHeight + (5 * 2) ' Add vertical padding to match text shadow offset
    windowBg.translation = [
        (1920 - windowBg.width) / 2
        textY
    ]
    return windowBg
end function

function reconstructFragments(styledText as string) as object
    fragments = styledText.split(chr(10))
    result = []
    openTag = ""
    for each fragment in fragments
        if not isStringEqual(openTag, "")
            fragment = openTag + fragment
        end if
        openTag = ""
        tagPos = 0
        while true
            tagStart = instr(tagPos, fragment, "<")
            if tagStart = 0 then
                exit while
            end if
            tagEnd = instr(tagStart, fragment, ">")
            if tagEnd = 0 then
                exit while
            end if
            tag = mid(fragment, tagStart, tagEnd - tagStart + 1)
            if isStringEqual(left(tag, 2), "</")
                openTag = ""
            else
                openTag = tag
            end if
            tagPos = tagEnd + 1
        end while
        if not isStringEqual(openTag, "")
            closeTag = "</" + mid(openTag, 2)
            fragment = fragment + closeTag
        end if
        result.push(fragment)
    end for
    return result
end function
'//# sourceMappingURL=./captionShadow.brs.map