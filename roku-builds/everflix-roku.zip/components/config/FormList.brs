'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.top.itemComponentName = "FormElement"
    m.top.drawFocusFeedback = True
    m.top.vertFocusAnimationStyle = "floatingFocus"
    m.top.observeField("itemSelected", "onItemSelected")
    m.top.itemSize = [
        750
        75
    ]
    m.top.itemSpacing = [
        0
        25
    ]
    m.top.setfocus(true)
end sub

sub setData()
    items = m.top.configItems
    data = CreateObject("roSGNode", "ContentNode")
    data.appendChildren(items)
    m.top.content = data
    ' Cached here (not in init) since content isn't populated until configItems changes
    m.itemCount = data.getChildCount()
end sub

sub onItemSelected()
    i = m.top.itemSelected
    ' Remember which index is being edited so we know where to jump
    ' after confirming (next field, or out of the list if it's the last one)
    m.currentIndex = i
    itemField = m.top.content.getchild(i)
    formListShowDialog(itemField)
end sub

function onDialogButton()
    d = m.dialog
    button_text = d.buttons[d.buttonSelected]
    if button_text = tr("OK")
        m.configField.value = d.text
        dismiss_dialog()
        if isValidAndNotEmpty(d.text)
            advanceFocus()
        end if
        return true
    else if button_text = tr("Cancel")
        dismiss_dialog()
        return true
    end if
    return false
end function

' Moves focus to the next form field after confirming one.
' If it was the last field, notify the outside world (SigninScene) via
' allFieldsSubmitted instead of trying to navigate within the list.
sub advanceFocus()
    nextIndex = m.currentIndex + 1
    if nextIndex < m.itemCount
        m.top.jumpToItem = nextIndex
    else
        m.top.allFieldsSubmitted = not m.top.allFieldsSubmitted
    end if
end sub

sub formListShowDialog(configField)
    dialog = createObject("roSGNode", "StandardKeyboardDialog")
    m.configField = configField
    dialog.title = configField.label
    dialog.buttons = [
        tr("OK")
        tr("Cancel")
    ]
    m.greenPalette = createObject("roSGNode", "RSGPalette")
    m.greenPalette.colors = {
        DialogBackgroundColor: "0x161A22FF"
        DialogTextColor: "0xF4F2EEFF"
        DialogItemColor: "0xF4F2EEFF"
        DialogSecondaryTextColor: "0x9AA0ADFF"
        DialogSecondaryItemColor: "0x9AA0ADFF"
        DialogFocusColor: "0xFFFFFFFF"
        DialogFocusItemColor: "0x000000FF"
        DialogInputFieldColor: "0x0B0D12FF"
        DialogKeyboardColor: "0x262B37FF"
        DialogFootprintColor: "0x3D63E0FF"
    }
    dialog.palette = m.greenPalette
    if configField.type = "password"
        dialog.textEditBox.secureMode = true
    end if
    if configField.value <> ""
        dialog.text = configField.value
    end if
    m.top.getscene().dialog = dialog
    m.dialog = dialog
    dialog.observeField("buttonSelected", "onDialogButton")
end sub

sub dismiss_dialog()
    m.dialog.close = true
end sub
'//# sourceMappingURL=./FormList.brs.map