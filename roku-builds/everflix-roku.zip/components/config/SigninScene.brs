'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/PosterLoadStatus.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/utils/misc.bs"


sub onProfileImageUriChange()
    if not isValid(m.top.profileImageUri)
        m.top.profileImageUri = "pkg:/images/baseline_person_white_48dp.png"
    end if
    if isStringEqual(m.top.profileImageUri, "")
        m.top.profileImageUri = "pkg:/images/baseline_person_white_48dp.png"
    end if
    m.profileImage.uri = m.top.profileImageUri
end sub

sub onPosterLoadStatusChanged()
    if m.profileImage.loadStatus <> "loading"
        m.profileImage.unobserveField("loadStatus")
    end if
    if isStringEqual(m.profileImage.loadStatus, "failed")
        m.top.profileImageUri = "pkg:/images/baseline_person_white_48dp.png"
    end if
end sub

sub init()
    m.top.setFocus(true)
    m.top.optionsAvailable = false
    m.profileImage = m.top.findNode("overlayCurrentUserProfileImage")
    m.profileImage.observeField("loadStatus", "onPosterLoadStatusChanged")
    m.submit = m.top.findNode("submit")
    m.submit.primary = true
    m.quickConnect = m.top.findNode("quickConnect")
    m.errorContainer = m.top.findNode("errorContainer")
    m.errorContainer.color = "0xC0392BFF"
    m.config = m.top.findNode("configOptions")
    m.config.focusBitmapUri = "pkg:/images/everflix/focus-ring.9.png"
    m.config.focusBitmapBlendColor = "0xFFFFFFFF"
    m.config.focusFootprintBlendColor = "0x00000000"
    ' When the last form field is confirmed, jump focus straight to Submit
    m.config.observeField("allFieldsSubmitted", "onAllFieldsSubmitted")
    username_field = CreateObject("roSGNode", "ConfigData")
    username_field.label = "Usuario"
    username_field.type = "string"
    username_field.value = ""
    password_field = CreateObject("roSGNode", "ConfigData")
    password_field.label = "Contraseña"
    password_field.type = "password"
    registryPassword = get_setting("password")
    if isValid(registryPassword)
        password_field.value = registryPassword
    end if
    saveCredentials = m.top.findNode("saveCredentials")
    saveCredentials.focusedColor = "0xFFFFFFFF"
    saveCredentials.color = "0x9AA0ADFF"
    saveCredentials.font.size = 28
    saveCredentials.focusedFont.size = 28
    if not isStringEqual(get_setting("saveCredentials", "true"), "true")
        saveCredentials.checkedState = "[false]"
    end if
    items = [
        username_field
        password_field
    ]
    m.config.configItems = items
    saveCredentials.checkedIconUri = "pkg:/images/icons/checkboxChecked.png"
    saveCredentials.focusedCheckedIconUri = "pkg:/images/icons/checkboxChecked.png"
    saveCredentials.uncheckedIconUri = "pkg:/images/icons/checkboxUnchecked.png"
    saveCredentials.focusedUncheckedIconUri = "pkg:/images/icons/checkboxUnchecked.png"
end sub

sub onAlertChange()
    m.errorContainer.visible = isValidAndNotEmpty(m.top.alert)
    errorMessage = m.top.findNode("errorMessage")
    errorMessage.text = m.top.alert
end sub

sub onUserChange()
    username_field = m.config.content.getChild(0)
    if isStringEqual(m.top.user, "") and isValid(get_setting("username"))
        username_field.value = get_setting("username")
    else
        username_field.value = m.top.user
    end if
    ' Username has been provided, focus on password field
    if not isStringEqual(username_field.value, "")
        m.config.jumpToItem = 1
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    ' Returns true if user navigates to a new focusable element
    if not press then
        return false
    end if
    list = m.top.findNode("configOptions")
    saveCredentials = m.top.findNode("saveCredentials")
    if key = "back"
        m.top.backPressed = true
        return false
    end if
    if key = "down" and list.isInFocusChain()
        limit = list.content.getChildren(-1, 0).count() - 1
        if limit = list.itemFocused
            saveCredentials.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = saveCredentials
            return true
        end if
        return false
    end if
    if key = "down" and saveCredentials.isInFocusChain()
        m.submit.setFocus(true)
        m.submit.focus = true
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.submit
        return true
    end if
    if key = "up" and m.submit.hasFocus()
        m.submit.focus = false
        saveCredentials.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = saveCredentials
        return true
    end if
    if key = "up" and m.quickConnect.hasFocus()
        m.quickConnect.focus = false
        saveCredentials.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = saveCredentials
        return true
    end if
    if key = "up" and saveCredentials.isInFocusChain()
        list.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = list
        return true
    end if
    if key = "right" and m.submit.hasFocus()
        m.submit.focus = false
        m.quickConnect.setFocus(true)
        m.quickConnect.focus = true
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.quickConnect
        return true
    end if
    if key = "left" and m.quickConnect.hasFocus()
        m.quickConnect.focus = false
        m.submit.setFocus(true)
        m.submit.focus = true
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.submit
        return true
    end if
    if key = "OK"
        if m.quickConnect.hasFocus()
            m.quickConnect.selected = not m.quickConnect.selected
            return true
        end if
        if m.submit.hasFocus()
            m.submit.selected = not m.submit.selected
            return true
        end if
    end if
    return false
end function

' Fired when FormList confirms the last field (Password).
' Jumps focus directly to Submit, skipping the "Save Credentials" checkbox
' -- UX decision: the user can still toggle it manually before submitting.
sub onAllFieldsSubmitted()
    m.submit.setFocus(true)
    m.submit.focus = true
    group = m.global.sceneManager.callFunc("getActiveScene")
    group.lastFocus = m.submit
end sub
'//# sourceMappingURL=./SigninScene.brs.map