'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/Image.bs"
'import "pkg:/source/enums/LiveTVChannelTitle.bs"
'import "pkg:/source/utils/config.bs"

sub setFields()
    ' Callers building many rows at once can pass the title setting in to avoid each
    ' row re-reading it from m.global (which allocates a regex per call).
    if not isStringEqual(m.top.titleFormat, "")
        channelTitleContent = m.top.titleFormat
    else
        channelTitleContent = chainLookupReturn(m.global.session, "user.settings.tvChannelTitleInfo", "numberName")
    end if
    json = m.top.json
    m.top.id = json.id
    m.top.favoriteChannelId = (function(json)
            __bsConsequent = json.ChannelId
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return json.id
            end if
        end function)(json)
    if not isStringEqual(channelTitleContent, "name") and isValid(json.number)
        if isStringEqual(channelTitleContent, "numberName")
            m.top.title = (bslib_toString(tr("CH")) + " " + bslib_toString(json.number) + " " + bslib_toString(json.name))
        else if isStringEqual(channelTitleContent, "number")
            m.top.title = (bslib_toString(tr("CH")) + " " + bslib_toString(json.number))
        end if
    else
        m.top.title = json.name
    end if
    m.top.live = true
    m.top.Type = "TvChannel"
    ' Logo URLs each build a regex; skip them here when the caller will populate
    ' them later off the critical path via populatePoster().
    if not m.top.deferPoster
        setPoster()
    end if
end sub

' Build the channel logo URLs on demand. Used by the TV guide to defer logo work
' until after first paint (see deferPoster).
sub populatePoster()
    setPoster()
end sub

sub setPoster()
    if m.top.image <> invalid
        m.top.posterURL = m.top.image.url
    else if m.top.json.ImageTags <> invalid and m.top.json.ImageTags.Primary <> invalid
        imgParams = {
            "maxHeight": 60
            "Tag": m.top.json.ImageTags.Primary
        }
        m.top.hdsmalliconurl = ImageURL(m.top.json.id, "Primary", imgParams)
        imgParams = {
            "maxHeight": 440
            "maxWidth": 295
            "Tag": m.top.json.ImageTags.Primary
        }
        m.top.posterURL = ImageURL(m.top.json.id, "Primary", imgParams)
    end if
end sub
'//# sourceMappingURL=./ChannelData.brs.map