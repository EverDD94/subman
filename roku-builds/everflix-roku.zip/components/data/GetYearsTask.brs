'import "pkg:/source/api/sdk.bs"
'import "pkg:/source/utils/config.bs"

sub init()
    m.top.functionName = "getYearsTask"
end sub

sub getYearsTask()
    m.top.data = api_years_Get(m.top.params)
end sub
'//# sourceMappingURL=./GetYearsTask.brs.map