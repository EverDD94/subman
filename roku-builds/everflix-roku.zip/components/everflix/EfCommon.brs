' Everflix: shared look and small helpers for the Everflix screens.
'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/Image.bs"
'import "pkg:/source/enums/ImageType.bs"
'import "pkg:/source/utils/misc.bs"










function ef_font(uri as string, size as integer) as object
    f = CreateObject("roSGNode", "Font")
    f.uri = uri
    f.size = size
    return f
end function

' Fields we ask Jellyfin for in every Everflix list
function ef_fields() as string
    return "Overview,Genres,MediaSources,MediaStreams,ParentId,PrimaryImageAspectRatio,ProductionYear,OfficialRating,CommunityRating,ChildCount,RecursiveItemCount"
end function

' Adds ready-made image URLs to a Jellyfin item so the UI thread never builds them.
function ef_decorate(item as object) as object
    if not isValid(item) then
        return item
    end if
    item.efThumb = FirstItemImageURL(item, [
        "Thumb"
        "Backdrop"
        "Primary"
    ], {
        maxWidth: 480
        maxHeight: 270
    })
    if isStringEqual(item.LookupCI("Type"), "Episode")
        ' Episodes show their own frame; the series art is the fallback
        own = ItemImageURL(item, "Primary", {
            maxWidth: 480
            maxHeight: 270
        }, false)
        if isValidAndNotEmpty(own) then
            item.efThumb = own
        end if
    end if
    item.efPoster = ItemImageURL(item, "Primary", {
        maxWidth: 300
        maxHeight: 450
    })
    item.efBackdrop = FirstItemImageURL(item, [
        "Backdrop"
        "Thumb"
        "Primary"
    ], {
        maxWidth: 1920
        maxHeight: 1080
    })
    item.efLogo = ItemImageURL(item, "Logo", {
        maxWidth: 700
        maxHeight: 260
    })
    return item
end function

' Builds a HomeData node (what the rest of the app understands) from a Jellyfin item.
function ef_itemNode(item as object) as object
    node = CreateObject("roSGNode", "HomeData")
    node.json = item
    node.title = item.LookupCI("Name")
    return node
end function

' GET on Jellyfin, returns the parsed JSON or invalid
function ef_getJellyfin(path as string, params = {} as object) as dynamic
    req = APIRequest(path, params)
    if not isValid(req) then
        return invalid
    end if
    return getJson(req)
end function

' Language code to Spanish name, like the Google TV app
function ef_langName(code as dynamic) as string
    if not isValidAndNotEmpty(code) then
        return "Desconocido"
    end if
    c = LCase(code)
    names = {
        spa: "Español"
        es: "Español"
        esp: "Español"
        eng: "Inglés"
        en: "Inglés"
        por: "Portugués"
        pt: "Portugués"
        fre: "Francés"
        fra: "Francés"
        fr: "Francés"
        jpn: "Japonés"
        ja: "Japonés"
        ita: "Italiano"
        it: "Italiano"
        ger: "Alemán"
        deu: "Alemán"
        de: "Alemán"
        und: "Desconocido"
    }
    if names.DoesExist(c) then
        return names[c]
    end if
    return UCase(code)
end function

function ef_isSpanish(code as dynamic) as boolean
    if not isValidAndNotEmpty(code) then
        return false
    end if
    c = LCase(code)
    return c = "spa" or c = "es" or c = "esp"
end function

' Videotecario runs on the same NAS: 8787 at home, 8921 through the https proxy.
function ef_isAdmin() as boolean
    user = m.global.session.user
    if not isValid(user) or not isValid(user.LookupCI("Policy")) then
        return false
    end if
    return user.Policy.LookupCI("IsAdministrator") = true
end function

function ef_videotecarioBase() as string
    server = m.global.session.server.url
    if not isValidAndNotEmpty(server) then
        return ""
    end if
    r = CreateObject("roRegex", "^(https?)://([^/:]+)", "i")
    parts = r.match(server)
    if parts.count() < 3 then
        return ""
    end if
    if LCase(parts[1]) = "https" then
        return "https://" + parts[2] + ":8921"
    end if
    return "http://" + parts[2] + ":8787"
end function
' Asks Main to open an Everflix screen or start playback (see source/Everflix.bs)
sub ef_go(data as object)
    data.selectionType = "ef"
    m.top.getScene().jumpTo = data
end sub
'//# sourceMappingURL=./EfCommon.brs.map