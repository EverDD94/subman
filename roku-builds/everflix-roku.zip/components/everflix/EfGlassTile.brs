'import "pkg:/components/everflix/EfCommon.bs"


sub init()
    m.body = m.top.findNode("body")
    m.ring = m.top.findNode("ring")
    m.bg = m.top.findNode("bg")
    m.icon = m.top.findNode("icon")
    m.label = m.top.findNode("label")
    m.grow = m.top.findNode("grow")
    m.growI = m.top.findNode("growI")
    m.scale = 1.0
end sub

sub paint()
    w = 120
    if m.top.primary then
        w = 240
    end if
    h = 120
    m.bg.width = w
    m.bg.height = h
    m.ring.width = w + 16
    m.ring.height = h + 16
    m.ring.translation = [
        -8
        -8
    ]
    m.body.scaleRotateCenter = [
        w / 2
        h / 2
    ]
    if m.top.icon <> "" then
        m.icon.uri = "pkg:/images/everflix/" + m.top.icon + ".png"
    end if
    m.label.text = m.top.text
    if m.top.primary
        m.bg.blendColor = "0xF4F2EEFF"
        m.icon.width = 36
        m.icon.height = 36
        m.icon.translation = [
            24
            22
        ]
        m.icon.blendColor = "0x000000FF"
        m.label.font = ef_font("pkg:/fonts/archivo_extrabold.ttf", 26)
        m.label.color = "0x000000FF"
        m.label.horizAlign = "left"
        m.label.width = w - 40
        m.label.translation = [
            24
            68
        ]
    else
        m.icon.width = 40
        m.icon.height = 40
        m.icon.translation = [
            (w - 40) / 2
            26
        ]
        if m.top.selected then
            m.icon.blendColor = "0x9DB4FFFF"
        else
            m.icon.blendColor = "0xF4F2EEFF"
        end if
        m.label.font = ef_font("pkg:/fonts/archivo_semibold.ttf", 18)
        m.label.color = "0xF4F2EEFF"
        m.label.horizAlign = "center"
        m.label.width = w - 8
        m.label.translation = [
            4
            78
        ]
    end if
    m.top.pillWidth = w
    onHighlight()
end sub

sub onHighlight()
    on = m.top.highlighted
    m.ring.visible = on
    if not m.top.primary
        if on then
            m.bg.blendColor = "0xFFFFFF47"
        else
            m.bg.blendColor = "0xFFFFFF1A"
        end if
    end if
    if on then
        target = 1.08
    else
        target = 1.0
    end if
    if target = m.scale then
        return
    end if
    m.growI.keyValue = [
        [
            m.scale
            m.scale
        ]
        [
            target
            target
        ]
    ]
    m.scale = target
    m.grow.control = "start"
end sub
'//# sourceMappingURL=./EfGlassTile.brs.map