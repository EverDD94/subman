'import "pkg:/components/everflix/EfCommon.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.badge = m.top.findNode("badge")
    m.badgeBg = m.top.findNode("badgeBg")
    m.badgeLabel = m.top.findNode("badgeLabel")
    m.meta = m.top.findNode("meta")
    m.title = m.top.findNode("title")
    m.episode = m.top.findNode("episode")
    m.left = m.top.findNode("left")
    m.bar = m.top.findNode("bar")
    m.barFill = m.top.findNode("barFill")
    m.overview = m.top.findNode("overview")
    m.episodeRow = m.top.findNode("episodeRow")
    m.badgeLabel.font = ef_font("pkg:/fonts/archivo_extrabold.ttf", 20)
    m.meta.font = ef_font("pkg:/fonts/archivo_semibold.ttf", 21)
    m.title.font = ef_font("pkg:/fonts/archivo_extrabold.ttf", 84)
    m.episode.font = ef_font("pkg:/fonts/archivo_semibold.ttf", 27)
    m.left.font = ef_font("pkg:/fonts/archivo_regular.ttf", 27)
    m.overview.font = ef_font("pkg:/fonts/archivo_regular.ttf", 27)
    m.top.findNode("previewLabel").font = ef_font("pkg:/fonts/archivo_semibold.ttf", 21)
end sub

sub onWidth()
    m.title.width = m.top.textWidth
    m.overview.width = m.top.textWidth
end sub

sub onLines()
    m.overview.maxLines = m.top.overviewLines
end sub

sub onPreview()
    m.top.findNode("previewTag").visible = m.top.preview
end sub

sub onItem()
    item = m.top.item
    if not isValid(item) or item.count() = 0
        m.top.visible = false
        return
    end if
    m.top.visible = true
    kind = item.LookupCI("Type")
    isEpisode = kind = "Episode"
    title = (function(item)
            __bsConsequent = item.LookupCI("Name")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return ""
            end if
        end function)(item)
    if isEpisode and isValidAndNotEmpty(item.LookupCI("SeriesName")) then
        title = item.LookupCI("SeriesName")
    end if
    m.title.text = UCase(title)
    badge = ""
    if kind = "Episode" or kind = "Series" or kind = "Season" then
        badge = "SERIE"
    end if
    if kind = "Movie" then
        badge = "PELÍCULA"
    end if
    if kind = "BoxSet" then
        badge = "COLECCIÓN"
    end if
    if kind = "Person" then
        badge = "PERSONA"
    end if
    m.badgeLabel.text = badge
    m.badge.visible = badge <> ""
    rect = m.badgeLabel.boundingRect()
    m.badgeBg.width = rect.width + 24
    meta = []
    year = item.LookupCI("ProductionYear")
    if isValid(year) then
        meta.push(year.toStr())
    end if
    genres = item.LookupCI("Genres")
    if isValid(genres) and genres.count() > 0
        g = genres[0]
        if genres.count() > 1 then
            g = g + " · " + genres[1]
        end if
        meta.push(g)
    end if
    rating = item.LookupCI("OfficialRating")
    if isValidAndNotEmpty(rating) then
        meta.push(rating)
    end if
    m.meta.text = UCase(meta.join(" · "))
    m.top.findNode("badgeRow").visible = badge <> "" or m.meta.text <> ""
    episodeLine = ""
    if isEpisode
        parts = []
        season = item.LookupCI("ParentIndexNumber")
        number = item.LookupCI("IndexNumber")
        if isValid(season) and isValid(number) then
            parts.push(("T" + bslib_toString(season) + " · E" + bslib_toString(number)))
        end if
        parts.push((function(item)
                __bsConsequent = item.LookupCI("Name")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(item))
        episodeLine = parts.join(" · ")
    end if
    m.episode.text = episodeLine
    runTicks = (function(item)
            __bsConsequent = item.LookupCI("RunTimeTicks")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return 0
            end if
        end function)(item)
    posTicks = 0
    data = item.LookupCI("UserData")
    if isValid(data) then
        posTicks = (function(data)
                __bsConsequent = data.LookupCI("PlaybackPositionTicks")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return 0
                end if
            end function)(data)
    end if
    progress = 0
    ' Ticks are 64-bit numbers; make the division a real one
    if runTicks > 0 then
        progress = (posTicks * 1.0) / (runTicks * 1.0)
    end if
    if progress > 1 then
        progress = 1
    end if
    minutesLeft = 0
    if runTicks > 0 then
        minutesLeft = Int(((runTicks - posTicks) * 1.0) / 600000000.0)
    end if
    m.left.text = ""
    if progress > 0 and minutesLeft > 0 then
        m.left.text = ("Quedan " + bslib_toString(minutesLeft) + " min")
    end if
    ' Empty labels would still take space in the row
    m.episode.visible = episodeLine <> ""
    m.left.visible = m.left.text <> ""
    m.episodeRow.visible = episodeLine <> "" or m.left.text <> ""
    m.bar.visible = progress > 0
    m.barFill.width = 340 * progress
    m.overview.text = (function(item)
            __bsConsequent = item.LookupCI("Overview")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return ""
            end if
        end function)(item)
end sub

' Centres the whole block on the hero translation x (series page)
sub onCentered()
    c = m.top.centered
    column = m.top.findNode("column")
    if c then
        column.horizAlignment = "center"
    else
        column.horizAlignment = "left"
    end if
    for each id in [
        "title"
        "overview"
    ]
        if c then
            m.top.findNode(id).horizAlign = "center"
        else
            m.top.findNode(id).horizAlign = "left"
        end if
    end for
end sub
'//# sourceMappingURL=./EfHero.brs.map