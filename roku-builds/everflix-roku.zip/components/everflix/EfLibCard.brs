'import "pkg:/components/everflix/EfCommon.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.image = m.top.findNode("image")
    m.name = m.top.findNode("name")
    m.ring = m.top.findNode("ring")
    m.progress = m.top.findNode("progress")
    m.name.font = ef_font("pkg:/fonts/archivo_extrabold.ttf", 24)
    m.top.scaleRotateCenter = [
        0
        0
    ] ' grow down and sideways, never up into the row title
end sub

sub onContent()
    node = m.top.itemContent
    if not isValid(node) or not isValid(node.json) then
        return
    end if
    item = node.json
    m.image.uri = (function(item)
            __bsConsequent = item.LookupCI("efThumb")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return ""
            end if
        end function)(item)
    m.name.text = UCase((function(item)
            __bsConsequent = item.LookupCI("Name")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return ""
            end if
        end function)(item))
    percent = 0
    data = item.LookupCI("UserData")
    if isValid(data) then
        percent = (function(data)
                __bsConsequent = data.LookupCI("PlayedPercentage")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return 0
                end if
            end function)(data)
    end if
    m.progress.width = 400 * percent / 100
end sub

sub onFocus()
    f = m.top.focusPercent * m.top.rowFocusPercent
    s = 1 + 0.08 * f
    m.top.scale = [
        s
        s
    ]
    m.ring.visible = f > 0.5
end sub
'//# sourceMappingURL=./EfLibCard.brs.map