'import "pkg:/components/everflix/EfCommon.bs"
'import "pkg:/source/utils/misc.bs"
' Big libraries load in pages so the first screen comes up fast; the genre rows come once all is loaded


sub init()
    m.top.overhangVisible = false
    m.top.optionsAvailable = false
    m.backdrop = m.top.findNode("backdrop")
    m.hero = m.top.findNode("hero")
    m.row = m.top.findNode("row")
    m.empty = m.top.findNode("empty")
    m.rail = m.top.findNode("rail")
    m.heroTimer = m.top.findNode("heroTimer")
    m.row.rowLabelFont = ef_font("pkg:/fonts/archivo_extrabold.ttf", 26)
    m.empty.font = ef_font("pkg:/fonts/archivo_regular.ttf", 28)
    m.row.observeField("rowItemFocused", "onFocused")
    m.row.observeField("rowItemSelected", "onSelected")
    m.heroTimer.observeField("fire", "showFocused")
    m.rail.observeField("selected", "onRailSelected")
    m.rail.observeField("leave", "onRailLeave")
    m.rail.observeField("open", "onRailOpen")
    m.task = CreateObject("roSGNode", "EfTask")
    m.task.observeField("result", "onPage")
    m.infoTask = CreateObject("roSGNode", "EfTask")
    m.infoTask.observeField("result", "onLibraryInfo")
    m.total = 0
    m.loaded = 0
    m.loading = false
    m.title = ""
    m.types = ""
    m.parentId = invalid
    m.items = []
    m.content = invalid
end sub

sub onSetup()
    s = m.top.setup
    if s.kind = "series"
        m.title = "Series"
        m.types = "Series"
        m.rail.active = "series"
        loadMore()
    else if s.kind = "movies"
        m.title = "Películas"
        m.types = "Movie"
        m.rail.active = "movies"
        loadMore()
    else
        m.parentId = s.libraryId
        m.rail.active = "lib:" + s.libraryId
        m.infoTask.job = "item"
        m.infoTask.args = {
            id: s.libraryId
        }
        m.infoTask.control = "RUN"
    end if
end sub

sub onLibraryInfo()
    library = m.infoTask.result.item
    kind = ""
    if isValid(library)
        m.title = (function(library)
                __bsConsequent = library.LookupCI("Name")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(library)
        kind = LCase((function(library)
                __bsConsequent = library.LookupCI("CollectionType")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(library))
    end if
    if kind = "tvshows"
        m.types = "Series"
    else if kind = "movies"
        m.types = "Movie"
    else if kind = "boxsets"
        m.types = "BoxSet"
    else
        m.types = "Series,Movie,Video"
    end if
    loadMore()
end sub

sub loadMore()
    if m.loading then
        return
    end if
    if m.total > 0 and m.loaded >= m.total then
        return
    end if
    m.loading = true
    params = {
        Recursive: true
        IncludeItemTypes: m.types
        SortBy: "DateCreated"
        SortOrder: "Descending"
        StartIndex: m.loaded
        Limit: 200
    }
    if isValid(m.parentId) then
        params.ParentId = m.parentId
    end if
    m.task.job = "items"
    m.task.args = {
        params: params
    }
    m.task.control = "RUN"
end sub

sub onPage()
    r = m.task.result
    m.loading = false
    if not isValid(r) or not isValid(r.items) then
        return
    end if
    m.total = r.total
    first = m.loaded = 0
    for each item in r.items
        m.items.push(item)
    end for
    m.loaded = m.items.count()
    done = r.items.count() = 0 or m.loaded >= m.total
    m.empty.visible = m.loaded = 0
    m.empty.text = "No hay nada aquí todavía."
    if first or done then
        buildRows(done)
    end if
    if first
        if m.loaded > 0 and not m.rail.hasFocus() then
            m.row.setFocus(true)
        end if
        showFocused()
    end if
    if not done then
        loadMore()
    end if
end sub

' Main genre (the first one Jellyfin lists) → row. Names come in Spanish or English depending on the server's
' metadata language, and TMDb series use their own combined genres ("Action & Adventure").
function genreRows() as object
    return [
        [
            "Para reír"
            [
                "comedia"
                "comedy"
            ]
        ]
        [
            "Acción y aventura"
            [
                "acción"
                "accion"
                "action"
                "aventura"
                "adventure"
                "action & adventure"
            ]
        ]
        [
            "Para pasar miedo"
            [
                "terror"
                "horror"
            ]
        ]
        [
            "Ciencia ficción y fantasía"
            [
                "ciencia ficción"
                "ciencia ficcion"
                "science fiction"
                "sci-fi"
                "fantasía"
                "fantasia"
                "fantasy"
                "sci-fi & fantasy"
            ]
        ]
        [
            "Suspense y misterio"
            [
                "suspense"
                "thriller"
                "misterio"
                "mystery"
                "suspenso"
            ]
        ]
        [
            "Crimen"
            [
                "crimen"
                "crime"
            ]
        ]
        [
            "Para enamorarse"
            [
                "romance"
                "romántica"
                "romantica"
            ]
        ]
        [
            "Drama"
            [
                "drama"
            ]
        ]
        [
            "Animación"
            [
                "animación"
                "animacion"
                "animation"
                "anime"
            ]
        ]
        [
            "Para ver en familia"
            [
                "familia"
                "family"
                "kids"
                "infantil"
                "niños"
            ]
        ]
        [
            "Historia y guerra"
            [
                "historia"
                "history"
                "bélica"
                "belica"
                "war"
                "war & politics"
                "guerra y política"
            ]
        ]
        [
            "Del oeste"
            [
                "western"
                "wéstern"
            ]
        ]
        [
            "Música"
            [
                "música"
                "musica"
                "music"
                "musical"
            ]
        ]
        [
            "De verdad"
            [
                "documental"
                "documentary"
                "reality"
                "telerrealidad"
            ]
        ]
    ]
end function

' "Recién añadidas" first, then one row per main genre (largest first), and whatever doesn't fit at the end.
' Until everything has loaded there is only the first row.
sub buildRows(complete as boolean)
    focus = m.row.rowItemFocused
    content = CreateObject("roSGNode", "ContentNode")
    recent = content.createChild("ContentNode")
    recent.title = UCase((bslib_toString(m.title) + " · Recién añadidas"))
    for i = 0 to m.items.count() - 1
        if i >= 30 and complete then
            exit for
        end if
        recent.appendChild(ef_itemNode(m.items[i]))
    end for
    if complete
        lookup = {}
        rows = genreRows()
        for each row in rows
            for each g in row[1]
                lookup[g] = row[0]
            end for
        end for
        groups = {}
        for each item in m.items
            name = "Más títulos"
            for each g in ((function(item)
                    __bsConsequent = item.LookupCI("Genres")
                    if __bsConsequent <> invalid then
                        return __bsConsequent
                    else
                        return []
                    end if
                end function)(item))
                hit = lookup[LCase(g.trim())]
                if isValid(hit)
                    name = hit
                    exit for
                end if
            end for
            if not isValid(groups[name]) then
                groups[name] = []
            end if
            groups[name].push(item)
        end for
        ordered = []
        for each row in rows
            if isValid(groups[row[0]]) then
                ordered.push({
                    name: row[0]
                    items: groups[row[0]]
                })
            end if
        end for
        ordered = sortBySize(ordered)
        if isValid(groups["Más títulos"]) then
            ordered.push({
                name: "Más títulos"
                items: groups["Más títulos"]
            })
        end if
        for each row in ordered
            node = content.createChild("ContentNode")
            node.title = UCase((bslib_toString(row.name) + " · " + bslib_toString(row.items.count())))
            for each item in row.items
                node.appendChild(ef_itemNode(item))
            end for
        end for
    end if
    m.content = content
    m.row.content = content
    ' keep the place in the first row when the genre rows arrive
    if isValid(focus) and focus.count() = 2 and focus[0] = 0 and focus[1] > 0 and focus[1] < recent.getChildCount()
        m.row.jumpToRowItem = [
            0
            focus[1]
        ]
    end if
end sub

function sortBySize(rows as object) as object
    for each r in rows
        r.size = r.items.count()
    end for
    rows.sortBy("size", "r")
    return rows
end function

function focusedItem() as dynamic
    if not isValid(m.content) then
        return invalid
    end if
    f = m.row.rowItemFocused
    rowNode = m.content.getChild(0)
    if not isValid(f) or f.count() < 2 then
        return rowNode.getChild(0)
    end if
    rowNode = m.content.getChild(f[0])
    if not isValid(rowNode) then
        return invalid
    end if
    return rowNode.getChild(f[1])
end function

sub onFocused()
    m.heroTimer.control = "stop"
    m.heroTimer.control = "start"
end sub

sub showFocused()
    node = focusedItem()
    if not isValid(node) then
        return
    end if
    m.hero.item = node.json
    m.backdrop.item = node.json
end sub

sub onSelected()
    node = focusedItem()
    if isValid(node) then
        ef_go({
            target: "details"
            id: node.json.Id
        })
    end if
end sub

sub onRailSelected()
    ef_go({
        target: m.rail.selected
    })
end sub

sub onRailLeave()
    if m.loaded > 0 then
        m.row.setFocus(true)
    end if
end sub

sub OnScreenShown()
    scene = m.top.getScene()
    overhang = scene.findNode("overhang")
    if isValid(overhang) then
        overhang.visible = false
    end if
    if m.loaded > 0
        m.row.setFocus(true)
    else
        m.top.setFocus(true)
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if key = "left" and m.row.isInFocusChain()
        m.rail.callFunc("focusIn")
        return true
    end if
    if key = "play" and m.row.isInFocusChain()
        node = focusedItem()
        if isValid(node) then
            ef_go({
                target: "play"
                item: node.json
            })
        end if
        return true
    end if
    return false
end function

' With the menu open, the page moves right so the menu never covers titles or cards
sub onRailOpen()
    x = 170
    if m.rail.open then
        x = 400
    end if
    for each node in [
        m.hero
        m.row
        m.top.findNode("empty")
    ]
        if node <> invalid then
            node.translation = [
                x
                node.translation[1]
            ]
        end if
    end for
end sub
'//# sourceMappingURL=./EfLibrary.brs.map