'import "pkg:/components/everflix/EfCommon.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.backdrop = m.top.findNode("backdrop")
    m.kicker = m.top.findNode("kicker")
    m.title = m.top.findNode("title")
    m.line = m.top.findNode("line")
    m.overview = m.top.findNode("overview")
    m.buttons = m.top.findNode("buttons")
    m.tick = m.top.findNode("tick")
    m.kicker.font = ef_font("pkg:/fonts/archivo_extrabold.ttf", 30)
    m.title.font = ef_font("pkg:/fonts/archivo_extrabold.ttf", 84)
    m.line.font = ef_font("pkg:/fonts/archivo_semibold.ttf", 32)
    m.overview.font = ef_font("pkg:/fonts/archivo_regular.ttf", 27)
    m.tick.observeField("fire", "onTick")
    m.buttons.observeField("pressed", "onPressed")
    m.top.focusable = true
    m.done = false
end sub

sub onItem()
    item = ef_decorate(m.top.item)
    m.backdrop.item = item
    m.left = m.top.seconds
    if m.top.stillWatching
        m.kicker.text = "¿SIGUES VIENDO?"
    else
        m.kicker.text = "SIGUIENTE"
    end if
    m.title.text = UCase((function(item)
            __bsConsequent = item.LookupCI("SeriesName")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return (function(item)
                        __bsConsequent = item.LookupCI("Name")
                        if __bsConsequent <> invalid then
                            return __bsConsequent
                        else
                            return ""
                        end if
                    end function)(item)
            end if
        end function)(item))
    parts = []
    season = item.LookupCI("ParentIndexNumber")
    number = item.LookupCI("IndexNumber")
    if isValid(season) and isValid(number) then
        parts.push(("T" + bslib_toString(season) + " · E" + bslib_toString(number)))
    end if
    parts.push((function(item)
            __bsConsequent = item.LookupCI("Name")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return ""
            end if
        end function)(item))
    m.line.text = parts.join(" · ")
    m.overview.text = (function(item)
            __bsConsequent = item.LookupCI("Overview")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return ""
            end if
        end function)(item)
    y = 350 + m.title.boundingRect().height + 16
    m.line.translation = [
        170
        y
    ]
    y += 56
    m.overview.translation = [
        170
        y
    ]
    y += m.overview.boundingRect().height + 40
    m.buttons.translation = [
        170
        y
    ]
    paintButtons()
    m.buttons.active = true
    if not m.top.stillWatching then
        m.tick.control = "start"
    end if
end sub

sub paintButtons()
    if m.top.stillWatching
        m.buttons.items = [
            {
                key: "next"
                icon: "play"
                text: "Seguir viendo"
                primary: true
            }
            {
                key: "cancel"
                text: "Salir"
            }
        ]
    else
        m.buttons.items = [
            {
                key: "next"
                icon: "play"
                text: ("Ver ahora · " + bslib_toString(m.left))
                primary: true
            }
            {
                key: "cancel"
                text: "Cancelar"
            }
        ]
    end if
end sub

sub onTick()
    m.left--
    if m.left <= 0
        m.tick.control = "stop"
        finish("next-auto")
        return
    end if
    index = m.buttons.index
    paintButtons()
    m.buttons.index = index
end sub

sub onPressed()
    finish(m.buttons.pressed)
end sub

sub finish(result as string)
    if m.done then
        return
    end if
    m.done = true
    m.tick.control = "stop"
    m.top.result = result
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if key = "left" or key = "right"
        m.buttons.callFunc("move", bslib_ternary(key = "left", -1, 1))
        return true
    else if key = "OK"
        m.buttons.callFunc("press")
        return true
    else if key = "back"
        finish("cancel")
        return true
    else if key = "play"
        finish("next")
        return true
    end if
    return true
end function
'//# sourceMappingURL=./EfNextUp.brs.map