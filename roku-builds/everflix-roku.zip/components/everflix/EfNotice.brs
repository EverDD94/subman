'import "pkg:/components/everflix/EfCommon.bs"

sub init()
    m.header = m.top.findNode("header")
    m.text = m.top.findNode("text")
    m.header.font = ef_font("pkg:/fonts/archivo_extrabold.ttf", 36)
    m.text.font = ef_font("pkg:/fonts/archivo_regular.ttf", 32)
    m.hide = m.top.findNode("hide")
    m.hide.observeField("fire", "onHide")
end sub

sub onMessage()
    msg = m.top.message
    if msg = invalid then
        return
    end if
    header = msg.LookupCI("header")
    if header = invalid or header = "" then
        header = "Everflix"
    end if
    m.header.text = header
    m.text.text = (function(msg)
            __bsConsequent = msg.LookupCI("text")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return ""
            end if
        end function)(msg)
    m.top.findNode("fadeOut").control = "stop"
    m.top.findNode("fadeIn").control = "start"
    m.hide.control = "stop"
    m.hide.control = "start"
end sub

sub onHide()
    m.top.findNode("fadeOut").control = "start"
end sub
'//# sourceMappingURL=./EfNotice.brs.map