'import "pkg:/components/everflix/EfCommon.bs"

sub init()
    m.bg = m.top.findNode("bg")
    m.label = m.top.findNode("label")
    m.icon = m.top.findNode("icon")
    m.label.font = ef_font("pkg:/fonts/archivo_extrabold.ttf", 28)
    m.top.scaleRotateCenter = [
        0
        32
    ]
end sub

sub onSmall()
    h = 64
    size = 28
    pad = 32
    if m.top.small
        h = 50
        size = 23
        pad = 24
    end if
    m.bg.height = h
    m.label.height = h
    m.label.translation = [
        pad
        0
    ]
    m.label.font = ef_font((function(__bsCondition, ef)
            if __bsCondition then
                return "pkg:/fonts/archivo_semibold.ttf"
            else
                return "pkg:/fonts/archivo_extrabold.ttf"
            end if
        end function)(m.top.small, ef), size)
    paint()
end sub

sub paint()
    m.label.text = m.top.text
    if m.top.small then
        pad = 24
    else
        pad = 32
    end if
    h = m.bg.height
    iconW = 0
    m.icon.visible = m.top.icon <> ""
    if m.icon.visible
        if m.top.small then
            size = 24
        else
            size = 30
        end if
        m.icon.uri = "pkg:/images/everflix/" + m.top.icon + ".png"
        m.icon.width = size
        m.icon.height = size
        m.icon.translation = [
            pad - 4
            (h - size) / 2
        ]
        iconW = size + 8
    end if
    textX = pad + iconW
    if m.top.text = "" then
        textX = pad
    end if
    m.label.translation = [
        textX
        0
    ]
    w = m.label.boundingRect().width + textX + pad
    if m.top.text = "" then
        w = pad * 2 + iconW - 8
    end if
    m.bg.width = w
    m.top.pillWidth = w
    if m.top.highlighted
        m.bg.blendColor = "0xFFFFFFFF"
        m.label.color = "0x000000FF"
        m.icon.blendColor = "0x000000FF"
    else if m.top.primary or m.top.selected
        m.bg.blendColor = "0x3D63E0FF"
        m.label.color = "0xFFFFFFFF"
        m.icon.blendColor = "0xFFFFFFFF"
    else
        m.bg.blendColor = "0xFFFFFF26"
        m.label.color = "0xF4F2EEFF"
        m.icon.blendColor = "0xF4F2EEFF"
    end if
    if m.top.highlighted then
        s = 1.05
    else
        s = 1.0
    end if
    m.top.scale = [
        s
        s
    ]
end sub
'//# sourceMappingURL=./EfPill.brs.map