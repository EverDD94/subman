' Everflix: minimal player button. Just the icon; when focused it becomes a white pill with its name
sub init()
    m.bg = m.top.findNode("bg")
    m.icon = m.top.findNode("icon")
    m.label = m.top.findNode("label")
    m.top.observeField("text", "layout")
    m.top.observeField("icon", "layout")
    m.top.observeField("height", "layout")
    m.top.observeField("padding", "layout")
    m.top.observeField("focus", "layout")
    m.top.observeField("enabled", "layout")
    layout()
end sub

sub layout()
    focused = m.top.focus = true and m.top.enabled
    h = m.top.height
    pad = m.top.padding
    iconSize = Int(h * 0.5)
    m.icon.uri = m.top.icon
    m.icon.width = iconSize
    m.icon.height = iconSize
    if not focused
        m.label.visible = false
        m.bg.visible = false
        m.icon.translation = [
            Int((h - iconSize) / 2)
            Int((h - iconSize) / 2)
        ]
        m.icon.blendColor = "0xF4F2EEFF"
        m.bg.width = h
        m.bg.height = h
        if m.top.enabled then
            m.top.opacity = 0.9
        else
            m.top.opacity = 0.35
        end if
        return
    end if
    x = pad
    m.icon.translation = [
        x
        Int((h - iconSize) / 2)
    ]
    x += iconSize
    m.label.text = m.top.text
    ' A label keeps its last width, and boundingRect never measures past it
    m.label.width = 0
    textWidth = 0
    if m.top.text <> ""
        x += 12
        textWidth = m.label.boundingRect().width
    end if
    m.label.height = h
    m.label.translation = [
        x
        0
    ]
    m.label.width = textWidth + 2
    m.label.visible = true
    x += textWidth
    m.bg.width = x + pad
    m.bg.height = h
    m.bg.blendColor = "0xFFFFFFFF"
    m.bg.visible = true
    m.icon.blendColor = "0x0B0D12FF"
    m.label.color = "0x0B0D12FF"
    m.top.opacity = 1.0
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press or not m.top.enabled then
        return false
    end if
    if m.top.focus = true and (key = "left" or key = "right" or key = "up" or key = "down")
        m.top.escape = key
    end if
    return false
end function
'//# sourceMappingURL=./EfPillButton.brs.map