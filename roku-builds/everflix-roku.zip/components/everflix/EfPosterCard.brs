'import "pkg:/components/everflix/EfCommon.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.image = m.top.findNode("image")
    m.title = m.top.findNode("title")
    m.subtitle = m.top.findNode("subtitle")
    m.fallback = m.top.findNode("fallback")
    m.progress = m.top.findNode("progress")
    m.progressBg = m.top.findNode("progressBg")
    m.watched = m.top.findNode("watched")
    m.title.font = ef_font("pkg:/fonts/archivo_semibold.ttf", 22)
    m.subtitle.font = ef_font("pkg:/fonts/archivo_regular.ttf", 19)
    m.fallback.font = ef_font("pkg:/fonts/archivo_extrabold.ttf", 28)
    m.top.scaleRotateCenter = [
        110
        165
    ]
end sub

sub onContent()
    node = m.top.itemContent
    if not isValid(node) or not isValid(node.json) then
        return
    end if
    item = node.json
    kind = item.LookupCI("Type")
    isEpisode = kind = "Episode"
    m.image.uri = (function(item)
            __bsConsequent = item.LookupCI("efPoster")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return ""
            end if
        end function)(item)
    m.fallback.text = (function(item)
            __bsConsequent = item.LookupCI("Name")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return ""
            end if
        end function)(item)
    m.fallback.visible = not isValidAndNotEmpty(m.image.uri)
    if isEpisode
        m.title.text = (function(item)
                __bsConsequent = item.LookupCI("SeriesName")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(item)
        season = item.LookupCI("ParentIndexNumber")
        episode = item.LookupCI("IndexNumber")
        prefix = ""
        if isValid(season) and isValid(episode) then
            prefix = ("T" + bslib_toString(season) + " · E" + bslib_toString(episode) + " · ")
        end if
        m.subtitle.text = prefix + ((function(item)
                __bsConsequent = item.LookupCI("Name")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(item))
    else
        m.title.text = (function(item)
                __bsConsequent = item.LookupCI("Name")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(item)
        year = item.LookupCI("ProductionYear")
        if isValid(year) then
            m.subtitle.text = year.toStr()
        else
            m.subtitle.text = ""
        end if
        if isValidAndNotEmpty(item.LookupCI("efNote")) then
            m.subtitle.text = item.efNote
        end if
    end if
    data = item.LookupCI("UserData")
    percent = 0
    played = false
    if isValid(data)
        percent = (function(data)
                __bsConsequent = data.LookupCI("PlayedPercentage")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return 0
                end if
            end function)(data)
        played = (function(data)
                __bsConsequent = data.LookupCI("Played")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return false
                end if
            end function)(data)
    end if
    m.progress.width = 196 * percent / 100
    m.progress.visible = percent > 0
    m.progressBg.visible = percent > 0
    m.watched.visible = played and percent = 0
end sub

sub onFocus()
    f = m.top.focusPercent * m.top.rowFocusPercent
    s = 1 + 0.08 * f
    m.top.scale = [
        s
        s
    ]
    m.title.opacity = 0.75 + 0.25 * f
    m.top.findNode("ring").visible = f > 0.5
end sub
'//# sourceMappingURL=./EfPosterCard.brs.map