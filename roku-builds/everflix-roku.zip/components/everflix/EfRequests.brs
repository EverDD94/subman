'import "pkg:/components/everflix/EfCommon.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.top.overhangVisible = false
    m.top.optionsAvailable = false
    m.grid = m.top.findNode("grid")
    m.empty = m.top.findNode("empty")
    m.rail = m.top.findNode("rail")
    m.top.findNode("heading").font = ef_font("pkg:/fonts/archivo_extrabold.ttf", 54)
    m.top.findNode("sub").font = ef_font("pkg:/fonts/archivo_regular.ttf", 26)
    m.empty.font = ef_font("pkg:/fonts/archivo_regular.ttf", 30)
    m.rail.observeField("selected", "onRailSelected")
    m.rail.observeField("leave", "onRailLeave")
    m.task = CreateObject("roSGNode", "EfTask")
    m.task.observeField("result", "onLoaded")
    m.admin = ef_isAdmin()
    m.decideTask = CreateObject("roSGNode", "EfTask")
    m.decideTask.observeField("result", "onDecided")
    m.grid.observeField("itemSelected", "onItemSelected")
    if m.admin
        m.top.findNode("heading").text = "DESCARGAS"
        m.top.findNode("sub").text = "Primero lo que han pedido los demás (pulsa OK para aprobar o rechazar) y luego lo que se está bajando."
    end if
    load()
end sub

sub load()
    m.task.job = "vt"
    m.task.args = {
        path: bslib_ternary(m.admin, "/api/pedir/admin", "/api/pedir/mine")
    }
    m.task.control = "STOP"
    m.task.control = "RUN"
end sub

function downloadStatus(state as string) as object
    if state = "listo" then
        return {
            label: "Ya está para ver"
            color: "0x2E9E5BFF"
        }
    end if
    if state = "descargando" then
        return {
            label: "Descargando"
            color: "0x3D63E0FF"
        }
    end if
    if state = "buscando" or state = "pidiendo" then
        return {
            label: "Buscándola"
            color: "0x3D63E0FF"
        }
    end if
    if state = "manual" then
        return {
            label: "Pulsa en Telegram"
            color: "0x8A6A1EFF"
        }
    end if
    if state = "no-esta" then
        return {
            label: "No la encuentro aún"
            color: "0x8A6A1EFF"
        }
    end if
    if state = "error" then
        return {
            label: "Error"
            color: "0x8A3A3AFF"
        }
    end if
    return {
        label: "En cola"
        color: "0x4A4F5CFF"
    }
end function

function statusOf(status as string) as object
    if status = "ya-esta" then
        return {
            label: "Ya está para ver"
            color: "0x2E9E5BFF"
        }
    end if
    if status = "descargando" then
        return {
            label: "Descargando"
            color: "0x3D63E0FF"
        }
    end if
    if status = "aceptada" then
        return {
            label: "Aprobada"
            color: "0x3D63E0FF"
        }
    end if
    if status = "rechazada" then
        return {
            label: "No aprobada"
            color: "0x8A3A3AFF"
        }
    end if
    if status = "no-disponible" then
        return {
            label: "Buscándola"
            color: "0x8A6A1EFF"
        }
    end if
    return {
        label: "Esperando aprobación"
        color: "0x4A4F5CFF"
    }
end function

sub onLoaded()
    r = m.task.result
    items = []
    if isValid(r) and isValid(r.data) and isValid(r.data.LookupCI("items")) then
        items = r.data.items
    end if
    if m.admin and isValid(r) and r.ok and isValid(r.data)
        showAdmin(r.data)
        return
    end if
    if not isValid(r) or not r.ok
        m.empty.text = "No puedo hablar con Videotecario ahora mismo."
        return
    end if
    if items.count() = 0
        m.empty.text = "Aún no has pedido nada. Búscalo en Buscar y pulsa «Pedir»."
        return
    end if
    m.empty.visible = false
    content = CreateObject("roSGNode", "ContentNode")
    for each it in items
        st = statusOf((function(it)
                __bsConsequent = it.LookupCI("status")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(it))
        title = (function(it)
                __bsConsequent = it.LookupCI("title")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(it)
        if isValid(it.LookupCI("year")) then
            title = title + (" (" + bslib_toString(it.year) + ")")
        end if
        node = content.createChild("HomeData")
        node.json = {
            Id: ""
            Name: title
            Type: "Request"
            image: (function(it)
                    __bsConsequent = it.LookupCI("poster")
                    if __bsConsequent <> invalid then
                        return __bsConsequent
                    else
                        return ""
                    end if
                end function)(it)
            title: title
            status: st.label
            statusColor: st.color
            note: (function(it)
                    __bsConsequent = it.LookupCI("why")
                    if __bsConsequent <> invalid then
                        return __bsConsequent
                    else
                        return ""
                    end if
                end function)(it)
        }
    end for
    m.grid.content = content
    if not m.rail.hasFocus() then
        m.grid.setFocus(true)
    end if
end sub

sub showAdmin(data as object)
    m.entries = []
    content = CreateObject("roSGNode", "ContentNode")
    for each it in ((function(data)
            __bsConsequent = data.LookupCI("requests")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return []
            end if
        end function)(data))
        if it.LookupCI("status") = "pendiente"
            who = ""
            if isValid(it.LookupCI("who")) then
                who = it.who.join(", ")
            end if
            addTile(content, it, "Pide " + who, "0xB8862BFF", {
                request: it
            })
        end if
    end for
    for each it in ((function(data)
            __bsConsequent = data.LookupCI("downloads")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return []
            end if
        end function)(data))
        st = downloadStatus((function(it)
                __bsConsequent = it.LookupCI("state")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(it))
        title = (function(it)
                __bsConsequent = it.LookupCI("title")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(it)
        if isValid(it.LookupCI("season")) then
            it.title = title + " · T" + it.season.toStr()
        end if
        addTile(content, it, st.label, st.color, {})
    end for
    if content.getChildCount() = 0
        m.empty.visible = true
        m.empty.text = "No hay nada pendiente ni bajándose. Busca algo en Buscar y pulsa «Descargar»."
        m.grid.content = invalid
        return
    end if
    m.empty.visible = false
    m.grid.content = content
    if not m.rail.hasFocus() then
        m.grid.setFocus(true)
    end if
end sub

sub addTile(content as object, it as object, status as string, color as string, extra as object)
    title = (function(it)
            __bsConsequent = it.LookupCI("title")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return ""
            end if
        end function)(it)
    if isValid(it.LookupCI("year")) then
        title = title + (" (" + bslib_toString(it.year) + ")")
    end if
    node = content.createChild("HomeData")
    node.json = {
        Id: ""
        Name: title
        Type: "Request"
        image: (function(it)
                __bsConsequent = it.LookupCI("poster")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(it)
        title: title
        status: status
        statusColor: color
        note: ""
    }
    m.entries.push(extra)
end sub

sub onItemSelected()
    if not m.admin or not isValid(m.entries) then
        return
    end if
    e = m.entries[m.grid.itemSelected]
    if not isValid(e) or not isValid(e.LookupCI("request")) then
        return
    end if
    m.choosing = e.request
    dialog = CreateObject("roSGNode", "StandardMessageDialog")
    dialog.title = m.choosing.title
    dialog.message = [
        "¿La descargo?"
    ]
    dialog.buttons = [
        "Aprobar"
        "Rechazar"
        "Ahora no"
    ]
    palette = CreateObject("roSGNode", "RSGPalette")
    palette.colors = {
        DialogBackgroundColor: "0x161A22FF"
        DialogTextColor: "0xF4F2EEFF"
        DialogItemColor: "0xF4F2EEFF"
        DialogFocusColor: "0xFFFFFFFF"
        DialogFocusItemColor: "0x000000FF"
        DialogFootprintColor: "0x3D63E0FF"
    }
    dialog.palette = palette
    dialog.observeField("buttonSelected", "onChoice")
    m.dialog = dialog
    m.top.getScene().dialog = dialog
end sub

sub onChoice()
    choice = m.dialog.buttonSelected
    m.dialog.close = true
    if choice > 1 then
        return
    end if
    m.decideTask.job = "vt"
    m.decideTask.args = {
        path: "/api/pedir/decide"
        body: {
            kind: m.choosing.kind
            tmdb: m.choosing.tmdb
            accept: choice = 0
        }
    }
    m.decideTask.control = "RUN"
end sub

sub onDecided()
    load()
end sub

sub onRailSelected()
    if m.rail.selected = "requests"
        onRailLeave()
        return
    end if
    ef_go({
        target: m.rail.selected
    })
end sub

sub onRailLeave()
    if isValid(m.grid.content) and m.grid.content.getChildCount() > 0
        m.grid.setFocus(true)
    else
        m.top.setFocus(true)
    end if
end sub

sub OnScreenShown()
    scene = m.top.getScene()
    overhang = scene.findNode("overhang")
    if isValid(overhang) then
        overhang.visible = false
    end if
    onRailLeave()
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if key = "left"
        m.rail.callFunc("focusIn")
        return true
    end if
    return false
end function
'//# sourceMappingURL=./EfRequests.brs.map