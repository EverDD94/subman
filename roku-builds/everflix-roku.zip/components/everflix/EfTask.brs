'import "pkg:/components/everflix/EfCommon.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.top.functionName = "doJob"
end sub

sub doJob()
    job = m.top.job
    a = m.top.args
    if not isValid(a) then
        a = {}
    end if
    r = {}
    if job = "home"
        r = loadHome()
    else if job = "views"
        r = {
            items: listOf(ef_getJellyfin(("Users/" + bslib_toString(efUid()) + "/Views")))
        }
    else if job = "items"
        params = a.params
        if not isValid(params) then
            params = {}
        end if
        params.Fields = ef_fields()
        params.ImageTypeLimit = 1
        params.EnableTotalRecordCount = true
        data = ef_getJellyfin(("Users/" + bslib_toString(efUid()) + "/Items"), params)
        total = 0
        if isValid(data) and isValid(data.TotalRecordCount) then
            total = data.TotalRecordCount
        end if
        r = {
            items: decorateAll(listOf(data))
            total: total
            startIndex: params.StartIndex
        }
    else if job = "details"
        r = loadDetails(a.id)
    else if job = "episodes"
        data = ef_getJellyfin(("Shows/" + bslib_toString(a.seriesId) + "/Episodes"), {
            UserId: efUid()
            SeasonId: a.seasonId
            Fields: ef_fields()
        })
        r = {
            items: decorateAll(listOf(data))
            seasonId: a.seasonId
        }
    else if job = "search"
        r = search(a.query)
    else if job = "favorite"
        r = setUserData(("Users/" + bslib_toString(efUid()) + "/FavoriteItems/" + bslib_toString(a.id)), a.value)
    else if job = "played"
        r = setUserData(("Users/" + bslib_toString(efUid()) + "/PlayedItems/" + bslib_toString(a.id)), a.value)
    else if job = "findOwned"
        r = findOwned(a)
    else if job = "homeExtra"
        r = loadHomeExtra()
    else if job = "vt"
        r = videotecario(a.path, a.body)
    else if job = "faces"
        r = loadFaces()
    else if job = "photo"
        r = setPhoto(a.url)
    else if job = "removePhoto"
        r = removePhoto()
    else if job = "item"
        r = {
            item: ef_decorate(ef_getJellyfin(("Users/" + bslib_toString(efUid()) + "/Items/" + bslib_toString(a.id))))
        }
    else if job = "me"
        r = {
            user: ef_getJellyfin(("Users/" + bslib_toString(efUid())))
        }
    end if
    m.top.result = r
end sub

function efUid() as string
    return m.global.session.user.id
end function

function listOf(data as dynamic) as object
    if isValid(data)
        if type(data) = "roArray" then
            return data
        end if
        if isValid(data.Items) then
            return data.Items
        end if
    end if
    return []
end function

function decorateAll(items as object) as object
    for each item in items
        ef_decorate(item)
    end for
    return items
end function

' Same rows as the Google TV home
function loadHome() as object
    common = {
        Fields: ef_fields()
        ImageTypeLimit: 1
        EnableTotalRecordCount: false
    }
    forYou = {
        Recursive: true
        IncludeItemTypes: "Series,Movie"
        SortOrder: "Descending"
        Limit: 30
    }
    forYou.Append(common)
    resume = {
        MediaTypes: "Video"
        Limit: 30
    }
    resume.Append(common)
    nextUp = {
        UserId: efUid()
        Limit: 30
        EnableResumable: true
        EnableRewatching: false
    }
    nextUp.Append(common)
    latest = {
        SortBy: "DateCreated"
    }
    latest.Append(forYou)
    mine = {
        SortBy: "DateCreated"
        IsFavorite: true
    }
    mine.Append(forYou)
    got = getJellyfinAll([
        [
            ("Users/" + bslib_toString(efUid()) + "/Items/Resume")
            resume
        ]
        [
            "Shows/NextUp"
            nextUp
        ]
        [
            ("Users/" + bslib_toString(efUid()) + "/Items")
            latest
        ]
        [
            ("Users/" + bslib_toString(efUid()) + "/Items")
            mine
        ]
        [
            ("Users/" + bslib_toString(efUid()) + "/Items")
            playedParams()
        ]
    ])
    ' Picks from your library by what you watch most; with no history, a slice that moves on each day
    p = {}
    p.Append(forYou)
    p.IsPlayed = false
    genres = favouriteGenres(listOf(got[4]))
    if genres.count() > 0
        p.Genres = genres.join("|")
        p.SortBy = "CommunityRating"
    else
        date = CreateObject("roDateTime")
        date.ToLocalTime()
        p.SortBy = "PremiereDate"
        p.StartIndex = (dayOfYearOf(date) * 7) mod 120
    end if
    skip = courseIds()
    if skip.count() > 0 then
        p.ExcludeItemIds = skip.join(",")
    end if
    rows = []
    addRow(rows, "Continuar viendo", got[0])
    addRow(rows, "Siguiente", got[1])
    addRow(rows, "Recomendado para ti", ef_getJellyfin(("Users/" + bslib_toString(efUid()) + "/Items"), p))
    addRow(rows, "Lo último en tu biblioteca", got[2])
    addRow(rows, "Mi lista", got[3])
    return {
        rows: rows
    }
end function

' Courses (libraries named like "Invested Academy" or "Cursos") are there to watch on purpose, never to recommend
function courseIds() as object
    ids = []
    for each view in listOf(ef_getJellyfin(("Users/" + bslib_toString(efUid()) + "/Views")))
        name = LCase((function(view)
                __bsConsequent = view.LookupCI("Name")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(view))
        if Instr(1, name, "academy") > 0 or Instr(1, name, "curso") > 0
            for each item in listOf(ef_getJellyfin(("Users/" + bslib_toString(efUid()) + "/Items"), {
                ParentId: view.Id
                EnableImages: false
                EnableTotalRecordCount: false
            }))
                ids.push(item.Id)
            end for
        end if
    end for
    return ids
end function

' Several Jellyfin GETs; the answers come back in the same order (invalid where one failed)
function getJellyfinAll(calls as object) as object
    out = []
    for each c in calls
        out.push(ef_getJellyfin(c[0], c[1]))
    end for
    return out
end function

' The library item for a TheMovieDB title we already have: by its TheMovieDB id, else by name
' The library item for a TheMovieDB title. Jellyfin may ignore AnyProviderIdEquals and answer with any item,
' so the TheMovieDB id is checked here; if no item carries it, a search by name that matches the title exactly
function findOwned(a as object) as object
    kind = "Movie"
    if a.kind = "tv" then
        kind = "Series"
    end if
    tmdb = a.tmdb.toStr()
    base = {
        Recursive: true
        IncludeItemTypes: kind
        Fields: "ProviderIds"
        EnableTotalRecordCount: false
    }
    p = {
        AnyProviderIdEquals: "Tmdb." + tmdb
        Limit: 20
    }
    p.Append(base)
    p2 = {
        SearchTerm: a.title
        Limit: 20
    }
    p2.Append(base)
    named = invalid
    for each found in [
        listOf(ef_getJellyfin(("Users/" + bslib_toString(efUid()) + "/Items"), p))
        listOf(ef_getJellyfin(("Users/" + bslib_toString(efUid()) + "/Items"), p2))
    ]
        for each it in found
            ids = (function(it)
                    __bsConsequent = it.LookupCI("ProviderIds")
                    if __bsConsequent <> invalid then
                        return __bsConsequent
                    else
                        return {}
                    end if
                end function)(it)
            if ((function(ids)
                    __bsConsequent = ids.LookupCI("Tmdb")
                    if __bsConsequent <> invalid then
                        return __bsConsequent
                    else
                        return ""
                    end if
                end function)(ids)) = tmdb and it.LookupCI("Type") = kind then
                return {
                    id: it.Id
                }
            end if
            if named = invalid and LCase((function(it)
                    __bsConsequent = it.LookupCI("Name")
                    if __bsConsequent <> invalid then
                        return __bsConsequent
                    else
                        return ""
                    end if
                end function)(it)) = LCase(a.title) and it.LookupCI("Type") = kind then
                named = it.Id
            end if
        end for
    end for
    return {
        id: named
    }
end function

' Rows from outside the library (releases, streaming platforms), shaped like Jellyfin items so cards and hero show them
function loadHomeExtra() as object
    rows = []
    res = videotecario("/api/pedir/home", invalid)
    if not res.ok or not isValid(res.data) or not isValid(res.data.LookupCI("rows")) then
        return {
            rows: rows
        }
    end if
    admin = ef_isAdmin()
    for each row in res.data.rows
        items = []
        for each s in row.items
            items.push(suggestionItem(s, admin))
        end for
        if items.count() > 0 then
            rows.push({
                title: row.title
                items: items
            })
        end if
    end for
    return {
        rows: rows
    }
end function

function suggestionItem(s as object, admin as boolean) as object
    kind = "Movie"
    if s.kind = "tv" then
        kind = "Series"
    end if
    if admin then
        note = "Descargar"
    else
        note = "Pedir"
    end if
    if s.LookupCI("asked") <> invalid then
        if admin then
            note = "En Descargas"
        else
            note = "Ya lo pediste"
        end if
    end if
    if s.LookupCI("have") = true then
        note = "En tu biblioteca"
    end if
    year = s.LookupCI("year")
    if isValid(year) then
        note = year.toStr() + " · " + note
    end if
    image = (function(s)
            __bsConsequent = s.LookupCI("backdrop")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return ""
            end if
        end function)(s)
    if image = "" then
        image = (function(s)
                __bsConsequent = s.LookupCI("poster")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(s)
    end if
    item = {
        Id: "tmdb-" + s.kind + s.tmdb.toStr()
        Name: s.title
        Type: kind
        Overview: (function(s)
                __bsConsequent = s.LookupCI("overview")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(s)
        Genres: (function(s)
                __bsConsequent = s.LookupCI("genres")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return []
                end if
            end function)(s)
        UserData: {
            Played: false
            PlaybackPositionTicks: 0
            UnplayedItemCount: 0
            IsFavorite: false
        }
        efThumb: image
        efBackdrop: image
        efPoster: (function(s)
                __bsConsequent = s.LookupCI("poster")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(s)
        efNote: note
        efSuggestion: {
            kind: s.kind
            tmdb: s.tmdb
            title: s.title
            poster: (function(s)
                    __bsConsequent = s.LookupCI("poster")
                    if __bsConsequent <> invalid then
                        return __bsConsequent
                    else
                        return ""
                    end if
                end function)(s)
            overview: (function(s)
                    __bsConsequent = s.LookupCI("overview")
                    if __bsConsequent <> invalid then
                        return __bsConsequent
                    else
                        return ""
                    end if
                end function)(s)
            have: s.LookupCI("have") = true
            asked: s.LookupCI("asked") <> invalid
        }
    }
    if isValid(year) then
        item.ProductionYear = year
    end if
    if isValid(year) then
        item.efSuggestion.year = year
    end if
    return item
end function

' The genres of what you watched lately (movies, and the series of your episodes), most watched first
function playedParams() as object
    return {
        Recursive: true
        IncludeItemTypes: "Movie,Episode"
        IsPlayed: true
        SortBy: "DatePlayed"
        SortOrder: "Descending"
        Limit: 80
        Fields: "Genres"
        EnableTotalRecordCount: false
    }
end function

function favouriteGenres(played as object) as object
    counts = {}
    perSeries = {}
    for each item in played
        if item.LookupCI("Type") = "Movie"
            for each g in ((function(item)
                    __bsConsequent = item.LookupCI("Genres")
                    if __bsConsequent <> invalid then
                        return __bsConsequent
                    else
                        return []
                    end if
                end function)(item))
                counts[g] = (bslib_coalesce(counts[g], 0)) + 1
            end for
        else if isValid(item.LookupCI("SeriesId"))
            perSeries[item.SeriesId] = ((function(item, perSeries)
                    __bsConsequent = perSeries[item.SeriesId]
                    if __bsConsequent <> invalid then
                        return __bsConsequent
                    else
                        return 0
                    end if
                end function)(item, perSeries)) + 1
        end if
    end for
    if perSeries.count() > 0
        ids = []
        for each id in perSeries
            ids.push(id)
        end for
        for each series in listOf(ef_getJellyfin(("Users/" + bslib_toString(efUid()) + "/Items"), {
            Ids: ids.join(",")
            Fields: "Genres"
        }))
            n = (function(perSeries, series)
                    __bsConsequent = perSeries.LookupCI(series.Id)
                    if __bsConsequent <> invalid then
                        return __bsConsequent
                    else
                        return 1
                    end if
                end function)(perSeries, series)
            if n > 5 then
                n = 5
            end if
            for each g in ((function(series)
                    __bsConsequent = series.LookupCI("Genres")
                    if __bsConsequent <> invalid then
                        return __bsConsequent
                    else
                        return []
                    end if
                end function)(series))
                counts[g] = (bslib_coalesce(counts[g], 0)) + n
            end for
        end for
    end if
    ranked = []
    for each g in counts
        ranked.push({
            name: g
            n: counts[g]
        })
    end for
    ranked.SortBy("n", "r")
    top = []
    for each r in ranked
        if top.count() < 3 then
            top.push(r.name)
        end if
    end for
    return top
end function

function dayOfYearOf(date as object) as integer
    start = CreateObject("roDateTime")
    start.FromISO8601String((bslib_toString(date.GetYear()) + "-01-01T00:00:00"))
    return Int((date.AsSeconds() - start.AsSeconds()) / 86400) + 1
end function

sub addRow(rows as object, title as string, data as dynamic)
    items = decorateAll(listOf(data))
    if items.count() = 0 then
        return
    end if
    rows.push({
        title: title
        items: items
    })
end sub

function loadDetails(id as string) as object
    item = ef_getJellyfin(("Users/" + bslib_toString(efUid()) + "/Items/" + bslib_toString(id)))
    if not isValid(item) then
        return {
            error: true
        }
    end if
    ef_decorate(item)
    r = {
        item: item
        seasons: []
        similar: []
    }
    kind = item.LookupCI("Type")
    seriesId = invalid
    if kind = "Episode" then
        seriesId = item.LookupCI("SeriesId")
    end if
    if kind = "Series" then
        seriesId = item.LookupCI("Id")
    end if
    if isValid(seriesId)
        if kind = "Series"
            r.series = item
            nextList = listOf(ef_getJellyfin("Shows/NextUp", {
                UserId: efUid()
                SeriesId: seriesId
                EnableResumable: true
                Fields: ef_fields()
                Limit: 1
            }))
            if nextList.count() > 0 then
                r.nextUp = ef_decorate(nextList[0])
            end if
        else
            r.series = ef_decorate(ef_getJellyfin(("Users/" + bslib_toString(efUid()) + "/Items/" + bslib_toString(seriesId))))
        end if
        r.seasons = listOf(ef_getJellyfin(("Shows/" + bslib_toString(seriesId) + "/Seasons"), {
            UserId: efUid()
        }))
        seasonId = item.LookupCI("SeasonId")
        if not isValid(seasonId) and isValid(r.nextUp) then
            seasonId = r.nextUp.LookupCI("SeasonId")
        end if
        if not isValid(seasonId) and r.seasons.count() > 0 then
            seasonId = r.seasons[0].Id
        end if
        r.seasonId = seasonId
    else if kind = "BoxSet" or kind = "Person"
        p = {
            Recursive: true
            IncludeItemTypes: "Movie,Series"
            SortBy: "PremiereDate"
            Fields: ef_fields()
            ImageTypeLimit: 1
        }
        if kind = "BoxSet" then
            p.ParentId = id
        else
            p.PersonIds = id
        end if
        r.similar = decorateAll(listOf(ef_getJellyfin(("Users/" + bslib_toString(efUid()) + "/Items"), p)))
    else
        r.similar = decorateAll(listOf(ef_getJellyfin(("Items/" + bslib_toString(id) + "/Similar"), {
            UserId: efUid()
            Limit: 20
            Fields: ef_fields()
        })))
    end if
    return r
end function

function search(query as string) as object
    r = {
        query: query
        items: []
        people: []
        suggestions: []
    }
    if Len(query) < 2 then
        return r
    end if
    p = {
        SearchTerm: query
        Recursive: true
        IncludeItemTypes: "Movie,Series,BoxSet"
        Limit: 40
        Fields: ef_fields()
        ImageTypeLimit: 1
    }
    r.items = decorateAll(listOf(ef_getJellyfin(("Users/" + bslib_toString(efUid()) + "/Items"), p)))
    r.people = decorateAll(listOf(ef_getJellyfin("Persons", {
        SearchTerm: query
        UserId: efUid()
        Limit: 15
    })))
    vt = videotecario("/api/pedir/browse?q=" + CreateObject("roUrlTransfer").Escape(query), invalid)
    if isValid(vt.data) and isValid(vt.data.items)
        for each title in vt.data.items
            if not title.LookupCI("have") then
                r.suggestions.push(title)
            end if
        end for
    end if
    return r
end function

function setUserData(path as string, value as boolean) as object
    req = APIRequest(path)
    if not isValid(req) then
        return {
            ok: false
        }
    end if
    if value
        ok = postVoid(req)
    else
        req.SetRequest("DELETE")
        ok = getVoid(req)
    end if
    return {
        ok: ok
        value: value
    }
end function

' Talks to Videotecario with the user's own Jellyfin token (no other password needed)
function videotecario(path as string, body as dynamic) as object
    ' The address that answered last time first (so a dead one is not waited on every time); otherwise
    ' the one derived from the Jellyfin server, Jellyfin's own LAN address and the NAS, keeping the first that answers
    reg = CreateObject("roRegistrySection", "everflix")
    known = reg.Read("videotecario")
    if known <> ""
        res = videotecarioAt(known, path, body)
        if isValid(res.LookupCI("code")) then
            return res
        end if
    end if
    bases = []
    base = ef_videotecarioBase()
    if base <> "" then
        bases.push(base)
    end if
    info = ef_getJellyfin("System/Info")
    if isValid(info) and isValidAndNotEmpty(info.LookupCI("LocalAddress"))
        r = CreateObject("roRegex", "^https?://([^/:]+)", "i")
        parts = r.match(info.LocalAddress)
        if parts.count() > 1 then
            bases.push("http://" + parts[1] + ":8787")
        end if
    end if
    bases.push("http://192.168.1.121:8787")
    res = {
        ok: false
        error: "Videotecario no responde"
    }
    for each b in bases
        if b <> known
            res = videotecarioAt(b, path, body)
            if isValid(res.LookupCI("code")) then
                exit for
            end if
        end if
    end for
    if isValid(res.LookupCI("base"))
        reg.Write("videotecario", res.base)
        reg.Flush()
    end if
    return res
end function

function videotecarioAt(base as string, path as string, body as dynamic) as object
    req = CreateObject("roUrlTransfer")
    req.SetUrl(base + path)
    req.AddHeader("X-Emby-Token", m.global.session.user.authToken)
    if base.left(5) = "https" then
        req.SetCertificatesFile("common:/certs/ca-bundle.crt")
    end if
    req.RetainBodyOnError(true)
    port = CreateObject("roMessagePort")
    req.SetMessagePort(port)
    if isValid(body)
        req.AddHeader("Content-Type", "application/json")
        started = req.AsyncPostFromString(FormatJson(body))
    else
        started = req.AsyncGetToString()
    end if
    if not started then
        return {
            ok: false
            error: "Videotecario no responde"
        }
    end if
    timeout = 6000
    if path = "/api/pedir/home" then
        timeout = 30000
    end if
    msg = wait(timeout, port)
    if type(msg) <> "roUrlEvent"
        req.AsyncCancel()
        return {
            ok: false
            error: "Videotecario no responde"
        }
    end if
    if msg.GetResponseCode() <= 0 then
        return {
            ok: false
            error: "Videotecario no responde"
        }
    end if
    data = ParseJson(msg.GetString())
    return {
        ok: msg.GetResponseCode() = 200
        code: msg.GetResponseCode()
        data: data
        base: base
    }
end function

' Faces of the cast of what you watch, to pick a profile photo from
function loadFaces() as object
    faces = []
    seen = {}
    recent = listOf(ef_getJellyfin(("Users/" + bslib_toString(efUid()) + "/Items"), {
        Recursive: true
        IncludeItemTypes: "Movie,Series"
        SortBy: "DatePlayed,DateCreated"
        SortOrder: "Descending"
        Limit: 20
        Fields: "People"
    }))
    for each item in recent
        people = item.LookupCI("People")
        if isValid(people)
            count = 0
            for each person in people
                tag = person.LookupCI("PrimaryImageTag")
                if isValid(tag) and not seen.DoesExist(person.Id) and count < 4
                    seen[person.Id] = true
                    count++
                    faces.push({
                        id: person.Id
                        name: person.Name
                        role: person.LookupCI("Role")
                        url: ImageURL(person.Id, "Primary", {
                            maxWidth: 400
                            maxHeight: 400
                            Tag: tag
                        })
                    })
                end if
            end for
        end if
        if faces.count() >= 40 then
            exit for
        end if
    end for
    return {
        faces: faces
    }
end function

' Jellyfin takes the photo as base64 text in the body
function setPhoto(url as string) as object
    tmp = "tmp:/ef-face.jpg"
    dl = CreateObject("roUrlTransfer")
    dl.SetUrl(url)
    dl = authRequest(dl)
    if url.left(5) = "https" then
        dl.SetCertificatesFile("common:/certs/ca-bundle.crt")
    end if
    if dl.GetToFile(tmp) <> 200 then
        return {
            ok: false
        }
    end if
    bytes = CreateObject("roByteArray")
    bytes.ReadFile(tmp)
    req = APIRequest(("Users/" + bslib_toString(efUid()) + "/Images/Primary"))
    if not isValid(req) then
        return {
            ok: false
        }
    end if
    req.AddHeader("Content-Type", "image/jpeg")
    port = CreateObject("roMessagePort")
    req.SetMessagePort(port)
    req.AsyncPostFromString(bytes.ToBase64String())
    msg = wait(20000, port)
    ok = type(msg) = "roUrlEvent" and msg.GetResponseCode() >= 200 and msg.GetResponseCode() < 300
    if not ok
        ' Newer servers moved it here
        req = APIRequest("UserImage", {
            userId: efUid()
        })
        req.AddHeader("Content-Type", "image/jpeg")
        req.SetMessagePort(port)
        req.AsyncPostFromString(bytes.ToBase64String())
        msg = wait(20000, port)
        ok = type(msg) = "roUrlEvent" and msg.GetResponseCode() >= 200 and msg.GetResponseCode() < 300
    end if
    DeleteFile(tmp)
    return {
        ok: ok
        me: ef_getJellyfin(("Users/" + bslib_toString(efUid())))
    }
end function

function removePhoto() as object
    req = APIRequest(("Users/" + bslib_toString(efUid()) + "/Images/Primary"))
    if not isValid(req) then
        return {
            ok: false
        }
    end if
    req.SetRequest("DELETE")
    port = CreateObject("roMessagePort")
    req.SetMessagePort(port)
    req.AsyncGetToString()
    msg = wait(10000, port)
    ok = type(msg) = "roUrlEvent" and msg.GetResponseCode() < 300
    return {
        ok: ok
        me: ef_getJellyfin(("Users/" + bslib_toString(efUid())))
    }
end function
'//# sourceMappingURL=./EfTask.brs.map