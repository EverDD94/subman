'import "pkg:/components/everflix/EfCommon.bs"
'import "pkg:/source/utils/misc.bs"



sub init()
    m.top.overhangVisible = false
    m.top.optionsAvailable = false
    m.tabsGroup = m.top.findNode("tabs")
    m.heading = m.top.findNode("heading")
    m.searchBox = m.top.findNode("searchBox")
    m.query = m.top.findNode("query")
    m.keysGroup = m.top.findNode("keys")
    m.grid = m.top.findNode("grid")
    m.hint = m.top.findNode("hint")
    m.rail = m.top.findNode("rail")
    m.toast = m.top.findNode("toast")
    m.toastText = m.top.findNode("toastText")
    m.toastBg = m.top.findNode("toastBg")
    m.debounce = m.top.findNode("debounce")
    m.toastTimer = m.top.findNode("toastTimer")
    m.heading.font = ef_font("pkg:/fonts/archivo_extrabold.ttf", 40)
    m.query.font = ef_font("pkg:/fonts/archivo_semibold.ttf", 30)
    m.hint.font = ef_font("pkg:/fonts/archivo_regular.ttf", 28)
    m.toastText.font = ef_font("pkg:/fonts/archivo_semibold.ttf", 25)
    m.debounce.observeField("fire", "runSearch")
    m.toastTimer.observeField("fire", "hideToast")
    m.grid.observeField("itemSelected", "onPick")
    m.rail.observeField("selected", "onRailSelected")
    m.rail.observeField("leave", "onRailLeave")
    m.task = CreateObject("roSGNode", "EfTask")
    m.task.observeField("result", "onItems")
    m.statusTask = CreateObject("roSGNode", "EfTask")
    m.statusTask.observeField("result", "onStatus")
    m.playTask = CreateObject("roSGNode", "EfTask")
    m.playTask.observeField("result", "onPlay")
    m.watchTask = CreateObject("roSGNode", "EfTask")
    m.keysGroup.focusable = true
    m.tabsGroup.focusable = true
    m.text = ""
    m.keyIndex = 0
    m.items = []
    m.zone = "tabs"
    m.cache = {}
    buildKeys()
    showQuery()
    buildTabs([
        {
            key: "buscar"
            label: "Buscar"
        }
        {
            key: "inicio"
            label: "Inicio"
        }
        {
            key: "historial"
            label: "Historial"
        }
    ])
    m.tab = "inicio"
    m.tabIndex = 1
    paintTabs()
    loadTab()
    m.statusTask.job = "vt"
    m.statusTask.args = {
        path: "/api/yt/status"
    }
    m.statusTask.control = "RUN"
end sub

' ---- pestañas ----
sub buildTabs(list as object)
    m.tabsGroup.removeChildrenIndex(m.tabsGroup.getChildCount(), 0)
    m.tabs = []
    x = 0
    for each t in list
        g = m.tabsGroup.createChild("Group")
        g.translation = [
            x
            0
        ]
        label = CreateObject("roSGNode", "Label")
        label.font = ef_font("pkg:/fonts/archivo_semibold.ttf", 27)
        label.text = t.label
        label.height = 60
        label.vertAlign = "center"
        label.translation = [
            28
            0
        ]
        w = label.boundingRect().width + 56
        bg = g.createChild("Poster")
        bg.uri = "pkg:/images/everflix/pill.9.png"
        bg.width = w
        bg.height = 60
        g.appendChild(label)
        t.bg = bg
        t.label = label
        m.tabs.push(t)
        x += w + 14
    end for
end sub

sub paintTabs()
    for i = 0 to m.tabs.count() - 1
        t = m.tabs[i]
        focused = m.zone = "tabs" and i = m.tabIndex and m.tabsGroup.hasFocus()
        if focused
            t.bg.blendColor = "0xFFFFFFFF"
            t.label.color = "0x000000FF"
        else if t.key = m.tab
            t.bg.blendColor = "0x3D63E0FF"
            t.label.color = "0xFFFFFFFF"
        else
            t.bg.blendColor = "0x161A22FF"
            t.label.color = "0xF4F2EEFF"
        end if
    end for
end sub

sub onStatus()
    r = m.statusTask.result
    if not isValid(r) or not isValid(r.LookupCI("data")) then
        return
    end if
    if r.data.LookupCI("linked") = true and r.data.LookupCI("admin") = true
        buildTabs([
            {
                key: "buscar"
                label: "Buscar"
            }
            {
                key: "inicio"
                label: "Inicio"
            }
            {
                key: "suscripciones"
                label: "Suscripciones"
            }
            {
                key: "canales"
                label: "Canales"
            }
            {
                key: "historial"
                label: "Historial"
            }
            {
                key: "tarde"
                label: "Ver más tarde"
            }
        ])
        if m.tab = "inicio" then
            loadTab()
        end if
    end if
    paintTabs()
end sub

sub selectTab(key as string)
    m.tab = key
    m.cid = ""
    for i = 0 to m.tabs.count() - 1
        if m.tabs[i].key = key then
            m.tabIndex = i
        end if
    end for
    paintTabs()
    loadTab()
end sub

sub loadTab()
    searching = m.tab = "buscar"
    m.searchBox.visible = searching
    if searching
        m.grid.translation = [
            700
            210
        ]
        m.grid.numColumns = 3
        m.heading.text = ""
        m.hint.translation = [
            700
            220
        ]
        runSearch()
        return
    end if
    m.grid.translation = [
        170
        210
    ]
    m.grid.numColumns = 4
    m.hint.translation = [
        170
        220
    ]
    m.heading.text = ""
    path = "/api/yt/feed?tab=" + m.tab
    if m.tab = "canal" then
        path = "/api/yt/channel?id=" + m.cid
    end if
    if m.tab = "canales" then
        path = "/api/yt/channels"
    end if
    fetch(path)
end sub

sub fetch(path as string)
    m.path = path
    if m.cache.DoesExist(path)
        show(m.cache[path])
        return
    end if
    m.grid.visible = false
    m.hint.visible = true
    m.hint.text = "Cargando…"
    m.task.job = "vt"
    m.task.args = {
        path: path
    }
    m.task.control = "STOP"
    m.task.control = "RUN"
end sub

sub onItems()
    r = m.task.result
    if not isValid(r) or not isValid(r.LookupCI("data")) or r.data.LookupCI("ok") <> true
        m.grid.visible = false
        m.hint.visible = true
        m.hint.text = "YouTube no responde ahora mismo. Prueba otra vez en un rato."
        return
    end if
    data = r.data
    m.cache[m.path] = data
    show(data)
end sub

sub show(data as object)
    m.items = data.items
    if m.tab = "canal" then
        m.heading.text = (function(data)
                __bsConsequent = data.LookupCI("title")
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return ""
                end if
            end function)(data)
    end if
    m.grid.translation = [
        m.grid.translation[0]
        bslib_ternary(m.heading.text = "", 150, 210)
    ]
    content = CreateObject("roSGNode", "ContentNode")
    if m.tab = "canales"
        list = []
        for each c in m.items
            list.push({
                id: ""
                title: c.title
                channel: ""
                thumb: c.avatar
                channel_id: c.id
                isChannel: true
            })
        end for
        m.items = list
    end if
    for each v in m.items
        node = content.createChild("ContentNode")
        node.addField("json", "assocarray", false)
        node.json = v
    end for
    m.grid.content = content
    m.grid.visible = m.items.count() > 0
    m.hint.visible = not m.grid.visible
    if m.tab = "buscar"
        if m.text.Trim() = "" then
            m.hint.text = "Escribe lo que quieras ver."
        else
            m.hint.text = "No encontré nada."
        end if
    else
        m.hint.text = "Aquí no hay nada todavía."
    end if
    if m.zone = "grid" and not m.grid.visible then
        focusTabs()
    end if
end sub

' ---- buscar ----
sub runSearch()
    q = m.text.Trim()
    if Len(q) < 2
        m.items = []
        m.grid.visible = false
        m.hint.visible = true
        m.hint.text = "Escribe lo que quieras ver."
        return
    end if
    fetch("/api/yt/search?q=" + CreateObject("roUrlTransfer").Escape(q))
end sub

sub buildKeys()
    letters = "abcdefghijklmnñopqrstuvwxyz1234567890"
    m.keyList = []
    for i = 0 to Len(letters) - 1
        m.keyList.push({
            key: Mid(letters, i + 1, 1)
            label: UCase(Mid(letters, i + 1, 1))
            width: 1
        })
    end for
    m.keyList.push({
        key: "space"
        label: "Espacio"
        width: 3
    })
    m.keyList.push({
        key: "delete"
        label: "Borrar"
        width: 2
    })
    m.keyList.push({
        key: "clear"
        label: "Limpiar"
        width: 2
    })
    m.keyNodes = []
    col = 0
    row = 0
    for each k in m.keyList
        if col + k.width > 7
            col = 0
            row++
        end if
        g = m.keysGroup.createChild("Group")
        g.translation = [
            col * 66
            row * 66
        ]
        bg = g.createChild("Poster")
        bg.uri = "pkg:/images/everflix/round8.9.png"
        bg.width = k.width * 66 - 8
        bg.height = 66 - 8
        label = g.createChild("Label")
        label.text = k.label
        label.width = bg.width
        label.height = bg.height
        label.horizAlign = "center"
        label.vertAlign = "center"
        label.font = ef_font("pkg:/fonts/archivo_semibold.ttf", bslib_ternary(k.width = 1, 28, 22))
        k.col = col
        k.row = row
        k.bg = bg
        k.label = label
        m.keyNodes.push(k)
        col += k.width
    end for
    paintKeys()
end sub

sub paintKeys()
    for i = 0 to m.keyNodes.count() - 1
        k = m.keyNodes[i]
        focused = m.zone = "keys" and i = m.keyIndex and m.keysGroup.hasFocus()
        if focused
            k.bg.blendColor = "0xFFFFFFFF"
            k.label.color = "0x000000FF"
        else
            k.bg.blendColor = "0x161A22FF"
            k.label.color = "0xF4F2EEFF"
        end if
    end for
end sub

' Finds the key closest to a column on another row
function keyAt(row as integer, col as integer) as integer
    best = -1
    for i = 0 to m.keyNodes.count() - 1
        k = m.keyNodes[i]
        if k.row = row and col >= k.col and col < k.col + k.width then
            return i
        end if
        if k.row = row then
            best = i
        end if
    end for
    return best
end function

sub showQuery()
    if m.text = ""
        m.query.text = "Buscar en YouTube…"
        m.query.color = "0x9AA0ADFF"
    else
        m.query.text = m.text + "_"
        m.query.color = "0xF4F2EEFF"
    end if
end sub

sub typeKey(key as string)
    if key = "space"
        m.text += " "
    else if key = "delete"
        if Len(m.text) > 0 then
            m.text = Left(m.text, Len(m.text) - 1)
        end if
    else if key = "clear"
        m.text = ""
    else
        m.text += key
    end if
    showQuery()
    m.debounce.control = "stop"
    m.debounce.control = "start"
end sub

' ---- reproducir ----
sub onPick()
    playAt(m.grid.itemSelected)
end sub

sub playAt(index as integer)
    if index < 0 or index >= m.items.count() then
        return
    end if
    v = m.items[index]
    if v.LookupCI("isChannel") = true
        openChannel(v.channel_id)
        return
    end if
    m.playIndex = index
    m.playing = v
    showToast("Abriendo: " + v.title)
    m.playTask.job = "vt"
    m.playTask.args = {
        path: "/api/yt/play?id=" + v.id
    }
    m.playTask.control = "STOP"
    m.playTask.control = "RUN"
end sub

sub onPlay()
    r = m.playTask.result
    if not isValid(r) or not isValid(r.LookupCI("data")) or r.data.LookupCI("ok") <> true
        message = "No se pudo abrir el vídeo"
        if isValid(r) and isValid(r.LookupCI("data")) and isValid(r.data.LookupCI("error")) then
            message = message + ": " + r.data.error
        end if
        showToast(message)
        return
    end if
    hideToast()
    d = r.data
    url = d.url
    if url.left(1) = "/" then
        url = r.base + url
    end if
    if not isValid(m.player)
        m.player = CreateObject("roSGNode", "EfYtPlayer")
        m.player.observeField("ended", "onEnded")
        m.player.observeField("closed", "onClosed")
        m.global.sceneManager.callFunc("pushScene", m.player)
    end if
    nextTitle = ""
    if m.playIndex + 1 < m.items.count() then
        nextTitle = m.items[m.playIndex + 1].title
    end if
    m.player.video = {
        url: url
        title: d.title
        format: d.format
        nextTitle: nextTitle
    }
    m.watchTask.job = "vt"
    m.watchTask.args = {
        path: "/api/yt/watched"
        body: m.playing
    }
    m.watchTask.control = "RUN"
end sub

' Al terminar, el siguiente de la lista (como YouTube)
sub onEnded()
    if m.playIndex + 1 < m.items.count()
        playAt(m.playIndex + 1)
    else
        m.global.sceneManager.callFunc("popScene")
    end if
end sub

sub onClosed()
    m.player = invalid
    m.grid.jumpToItem = m.playIndex
end sub

sub openChannel(cid as string)
    m.tab = "canal"
    m.cid = cid
    paintTabs()
    loadTab()
end sub

' ---- avisos ----
sub showToast(text as string)
    m.toastText.text = text
    m.toastBg.width = m.toastText.boundingRect().width + 56
    m.toast.visible = true
    m.toastTimer.control = "stop"
    m.toastTimer.control = "start"
end sub

sub hideToast()
    m.toast.visible = false
end sub

' ---- foco ----
sub focusTabs()
    m.zone = "tabs"
    m.tabsGroup.setFocus(true)
    paintTabs()
    paintKeys()
end sub

sub focusGrid()
    if not m.grid.visible then
        return
    end if
    m.zone = "grid"
    m.grid.setFocus(true)
    paintTabs()
    paintKeys()
end sub

sub focusKeys()
    m.zone = "keys"
    m.keysGroup.setFocus(true)
    paintTabs()
    paintKeys()
end sub

sub onRailSelected()
    if m.rail.selected = "youtube"
        onRailLeave()
        return
    end if
    ef_go({
        target: m.rail.selected
    })
end sub

sub onRailLeave()
    focusTabs()
end sub

sub OnScreenShown()
    scene = m.top.getScene()
    overhang = scene.findNode("overhang")
    if isValid(overhang) then
        overhang.visible = false
    end if
    if m.zone = "grid" and m.grid.visible
        m.grid.setFocus(true)
    else if m.zone = "keys"
        m.keysGroup.setFocus(true)
    else
        focusTabs()
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if m.zone = "tabs"
        if key = "left"
            if m.tabIndex > 0
                m.tabIndex--
                paintTabs()
            else
                m.rail.callFunc("focusIn")
                paintTabs()
            end if
            return true
        else if key = "right"
            if m.tabIndex < m.tabs.count() - 1 then
                m.tabIndex++
            end if
            paintTabs()
            return true
        else if key = "OK"
            selectTab(m.tabs[m.tabIndex].key)
            if m.tab = "buscar" then
                focusKeys()
            end if
            return true
        else if key = "down"
            if m.tab = "buscar"
                focusKeys()
            else
                focusGrid()
            end if
            return true
        end if
        return false
    end if
    if m.zone = "grid"
        cols = m.grid.numColumns
        if key = "up" and m.grid.itemFocused < cols
            focusTabs()
            return true
        else if key = "left" and m.grid.itemFocused mod cols = 0
            if m.tab = "buscar" then
                focusKeys()
            else
                m.rail.callFunc("focusIn")
            end if
            return true
        else if key = "options"
            v = m.items[m.grid.itemFocused]
            if isValidAndNotEmpty(v.LookupCI("channel_id")) then
                openChannel(v.channel_id)
            end if
            return true
        else if key = "back" and m.tab = "canal"
            selectTab("inicio")
            focusTabs()
            return true
        end if
        return false
    end if
    if m.zone = "keys"
        k = m.keyNodes[m.keyIndex]
        if key = "OK"
            typeKey(k.key)
            return true
        else if key = "left"
            if k.col = 0 then
                m.rail.callFunc("focusIn")
            else
                m.keyIndex--
            end if
            paintKeys()
            return true
        else if key = "right"
            last = m.keyIndex = m.keyNodes.count() - 1
            if not last and m.keyNodes[m.keyIndex + 1].row = k.row
                m.keyIndex++
                paintKeys()
            else
                focusGrid()
            end if
            return true
        else if key = "up"
            i = keyAt(k.row - 1, k.col)
            if i >= 0
                m.keyIndex = i
                paintKeys()
            else
                focusTabs()
            end if
            return true
        else if key = "down"
            i = keyAt(k.row + 1, k.col)
            if i >= 0 then
                m.keyIndex = i
            end if
            paintKeys()
            return true
        else if key = "replay" or key = "rewind"
            typeKey("delete")
            return true
        end if
    end if
    return false
end function
'//# sourceMappingURL=./EfYouTube.brs.map