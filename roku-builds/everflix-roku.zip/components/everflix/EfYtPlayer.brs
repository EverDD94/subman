'import "pkg:/components/everflix/EfCommon.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.top.overhangVisible = false
    m.top.optionsAvailable = false
    m.player = m.top.findNode("player")
    m.player.observeField("state", "onState")
    m.player.observeField("position", "onPosition")
    m.next = m.top.findNode("next")
    m.nextLabel = m.top.findNode("nextLabel")
    m.nextLabel.font = ef_font("pkg:/fonts/archivo_semibold.ttf", 24)
end sub

sub onVideo()
    v = m.top.video
    content = CreateObject("roSGNode", "ContentNode")
    content.url = v.url
    content.title = (function(v)
            __bsConsequent = v.title
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return ""
            end if
        end function)(v)
    content.streamFormat = (function(v)
            __bsConsequent = v.format
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return "hls"
            end if
        end function)(v)
    content.HttpCertificatesFile = "common:/certs/ca-bundle.crt"
    content.HttpHeaders = [
        "User-Agent: Mozilla/5.0"
    ]
    m.next.visible = false
    m.nextLabel.text = "A continuación: " + ((function(v)
            __bsConsequent = v.nextTitle
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return ""
            end if
        end function)(v))
    m.hasNext = isValidAndNotEmpty(v.nextTitle)
    m.player.control = "stop"
    m.player.content = content
    m.player.control = "play"
    m.player.setFocus(true)
end sub

sub onState()
    if m.player.state = "finished"
        m.top.ended = true
    else if m.player.state = "error"
        print "YouTube: "; m.player.errorMsg; " "; m.player.errorStr
        close()
    end if
end sub

' Los últimos 10 segundos avisa de lo que viene después
sub onPosition()
    d = m.player.duration
    m.next.visible = m.hasNext and d > 30 and d - m.player.position < 10
end sub

sub close()
    m.player.control = "stop"
    m.global.sceneManager.callFunc("popScene")
    m.top.closed = true
end sub

sub OnScreenShown()
    m.player.setFocus(true)
end sub

sub OnScreenHidden()
    m.player.control = "stop"
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if press and key = "back"
        close()
        return true
    end if
    return false
end function
'//# sourceMappingURL=./EfYtPlayer.brs.map