'import "pkg:/components/everflix/EfCommon.bs"
'import "pkg:/source/utils/deviceCapabilities.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.isFirstRun = true
    m.top.overhangTitle = ""
    m.top.optionsAvailable = false
    m.top.overhangVisible = false
    m.rows = m.top.findNode("rows")
    m.hero = m.top.findNode("hero")
    m.rail = m.top.findNode("rail")
    m.empty = m.top.findNode("empty")
    m.heroTimer = m.top.findNode("heroTimer")
    m.backdrops = [
        m.top.findNode("backdropA")
        m.top.findNode("backdropB")
    ]
    m.front = 0
    m.fade = m.top.findNode("fade")
    m.fadeIn = m.top.findNode("fadeIn")
    m.fadeOut = m.top.findNode("fadeOut")
    m.rows.rowLabelFont = ef_font("pkg:/fonts/archivo_extrabold.ttf", 30)
    m.empty.font = ef_font("pkg:/fonts/archivo_regular.ttf", 28)
    m.rows.observeField("rowItemFocused", "onItemFocused")
    m.rows.observeField("rowItemSelected", "onItemSelected")
    m.heroTimer.observeField("fire", "showFocused")
    m.rail.observeField("selected", "onRailSelected")
    m.rail.observeField("leave", "onRailLeave")
    m.rail.observeField("open", "onRailOpen")
    m.postTask = CreateObject("roSGNode", "PostTask")
    m.task = CreateObject("roSGNode", "EfTask")
    m.task.observeField("result", "onLoaded")
    ' Rows from outside the library load on their own, after the rest, so they never slow the home screen down
    m.extraTask = CreateObject("roSGNode", "EfTask")
    m.extraTask.observeField("result", "onExtraLoaded")
    m.extraRows = []
    m.askTask = CreateObject("roSGNode", "EfTask")
    m.askTask.observeField("result", "onAsked")
    m.findTask = CreateObject("roSGNode", "EfTask")
    m.findTask.job = "findOwned"
    m.findTask.observeField("result", "onFound")
    m.toast = m.top.findNode("toast")
    m.toastText = m.top.findNode("toastText")
    m.toastBg = m.top.findNode("toastBg")
    m.toastTimer = m.top.findNode("toastTimer")
    m.toastText.font = ef_font("pkg:/fonts/archivo_semibold.ttf", 25)
    m.toastTimer.observeField("fire", "hideToast")
end sub

sub loadLibraries()
    load()
end sub

sub refresh()
    load()
end sub

sub load()
    m.task.job = "home"
    m.task.control = "STOP"
    m.task.control = "RUN"
end sub

sub onLoaded()
    r = m.task.result
    if not isValid(r) or not isValid(r.rows) then
        return
    end if
    m.libraryRows = r.rows
    render()
    if m.global.hasField("efSplash") and isValid(m.global.efSplash) then
        m.global.efSplash.done = true
    end if
    m.extraTask.job = "homeExtra"
    m.extraTask.control = "STOP"
    m.extraTask.control = "RUN"
end sub

sub onExtraLoaded()
    r = m.extraTask.result
    if not isValid(r) or not isValid(r.rows) then
        return
    end if
    m.extraRows = r.rows
    render()
end sub

sub render()
    r = {
        rows: []
    }
    r.rows.Append((function(m)
            __bsConsequent = m.libraryRows
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return []
            end if
        end function)(m))
    r.rows.Append(m.extraRows)
    focus = m.rows.rowItemFocused
    root = CreateObject("roSGNode", "ContentNode")
    for each row in r.rows
        rowNode = root.createChild("ContentNode")
        rowNode.title = row.title
        for each item in row.items
            rowNode.appendChild(ef_itemNode(item))
        end for
    end for
    m.rows.content = root
    m.empty.visible = root.getChildCount() = 0
    m.empty.text = "Aún no hay nada en tu biblioteca."
    if isValid(focus) and focus.count() = 2 and focus[0] < root.getChildCount()
        row = root.getChild(focus[0])
        col = focus[1]
        if col >= row.getChildCount() then
            col = row.getChildCount() - 1
        end if
        if col < 0 then
            col = 0
        end if
        m.rows.jumpToRowItem = [
            focus[0]
            col
        ]
    end if
    ' only when the home is the screen in use: the late rows used to pull the focus away from
    ' another screen (a series, the player), and the remote then did nothing
    if m.top.isInFocusChain() and not m.rail.hasFocus() then
        m.rows.setFocus(true)
    end if
    showFocused()
end sub

function focusedItem() as dynamic
    if not isValid(m.rows.content) then
        return invalid
    end if
    f = m.rows.rowItemFocused
    if not isValid(f) or f.count() < 2 then
        return invalid
    end if
    row = m.rows.content.getChild(f[0])
    if not isValid(row) then
        return invalid
    end if
    return row.getChild(f[1])
end function

sub onItemFocused()
    m.heroTimer.control = "stop"
    m.heroTimer.control = "start"
end sub

sub showFocused()
    node = focusedItem()
    if not isValid(node) then
        return
    end if
    item = node.json
    m.hero.item = item
    setBackdrop((function(item)
            __bsConsequent = item.LookupCI("efBackdrop")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return ""
            end if
        end function)(item))
end sub

' Cross-fade between two posters so the backdrop never flashes black
sub setBackdrop(uri as string)
    current = m.backdrops[m.front]
    if current.uri = uri then
        return
    end if
    m.front = 1 - m.front
    incoming = m.backdrops[m.front]
    outgoing = m.backdrops[1 - m.front]
    incoming.uri = uri
    m.fadeIn.fieldToInterp = incoming.id + ".opacity"
    m.fadeOut.fieldToInterp = outgoing.id + ".opacity"
    m.fadeOut.keyValue = [
        outgoing.opacity
        0.0
    ]
    m.fade.control = "stop"
    m.fade.control = "start"
end sub

sub onItemSelected()
    node = focusedItem()
    if not isValid(node) then
        return
    end if
    s = node.json.LookupCI("efSuggestion")
    if isValid(s)
        askFor(s)
        return
    end if
    ef_go({
        target: "details"
        id: node.json.Id
    })
end sub

' Already in the library: open it. Not yet: ask first, then download (admin) or request it (everyone else)
sub askFor(s as object)
    if s.have
        m.findTask.args = {
            kind: s.kind
            tmdb: s.tmdb
            title: s.title
        }
        m.findTask.control = "STOP"
        m.findTask.control = "RUN"
        return
    end if
    if s.asked
        showToast((bslib_ternary(ef_isAdmin(), "Ya está en Descargas: ", "Ya lo pediste: ")) + s.title)
        return
    end if
    m.asking = s
    dialog = CreateObject("roSGNode", "StandardMessageDialog")
    dialog.title = s.title
    dialog.message = [
        "Esto no está en tu biblioteca. " + (bslib_ternary(ef_isAdmin(), "¿Quieres descargarlo?", "¿Quieres pedirlo?"))
    ]
    dialog.buttons = [
        bslib_ternary(ef_isAdmin(), "Sí, descargar", "Sí, pedirlo")
        "No"
    ]
    dialog.observeField("buttonSelected", "onAskAnswer")
    dialog.observeField("wasClosed", "onAskClosed")
    m.top.getScene().dialog = dialog
end sub

sub onAskAnswer(event as object)
    dialog = event.getRoSGNode()
    yes = dialog.buttonSelected = 0
    dialog.close = true
    if not yes then
        return
    end if
    s = m.asking
    item = {
        kind: s.kind
        tmdb: s.tmdb
        title: s.title
        poster: s.poster
        overview: s.overview
    }
    if isValid(s.LookupCI("year")) then
        item.year = s.year
    end if
    m.askTask.job = "vt"
    m.askTask.args = {
        path: "/api/pedir/ask"
        body: {
            item: item
        }
    }
    m.askTask.control = "STOP"
    m.askTask.control = "RUN"
end sub

sub onAskClosed()
    m.rows.setFocus(true)
end sub

sub onFound()
    r = m.findTask.result
    if isValid(r) and isValid(r.LookupCI("id"))
        ef_go({
            target: "details"
            id: r.id
        })
    else
        showToast("No la encuentro en tu biblioteca")
    end if
end sub

sub onAsked()
    r = m.askTask.result
    if isValid(r) and r.ok and isValid(r.data) and r.data.LookupCI("ok") = true
        if r.data.LookupCI("downloading") = true
            showToast("A descargar: " + m.asking.title + ". Aparecerá sola en tu biblioteca.")
        else
            showToast("Pedido enviado: " + m.asking.title + ". Se descargará cuando se apruebe.")
        end if
        m.extraTask.control = "STOP"
        m.extraTask.control = "RUN"
    else
        message = "No se pudo pedir"
        if isValid(r) and isValid(r.LookupCI("error")) then
            message = r.error
        end if
        if isValid(r) and isValid(r.data) and isValid(r.data.LookupCI("error")) then
            message = r.data.error
        end if
        showToast(message)
    end if
end sub

sub showToast(text as string)
    m.toastText.text = text
    m.toastBg.width = m.toastText.boundingRect().width + 56
    m.toast.visible = true
    m.toastTimer.control = "stop"
    m.toastTimer.control = "start"
end sub

sub hideToast()
    m.toast.visible = false
end sub

sub onRailSelected()
    ef_go({
        target: m.rail.selected
    })
end sub

sub onRailLeave()
    m.rows.setFocus(true)
end sub

' JFScreen hook called when the screen is displayed by the screen manager
sub OnScreenShown()
    scene = m.top.getScene()
    overhang = scene.findNode("overhang")
    if isValid(overhang) then
        overhang.visible = false
    end if
    m.rail.active = "home"
    m.rows.setFocus(true)
    group = m.global.sceneManager.callFunc("getActiveScene")
    if isValid(group) then
        group.lastFocus = m.rows
    end if
    if m.isFirstRun
        ' post the device profile the first time this screen is loaded
        m.isFirstRun = false
        m.postTask.arrayData = getDeviceCapabilities()
        m.postTask.apiUrl = "/Sessions/Capabilities/Full"
        m.postTask.control = "RUN"
        m.postTask.observeField("responseCode", "postFinished")
    else
        load()
    end if
end sub

sub OnScreenHidden()
end sub

sub postFinished()
    m.postTask.unobserveField("responseCode")
    m.postTask.callFunc("empty")
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if m.rows.hasFocus() or m.rows.isInFocusChain()
        if key = "left"
            m.rail.callFunc("focusIn")
            return true
        else if key = "play"
            node = focusedItem()
            if isValid(node) and not isValid(node.json.LookupCI("efSuggestion")) then
                ef_go({
                    target: "play"
                    item: node.json
                })
            end if
            return true
        else if key = "back"
            f = m.rows.rowItemFocused
            if isValid(f) and f.count() = 2 and (f[0] > 0 or f[1] > 0)
                m.rows.jumpToRowItem = [
                    0
                    0
                ]
                return true
            end if
        end if
    end if
    return false
end function

' With the menu open, the page moves right so the menu never covers titles or cards
sub onRailOpen()
    x = 170
    if m.rail.open then
        x = 400
    end if
    for each node in [
        m.hero
        m.rows
        m.top.findNode("empty")
    ]
        if node <> invalid then
            node.translation = [
                x
                node.translation[1]
            ]
        end if
    end for
end sub
'//# sourceMappingURL=./Home.brs.map