'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/Image.bs"
'import "pkg:/source/enums/AnimationControl.bs"
'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/ItemType.bs"
'import "pkg:/source/enums/PosterLoadStatus.bs"
'import "pkg:/source/enums/SeriesStatus.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/misc.bs"



sub init()
    findNodes()
    m.itemPoster.observeField("loadStatus", "onPosterLoadStatusChanged")
    setColors()
end sub

sub setColors()
    if not isAllValid([
        m.itemProgress
        m.itemProgressBackground
        m.backdrop
    ]) then
        findNodes()
    end if
    if isValid(m.itemProgress)
        m.itemProgress.color = chainLookupReturn(m.global.session, "user.settings.colorHomeRowItemProgress", "#3D63E0")
    end if
    if isValid(m.itemProgressBackground)
        m.itemProgressBackground.color = chainLookupReturn(m.global.session, "user.settings.colorHomeRowItemProgressBackground", "0x00000090")
    end if
    if isValid(m.backdrop)
        m.backdrop.color = chainLookupReturn(m.global.session, "user.settings.colorHomeRowItemBackground", "#161A22")
    end if
end sub

sub findNodes()
    initItemText()
    initItemPoster()
    initItemTextExtra()
    initBackdrop()
    initItemIcon()
    m.itemProgress = m.top.findNode("progress")
    m.itemProgressBackground = m.top.findNode("progressBackground")
    m.playedIndicator = m.top.findNode("playedIndicator")
    m.showProgressBarAnimation = m.top.findNode("showProgressBar")
    m.showProgressBarField = m.top.findNode("showProgressBarField")
end sub

sub initItemText()
    m.itemText = m.top.findNode("itemText")
    if isValid(m.itemText)
        m.itemText.color = chainLookupReturn(m.global.session, "user.settings.colorHomeRowItemTitle", "#ffffff")
    end if
end sub

sub initItemPoster()
    m.itemPoster = m.top.findNode("itemPoster")
end sub

sub initItemTextExtra()
    m.itemTextExtra = m.top.findNode("itemTextExtra")
    if isValid(m.itemTextExtra)
        m.itemTextExtra.color = chainLookupReturn(m.global.session, "user.settings.colorHomeRowItemSubtitle", "#777777")
    end if
end sub

sub initBackdrop()
    m.backdrop = m.top.findNode("backdrop")
end sub

sub initItemIcon()
    m.itemIcon = m.top.findNode("itemIcon")
    if not isValid(m.itemIcon) then
        return
    end if
    m.itemIcon.blendcolor = chainLookupReturn(m.global.session, "user.settings.colorHomeMyListIcon", "#ffffff")
end sub

sub itemContentChanged()
    itemData = m.top.itemContent
    if not isValid(itemData) then
        return
    end if
    localGlobal = m.global
    if isValid(itemData.type) then
        itemDataType = LCase(itemData.type)
    else
        itemDataType = ""
    end if
    if isValid(m.playedIndicator)
        m.playedIndicator.data = {
            showWatchedCheckmark: not isStringEqual(itemDataType, "audio")
            played: chainLookupReturn(itemData, "json.UserData.Played", false)
            unplayedCount: chainLookupReturn(itemData, "json.UserData.UnplayedItemCount", 0)
        }
    end if
    if isValid(m.stationGroup)
        m.top.removeChild(m.stationGroup)
        m.stationGroup = invalid
    end if
    itemData.AddReplace("Title", itemData.LookupCI("name"))
    setColors()
    initItemIcon()
    initItemText()
    initItemTextExtra()
    ' validate to prevent crash
    if not isValid(m.itemPoster) then
        initItemPoster()
    end if
    if not isValid(m.backdrop) then
        initBackdrop()
    end if
    if not isValid(m.itemIcon) then
        initItemIcon()
    end if
    m.itemPoster.width = itemData.imageWidth
    m.itemPoster.height = 261
    m.itemPoster.loadDisplayMode = "scaleToZoom"
    m.showProgressBarAnimation.control = "stop"
    m.itemProgressBackground.width = itemData.imageWidth
    m.itemProgressBackground.visible = false
    m.itemProgress.width = 0
    m.itemTextExtra.maxWidth = itemData.imageWidth
    m.itemTextExtra.visible = true
    m.itemTextExtra.text = ""
    m.itemTextExtra.font.size = 22
    m.itemText.maxWidth = itemData.imageWidth
    m.itemText.height = 34
    m.itemText.font.size = 25
    m.itemText.horizAlign = "left"
    m.itemText.vertAlign = "bottom"
    m.backdrop.width = itemData.imageWidth
    m.backdrop.height = 261
    if isValid(m.itemIcon)
        iconX = (itemData.imageWidth - m.itemIcon.width) / 2
        if iconX < 0 then
            iconX = 0
        end if
        m.itemIcon.translation = [
            iconX
            85
        ]
        if isValidAndNotEmpty(itemData.iconUrl)
            m.itemIcon.uri = itemData.iconUrl
            m.itemIcon.visible = true
        else
            m.itemIcon.uri = ""
            m.itemIcon.visible = false
        end if
    end if
    if inArray([
        "collectionfolder"
        "userview"
        "channel"
        "folder"
    ], itemDataType)
        displayCollectionInfo(itemData)
        return
    end if
    playedIndicatorLeftPosition = m.itemPoster.width - 60
    m.playedIndicator.translation = [
        playedIndicatorLeftPosition
        0
    ]
    ' "Program" is from clicking on an "On Now" item on the Home Screen
    if itemDataType = "program"
        displayProgramInfo(itemData)
        return
    end if
    if inArray([
        "episode"
        "recording"
    ], itemDataType)
        displayEpisodeInfo(localGlobal, itemData)
        return
    end if
    if inArray([
        "movie"
        "musicvideo"
    ], itemDataType)
        displayMovieInfo(itemData)
        return
    end if
    if itemDataType = "video"
        displayVideoInfo(itemData)
        return
    end if
    if inArray([
        "boxset"
        "playlist"
    ], itemDataType)
        displayBoxsetInfo(itemData)
        return
    end if
    if itemDataType = "series"
        displaySeriesInfo(itemData)
        return
    end if
    if itemDataType = "musicalbum"
        displayMusicAlbumInfo(itemData)
        return
    end if
    if itemDataType = "radiostation"
        displayRadioStationInfo(itemData)
        return
    end if
    if itemDataType = "person"
        displayPersonInfo(itemData)
        return
    end if
    if itemDataType = "audiobook"
        displayAudioBookInfo(itemData)
        return
    end if
    if inArray([
        "musicartist"
        "audio"
    ], itemDataType)
        displayAudioInfo(itemData)
        return
    end if
    if itemDataType = "tvchannel"
        displayTVChannelInfo(itemData)
        return
    end if
    if itemDataType = "season"
        displaySeasonInfo(itemData)
        return
    end if
    if itemDataType = "photo"
        displayPhotoInfo(itemData)
        return
    end if
    if itemDataType = "photoalbum"
        displayPhotoAlbumInfo(itemData)
        return
    end if
    print ("Unhandled Home Item Type " + bslib_toString(itemDataType))
end sub

sub displayCollectionInfo(itemData as object)
    m.itemText.text = itemData.name
    if isValidAndNotEmpty(itemData.widePosterURL)
        m.itemPoster.uri = itemData.widePosterURL
    else if isValidAndNotEmpty(itemData.posterURL)
        m.itemPoster.uri = itemData.posterURL
    else
        m.itemPoster.uri = ""
    end if
end sub

sub displayPhotoAlbumInfo(itemData as object)
    m.itemText.text = itemData.name
    m.itemPoster.uri = ItemImageURL(itemData.json, "Primary")
    ' subtext
    if isValid(itemData.json.ChildCount)
        m.itemTextExtra.text = itemData.json.ChildCount.ToStr().trim() + " items"
    end if
end sub

sub displayPhotoInfo(itemData as object)
    m.itemText.text = itemData.name
    m.itemPoster.uri = ItemImageURL(itemData.json, "Primary")
    ' subtext
    if isValidAndNotEmpty(itemData.json)
        if isValid(itemData.json.ProductionYear)
            m.itemTextExtra.text = itemData.json.ProductionYear.ToStr().trim()
        end if
        if isValidAndNotEmpty(itemData.json.Album)
            if m.itemTextExtra.text = ""
                m.itemTextExtra.text = tr("Album") + ": " + itemData.json.Album.trim()
            else
                m.itemTextExtra.text = m.itemTextExtra.text + " - " + tr("Album") + ": " + itemData.json.Album.trim()
            end if
        end if
    end if
end sub

sub displaySeasonInfo(itemData as object)
    m.itemText.text = itemData.json.SeriesName
    m.itemTextExtra.text = itemData.name
    m.itemPoster.uri = ItemImageURL(itemData.json, "Primary")
end sub

sub displayTVChannelInfo(itemData as object)
    m.itemText.text = itemData.name
    m.itemTextExtra.text = itemData.json.AlbumArtist
    m.itemPoster.uri = ItemImageURL(itemData.json, "Primary")
end sub

sub displayAudioInfo(itemData as object)
    m.itemText.text = itemData.name
    m.itemTextExtra.text = itemData.json.AlbumArtist
    if isValidAndNotEmpty(itemData.posterURL)
        m.itemPoster.uri = itemData.posterURL
    else
        m.itemPoster.uri = "pkg:/images/icons/album.png"
    end if
end sub

sub displayAudioBookInfo(itemData as object)
    if itemData.PlayedPercentage > 0
        drawProgressBar(itemData)
    end if
    m.itemText.text = itemData.name
    m.itemTextExtra.text = itemData.json.AlbumArtist
    m.itemPoster.uri = ItemImageURL(itemData.json, "Primary")
end sub

sub displayMusicAlbumInfo(itemData as object)
    m.itemText.text = itemData.name
    m.itemTextExtra.text = itemData.json.AlbumArtist
    m.itemPoster.uri = itemData.posterURL
end sub

sub displayRadioStationInfo(itemData as object)
    m.stationGroup = createObject("roSGNode", "Group")
    m.stationGroup.clippingRect = "[0,0,261,261]"
    stationText = m.stationGroup.CreateChild("Text")
    stationText.color = "#161A22"
    stationText.id = "radioStationName"
    stationText.font = "font:LargeBoldSystemFont"
    stationText.font.size = 80
    stationText.ellipsisText = " "
    stationText.wrap = "true"
    stationText.width = "275"
    stationText.height = "290"
    stationText.translation = "[-10, 0]"
    stationText.displayPartialLines = "true"
    stationText.vertAlign = "bottom"
    stationText.text = itemData.name
    m.top.insertChild(m.stationGroup, 1)
    m.itemText.text = itemData.name
    m.itemTextExtra.text = itemData.json.Subtitle
    m.backdrop.color = itemData.json.BackgroundColor
end sub

sub displayPersonInfo(itemData as object)
    m.itemText.text = itemData.name
    m.itemPoster.loadDisplayMode = "scaleToFit"
    m.itemPoster.uri = itemData.posterURL
end sub

sub displaySeriesInfo(itemData as object)
    m.itemText.text = itemData.name
    if itemData.usePoster
        if itemData.imageWidth = 180 then
            m.itemPoster.uri = itemData.posterURL
        else
            m.itemPoster.uri = itemData.widePosterURL
        end if
    else
        m.itemPoster.uri = itemData.thumbnailURL
    end if
    textExtra = ""
    if isValid(itemData.json.ProductionYear)
        textExtra = StrI(itemData.json.ProductionYear).trim()
    end if
    ' Set Years Run for Extra Text
    if isValid(itemData.json.Status)
        if LCase(itemData.json.Status) = "continuing"
            textExtra = textExtra + " - Present"
        else if LCase(itemData.json.Status) = "ended" and isValid(itemData.json.EndDate)
            textExtra = textExtra + " - " + LEFT(itemData.json.EndDate, 4)
        end if
    end if
    m.itemTextExtra.text = textExtra
end sub

sub displayBoxsetInfo(itemData as object)
    m.itemText.text = itemData.name
    m.itemPoster.uri = itemData.posterURL
    ' Set small text to number of items in the collection
    if isChainValid(itemData, "json.ChildCount")
        m.itemTextExtra.text = StrI(itemData.json.ChildCount).trim() + " item"
        if itemData.json.ChildCount > 1
            m.itemTextExtra.text += "s"
        end if
    end if
end sub

sub displayVideoInfo(itemData as object)
    m.itemText.text = itemData.name
    if itemData.PlayedPercentage > 0
        drawProgressBar(itemData)
    end if
    if itemData.imageWidth = 180 then
        m.itemPoster.uri = itemData.posterURL
    else
        m.itemPoster.uri = itemData.thumbnailURL
    end if
end sub

sub displayMovieInfo(itemData as object)
    m.itemText.text = itemData.name
    if itemData.PlayedPercentage > 0
        drawProgressBar(itemData)
    end if
    ' Use best image, but fallback to secondary if it's empty
    if (itemData.imageWidth = 180 and itemData.posterURL <> "") or itemData.thumbnailURL = ""
        m.itemPoster.uri = itemData.posterURL
    else
        m.itemPoster.uri = itemData.thumbnailURL
    end if
    ' Set Release Year and Age Rating for Extra Text
    textExtra = ""
    if isValid(itemData.json.ProductionYear)
        textExtra = StrI(itemData.json.ProductionYear).trim()
    end if
    if isValid(itemData.json.OfficialRating)
        if textExtra = ""
            textExtra = itemData.json.OfficialRating
        else
            textExtra = (bslib_toString(textExtra) + " - " + bslib_toString(itemData.json.OfficialRating))
        end if
    end if
    m.itemTextExtra.text = textExtra
end sub

sub displayProgramInfo(itemData as object)
    m.itemText.Text = itemData.json.name
    m.itemTextExtra.Text = itemData.json.ChannelName
    channel = {
        Id: itemData.json.ChannelId
        PrimaryImageTag: itemData.json.ChannelPrimaryImageTag
    }
    if itemData.usePoster then
        m.itemPoster.uri = itemData.thumbnailURL
    else
        m.itemPoster.uri = ItemImageURL(channel, "Primary", {}, false)
    end if
    m.itemPoster.loadDisplayMode = "scaleToFill"
    if isValid(itemData.FHDItemWidth)
        realWidth = itemData.FHDItemWidth
        m.itemPoster.width = realWidth
        m.itemText.maxWidth = realWidth - 8
        m.itemTextExtra.width = realWidth - 8
        m.backdrop.width = realWidth
    end if
    ' Set Episode title if available
    if isValid(itemData.json.EpisodeTitle)
        m.itemTextExtra.text = itemData.json.EpisodeTitle
    end if
end sub

sub displayEpisodeInfo(localGlobal as object, itemData as object)
    if isChainValid(itemData, "json.SeriesName")
        m.itemText.text = itemData.json.SeriesName
    end if
    if isValid(itemData.LookupCI("PlayedPercentage"))
        if itemData.LookupCI("PlayedPercentage") > 0
            drawProgressBar(itemData)
        end if
    end if
    episodeimagesnextupSetting = chainLookup(localGlobal, "session.user.settings.ui-general-episodeimagesnextup")
    ' Default to wide poster image
    m.itemPoster.uri = itemData.LookupCI("widePosterURL")
    if isValid(episodeimagesnextupSetting)
        if isStringEqual(episodeimagesnextupSetting, "webclient")
            useEpisodeImagesInNextUpAndResumeSetting = chainLookup(localGlobal, "session.user.Configuration.useEpisodeImagesInNextUpAndResume")
            if isValid(useEpisodeImagesInNextUpAndResumeSetting) and useEpisodeImagesInNextUpAndResumeSetting
                m.itemPoster.uri = itemData.LookupCI("thumbnailURL")
            else
                m.itemPoster.uri = itemData.LookupCI("widePosterURL")
            end if
        else if isStringEqual(episodeimagesnextupSetting, "show")
            m.itemPoster.uri = itemData.LookupCI("widePosterURL")
        else if isStringEqual(episodeimagesnextupSetting, "episode")
            m.itemPoster.uri = itemData.LookupCI("thumbnailURL")
        end if
    end if
    ' Set Series and Episode Number for Extra Text
    extraPrefix = ""
    if isChainValid(itemData, "json.ParentIndexNumber")
        extraPrefix = "S" + StrI(itemData.json.ParentIndexNumber).trim()
    end if
    if isChainValid(itemData, "json.IndexNumber")
        extraPrefix = extraPrefix + "E" + StrI(itemData.json.IndexNumber).trim()
    end if
    if extraPrefix.len() > 0
        extraPrefix = extraPrefix + " - "
    end if
    if isValid(m.itemTextExtra)
        m.itemTextExtra.text = extraPrefix + itemData.LookupCI("name")
    end if
end sub

'
' Draws and animates item progress bar
sub drawProgressBar(itemData)
    if not isValid(itemData.LookupCI("imageWidth")) then
        return
    end if
    m.itemProgressBackground.width = itemData.LookupCI("imageWidth")
    m.itemProgressBackground.visible = true
    m.showProgressBarField.keyValue = [
        0
        m.itemPoster.width * (itemData.PlayedPercentage / 100)
    ]
    m.showProgressBarAnimation.control = "start"
end sub

'
' Enable title scrolling based on item Focus
sub focusChanged()
    if m.top.itemHasFocus then
        m.itemText.repeatCount = - 1
    else
        m.itemText.repeatCount = 0
    end if
    if m.top.itemHasFocus then
        m.itemTextExtra.repeatCount = - 1
    else
        m.itemTextExtra.repeatCount = 0
    end if
end sub

'Hide backdrop and icon when poster loaded
sub onPosterLoadStatusChanged()
    if m.itemPoster.loadStatus = "failed"
        thisItemType = chainLookupReturn(m.top.itemContent, "json.type", "")
        ' If loading the album poster image failed, try loading the artist image
        if isStringEqual(thisItemType, "musicalbum")
            params = {
                tag: m.top.itemContent.json.parentbackdropimagetags
                maxHeight: 261
                maxWidth: 261
            }
            artistPrimaryImageURL = ImageURL(m.top.itemContent.json.parentbackdropitemid, "Primary", params)
            ' Check if we've already tried to fall back to the artist image
            if isStringEqual(m.itemPoster.uri, artistPrimaryImageURL) then
                return
            end if
            m.itemPoster.uri = artistPrimaryImageURL
            return
        end if
        if isStringEqual(thisItemType, "audio") and isValidAndNotEmpty(m.top.itemContent.thumbnailURL)
            if not isStringEqual(m.itemPoster.uri, m.top.itemContent.thumbnailURL)
                m.itemPoster.uri = m.top.itemContent.thumbnailURL
                return
            end if
        end if
        ' If loading the episode poster image failed, try loading the series image
        if isStringEqual(thisItemType, "episode")
            params = {
                tag: m.top.itemContent.json.parentbackdropimagetags
                maxHeight: 261
                maxWidth: 261
            }
            seriesPrimaryImageURL = ImageURL(m.top.itemContent.json.parentbackdropitemid, "Primary", params)
            ' Check if we've already tried to fall back to the series image
            if isStringEqual(m.itemPoster.uri, seriesPrimaryImageURL) then
                return
            end if
            m.itemPoster.uri = seriesPrimaryImageURL
            return
        end if
        ' Wide Poster failed to load, try poster url
        if isStringEqual(m.itemPoster.uri, m.top.itemContent.widePosterURL)
            m.itemPoster.uri = m.top.itemContent.posterURL
            return
        end if
        ' Thumbnail failed to load, try poster url
        if isStringEqual(m.itemPoster.uri, m.top.itemContent.thumbnailURL)
            m.itemPoster.uri = m.top.itemContent.posterURL
            return
        end if
        ' Poster url has failed. Show blank backdrop
        m.backdrop.visible = true
        m.itemIcon.visible = true
        return
    end if
    if m.itemPoster.loadStatus = "ready" and m.itemPoster.uri <> ""
        m.backdrop.visible = false
        m.itemIcon.visible = false
    else
        m.backdrop.visible = true
        m.itemIcon.visible = true
    end if
end sub
'//# sourceMappingURL=./HomeItem.brs.map