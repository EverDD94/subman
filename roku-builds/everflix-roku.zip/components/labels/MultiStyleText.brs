'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.top.observeFieldScoped("drawingStyles", "onDrawingStylesChanged")
end sub

sub setFont()
    if not isValidAndNotEmpty(m.top.drawingStyles) then
        return
    end if
    if not isValidAndNotEmpty(m.global.fallbackFont) then
        return
    end if
    if not chainLookupReturn(m.global.session, "user.settings.useFallbackFont", false) then
        return
    end if
    drawingStyles = formatJson(m.top.drawingStyles)
    regularFonts = [
        "font:TinySystemFontFile"
        "font:SmallerSystemFontFile"
        "font:SmallestSystemFontFile"
        "font:SmallSystemFontFile"
        "font:MediumSystemFontFile"
        "font:LargeSystemFontFile"
        "font:LargestSystemFontFile"
        "font:ExtraLargeSystemFontFile"
    ]
    boldFonts = [
        "font:TinyBoldSystemFontFile"
        "font:SmallerBoldSystemFontFile"
        "font:SmallestBoldSystemFontFile"
        "font:SmallBoldSystemFontFile"
        "font:MediumBoldSystemFontFile"
        "font:LargeBoldSystemFontFile"
        "font:ExtraLargeBoldSystemFontFile"
    ]
    for each font in regularFonts
        drawingStyles = drawingStyles.replace(font, m.global.fallbackFont.regular)
    end for
    for each font in boldFonts
        drawingStyles = drawingStyles.replace(font, m.global.fallbackFont.bold)
    end for
    m.top.drawingStyles = ParseJSON(drawingStyles)
end sub

sub onDrawingStylesChanged()
    setFont()
end sub
'//# sourceMappingURL=./MultiStyleText.brs.map