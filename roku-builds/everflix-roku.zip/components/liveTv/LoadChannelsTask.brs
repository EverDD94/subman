'import "pkg:/source/api/baserequest.bs"
'import "pkg:/source/api/sdk.bs"
'import "pkg:/source/enums/LiveTVChannelTitle.bs"
'import "pkg:/source/utils/config.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.top.filter = "All"
    m.top.sortField = "SortName"
    m.top.functionName = "loadChannels"
    m.top.favoritesAtTop = false
end sub

sub loadChannels()
    m.top.totalRecordCount = 0
    results = []
    favoriteResults = []
    standardResults = []
    sort_field = m.top.sortField
    if m.top.sortAscending = true
        sort_order = "Ascending"
    else
        sort_order = "Descending"
    end if
    params = {
        includeItemTypes: "LiveTvChannel"
        SortBy: sort_field
        SortOrder: sort_order
        UserId: m.global.session.user.id
        EnableFavoriteSorting: true
        EnableUserData: true
        AddCurrentProgram: false
        recursive: true
    }
    ' Handle special case when getting names starting with numeral
    if m.top.NameStartsWith <> ""
        if m.top.NameStartsWith = "#"
            params.searchterm = "A"
        else
            params.searchterm = m.top.nameStartsWith
        end if
    end if
    'Append voice search when there is text
    if m.top.searchTerm <> ""
        params.searchTerm = m.top.searchTerm
    end if
    if m.top.filter = "Favorites"
        params.append({
            isFavorite: true
        })
    end if
    data = api_items_Get(params)
    if data.TotalRecordCount = invalid
        m.top.channels = results
        return
    end if
    m.top.totalRecordCount = data.TotalRecordCount
    ' The TV guide builds every channel row up front, so make each row cheap: read the
    ' (shared) channel-title setting once instead of each row re-reading it from m.global,
    ' and defer logo-URL building. Both otherwise allocate a regex per row.
    titleFormat = chainLookupReturn(m.global.session, "user.settings.tvChannelTitleInfo", "numberName")
    for each item in data.Items
        channel = createObject("roSGNode", "ChannelData")
        channel.titleFormat = titleFormat
        channel.deferPoster = true
        channel.json = item
        if chainLookupReturn(item, "UserData.IsFavorite", false)
            channel.favorite = true
        end if
        if m.top.favoritesAtTop and channel.favorite
            favoriteResults.push(channel)
        else
            standardResults.push(channel)
        end if
    end for
    results.Append(favoriteResults)
    results.Append(standardResults)
    m.top.channels = results
end sub
'//# sourceMappingURL=./LoadChannelsTask.brs.map