'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/enums/TaskControl.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.state = "RUN"
    ' All channel rows are built up front (cheaply - logos deferred) so wrap-around
    ' navigation is stable, then schedules load in batches over that list: a small
    ' first batch for a fast first paint, then larger batches to finish the rest
    ' (including the wrap-around tail) in a few requests.
    m.channelScheduleLimit = 12
    m.channelBackgroundLimit = 60
    m.currentBatchSize = m.channelScheduleLimit
    m.channelBatchOffset = 0
    m.channelHasPlaceholder = {}
    m.channelIdList = []
    m.channelIndex = {}
    m.favoriteOverrides = {}
    ' Progressive load tuning:
    ' Paint a narrow window first so the grid appears quickly, then expand the
    ' loaded time range in the background up to the full horizon.
    m.initialWindowHours = 12
    m.backgroundWindowHours = 24
    m.backgroundExpandStep = 3
    m.allChannelsLoaded = false
    m.awaitingFirstPaint = true
    m.EPGLaunchCompleteSignaled = false
    m.scheduleGrid = m.top.findNode("scheduleGrid")
    m.detailsPane = m.top.findNode("detailsPane")
    m.gridData = createObject("roSGNode", "ContentNode")
    m.scheduleGrid.content = m.gridData
    m.detailsPane.observeField("watchSelectedChannel", "onWatchChannelSelected")
    m.detailsPane.observeField("recordSelectedChannel", "onRecordChannelSelected")
    m.detailsPane.observeField("recordSeriesSelectedChannel", "onRecordSeriesChannelSelected")
    m.gridStartDate = CreateObject("roDateTime")
    m.scheduleGrid.contentStartTime = m.gridStartDate.AsSeconds() - 1800
    m.gridEndDate = createObject("roDateTime")
    m.gridEndDate.FromSeconds(m.gridStartDate.AsSeconds() + (m.initialWindowHours * 60 * 60))
    m.scheduleGrid.observeField("programFocused", "onProgramFocused")
    m.scheduleGrid.observeField("programSelected", "onProgramSelected")
    m.scheduleGrid.observeField("leftEdgeTargetTime", "onGridScrolled")
    m.scheduleGrid.channelInfoWidth = 350
    m.scheduleGrid.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    m.scheduleGrid.programTitleFocusedColor = "#ffffff"
    m.scheduleGrid.timeLabelColor = "#aaaaaa"
    m.scheduleGrid.timeLabelFont.size = 30
    m.gridMoveAnimation = m.top.findNode("gridMoveAnimation")
    m.gridMoveAnimationPosition = m.top.findNode("gridMoveAnimationPosition")
    m.bgExpandTimer = m.top.findNode("bgExpandTimer")
    m.bgExpandTimer.observeField("fire", "onBgExpandTimerFire")
    m.LoadChannelsTask = createObject("roSGNode", "LoadChannelsTask")
    m.LoadChannelsTask.observeField("channels", "onChannelListLoaded")
    m.LoadChannelsTask.sortField = chainLookupReturn(m.global.session, "user.settings.`display.livetv.sortField`", "SortName")
    m.LoadChannelsTask.sortAscending = chainLookupReturn(m.global.session, "user.settings.`display.livetv.sortAscending`", true)
    m.LoadChannelsTask.favoritesAtTop = chainLookupReturn(m.global.session, "user.settings.`ui.guide.favorites.at.top`", false)
    m.LoadProgramDetailsTask = createObject("roSGNode", "LoadProgramDetailsTask")
    m.LoadProgramDetailsTask.observeField("programDetails", "onProgramDetailsLoaded")
    m.loadedChannels = {}
    m.top.filter = "All"
    loadChannelList()
    m.top.lastFocus = m.scheduleGrid
end sub

' Load the full channel list in one request. Building every row up front (cheaply -
' logos are deferred, see ChannelData.deferPoster) keeps the grid's row count stable
' so wrap-around navigation always targets the correct channel. Schedules then load
' in batches over this list.
sub loadChannelList(showSpinner = true as boolean)
    if not isStringEqual(m.state, "RUN") then
        return
    end if
    if showSpinner then
        startLoadingSpinner()
    end if
    m.LoadChannelsTask.control = "STOP"
    m.LoadChannelsTask.observeField("channels", "onChannelListLoaded")
    m.LoadChannelsTask.control = "RUN"
end sub

' Keep the cached guide in sync with favorite changes made during playback.
sub updateChannelFavorite(change as object)
    m.favoriteOverrides[change.channelId] = change.isFavorite
    for each channel in m.gridData.getChildren(-1, 0)
        if isStringEqual(channel.id, change.channelId)
            channel.favorite = change.isFavorite
            if isValid(m.detailsPane.channel) and isStringEqual(m.detailsPane.channel.id, change.channelId)
                m.detailsPane.callFunc("refreshFavorite")
            end if
            exit for
        end if
    end for
    ' Re-sort or apply the Favorites filter without covering the existing guide.
    if isStringEqual(m.top.filter, "Favorites") or m.LoadChannelsTask.favoritesAtTop
        loadChannelList(false)
    end if
end sub

' Reset progressive-load state so the next channel load starts a fresh initial window.
sub resetScheduleProgress()
    m.allChannelsLoaded = false
    m.awaitingFirstPaint = true
    m.channelBatchOffset = 0
    m.channelHasPlaceholder = {}
    if isValid(m.bgExpandTimer)
        m.bgExpandTimer.control = "stop"
    end if
    ' Reset the loaded horizon back to the initial narrow window
    m.gridEndDate.FromSeconds(m.gridStartDate.AsSeconds() + (m.initialWindowHours * 60 * 60))
end sub

sub onFilterSet()
    ' Do nothing if the selected filter didn't change
    if not isValid(m.top.filter) then
        return
    end if
    if isStringEqual(m.LoadChannelsTask.filter, m.top.filter) then
        return
    end if
    m.scheduleGrid.jumpToChannel = 0
    if m.LoadChannelsTask.state = "RUN" then
        m.LoadChannelsTask.control = "STOP"
    end if
    m.LoadChannelsTask.filter = m.top.filter
    m.gridData = createObject("roSGNode", "ContentNode")
    m.scheduleGrid.content = m.gridData
    m.LoadChannelsTask.channels = []
    m.loadedChannels = {}
    m.channelIdList = []
    m.channelIndex = {}
    resetScheduleProgress()
    loadChannelList()
end sub

'Voice Search set
sub onSearchTermSet()
    m.scheduleGrid.jumpToChannel = 0
    'Reset filter if user says all
    if isStringEqual(m.top.searchTerm, tr("all")) or isStringEqual(m.LoadChannelsTask.searchTerm, tr("all"))
        m.top.searchTerm = " "
        m.LoadChannelsTask.searchTerm = " "
        'filter if the searterm is not invalid
    else if isValid(m.top.searchTerm) and not isStringEqual(m.LoadChannelsTask.searchTerm, m.top.searchTerm)
        if m.LoadChannelsTask.state = "RUN" then
            m.LoadChannelsTask.control = "STOP"
        end if
        m.LoadChannelsTask.searchTerm = m.top.searchTerm
    end if
    m.gridData.removeChildren(m.gridData.getChildren(-1, 0))
    m.loadedChannels = {}
    m.channelIdList = []
    m.channelIndex = {}
    resetScheduleProgress()
    loadChannelList()
end sub

' All channels arrived. Build every row up front (cheaply - logos deferred) so the
' grid's row count is stable for wrap-around, then load schedules in batches.
sub onChannelListLoaded()
    m.LoadChannelsTask.control = "STOP"
    m.LoadChannelsTask.unobserveField("channels")
    channels = m.LoadChannelsTask.channels
    favoriteChannels = []
    standardChannels = []
    for each item in channels
        if m.favoriteOverrides.DoesExist(item.Id)
            desiredFavorite = m.favoriteOverrides[item.Id]
            if item.favorite = desiredFavorite
                m.favoriteOverrides.Delete(item.Id)
            else
                item.favorite = desiredFavorite
            end if
        end if
        if isStringEqual(m.top.filter, "Favorites") and not item.favorite then
            continue for
        end if
        if m.LoadChannelsTask.favoritesAtTop and item.favorite
            favoriteChannels.push(item)
        else
            standardChannels.push(item)
        end if
    end for
    channels = favoriteChannels
    channels.Append(standardChannels)
    m.channelBatchOffset = 0
    m.channelHasPlaceholder = {}
    m.channelIdList = []
    m.channelIndex = {}
    m.gridData.removeChildren(m.gridData.getChildren(-1, 0))
    counter = 0
    'if search returns no channels
    if channels.count() = 0
        m.LoadChannelsTask.channels = []
        stopLoadingSpinner()
        return
    end if
    for each item in channels
        m.gridData.appendChild(item)
        m.channelIndex[item.Id] = counter
        m.channelIdList.push(item.Id)
        ' Placeholder program shows channel name while EPG loads,
        ' replacing the default "No data available" TimeGrid text.
        placeholder = createObject("roSGNode", "ContentNode")
        placeholder.title = item.Title
        placeholder.PlayStart = m.gridStartDate.AsSeconds() - 1800
        placeholder.PlayDuration = 25 * 3600
        item.appendChild(placeholder)
        m.channelHasPlaceholder[item.Id] = true
        counter++
    end for
    m.LoadChannelsTask.channels = []
    m.channelScheduleLoadedCount = 0
    loadScheduleBatch()
end sub

' Load the initial-window schedule for the next slice of channels. The first slice is
' small (fast first paint); later slices are larger to finish the list in fewer requests.
sub loadScheduleBatch()
    if not isStringEqual(m.state, "RUN") then
        return
    end if
    if m.channelBatchOffset = 0
        m.currentBatchSize = m.channelScheduleLimit
    else
        m.currentBatchSize = m.channelBackgroundLimit
    end if
    channelSlice = m.channelIdList.slice(m.channelBatchOffset, m.channelBatchOffset + m.currentBatchSize)
    startScheduleTask(channelSlice, m.gridStartDate.ToISOString(), m.gridEndDate.ToISOString())
end sub

' Create a fresh LoadScheduleTask instance and start it. Stops any previous
' instance first to avoid leaked threads (Task nodes auto-stop when orphaned,
' but explicit stop is cleaner).
sub startScheduleTask(channelIds, startTime, endTime)
    if isValid(m.LoadScheduleTask)
        m.LoadScheduleTask.control = "STOP"
        m.LoadScheduleTask.unobserveField("schedule")
    end if
    m.LoadScheduleTask = createObject("roSGNode", "LoadScheduleTask")
    m.LoadScheduleTask.startTime = startTime
    m.LoadScheduleTask.endTime = endTime
    m.LoadScheduleTask.channelIds = channelIds
    m.LoadScheduleTask.observeField("schedule", "onScheduleLoaded")
    m.LoadScheduleTask.control = "RUN"
end sub

' Build channel logos for a slice of rows (deferred from row creation). Runs after the
' slice's schedule arrives, so it stays off the first-paint critical path.
sub populateChannelPosters(startIndex, count)
    last = startIndex + count - 1
    if last > m.channelIdList.count() - 1
        last = m.channelIdList.count() - 1
    end if
    for i = startIndex to last
        channel = m.scheduleGrid.content.GetChild(i)
        if isValid(channel)
            channel.callFunc("populatePoster")
        end if
    end for
end sub

' When LoadScheduleTask completes (initial, background expansion, or scroll) and we have a schedule to display
sub onScheduleLoaded()
    m.LoadScheduleTask.unobserveField("schedule")
    ' make sure we actually have a schedule (i.e. filter by favorites, but no channels have been favorited)
    if m.scheduleGrid.content.GetChildCount() <= 0
        return
    end if
    isFirstPaint = m.awaitingFirstPaint
    ' Build this slice's channel logos before merging so each program inherits the
    ' channel's logo (channelLogoUri). Only needed during the initial per-slice pass;
    ' background/scroll expansion reuses logos already populated here.
    if not m.allChannelsLoaded
        populateChannelPosters(m.channelBatchOffset, m.currentBatchSize)
    end if
    applyScheduleResults(m.LoadScheduleTask.schedule)
    m.scheduleGrid.showLoadingDataFeedback = false
    ' Only claim focus on the very first paint. Background expansion and scroll loads
    ' must not steal focus from the details pane or fight the user's scrolling.
    if isFirstPaint
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.scheduleGrid
    end if
    stopLoadingSpinner()
    if isFirstPaint
        m.awaitingFirstPaint = false
        if m.EPGLaunchCompleteSignaled = false
            m.top.signalBeacon("EPGLaunchComplete") ' Required Roku Performance monitoring
            m.EPGLaunchCompleteSignaled = true
        end if
    end if
    ' Phase 1: keep loading schedule batches until every channel's initial window is
    ' covered, then switch to background time-window expansion. Background/scroll
    ' expansion runs after this and skips the advance.
    if not m.allChannelsLoaded
        m.channelBatchOffset += m.currentBatchSize
        if m.channelBatchOffset < m.channelIdList.count()
            loadScheduleBatch()
            return
        end if
        m.allChannelsLoaded = true
        startBackgroundExpansion()
    end if
end sub

' Merge a batch of program nodes into their channels: drop the channel-name
' placeholder on first real program, skip duplicates from overlapping fetch windows
' (programs are sorted by start time, so comparing against the channel's last loaded
' program is enough), and stamp channel logo/name onto each program.
sub applyScheduleResults(schedule)
    if not isValid(schedule) then
        return
    end if
    for each item in schedule
        channelIndex = m.channelIndex[item.ChannelId]
        if not isValid(channelIndex) then
            continue for
        end if
        channel = m.scheduleGrid.content.GetChild(channelIndex)
        if not isValid(channel) then
            continue for
        end if
        ' Remove the channel-name placeholder before inserting the first real program.
        if m.channelHasPlaceholder[item.ChannelId] = true
            channel.removeChild(channel.getChild(0))
            m.channelHasPlaceholder[item.ChannelId] = false
        end if
        childCount = channel.getChildCount()
        if childCount > 0
            lastProg = channel.getChild(childCount - 1)
            if isValid(lastProg) and item.PlayStart < (lastProg.PlayStart + lastProg.PlayDuration)
                continue for
            end if
        end if
        if channel.PosterUrl <> ""
            item.channelLogoUri = channel.PosterUrl
        end if
        if channel.Title <> ""
            item.channelName = channel.Title
        end if
        channel.appendChild(item)
        m.loadedChannels[item.ChannelId] = 1
    end for
end sub

' Begin filling the rest of the day in the background, off the first-paint critical path.
sub startBackgroundExpansion()
    if m.gridEndDate.AsSeconds() >= m.gridStartDate.AsSeconds() + (m.backgroundWindowHours * 60 * 60)
        return
    end if
    m.bgExpandTimer.control = "start"
end sub

' Tick the background expansion: load the next time slice for all channels when idle.
sub onBgExpandTimerFire()
    if not isStringEqual(m.state, "RUN")
        m.bgExpandTimer.control = "stop"
        return
    end if
    ' Stop once the full horizon is loaded.
    if m.gridEndDate.AsSeconds() >= m.gridStartDate.AsSeconds() + (m.backgroundWindowHours * 60 * 60)
        m.bgExpandTimer.control = "stop"
        return
    end if
    ' Yield to in-flight loads (scroll expansion shares the same task node).
    if isStringEqual(chainLookup(m.LoadScheduleTask, "state"), "RUN") then
        return
    end if
    expandScheduleWindow(m.backgroundExpandStep)
end sub

' Extend the loaded time window by stepHours for all channels. Shared by the
' background timer and scroll expansion; both advance m.gridEndDate monotonically
' and are serialized by the LoadScheduleTask "run" state guard.
sub expandScheduleWindow(stepHours)
    sliceStart = m.gridEndDate.ToISOString()
    m.gridEndDate.FromSeconds(m.gridEndDate.AsSeconds() + (stepHours * 60 * 60))
    sliceEnd = m.gridEndDate.ToISOString()
    startScheduleTask(m.channelIdList, sliceStart, sliceEnd)
end sub

sub onProgramFocused()
    m.top.watchChannel = invalid
    ' Make sure we have channels (i.e. filter set to favorite yet there are none)
    if m.scheduleGrid.content.getChildCount() <= 0
        channel = invalid
    else
        channel = m.scheduleGrid.content.GetChild(m.scheduleGrid.programFocusedDetails.focusChannelIndex)
    end if
    m.detailsPane.channel = channel
    m.top.focusedChannel = channel
    ' Exit if Channels not yet loaded
    channelId = m.channelIdList[m.scheduleGrid.programFocusedDetails.focusChannelIndex]
    if not isValid(channel) or channel.getChildCount() = 0 or m.channelHasPlaceholder[channelId] = true
        m.detailsPane.programDetails = invalid
        return
    end if
    prog = channel.GetChild(m.scheduleGrid.programFocusedDetails.focusIndex)
    if prog <> invalid and prog.fullyLoaded = false
        m.LoadProgramDetailsTask.programId = prog.Id
        m.LoadProgramDetailsTask.channelIndex = m.scheduleGrid.programFocusedDetails.focusChannelIndex
        m.LoadProgramDetailsTask.programIndex = m.scheduleGrid.programFocusedDetails.focusIndex
        m.LoadProgramDetailsTask.control = "RUN"
    end if
    m.detailsPane.programDetails = prog
end sub

' Update the Program Details with full information
sub onProgramDetailsLoaded()
    if not isStringEqual(m.state, "RUN") then
        return
    end if
    if m.LoadProgramDetailsTask.programDetails = invalid then
        return
    end if
    channel = m.scheduleGrid.content.GetChild(m.LoadProgramDetailsTask.programDetails.channelIndex)
    ' If TV Show does not have its own image, use the channel logo
    if m.LoadProgramDetailsTask.programDetails.PosterUrl = invalid or m.LoadProgramDetailsTask.programDetails.PosterUrl = ""
        m.LoadProgramDetailsTask.programDetails.PosterUrl = channel.PosterUrl
    end if
    channel.ReplaceChild(m.LoadProgramDetailsTask.programDetails, m.LoadProgramDetailsTask.programDetails.programIndex)
    m.LoadProgramDetailsTask.programDetails = invalid
    m.scheduleGrid.showLoadingDataFeedback = false
end sub

sub onProgramSelected()
    ' If there is no program data - view the channel
    if m.detailsPane.programDetails = invalid
        m.top.watchChannel = m.scheduleGrid.content.GetChild(m.scheduleGrid.programFocusedDetails.focusChannelIndex)
        return
    end if
    ' Move Grid Down
    focusProgramDetails(true)
end sub

' Move the TV Guide Grid down or up depending whether details are selected
sub focusProgramDetails(setFocused)
    h = m.detailsPane.height
    if h < 400 then
        h = 400
    end if
    h = h + 160 + 80
    if setFocused = true
        m.gridMoveAnimationPosition.keyValue = [
            [
                0
                600
            ]
            [
                0
                h
            ]
        ]
        m.detailsPane.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.detailsPane
        m.detailsPane.hasFocus = true
        m.top.lastFocus = m.detailsPane
    else
        m.detailsPane.hasFocus = false
        m.gridMoveAnimationPosition.keyValue = [
            [
                0
                h
            ]
            [
                0
                600
            ]
        ]
        m.scheduleGrid.setFocus(true)
        group = m.global.sceneManager.callFunc("getActiveScene")
        group.lastFocus = m.scheduleGrid
        m.top.lastFocus = m.scheduleGrid
    end if
    m.gridMoveAnimation.control = "start"
end sub

' Handle user selecting "Watch Channel" from Program Details
sub onWatchChannelSelected()
    if m.detailsPane.watchSelectedChannel = false then
        return
    end if
    ' Set focus back to grid before showing channel, to ensure grid has focus when we return
    focusProgramDetails(false)
    m.top.watchChannel = m.detailsPane.channel
end sub

' As user scrolls grid, check if more data requires to be loaded
sub onGridScrolled()
    ' Don't let scroll prefetch run until the initial per-channel batch load has
    ' finished. Otherwise a future-window fetch can land on a channel before its
    ' current-window data, and the onScheduleLoaded dedup drops the real current
    ' programs as if they were duplicates (programs are assumed to arrive in order).
    if not m.allChannelsLoaded then
        return
    end if
    ' If we're within 6 hours of the loaded edge, load the next slice of data.
    ' (Background expansion proactively fills toward the full horizon; this covers
    ' fast scrolling and scrolling beyond that horizon.)
    if m.scheduleGrid.leftEdgeTargetTime + (6 * 60 * 60) > m.gridEndDate.AsSeconds()
        ' Ensure the task is not already (still) running.
        if not isStringEqual(chainLookup(m.LoadScheduleTask, "state"), "RUN")
            expandScheduleWindow(6)
        end if
    end if
end sub

' Handle user selecting "Record Channel" from Program Details
sub onRecordChannelSelected()
    if m.detailsPane.recordSelectedChannel = false then
        return
    end if
    ' Set focus back to grid before showing channel, to ensure grid has focus when we return
    focusProgramDetails(false)
    m.scheduleGrid.showLoadingDataFeedback = true
    m.RecordProgramTask = createObject("roSGNode", "RecordProgramTask")
    m.RecordProgramTask.programDetails = m.detailsPane.programDetails
    m.RecordProgramTask.recordSeries = false
    m.RecordProgramTask.observeField("recordOperationDone", "onRecordOperationDone")
    m.RecordProgramTask.control = "RUN"
end sub

' Handle user selecting "Record Series" from Program Details
sub onRecordSeriesChannelSelected()
    if m.detailsPane.recordSeriesSelectedChannel = false then
        return
    end if
    ' Set focus back to grid before showing channel, to ensure grid has focus when we return
    focusProgramDetails(false)
    m.scheduleGrid.showLoadingDataFeedback = true
    m.RecordProgramTask = createObject("roSGNode", "RecordProgramTask")
    m.RecordProgramTask.programDetails = m.detailsPane.programDetails
    m.RecordProgramTask.recordSeries = true
    m.RecordProgramTask.observeField("recordOperationDone", "onRecordOperationDone")
    m.RecordProgramTask.control = "RUN"
end sub

sub onRecordOperationDone()
    if m.RecordProgramTask.recordSeries = true and not isStringEqual(chainLookup(m.LoadSchedule, "state"), "RUN")
        startScheduleTask(m.channelIdList, m.gridStartDate.ToISOString(), m.gridEndDate.ToISOString())
    else
        ' This reloads just the details for the currently selected program, so that we don't have to
        ' reload the entire grid...
        channel = m.scheduleGrid.content.GetChild(m.scheduleGrid.programFocusedDetails.focusChannelIndex)
        prog = channel.GetChild(m.scheduleGrid.programFocusedDetails.focusIndex)
        m.LoadProgramDetailsTask.programId = prog.Id
        m.LoadProgramDetailsTask.channelIndex = m.scheduleGrid.programFocusedDetails.focusChannelIndex
        m.LoadProgramDetailsTask.programIndex = m.scheduleGrid.programFocusedDetails.focusIndex
        m.LoadProgramDetailsTask.control = "RUN"
    end if
end sub

' Tear down all tasks, timers, observers and content held by this guide instance.
' The node is recreated on each guide open, so this prevents tasks/observers/content
' from leaking across open/close cycles (see issue #598).
sub dispose()
    m.state = "STOP"
    if isValid(m.bgExpandTimer)
        m.bgExpandTimer.control = "stop"
        m.bgExpandTimer.unobserveField("fire")
    end if
    if isValid(m.LoadChannelsTask)
        m.LoadChannelsTask.control = "STOP"
        m.LoadChannelsTask.unobserveField("channels")
    end if
    if isValid(m.LoadScheduleTask)
        m.LoadScheduleTask.control = "STOP"
        m.LoadScheduleTask.unobserveField("schedule")
    end if
    if isValid(m.LoadProgramDetailsTask)
        m.LoadProgramDetailsTask.control = "STOP"
        m.LoadProgramDetailsTask.unobserveField("programDetails")
    end if
    if isValid(m.RecordProgramTask)
        m.RecordProgramTask.control = "STOP"
        m.RecordProgramTask.unobserveField("recordOperationDone")
    end if
    if isValid(m.detailsPane)
        m.detailsPane.unobserveField("watchSelectedChannel")
        m.detailsPane.unobserveField("recordSelectedChannel")
        m.detailsPane.unobserveField("recordSeriesSelectedChannel")
    end if
    if isValid(m.scheduleGrid)
        m.scheduleGrid.unobserveField("programFocused")
        m.scheduleGrid.unobserveField("programSelected")
        m.scheduleGrid.unobserveField("leftEdgeTargetTime")
        m.scheduleGrid.content = invalid
    end if
    m.gridData = invalid
    m.loadedChannels = {}
    m.channelIdList = []
    m.channelIndex = {}
    m.channelHasPlaceholder = {}
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    detailsGrp = m.top.findNode("detailsPane")
    gridGrp = m.top.findNode("scheduleGrid")
    if isStringEqual(key, "back")
        if detailsGrp.isInFocusChain()
            focusProgramDetails(false)
            detailsGrp.setFocus(false)
            gridGrp.setFocus(true)
            group = m.global.sceneManager.callFunc("getActiveScene")
            group.lastFocus = gridGrp
            return true
        end if
        dispose()
        m.global.sceneManager.callFunc("popScene")
        return true
    end if
    return false
end function
'//# sourceMappingURL=./schedule.brs.map