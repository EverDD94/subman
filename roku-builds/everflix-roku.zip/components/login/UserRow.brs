'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.top.focusBitmapBlendColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    m.top.itemComponentName = "UserItem"
    m.top.content = SetData()
    m.top.observeField("itemSelected", "SetUser")
    m.top.showRowLabel = [
        false
    ]
    updateSize()
    m.top.setFocus(true)
end sub

sub updateSize()
    itemWidth = 300
    itemHeight = 410
    m.top.visible = true
    ' Size of the individual rows
    m.top.itemSize = [
        1660
        itemHeight
    ]
    ' Spacing between Rows
    m.top.itemSpacing = [
        0
        40
    ]
    ' Size of items in the row
    m.top.rowItemSize = [
        itemWidth
        itemHeight
    ]
    ' Spacing between items in the row
    m.top.rowItemSpacing = [
        40
        0
    ]
end sub

function setData()
    if m.top.itemContent = invalid
        m.allowWraparoundNavigation = false
        m.lastUserIndex = 0
        data = CreateObject("roSGNode", "ContentNode")
        return data
    end if
    userData = m.top.itemContent
    userCount = userData.count()
    m.allowWraparoundNavigation = userCount > 1
    m.lastUserIndex = userCount - 1
    data = CreateObject("roSGNode", "ContentNode")
    row = data.CreateChild("ContentNode")
    for each item in userData
        row.appendChild(item)
    end for
    m.top.content = data
    updateSize()
    return data
end function

sub setUser()
    m.top.userSelected = m.top.itemContent[m.top.rowItemFocused[1]].Name
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if inArray([
        "left"
        "right"
    ], key)
        if not isValidAndNotEmpty(m.top.rowItemFocused) then
            return false
        end if
        if not m.allowWraparoundNavigation then
            return false
        end if
        focusedIndex = m.top.rowItemFocused[1]
        if isStringEqual("left", key) and focusedIndex = 0
            m.top.jumpToRowItem = [
                0
                m.lastUserIndex
            ]
            return true
        end if
        if isStringEqual("right", key) and focusedIndex = m.lastUserIndex
            m.top.jumpToRowItem = [
                0
                0
            ]
            return true
        end if
    end if
    return false
end function
'//# sourceMappingURL=./UserRow.brs.map