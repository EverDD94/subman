'import "pkg:/source/enums/ItemType.bs"
'import "pkg:/source/enums/MediaPlaybackState.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/enums/SubtitleSelection.bs"
'import "pkg:/source/enums/TaskControl.bs"
'import "pkg:/source/enums/TimerControl.bs"
'import "pkg:/source/enums/TransportCommand.bs"
'import "pkg:/source/enums/TransportStatus.bs"
'import "pkg:/source/enums/VideoControl.bs"


' Play Audio
sub CreateAudioPlayerView(showAudioPlayerView = false as boolean)
    currentItem = m.global.queueManager.callFunc("getCurrentItem")
    if not isValid(currentItem)
        stopLoadingSpinner()
        return
    end if
    audioItemChanged = m.global.audioPlayer.id <> currentItem.id
    if audioItemChanged
        m.global.audioPlayer.id = invalid
        m.global.audioPlayer.id = currentItem.id
    end if
    ' Only bypass creating an audio player view if the current queue is only audio
    if m.global.queueManager.callFunc("getQueueUniqueTypes").count() = 1
        if audioMiniPlayerIsVisible(m.top)
            if not showAudioPlayerView
                if not audioItemChanged then
                    stopLoadingSpinner()
                end if
                return
            end if
            m.audioMiniPlayer.callFunc("setVisible", false)
        end if
    end if
    m.view = CreateObject("roSGNode", "AudioPlayerView")
    m.view.observeField("state", "onStateChange")
    m.global.sceneManager.callFunc("pushScene", m.view)
end sub

' Play Audio
sub JumpIntoAudioPlayerView()
    m.view = CreateObject("roSGNode", "AudioPlayerView")
    ' Hide the mini player
    if audioMiniPlayerIsVisible(m.view)
        m.audioMiniPlayer.callFunc("setVisible", false)
    end if
    m.view.returnOnStop = true
    m.global.sceneManager.callFunc("pushScene", m.view)
end sub

' Play Video
sub CreateVideoPlayerView()
    m.playbackData = {}
    m.selectedSubtitle = {}
    ' Hide the mini player if needed
    if audioMiniPlayerIsVisible(m.top)
        m.audioMiniPlayer.callFunc("setVisible", false)
    end if
    ' Stop active audio and release its media content before creating the video player
    if inArray([
        "playing"
        "paused"
        "buffering"
    ], m.global.audioPlayer.state)
        m.global.audioPlayer.control = "STOP"
        m.global.audioPlayer.content = invalid
    end if
    ' If the user has set a preferred audio track index, use it
    preferredAudioTrackIndex = m.global.queueManager.callFunc("getPreferredAudioTrackIndex")
    if preferredAudioTrackIndex < 0 then
        preferredAudioTrackIndex = 0
    end if
    m.global.queueManager.callFunc("setSelectedAudioStreamIndex", preferredAudioTrackIndex)
    m.view = CreateObject("roSGNode", "VideoPlayerView")
    m.view.observeField("state", "onStateChange")
    m.view.observeField("nowPlayingMetadata", "onNowPlayingMetadata")
    m.view.observeField("selectPlaybackInfoPressed", "onSelectPlaybackInfoPressed")
    m.view.observeField("selectSubtitlePressed", "onSelectSubtitlePressed")
    m.view.observeField("selectAudioPressed", "onSelectAudioPressed")
    m.view.observeField("selectSpeedPressed", "onSelectSpeedPressed")
    ' Start VoiceInputTask to receive voice transport commands
    m.voiceInputTask = CreateObject("roSGNode", "VoiceInputTask")
    m.voiceInputTask.observeField("inputData", "onVoiceInputData")
    m.voiceInputTask.control = "RUN"
    mediaSourceId = m.global.queueManager.callFunc("getCurrentItem").mediaSourceId
    if not isValid(mediaSourceId) or mediaSourceId = ""
        mediaSourceId = m.global.queueManager.callFunc("getCurrentItem").id
    end if
    m.getPlaybackInfoTask = createObject("roSGNode", "GetPlaybackInfoTask")
    m.getPlaybackInfoTask.videoID = mediaSourceId
    m.getPlaybackInfoTask.observeField("data", "onPlaybackInfoLoaded")
    m.global.sceneManager.callFunc("pushScene", m.view)
end sub
' -----------------
' Event Handlers
' -----------------

' onSelectAudioPressed: Display audio selection dialog
'
sub onSelectAudioPressed()
    preferredAudioTrackName = m.global.queueManager.callFunc("getPreferredAudioTrackName")
    audioData = {
        data: []
    }
    for each item in m.view.fullAudioData
        audioStreamItem = {
            "Index": item.Index
            "RokuTrackName": item.RokuTrackName
            "IsExternal": item.IsExternal
            "Track": {
                "description": item.DisplayTitle
            }
            "Type": "audioselection"
        }
        if isStringEqual(preferredAudioTrackName, "")
            if m.view.audioIndex = item.Index
                audioStreamItem.selected = true
            end if
        else
            if isStringEqual(item.RokuTrackName, preferredAudioTrackName)
                audioStreamItem.selected = true
            end if
        end if
        audioData.data.push(audioStreamItem)
    end for
    m.global.sceneManager.callFunc("radioDialog", tr("Select Audio"), audioData)
    m.global.sceneManager.observeField("returnData", "onSelectionMade")
end sub

' onSelectSpeedPressed: Display audio selection dialog
'
sub onSelectSpeedPressed()
    speedData = {
        data: []
    }
    speeds = [
        0.5
        0.75
        1
        1.5
        2
        2.5
        3
    ]
    index = 0
    for each speed in speeds
        speedItem = {
            "Index": index
            "Speed": speed
            "IsExternal": false
            "Type": "speedselection"
            "Track": {
                "description": speed
            }
        }
        index++
        if speed = m.global.sceneManager.currentSpeed
            speedItem.selected = true
        end if
        speedData.data.push(speedItem)
    end for
    m.global.sceneManager.callFunc("radioDialog", tr("Select Speed"), speedData)
    m.global.sceneManager.observeField("returnData", "onSelectionMade")
end sub

' User requested subtitle selection popup
sub onSelectSubtitlePressed()
    subtitleData = {
        data: []
    }
    selectedSubtitleIsExternal = false
    for each item in m.view.fullSubtitleData
        item.type = "subtitleselection"
        if m.view.selectedSubtitle <> -1
            ' Subtitle is a track within the file
            if item.index = m.view.selectedSubtitle
                item.selected = true
                selectedSubtitleIsExternal = item.LookupCI("IsExternal")
            end if
        else
            ' Subtitle is from an external source
            availableSubtitleTrackIndex = availSubtitleTrackIdx(item.track.TrackName)
            if availableSubtitleTrackIndex <> -1
                ' Convert Jellyfin subtitle track name to Roku track name
                subtitleFullTrackName = m.view.availableSubtitleTracks[availableSubtitleTrackIndex].TrackName
                if subtitleFullTrackName = m.view.subtitleTrack
                    item.selected = true
                    selectedSubtitleIsExternal = item.LookupCI("IsExternal")
                end if
            end if
        end if
        item.StreamIndex = item.index
        ' Put the selected item at the top of the option list
        if isValid(item.selected) and item.selected
            subtitleData.data.Unshift(item)
        else
            subtitleData.data.push(item)
        end if
    end for
    ' Manually create the None option and place at top
    subtitleData.data.Unshift({
        "Index": -1
        "StreamIndex": -1
        "IsExternal": false
        "Track": {
            "description": "None"
        }
        "Type": "subtitleselection"
    })
    buttons = [
        tr("OK")
    ]
    if selectedSubtitleIsExternal
        if chainLookupReturn(m.global, "session.user.settings.`playback.subs.custom`", false)
            buttons.push(tr("Adjust Subtitle Timing"))
        end if
    end if
    m.global.sceneManager.callFunc("radioDialog", tr("Select Subtitles"), subtitleData, buttons)
    m.global.sceneManager.observeField("returnData", "onSelectionMade")
end sub

' User has selected something from the radioDialog popup
sub onSelectionMade()
    m.global.sceneManager.unobserveField("returnData")
    if not isValid(m.global.sceneManager.returnData) then
        return
    end if
    if not isValid(m.global.sceneManager.returnData.type) then
        return
    end if
    if LCase(m.global.sceneManager.returnData.type) = "subtitleselection"
        processSubtitleSelection()
        return
    end if
    if LCase(m.global.sceneManager.returnData.type) = "audioselection"
        processAudioSelection()
        return
    end if
    if isStringEqual(chainLookup(m.global.sceneManager, "returnData.type"), "speedselection")
        processSpeedSelection()
        return
    end if
end sub

' processAudioSelection: Audio track selection handler
'
sub processAudioSelection()
    selectedAudioTrack = m.global.sceneManager.returnData
    if not isChainValid(selectedAudioTrack, "index") then
        return
    end if
    m.global.queueManager.callFunc("setPreferredAudioTrackName", selectedAudioTrack.LookupCI("RokuTrackName"))
    for each audioTrack in m.view.availableAudioTracks
        if isStringEqual(audioTrack.LookupCI("name"), selectedAudioTrack.LookupCI("RokuTrackName"))
            m.global.queueManager.callFunc("setPreferredAudioTrackIndex", audioTrack.LookupCI("Track").toint())
            m.view.audioIndex = audioTrack.LookupCI("Track").toint()
            return
        end if
    end for
    m.global.queueManager.callFunc("setPreferredAudioTrackIndex", selectedAudioTrack.index)
    m.view.audioIndex = selectedAudioTrack.index
end sub

' processSpeedSelection: Speed selection handler
'
sub processSpeedSelection()
    selectedSpeed = chainLookupReturn(m.global.sceneManager, "returnData", {
        speed: 1
    })
    m.global.sceneManager.currentSpeed = selectedSpeed.speed
    m.view.selectedSpeed = selectedSpeed.speed
end sub

sub processSubtitleSelection()
    m.selectedSubtitle = m.global.sceneManager.returnData
    ' The selected encoded subtitle did not change.
    if m.view.selectedSubtitle <> -1 or m.selectedSubtitle.index <> -1
        if m.view.selectedSubtitle = m.selectedSubtitle.index then
            return
        end if
    end if
    ' The playbackData is now outdated and must be refreshed
    m.playbackData = invalid
    ' Find previously selected subtitle and identify if it was encoded
    for each item in m.view.fullSubtitleData
        if item.index = m.view.selectedSubtitle
            m.view.previousSubtitleWasEncoded = item.IsEncoded
            exit for
        end if
    end for
    if LCase(m.selectedSubtitle.track.description) = "none"
        m.view.globalCaptionMode = "Off"
        m.view.subtitleTrack = ""
        if m.view.selectedSubtitle <> -1
            m.view.selectedSubtitle = -1
        end if
        m.global.queueManager.callFunc("setPreferredSubtitleTrack", m.selectedSubtitle)
        return
    end if
    if m.selectedSubtitle.IsEncoded
        ' Roku can not natively display these subtitles, so turn off the caption mode on the device
        m.view.globalCaptionMode = "Off"
    else
        ' Roku can natively display these subtitles, ensure the caption mode on the device is on
        m.view.globalCaptionMode = "On"
        ' Roku may rearrange subtitle tracks. Look up track based on name to ensure we get the correct index
        availableSubtitleTrackIndex = availSubtitleTrackIdx(m.selectedSubtitle.Track.TrackName)
        if availableSubtitleTrackIndex = -1 then
            return
        end if
        m.view.subtitleTrack = m.view.availableSubtitleTracks[availableSubtitleTrackIndex].TrackName
    end if
    m.global.queueManager.callFunc("setPreferredSubtitleTrack", m.selectedSubtitle)
    m.view.selectedSubtitle = m.selectedSubtitle.Index
end sub

' User requested playback info
sub onSelectPlaybackInfoPressed()
    ' Check if we already have playback info and show it in a popup
    if isValid(m.playbackData) and isValid(m.playbackData.playbackinfo)
        m.global.sceneManager.callFunc("standardDialog", tr("Playback Info"), m.playbackData.playbackinfo)
        return
    end if
    m.getPlaybackInfoTask.control = "RUN"
end sub

' The playback info task has returned data
sub onPlaybackInfoLoaded()
    m.playbackData = m.getPlaybackInfoTask.data
    ' Check if we have playback info and show it in a popup
    if isValid(m.playbackData) and isValid(m.playbackData.playbackinfo)
        m.global.sceneManager.callFunc("standardDialog", tr("Playback Info"), m.playbackData.playbackinfo)
    end if
end sub

' Playback state change event handlers
sub onStateChange()
    ' Ignore errors, they are handled inside VideoPlayerView.bs
    if m.view.errorCode <> 0
        return
    end if
    if LCase(m.view.state) = "finished"
        if isValid(m.view.returnOnStop)
            if m.view.returnOnStop then
                return
            end if
        end if
        ' Close any open dialogs
        if m.global.sceneManager.callFunc("isDialogOpen")
            m.global.sceneManager.callFunc("dismissDialog")
        end if
        ' Check if user chose not to continue to next episode
        currentView = m.global.sceneManager.callFunc("getActiveScene")
        if isChainValid(currentView, "disableNextEpisodeAutoPlay")
            if currentView.disableNextEpisodeAutoPlay
                m.global.queueManager.callFunc("bypassNextPreferredAudioTrackIndexReset")
                m.global.queueManager.callFunc("clear")
                ' Stop VoiceInputTask when playback ends
                if isValid(m.voiceInputTask)
                    m.voiceInputTask.nowPlayingData = {
                        title: ""
                        contentType: ""
                    } ' clear before stopping
                    m.voiceInputTask.control = "STOP"
                end if
                ' Playback completed, return user to previous screen
                m.global.sceneManager.callFunc("popScene")
                m.global.audioPlayer.loopMode = ""
            end if
        end if
        ' If there is something next in the queue, Everflix shows it full screen first
        if m.global.queueManager.callFunc("getPosition") < m.global.queueManager.callFunc("getCount") - 1
            showEverflixNextUp()
            return
        end if
        episodeToShowAtFinish = ""
        gotoNextEpisodeAfterCurrentEnds = chainLookupReturn(m.global.session, "user.settings.`playback.showNextUpAfterFinish`", false)
        if gotoNextEpisodeAfterCurrentEnds
            episodeToShowAtFinish = m.global.queueManager.callFunc("getEpisodeToShowAtFinish")
        end if
        m.global.queueManager.callFunc("bypassNextPreferredAudioTrackIndexReset")
        m.global.queueManager.callFunc("clear")
        if isValidAndNotEmpty(episodeToShowAtFinish)
            m.global.queueManager.callFunc("setLastKnownItemID", episodeToShowAtFinish.LookupCI("id"))
        end if
        ' Stop VoiceInputTask when playback ends
        if isValid(m.voiceInputTask)
            m.voiceInputTask.nowPlayingData = {
                title: ""
                contentType: ""
            } ' clear before stopping
            m.voiceInputTask.control = "STOP"
        end if
        ' Playback completed, return user to previous screen
        m.global.sceneManager.callFunc("popScene")
        m.global.audioPlayer.loopMode = ""
    else if LCase(m.view.state) = "stopped"
        if isValid(m.voiceInputTask)
            m.voiceInputTask.nowPlayingData = {
                title: ""
                contentType: ""
            } ' clear before stopping
            m.voiceInputTask.control = "STOP"
        end if
    end if
end sub

' Everflix: "Siguiente" with a countdown, or "¿Sigues viendo?" after a long stretch without the remote
sub showEverflixNextUp()
    queue = m.global.queueManager
    nextItem = queue.callFunc("getItemByIndex", queue.callFunc("getPosition") + 1)
    json = {}
    if isValid(nextItem)
        if isValid(nextItem.json) then
            json = nextItem.json
        else
            json = nextItem
        end if
    end if
    if not isValid(m.global.efInARow) then
        m.global.addFields({
            efInARow: 0
        })
    end if
    minutes = chainLookupReturn(m.global.session, "user.settings.stillwatchingPopupInactivityTime", "0").ToInt()
    if minutes = 0 then
        minutes = 90
    end if
    deviceInfo = CreateObject("roDeviceInfo")
    idle = deviceInfo.TimeSinceLastKeypress() >= minutes * 60
    still = idle or m.global.efInARow >= 3
    m.efNextUp = CreateObject("roSGNode", "EfNextUp")
    m.efNextUp.stillWatching = still
    m.efNextUp.item = json
    m.efNextUp.observeField("result", "onEverflixNextUp")
    m.view.appendChild(m.efNextUp)
    m.efNextUp.setFocus(true)
end sub

sub onEverflixNextUp()
    result = m.efNextUp.result
    if isValid(m.view) then
        m.view.removeChild(m.efNextUp)
    end if
    if result = "next" or result = "next-auto"
        ' Episodes that roll on by themselves count towards "¿Sigues viendo?"
        if result = "next-auto" then
            m.global.efInARow = m.global.efInARow + 1
        else
            m.global.efInARow = 0
        end if
        m.global.sceneManager.callFunc("clearPreviousScene")
        m.global.queueManager.callFunc("moveForward")
        m.global.queueManager.callFunc("playQueue")
    else
        m.global.efInARow = 0
        m.global.queueManager.callFunc("bypassNextPreferredAudioTrackIndexReset")
        m.global.queueManager.callFunc("clear")
        m.global.sceneManager.callFunc("popScene")
    end if
    m.efNextUp = invalid
end sub

sub stillWatchingTimerComplete()
    m.stillWatchingTimer.control = "stop"
    ' Check if user pressed a button before the timer fired
    if m.deviceInfo.TimeSinceLastKeypress() <= 60 then
        return
    end if
    if m.global.sceneManager.callFunc("isDialogOpen")
        m.global.sceneManager.callFunc("dismissDialog")
    end if
    m.global.queueManager.callFunc("bypassNextPreferredAudioTrackIndexReset")
    m.global.queueManager.callFunc("clear")
    ' Stop VoiceInputTask when playback ends
    if isValid(m.voiceInputTask)
        m.voiceInputTask.nowPlayingData = {
            title: ""
            contentType: ""
        } ' clear before stopping
        m.voiceInputTask.control = "STOP"
    end if
    m.global.sceneManager.callFunc("popScene")
end sub

' Roku translates the info provided in subtitleTracks into availableSubtitleTracks
' Including ignoring tracks, if they are not understood, thus making indexing unpredictable.
' This function translates between our internel selected subtitle index
' and the corresponding index in availableSubtitleTracks.
function availSubtitleTrackIdx(tracknameToFind as string) as integer
    idx = 0
    for each availTrack in m.view.availableSubtitleTracks
        ' The TrackName must contain the URL we supplied originally, though
        ' Roku mangles the name a bit, so we check if the URL is a substring, rather
        ' than strict equality
        if Instr(1, availTrack.TrackName, tracknameToFind)
            return idx
        end if
        idx = idx + 1
    end for
    return -1
end function

function audioMiniPlayerIsVisible(baseNode as dynamic) as boolean
    m.audioMiniPlayer = invalid
    scene = baseNode.getScene()
    if not isValid(scene) then
        return false
    end if
    m.audioMiniPlayer = scene.findNode("audioMiniPlayer")
    if not isValid(m.audioMiniPlayer) then
        return false
    end if
    return m.audioMiniPlayer.callFunc("isVisible")
end function

' onVoiceInputData: Called when VoiceInputTask receives a voice/transport command.
' Decodes the command, handles it, and sends EventResponse back to Roku OS.
'
sub onVoiceInputData()
    if not isValid(m.view) then
        return
    end if
    data = m.voiceInputTask.inputData
    if not isChainValid(data, "type") then
        return
    end if
    ret = handleTransportCommand(data)
    ' Send EventResponse back to Roku OS with the result
    if isChainValid(data, "id")
        m.voiceInputTask.transportResponse = {
            id: data.id
            status: ret.status
        }
    end if
    ' Forward seek commands to VideoPlayerView
    if isValid(ret.cmd)
        m.view.voiceCommand = ret.cmd
    end if
end sub

' Forward Now Playing metadata from VideoPlayerView to VoiceInputTask.
' VoiceInputTask calls roAppManager on its own thread since it cannot be called from render thread.
sub onNowPlayingMetadata()
    if not isValid(m.voiceInputTask) then
        return
    end if
    m.voiceInputTask.nowPlayingData = m.view.nowPlayingMetadata
end sub

' handleTransportCommand: Decodes and handles a voice/transport command.
' Returns an assocarray with "status" and optionally "cmd" for VideoPlayerView.
' Status values follow Roku's EventResponse spec:
'   "success"   - command handled successfully
'   "unhandled" - command not handled, Roku OS will execute default behavior
'   "error.generic" - command not available in current context
'
function handleTransportCommand(data as object) as object
    ret = {
        status: "unhandled"
    }
    if not isValid(m.view) then
        return ret
    end if
    if isStringEqual(data.type, "seek")
        ret.cmd = {
            type: "seek"
            position: data.position
        }
        ret.status = "success"
        return ret
    end if
    if not isStringEqual(data.type, "transport") then
        return ret
    end if
    if not isChainValid(data, "command") then
        return ret
    end if
    cmd = LCase(data.command)
    if isStringEqual(cmd, "startover")
        ret.cmd = {
            type: "seek"
            position: 0
        }
        ret.status = "success"
    else if isStringEqual(cmd, "seek")
        currentPos = m.view.position
        duration = Val(data.duration)
        newPos = currentPos + duration
        if isStringEqual(data.direction, "backward")
            newPos = currentPos - duration
        end if
        if newPos < 0
            newPos = 0
            ret.status = "success.seek-start"
        else if newPos > m.view.duration
            newPos = m.view.duration - 30
            ret.status = "success.seek-end"
        else
            ret.status = "success"
        end if
        ret.cmd = {
            type: "seek"
            position: newPos
        }
    else if isStringEqual(cmd, "play") or isStringEqual(cmd, "resume")
        ret.cmd = {
            type: "play"
        }
        ret.status = "success"
    else if isStringEqual(cmd, "pause") or isStringEqual(cmd, "stop")
        ret.cmd = {
            type: "pause"
        }
        ret.status = "success"
    else if isStringEqual(cmd, "playpause")
        ret.status = "success"
    else if isStringEqual(cmd, "forward") or isStringEqual(cmd, "fastforward") or isStringEqual(cmd, "ff")
        if m.view.hasActiveSegment
            ret.cmd = {
                type: "skip"
            }
            ret.status = "success"
        else
            ret.status = "unhandled"
        end if
    else if isStringEqual(cmd, "rewind") or isStringEqual(cmd, "rw")
        ret.status = "unhandled"
    else if isStringEqual(cmd, "next")
        if m.view.hasActiveSegment
            ret.cmd = {
                type: "skip"
            }
            ret.status = "success"
        else if m.global.queueManager.callFunc("getPosition") < m.global.queueManager.callFunc("getCount") - 1
            m.global.sceneManager.callFunc("clearPreviousScene")
            m.global.queueManager.callFunc("moveForward")
            m.global.queueManager.callFunc("playQueue")
            ret.status = "success"
        else
            ret.status = "error.generic"
        end if
    else if isStringEqual(cmd, "replay")
        ret.status = "unhandled"
    else if isStringEqual(cmd, "nowplaying")
        ' Metadata was already sent to Roku OS when playback started in VideoPlayerView.
        currentItem = m.global.queueManager.callFunc("getCurrentItem")
        if isValid(currentItem)
            ret.status = "success"
        else
            ret.status = "error.generic"
        end if
    else if isStringEqual(cmd, "skip")
        ret.cmd = {
            type: "skip"
        }
        ret.status = "success"
    else if isStringEqual(cmd, "loop")
        ret.status = "unhandled"
    else if isStringEqual(cmd, "shuffle")
        ret.status = "unhandled"
    else if isStringEqual(cmd, "like")
        ret.status = "unhandled"
    else if isStringEqual(cmd, "dislike")
        ret.status = "unhandled"
    else if isStringEqual(cmd, "stop")
        ret.status = "unhandled"
    else if isStringEqual(cmd, "resume")
        ret.status = "unhandled"
    else if isStringEqual(cmd, "ok")
        ret.status = "unhandled"
    end if
    return ret
end function
'//# sourceMappingURL=./ViewCreator.brs.map