'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/KeyCode.bs"
'import "pkg:/source/enums/PlaybackMethod.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/enums/SubtitleSelection.bs"
'import "pkg:/source/utils/misc.bs"
' Category indexes shared by the row list and the m.menus array





sub init()
    m.optionsMenu = m.top.findNode("optionsMenu")
    m.detailPopup = m.top.findNode("detailPopup")
    m.detailTitle = m.top.findNode("detailTitle")
    m.top.findNode("optionsHeader").text = tr("Options")
    m.selectedAudioIndex = 0
    m.selectedVideoIndex = 0
    m.selectedSubtitleIndex = -1
    m.activeCategory = -1
    m.playbackLocked = false
    ' Concise labels shown on the Playback Mode row (the sub-popup may relabel disabled entries)
    m.playbackTitles = [
        tr("Play Normally")
        tr("Force Transcode (Allow Remux)")
        tr("Force Transcode (Remux Disabled)")
    ]
    m.optionMenu = m.top.findNode("optionMenu")
    m.menus = [
        m.top.findNode("subtitleMenu")
        m.top.findNode("audioMenu")
        m.top.findNode("videoMenu")
        m.optionMenu
    ]
    cursorColor = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    m.optionsMenu.focusBitmapBlendColor = cursorColor
    for each menu in m.menus
        menu.focusBitmapBlendColor = cursorColor
        menu.focusedColor = "#ffffff"
        ' Auto-close the sub-popup as soon as the user confirms a choice
        menu.observeField("itemSelected", "onDetailItemSelected")
    end for
    m.videoNames = []
    m.audioNames = []
    ' Build the single-page rows once, their values are filled in by optionsSet()
    m.rowContent = CreateObject("roSGNode", "ContentNode")
    m.rowSubtitle = m.rowContent.createChild("ContentNode")
    m.rowSubtitle.title = tr("Subtitles")
    m.rowAudio = m.rowContent.createChild("ContentNode")
    m.rowAudio.title = tr("Audio")
    m.rowVideo = m.rowContent.createChild("ContentNode")
    m.rowVideo.title = tr("Video")
    m.rowPlayback = m.rowContent.createChild("ContentNode")
    m.rowPlayback.title = tr("Playback Mode")
    ' optionCount drives whether the left/right chevrons are shown for a row
    for each row in [
        m.rowSubtitle
        m.rowAudio
        m.rowVideo
        m.rowPlayback
    ]
        row.addField("optionCount", "integer", false)
        row.optionCount = 0
    end for
    m.optionsMenu.content = m.rowContent
    m.top.observeField("visible", "onVisibleChange")
end sub

' Move focus onto the rows whenever the dialog becomes visible
sub onVisibleChange()
    if not m.top.visible then
        return
    end if
    m.detailPopup.visible = false
    m.activeCategory = -1
    m.optionsMenu.setFocus(true)
    group = m.global.sceneManager.callFunc("getActiveScene")
    group.lastFocus = m.optionsMenu
end sub

sub optionsSet()
    forceTranscodeSetting = chainLookupReturn(m.global.session, "user.settings.`playback.media.forceTranscode`", "playNormally")
    ' When force transcoding is dictated by a global setting, Playback Mode row is read-only
    m.playbackLocked = not isStringEqual("playNormally", forceTranscodeSetting)
    if not isStringEqual("playNormally", forceTranscodeSetting)
        normalOption = m.optionMenu.content.getChild(0)
        normalOption.title = tr("Play Normally - disabled because of selected force transcoding setting")
        if isStringEqual(forceTranscodeSetting, "forceTranscodeAllowRemux")
            transcodeOption = m.optionMenu.content.getChild(2)
            transcodeOption.title = tr("Force Transcode (Allow Remux) - disabled because of selected force transcoding setting")
            m.optionMenu.checkedItem = 1
        end if
        if isStringEqual(forceTranscodeSetting, "forceTranscodeDisableRemux")
            transcodeOption = m.optionMenu.content.getChild(1)
            transcodeOption.title = tr("Force Transcode (Remux Disabled) - disabled because of selected force transcoding setting")
            m.optionMenu.checkedItem = 2
        end if
    else if isStringEqual(m.global.queueManager.callFunc("getForceTranscode"), "forceTranscodeAllowRemux")
        m.optionMenu.checkedItem = 1
    else if isStringEqual(m.global.queueManager.callFunc("getForceTranscode"), "forceTranscodeDisableRemux")
        m.optionMenu.checkedItem = 2
    else
        m.optionMenu.checkedItem = 0
    end if
    m.rowPlayback.description = m.playbackTitles[m.optionMenu.checkedItem]
    if m.playbackLocked then
        m.rowPlayback.optionCount = 1
    else
        m.rowPlayback.optionCount = m.playbackTitles.count()
    end if
    '  Subtitle list
    if isValid(m.top.Options.subtitles)
        subtitleContent = CreateObject("roSGNode", "ContentNode")
        index = 0
        selectedSubtitleIndex = 0
        selectedSubtitleTitle = tr("None")
        for each subtitle in m.top.options.subtitles
            entry = subtitleContent.CreateChild("SubtitleTrackListData")
            entry.json = subtitle.json
            entry.title = subtitle.Title
            entry.description = subtitle.Title
            entry.StreamIndex = subtitle.StreamIndex
            if isValid(subtitle.Selected) and subtitle.Selected
                selectedSubtitleIndex = index
                entry.selected = true
                selectedSubtitleTitle = subtitle.Title
            end if
            index = index + 1
        end for
        m.menus[0].content = subtitleContent
        m.menus[0].jumpToItem = selectedSubtitleIndex
        m.menus[0].checkedItem = selectedSubtitleIndex
        m.selectedSubtitleIndex = selectedSubtitleIndex
        m.rowSubtitle.description = selectedSubtitleTitle
        m.rowSubtitle.optionCount = subtitleContent.getChildCount()
    end if
    '  Audio list
    if isValid(m.top.Options.audios)
        audioContent = CreateObject("roSGNode", "ContentNode")
        index = 0
        selectedAudioIndex = 0
        selectedAudioTitle = ""
        for each audio in m.top.options.audios
            entry = audioContent.CreateChild("AudioTrackListData")
            ' Some sources expose unnamed audio tracks, show "Default" so the row/list isn't blank
            if isValidAndNotEmpty(audio.Title) then
                audioTitle = audio.Title
            else
                audioTitle = tr("Default")
            end if
            entry.title = audioTitle
            if isValidAndNotEmpty(audio.Description) then
                entry.description = audio.Description
            else
                entry.description = audioTitle
            end if
            entry.streamIndex = audio.StreamIndex
            entry.streamName = audio.RokuTrackName
            m.audioNames.push(audio.Name)
            if audio.Selected <> invalid and audio.Selected
                selectedAudioIndex = index
                entry.selected = true
                selectedAudioTitle = audioTitle
                m.top.audioStreamName = audio.LookupCI("RokuTrackName")
                m.top.audioStreamIndex = audio.LookupCI("streamIndex")
            end if
            index = index + 1
        end for
        m.menus[1].content = audioContent
        m.menus[1].jumpToItem = selectedAudioIndex
        m.menus[1].checkedItem = selectedAudioIndex
        m.selectedAudioIndex = selectedAudioIndex
        if isValidAndNotEmpty(selectedAudioTitle) then
            m.rowAudio.description = selectedAudioTitle
        else
            m.rowAudio.description = tr("Default")
        end if
        m.rowAudio.optionCount = audioContent.getChildCount()
    end if
    '  Video list
    if isValid(m.top.options.videos)
        viewContent = CreateObject("roSGNode", "ContentNode")
        index = 0
        selectedViewIndex = 0
        selectedViewTitle = ""
        for each view in m.top.options.videos
            entry = viewContent.CreateChild("VideoTrackListData")
            entry.title = view.Title
            entry.description = view.Description
            entry.streamId = view.streamId
            entry.video_codec = view.video_codec
            entry.codec = view.codec
            m.videoNames.push(view.Name)
            if isValid(view.Selected) and view.Selected
                selectedViewIndex = index
                entry.selected = true
                selectedViewTitle = view.Title
                m.top.videoStreamId = view.streamId
            end if
            index = index + 1
        end for
        m.menus[2].content = viewContent
        m.menus[2].jumpToItem = selectedViewIndex
        m.menus[2].checkedItem = selectedViewIndex
        m.selectedVideoIndex = selectedViewIndex
        m.rowVideo.description = selectedViewTitle
        m.rowVideo.optionCount = viewContent.getChildCount()
    end if
end sub

' Index of the currently selected entry for a given category
function currentIndexFor(category as integer) as integer
    if category = 0 then
        return m.selectedSubtitleIndex
    end if
    if category = 1 then
        return m.selectedAudioIndex
    end if
    if category = 2 then
        return m.selectedVideoIndex
    end if
    return m.optionMenu.checkedItem
end function

' Open the full-list sub-popup for the focused row
sub openDetail(category as integer)
    m.activeCategory = category
    for i = 0 to m.menus.count() - 1
        if (i = category) then
            m.menus[i].opacity = 1
        else
            m.menus[i].opacity = 0
        end if
    end for
    m.detailTitle.text = m.rowContent.getChild(category).title
    m.detailPopup.visible = true
    selMenu = m.menus[category]
    selMenu.itemSelected = -1
    m.optionsMenu.setFocus(false)
    selMenu.setFocus(true)
    selMenu.drawFocusFeedback = true
    selMenu.jumpToItem = currentIndexFor(category)
    group = m.global.sceneManager.callFunc("getActiveScene")
    group.lastFocus = selMenu
end sub

' Close the sub-popup and return focus to the rows
sub closeDetail()
    if m.activeCategory >= 0
        m.menus[m.activeCategory].drawFocusFeedback = false
    end if
    m.detailPopup.visible = false
    m.activeCategory = -1
    m.optionsMenu.setFocus(true)
    group = m.global.sceneManager.callFunc("getActiveScene")
    group.lastFocus = m.optionsMenu
end sub

' Scroll the focused row's value left/right
sub cycleRow(category as integer, delta as integer)
    if category = 3 and m.playbackLocked then
        return
    end if
    selMenu = m.menus[category]
    if category = 3
        count = 3
    else if isValid(selMenu.content)
        count = selMenu.content.getChildCount()
    else
        count = 0
    end if
    if count <= 1 then
        return
    end if
    newIndex = currentIndexFor(category) + delta
    if newIndex < 0 then
        newIndex = count - 1
    end if
    if newIndex >= count then
        newIndex = 0
    end if
    applyCategorySelection(category, newIndex)
end sub

sub applyCategorySelection(category as integer, selIndex as integer)
    selMenu = m.menus[category]
    if category = 0
        if m.selectedSubtitleIndex <> selIndex
            selMenu.content.getChild(m.selectedSubtitleIndex).selected = false
            newSelection = selMenu.content.getChild(selIndex)
            newSelection.selected = true
            m.selectedSubtitleIndex = selIndex
            m.top.subtitleStream = newSelection
            m.global.queueManager.callFunc("setPreferredSubtitleTrack", newSelection)
            m.rowSubtitle.description = newSelection.title
            selMenu.checkedItem = selIndex
        end if
    else if category = 1
        if m.selectedAudioIndex <> selIndex
            selMenu.content.getChild(m.selectedAudioIndex).selected = false
            newSelection = selMenu.content.getChild(selIndex)
            newSelection.selected = true
            m.selectedAudioIndex = selIndex
            m.top.audioStreamName = newSelection.LookupCI("streamName")
            m.top.audioStreamIndex = newSelection.LookupCI("streamIndex")
            m.rowAudio.description = newSelection.title
            selMenu.checkedItem = selIndex
        end if
    else if category = 2
        if m.selectedVideoIndex <> selIndex
            selMenu.content.getChild(m.selectedVideoIndex).selected = false
            newSelection = selMenu.content.getChild(selIndex)
            newSelection.selected = true
            m.selectedVideoIndex = selIndex
            m.rowVideo.description = newSelection.title
            selMenu.checkedItem = selIndex
            ' Setting videoStreamId triggers MovieDetails to rebuild the audio/subtitle lists
            m.top.video_codec = newSelection.video_codec
            m.top.codec = newSelection.codec
            m.top.videoStreamId = newSelection.streamId
        end if
    else if category = 3
        if m.playbackLocked then
            return
        end if
        m.optionMenu.checkedItem = selIndex
        if selIndex = 0
            m.global.queueManager.callFunc("setForceTranscode", "playNormally")
        else if selIndex = 1
            m.global.queueManager.callFunc("setForceTranscode", "forceTranscodeAllowRemux", "")
        else if selIndex = 2
            m.global.queueManager.callFunc("setForceTranscode", "forceTranscodeDisableRemux", m.top.codec)
        end if
        m.rowPlayback.description = m.playbackTitles[selIndex]
    end if
end sub

' Confirming a choice in the sub-popup applies it and returns to the rows
sub onDetailItemSelected()
    if not m.detailPopup.visible or m.activeCategory < 0 then
        return
    end if
    selMenu = m.menus[m.activeCategory]
    if selMenu.itemSelected < 0 then
        return
    end if
    applyCategorySelection(m.activeCategory, selMenu.itemSelected)
    closeDetail()
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if m.detailPopup.visible
        if key = "back"
            closeDetail()
            return true
        end if
        return false
    end if
    ' Main single-page rows
    if key = "OK"
        openDetail(m.optionsMenu.itemFocused)
        return true
    else if key = "left"
        cycleRow(m.optionsMenu.itemFocused, -1)
        return true
    else if key = "right"
        cycleRow(m.optionsMenu.itemFocused, 1)
        return true
    end if
    return false
end function
'//# sourceMappingURL=./MovieOptions.brs.map