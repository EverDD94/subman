'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.categoryLabel = m.top.findNode("categoryLabel")
    m.valueLabel = m.top.findNode("valueLabel")
    m.leftArrow = m.top.findNode("leftArrow")
    m.rightArrow = m.top.findNode("rightArrow")
    focusChanged()
end sub

sub itemContentChanged()
    itemData = m.top.itemContent
    if not isValid(itemData) then
        return
    end if
    m.categoryLabel.text = itemData.title
    m.valueLabel.text = itemData.description
    updateArrows()
end sub

sub focusChanged()
    m.categoryLabel.color = "#ffffff"
    m.valueLabel.color = "#ffffff"
    if m.top.itemHasFocus
        m.categoryLabel.font = "font:MediumBoldSystemFont"
        m.valueLabel.font = "font:MediumBoldSystemFont"
        m.valueLabel.repeatCount = -1
    else
        m.categoryLabel.font = "font:MediumSystemFont"
        m.valueLabel.font = "font:MediumSystemFont"
        m.valueLabel.repeatCount = 0
    end if
    updateArrows()
end sub

sub updateArrows()
    itemData = m.top.itemContent
    hasMultiple = isValid(itemData) and itemData.optionCount > 1
    if (m.top.itemHasFocus and hasMultiple) then
        arrowOpacity = 1
    else
        arrowOpacity = 0
    end if
    m.leftArrow.opacity = arrowOpacity
    m.rightArrow.opacity = arrowOpacity
end sub
'//# sourceMappingURL=./OptionsRow.brs.map