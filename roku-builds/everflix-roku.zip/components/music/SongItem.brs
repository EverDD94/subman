'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/enums/FavoriteStatus.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/utils/misc.bs"

sub init()
    m.itemText = m.top.findNode("itemText")
    if isValid(m.itemText)
        m.itemText.font.size = 28
    end if
    m.trackNumber = m.top.findNode("trackNumber")
    if isValid(m.trackNumber)
        m.trackNumber.font.size = 28
    end if
    m.favoriteIcon = m.top.findNode("favoriteIcon")
    if isValid(m.favoriteIcon)
        m.favoriteIcon.blendColor = "#FF0000"
    end if
    m.favoriteStatusUnknown = m.top.findNode("favoriteStatusUnknown")
    if isValid(m.favoriteStatusUnknown)
        m.favoriteStatusUnknown.color = "#FF0000"
        m.favoriteStatusUnknown.font.size = 28
    end if
    m.tracklength = m.top.findNode("tracklength")
    if isValid(m.tracklength)
        m.tracklength.font.size = 28
    end if
    m.playCount = m.top.findNode("playCount")
    if isValid(m.playCount)
        m.playCount.font.size = 28
    end if
end sub

sub itemContentChanged()
    if isValid(m.itemData)
        m.itemData.unobserveFieldScoped("favorite")
        m.itemData.unobserveFieldScoped("favoriteStatus")
        m.itemData.unobserveFieldScoped("playCount")
    end if
    m.itemData = m.top.itemContent
    if not isValid(m.itemData)
        if isValid(m.favoriteIcon)
            m.favoriteIcon.visible = false
        end if
        if isValid(m.favoriteStatusUnknown)
            m.favoriteStatusUnknown.visible = false
        end if
        return
    end if
    m.itemData.observeFieldScoped("favorite", "onFavoriteChanged")
    m.itemData.observeFieldScoped("favoriteStatus", "onFavoriteChanged")
    m.itemData.observeFieldScoped("playCount", "onPlayCountChanged")
    onFavoriteChanged()
    onPlayCountChanged()
    itemData = m.itemData
    title = []
    isCompilation = chainLookupReturn(m.top.getParent(), "isCompilation", false)
    if isCompilation
        artists = chainLookup(itemData, "artists")
        if isValidAndNotEmpty(artists)
            title.push(artists[0])
        end if
    end if
    if isValidAndNotEmpty(itemData.LookupCI("title"))
        title.push(itemData.LookupCI("title"))
    end if
    m.itemText.text = title.join(" - ")
    if itemData.LookupCI("trackNumber") <> 0
        m.trackNumber.text = (bslib_toString(itemData.LookupCI("trackNumber")))
    end if
    if isValid(itemData.LookupCI("RunTimeTicks"))
        m.tracklength.text = ticksToHuman(itemData.LookupCI("RunTimeTicks"))
    end if
end sub

sub onFavoriteChanged()
    if not isValid(m.favoriteIcon) or not isValid(m.favoriteStatusUnknown) or not isValid(m.itemData) then
        return
    end if
    itemFavoriteStatus = chainLookupReturn(m.itemData, "favoriteStatus", "")
    if isStringEqual(itemFavoriteStatus, "unknown")
        m.favoriteIcon.visible = false
        m.favoriteStatusUnknown.visible = true
        return
    end if
    m.favoriteStatusUnknown.visible = false
    if isStringEqual(itemFavoriteStatus, "favorite")
        m.favoriteIcon.visible = true
        return
    end if
    if isStringEqual(itemFavoriteStatus, "notFavorite")
        m.favoriteIcon.visible = false
        return
    end if
    m.favoriteIcon.visible = chainLookupReturn(m.itemData, "favorite", false)
end sub

sub onPlayCountChanged()
    if not isValid(m.playCount) or not isValid(m.itemData) then
        return
    end if
    playCount = chainLookupReturn(m.itemData, "playCount", invalid)
    if isValid(playCount) then
        m.playCount.text = (bslib_toString(playCount))
    else
        m.playCount.text = ""
    end if
end sub
'//# sourceMappingURL=./SongItem.brs.map