'import "pkg:/source/enums/TransportCommand.bs"
'import "pkg:/source/utils/misc.bs"

' VoiceInputTask: Listens for roInput events on its own thread.
' Based on Roku's official transport-control sample.
' Uses enableTransportEvents() to receive voice/transport commands.
' Communicates results via inputData field and sends EventResponse to Roku OS.
'
sub init()
    m.port = CreateObject("roMessagePort")
    m.top.observeField("transportResponse", m.port)
    m.top.functionName = "runLoop"
    m.top.observeField("nowPlayingData", m.port)
end sub

' runLoop: Main task loop. Listens for roInput events and forwards them.
'
sub runLoop()
    m.input = CreateObject("roInput")
    m.input.SetMessagePort(m.port)
    ' Required to receive transport commands from Alexa and Roku voice remote
    m.input.enableTransportEvents()
    while true
        msg = m.port.waitMessage(500)
        if type(msg) = "roInputEvent"
            if msg.isInput()
                info = msg.getInfo()
                handleVoiceInput(info)
            end if
        else if type(msg) = "roSGNodeEvent"
            ' Send EventResponse back to Roku OS after command is handled
            if isStringEqual(msg.getField(), "transportResponse")
                response = msg.getData()
                if isValid(response) and isValid(response.id)
                    m.input.EventResponse({
                        id: response.id
                        status: response.status
                    })
                end if
                ' Send Now Playing metadata to Roku OS
            else if isStringEqual(msg.getField(), "nowPlayingData")
                data = msg.getData()
                if isChainValid(data, "title")
                    appMgr = CreateObject("roAppManager")
                    ' Roku Voice reads Now Playing metadata from roAppManager.
                    ' Keep this in TASK context; calling roAppManager from SceneGraph nodes fails.
                    appMgr.SetNowPlayingContentMetaData({
                        title: data.title
                        contentType: (function(data)
                                __bsConsequent = data.contentType
                                if __bsConsequent <> invalid then
                                    return __bsConsequent
                                else
                                    return "video"
                                end if
                            end function)(data)
                    })
                end if
            end if
        end if
    end while
end sub

' handleVoiceInput: Decodes the roInputEvent and forwards it to VideoPlayerView.
' Transport seek is relative (duration + direction), absolute seek uses seek_position.
'
sub handleVoiceInput(info as object)
    if not isValid(info) then
        return
    end if
    if not info.doesExist("type") then
        return
    end if
    if isStringEqual(info.type, "seek")
        if info.doesExist("seek_position")
            m.top.inputData = {
                type: "seek"
                position: Val(info.seek_position) / 1000.0
                id: info.id
            }
        end if
    else if isStringEqual(info.type, "transport")
        if not info.doesExist("command") then
            return
        end if
        m.top.inputData = {
            type: "transport"
            command: LCase(info.command)
            duration: info.duration
            direction: info.direction
            id: info.id
        }
    end if
end sub
'//# sourceMappingURL=./VoiceInputTask.brs.map