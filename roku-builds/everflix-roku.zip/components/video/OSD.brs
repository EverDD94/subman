'import "pkg:/source/enums/ColorPalette.bs"
'import "pkg:/source/utils/misc.bs"


 ' 1 hour
sub init()
    m.videoControls = m.top.findNode("videoControls")
    m.optionControls = m.top.findNode("optionControls")
    if isValid(m.videoControls)
        if chainLookupReturn(m.global.session, "user.settings.`playback.showPlaybackSpeedControls`", false)
            showSpeedMenu = createObject("roSGNode", "StandardButton")
            showSpeedMenu.id = "showSpeedMenu"
            showSpeedMenu.fontSize = "25"
            showSpeedMenu.padding = "20"
            showSpeedMenu.text = "1x"
            showSpeedMenu.height = "50"
            showSpeedMenu.width = "100"
            m.videoControls.appendChild(showSpeedMenu)
        end if
    end if
    m.inactivityTimeoutSetting = chainLookupReturn(m.global.session, "user.settings.`playback.inactiveTimeoutLength`", "5").ToInt()
    m.inactivityTimer = m.top.findNode("inactivityTimer")
    if isValid(m.inactivityTimer)
        if m.inactivityTimeoutSetting = 0
            inactivityTimerContainer = m.inactivityTimer.GetParent()
            inactivityTimerContainer.removeChild(m.inactivityTimer)
            m.inactivityTimer = invalid
        end if
    end if
    m.videoInfo = m.top.findNode("videoInfo")
    m.itemTitle = m.top.findNode("itemTitle")
    m.itemBack = m.top.findNode("itemBack")
    m.chapterBack = m.top.findNode("chapterBack")
    m.videoPlayPause = m.top.findNode("videoPlayPause")
    m.chapterNext = m.top.findNode("chapterNext")
    m.itemNext = m.top.findNode("itemNext")
    m.videoPositionTime = m.top.findNode("videoPositionTime")
    m.videoRemainingTime = m.top.findNode("videoRemainingTime")
    m.videoEndingTime = m.top.findNode("videoEndingTime")
    m.progressBar = m.top.findNode("progressBar")
    m.progressBarBackground = m.top.findNode("progressBarBackground")
    m.progressBarGroup = m.top.findNode("progressBarGroup")
    m.scrubber = m.top.findNode("scrubber")
    m.scrubberOldPosition = m.top.findnode("scrubberOldPosition")
    m.liveTvPos = m.top.findNode("liveTvPos")
    m.nextItem = m.top.FindNode("nextItem")
    m.previousItem = m.top.FindNode("previousItem")
    m.clock = m.top.FindNode("clock")
    m.top.observeField("visible", "onVisibleChanged")
    m.top.observeField("hasFocus", "onFocusChanged")
    m.top.observeField("progressPercentage", "onProgressPercentageChanged")
    m.top.observeField("playbackState", "onPlaybackStateChanged")
    m.top.observeField("videoEndingTime", "setVideoEndingTime")
    m.top.observeField("itemTitleText", "onItemTitleTextChanged")
    m.top.observeField("itemSubtitleText", "onItemSubtitleTextChanged")
    m.top.observeField("seasonNumber", "onSeasonNumberChanged")
    m.top.observeField("episodeNumber", "onEpisodeNumberChanged")
    m.top.observeField("episodeNumberEnd", "onEpisodeNumberEndChanged")
    m.top.observeField("logoImage", "onLogoImageChanged")
    m.top.observeField("previousItemIcon", "onPreviousItemIconChanged")
    m.top.observeField("previousItemTitleText", "onPreviousItemTitleTextChanged")
    m.top.observeField("nextItemIcon", "onNextItemIconChanged")
    m.top.observeField("nextItemTitleText", "onNextItemTitleTextChanged")
    m.top.observeField("playbackSpeed", "onPlaybackSpeedChanged")
    m.top.defaultButtonIndex = 2
    m.focusedButtonIndex = 2
    m.optionControlsMoved = false
    m.videoControls.buttonFocused = m.top.defaultButtonIndex
    m.optionControls.buttonFocused = m.optionControls.getChildCount() - 1
    m.videoControls.getChild(m.top.defaultButtonIndex).focus = true
    m.deviceInfo = CreateObject("roDeviceInfo")
    m.progressBarBackground.color = "0xFFFFFF38"
    m.progressBar.color = "0xF4F2EEFF"
    m.optionHint = m.top.findNode("optionHint")
    optionButtons = m.optionControls.getChildren(-1, 0)
    for each button in optionButtons
        button.observeField("focus", "onOptionFocusChanged")
        button.background = "#161A22"
        button.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    end for
    videoButtons = m.videoControls.getChildren(-1, 0)
    for each button in videoButtons
        button.background = "#161A22"
        button.focusBackground = chainLookupReturn(m.global.session, "user.settings.colorCursor", "0x3D63E0FF")
    end for
    m.top.isSeeking = false
    m.scrubberOldPosition.opacity = 0.66
    m.top.liveTvStartOffset = 0
    m.top.liveTvRewindLimit = 3600
    reloadUI()
    onTransportButtonStatusChanged()
end sub

' onProgressPercentageChanged: Handler for changes to m.top.progressPercentage param
'
sub onProgressPercentageChanged()
    positionTime = clampSeek(m.top.previewPos)
    updateProgressBar(m.top.live, positionTime)
end sub

' clampSeek: Clamps the given position to be within the bounds of the video duration or live TV rewind limit, depending on the content type.
'
' @param {integer} position - The position to clamp, in seconds.
' @return {integer} - The clamped position, in seconds.
function clampSeek(position as integer) as integer
    if m.top.live
        if position < m.top.liveTvStartOffset
            position = m.top.liveTvStartOffset
        else if position > m.top.progressDuration
            position = m.top.progressDuration
        end if
    else
        if position < 0
            position = 0
        else if position > m.top.progressDuration
            position = m.top.progressDuration
        end if
    end if
    return position
end function

sub setVideoEndingTime()
    m.videoEndingTime.text = m.top.videoEndingTime
end sub

' onPlaybackStateChanged: Handler for changes to m.top.playbackState param
'
sub onPlaybackStateChanged()
    if LCase(m.top.playbackState) = "playing"
        m.scrubberOldPosition.visible = false
        m.videoPlayPause.icon = "pkg:/images/icons/pause.png"
        return
    end if
    m.scrubberOldPosition.visible = true
    m.videoPlayPause.icon = "pkg:/images/icons/play.png"
end sub

' onItemTitleTextChanged: Handler for changes to m.top.itemTitleText param.
'
sub onItemTitleTextChanged()
    m.itemTitle.text = m.top.itemTitleText
end sub

sub onItemSubtitleTextChanged()
    itemSeason = m.top.findNode("itemSeason")
    itemSeason.font.size = 26
    itemSeason.text = m.top.itemSubtitleText
    ' Move the option controls down to give room for season number
    if not m.optionControlsMoved
        moveOptionControls(0, 50)
        m.optionControlsMoved = true
    end if
end sub

' onSeasonNumberChanged: Handler for changes to m.top.seasonNumber param.
'
sub onSeasonNumberChanged()
    m.top.unobserveField("seasonNumber")
    itemSeason = m.top.findNode("itemSeason")
    itemSeason.font.size = 26
    itemSeason.text = ("T" + bslib_toString(m.top.seasonNumber))
    ' Move the option controls down to give room for season number
    if not m.optionControlsMoved
        moveOptionControls(0, 50)
        m.optionControlsMoved = true
    end if
end sub

' onEpisodeNumberChanged: Handler for changes to m.top.episodeNumber param.
'
sub onEpisodeNumberChanged()
    m.top.unobserveField("episodeNumber")
    itemEpisode = m.top.findNode("itemEpisode")
    itemEpisode.font.size = 26
    itemEpisode.text = (" · E" + bslib_toString(m.top.episodeNumber))
    ' Move the option controls down to give room for episode number
    if not m.optionControlsMoved
        moveOptionControls(0, 50)
        m.optionControlsMoved = true
    end if
end sub

' onEpisodeNumberEndChanged: Handler for changes to m.top.episodeNumberEnd param.
'
sub onEpisodeNumberEndChanged()
    m.top.unobserveField("episodeNumberEnd")
    itemEpisodeEnd = m.top.findNode("itemEpisodeEnd")
    itemEpisodeEnd.font.size = 26
    itemEpisodeEnd.text = ("-" + bslib_toString(m.top.episodeNumberEnd))
    ' Move the option controls down to give room for episode number
    if not m.optionControlsMoved
        moveOptionControls(0, 50)
        m.optionControlsMoved = true
    end if
end sub

' moveOptionControls: Moves option controls node based on passed pixel values
'
' @param {integer} horizontalPixels - Number of horizontal pixels to move option controls
' @param {integer} verticalPixels - Number of vertical pixels to move option controls
sub moveOptionControls(horizontalPixels as integer, verticalPixels as integer)
    ' Everflix: the title sits above the bottom panel now, so the top pills never move
    return
    m.optionControls.translation = ("[" + bslib_toString(m.optionControls.translation[0] + horizontalPixels) + ", " + bslib_toString(m.optionControls.translation[1] + verticalPixels) + "]")
end sub

' onLogoLoadStatusChanged: Handler for changes to logo image's status.
'
' @param {dynamic} event - field change event
sub onLogoLoadStatusChanged(event)
    if LCase(event.GetData()) = "ready"
        logoImage = event.getRoSGNode()
        logoImage.unobserveField("loadStatus")
        ' Move video info to the right based on the logo width
        m.videoInfo.translation = ("[" + bslib_toString(m.videoInfo.translation[0] + logoImage.bitmapWidth + 30) + ", " + bslib_toString(m.videoInfo.translation[1]) + "]")
        m.itemTitle.maxWidth = m.itemTitle.maxWidth - (logoImage.bitmapWidth + 30)
        ' Move the option controls down based on the logo height
        if not m.optionControlsMoved
            moveOptionControls(0, 50)
            m.optionControlsMoved = true
        end if
    end if
end sub

' onLogoImageChanged: Handler for changes to m.top.logoImage param.
'
sub onLogoImageChanged()
    ' Everflix: the bottom-left title replaces the logo
    return
    if isValidAndNotEmpty(m.top.logoImage)
        logoImage = createObject("roSGNode", "Poster")
        logoImage.Id = "logoImage"
        logoImage.observeField("loadStatus", "onLogoLoadStatusChanged")
        logoImage.uri = m.top.logoImage
        logoImage.translation = [
            103
            61
        ]
        m.top.appendChild(logoImage)
    end if
end sub

' onPreviousItemIconChanged: Handler for changes to m.top.previousItemIcon param.
'
sub onPreviousItemIconChanged()
    m.previousItem.icon = m.top.previousItemIcon
end sub

' onPreviousItemTitleTextChanged: Handler for changes to m.top.previousItemTitleText param.
'
sub onPreviousItemTitleTextChanged()
    m.previousItem.text = m.top.previousItemTitleText
end sub

' onNextItemIconChanged: Handler for changes to m.top.nextItemIcon param.
'
sub onNextItemIconChanged()
    m.nextItem.icon = m.top.nextItemIcon
end sub

' onPlaybackSpeedChanged: Handler for changes to m.top.playbackSpeed param.
'
sub onPlaybackSpeedChanged()
    showSpeedMenu = m.top.findNode("showSpeedMenu")
    if not isValid(showSpeedMenu) then
        return
    end if
    showSpeedMenu.text = (bslib_toString(m.top.playbackSpeed) + "x")
end sub

' onNextItemTitleTextChanged: Handler for changes to m.top.nextItemTitleText param.
'
sub onNextItemTitleTextChanged()
    m.nextItem.text = m.top.nextItemTitleText
end sub

' isButtonFocusable: Returns true if button is valid, has focus field, and is both visible and enabled
'
function isButtonFocusable(button as dynamic) as boolean
    if not isValid(button) then
        return false
    end if
    if not isValid(button.focus) then
        return false
    end if
    if isValid(button.visible) and not button.visible then
        return false
    end if
    if isValid(button.enabled) and not button.enabled then
        return false
    end if
    return true
end function

' onTransportButtonStatusChanged: Updates enabled states of bottom transport buttons
'
sub onTransportButtonStatusChanged()
    if isValid(m.itemBack)
        m.itemBack.enabled = m.top.itemBackEnabled
    end if
    if isValid(m.chapterBack)
        m.chapterBack.enabled = m.top.chapterBackEnabled
    end if
    if isValid(m.chapterNext)
        m.chapterNext.enabled = m.top.chapterNextEnabled
    end if
    if isValid(m.itemNext)
        m.itemNext.enabled = m.top.itemNextEnabled
    end if
    ' If the currently focused button in videoControls is now disabled, reset focus to default
    if isValid(m.videoControls) and m.videoControls.isInFocusChain()
        focusedButton = m.videoControls.getChild(m.focusedButtonIndex)
        if not isButtonFocusable(focusedButton)
            resetFocusToDefaultButton()
        end if
    end if
end sub

' focusRightmostVideoControl: Focus the rightmost enabled/focusable button in videoControls
'
sub focusRightmostVideoControl()
    rightmostIndex = -1
    for i = m.videoControls.getChildCount() - 1 to 0 step -1
        button = m.videoControls.getChild(i)
        if isButtonFocusable(button)
            rightmostIndex = i
            exit for
        end if
    end for
    if rightmostIndex = -1 then
        rightmostIndex = m.top.defaultButtonIndex
    end if
    for each child in m.videoControls.getChildren(-1, 0)
        if isValid(child.focus) then
            child.focus = false
        end if
    end for
    m.focusedButtonIndex = rightmostIndex
    m.videoControls.buttonFocused = rightmostIndex
    focusedButton = m.videoControls.getChild(rightmostIndex)
    if isValid(focusedButton) and isValid(focusedButton.focus)
        focusedButton.focus = true
        if m.videoControls.isInFocusChain() then
            focusedButtonID = focusedButton.id
        else
            focusedButtonID = ""
        end if
        checkDisplaySiblingItem(focusedButtonID)
    end if
    m.videoControls.setFocus(true)
end sub

' resetFocusToDefaultButton: Reset focus back to the default button
'
sub resetFocusToDefaultButton()
    ' Remove focus from previously selected button
    for each child in m.videoControls.getChildren(-1, 0)
        if isValid(child.focus)
            child.focus = false
        end if
    end for
    for each child in m.optionControls.getChildren(-1, 0)
        if isValid(child.focus)
            child.focus = false
        end if
    end for
    m.optionControls.setFocus(false)
    ' Set focus back to the default button
    m.videoControls.setFocus(true)
    targetIndex = m.top.defaultButtonIndex
    defaultButton = m.videoControls.getChild(targetIndex)
    if not isButtonFocusable(defaultButton)
        for i = 0 to m.videoControls.getChildCount() - 1
            button = m.videoControls.getChild(i)
            if isButtonFocusable(button)
                targetIndex = i
                exit for
            end if
        end for
    end if
    m.focusedButtonIndex = targetIndex
    buttonToFocus = m.videoControls.getChild(targetIndex)
    if isValid(buttonToFocus) and isValid(buttonToFocus.focus)
        buttonToFocus.focus = true
    end if
    m.videoControls.buttonFocused = targetIndex
    m.optionControls.buttonFocused = m.optionControls.getChildCount() - 1
end sub

' onVisibleChanged: Handler for changes to the visibility of this menu.
'
sub onVisibleChanged()
    if m.top.visible
        resetFocusToDefaultButton()
        if isValid(m.inactivityTimer)
            m.inactivityTimer.observeField("fire", "inactiveCheck")
            m.inactivityTimer.control = "start"
        end if
        return
    end if
    if not isValid(m.inactivityTimer) then
        return
    end if
    m.inactivityTimer.unobserveField("fire")
    m.inactivityTimer.control = "stop"
end sub

' onFocusChanged: Handler for changes to the focus of this menu.
'
sub onFocusChanged()
    if m.top.hasfocus
        focusedButton = m.optionControls.getChild(m.focusedButtonIndex)
        if focusedButton.focus
            m.optionControls.setFocus(true)
            return
        end if
        m.videoControls.setFocus(true)
    end if
end sub

' inactiveCheck: Checks if the time since last keypress is greater than or equal to the allowed inactive time of the menu.
'
sub inactiveCheck()
    ' If user is currently seeing a dialog box, ignore inactive check
    if m.global.sceneManager.callFunc("isDialogOpen")
        return
    end if
    ' If user is seeking (such as fastforwarding), ignore inactive check
    if m.top.isSeeking
        return
    end if
    if m.deviceInfo.timeSinceLastKeypress() >= m.inactivityTimeoutSetting
        checkDisplaySiblingItem("")
        m.top.action = "hide"
    end if
end sub

' onButtonSelected: Handler for selection of buttons from the menu.
'
sub onButtonSelected()
    if m.optionControls.isInFocusChain()
        buttonGroup = m.optionControls
    else
        buttonGroup = m.videoControls
    end if
    selectedButton = buttonGroup.getChild(m.focusedButtonIndex)
    ' If selected button is disabled, do nothing
    if isValid(selectedButton) and isValid(selectedButton.enabled) and not selectedButton.enabled
        return
    end if
    if LCase(selectedButton.id) = "chapterlist"
        m.top.showChapterList = not m.top.showChapterList
    end if
    checkDisplaySiblingItem("")
    m.top.action = selectedButton.id
end sub

' checkDisplaySiblingItem: Determine visible state for both previous and next item popups
'
sub checkDisplaySiblingItem(selectedButtonID)
    if not isValidAndNotEmpty(selectedButtonID) then
        selectedButtonID = ""
    end if
    selectedButtonID = LCase(selectedButtonID)
    showNextItem = false
    if selectedButtonID = "itemnext" and m.top.itemNextEnabled
        showNextItem = true
    end if
    if not isValidAndNotEmpty(m.nextItem.text)
        showNextItem = false
    end if
    m.nextItem.visible = showNextItem
    showPreviousItem = false
    if selectedButtonID = "itemback" and m.top.itemBackEnabled
        showPreviousItem = true
    end if
    if not isValidAndNotEmpty(m.previousItem.text)
        showPreviousItem = false
    end if
    m.previousItem.visible = showPreviousItem
end sub

' onKeyEvent: Handler for key events when this menu is in focus. Handles navigation within the menu.
'
' @param {string} key - the key that was pressed
' @param {boolean} press - whether the key was pressed down (true) or released (false)
' @return {boolen} - returns true if the key event was handled, false if it should be passed through
function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        return false
    end if
    if not m.progressBarGroup.hasfocus()
        if key = "OK"
            onButtonSelected()
            return true
        end if
        if key = "play"
            checkDisplaySiblingItem("")
            m.top.action = "videoplaypause"
            return true
        end if
        if key = "right"
            if m.optionControls.isInFocusChain()
                buttonGroup = m.optionControls
            else
                buttonGroup = m.videoControls
            end if
            ' Look for the next focusable and enabled button to the right
            nextFocusIndex = -1
            for i = m.focusedButtonIndex + 1 to buttonGroup.getChildCount() - 1
                button = buttonGroup.getChild(i)
                if isButtonFocusable(button)
                    nextFocusIndex = i
                    exit for
                end if
            end for
            if nextFocusIndex <> -1
                focusedButton = buttonGroup.getChild(m.focusedButtonIndex)
                if isValid(focusedButton) and isValid(focusedButton.focus)
                    focusedButton.focus = false
                end if
                m.focusedButtonIndex = nextFocusIndex
                focusedButton = buttonGroup.getChild(m.focusedButtonIndex)
                buttonGroup.buttonFocused = m.focusedButtonIndex
                focusedButton.focus = true
                if m.videoControls.isInFocusChain() then
                    focusedButtonID = focusedButton.id
                else
                    focusedButtonID = ""
                end if
                checkDisplaySiblingItem(focusedButtonID)
                return true
            end if
            ' No focusable button to the right in this group.
            ' Check if we can move focus to skipSegmentButton if we are in videoControls
            m.top.action = "checkskipsegmentbuttonvisible"
            if m.top.skipSegmentButtonVisible and m.videoControls.isInFocusChain()
                buttonGroup.setFocus(false)
                m.top.action = "setskipsegmentbuttonfocus"
                focusedButton = buttonGroup.getChild(m.focusedButtonIndex)
                if isValid(focusedButton) and isValid(focusedButton.focus)
                    focusedButton.focus = false
                end if
                checkDisplaySiblingItem("")
            end if
            return true
        end if
        if key = "left"
            if m.focusedButtonIndex = 0
                return true
            end if
            if m.optionControls.isInFocusChain()
                buttonGroup = m.optionControls
            else
                buttonGroup = m.videoControls
            end if
            ' Look for the previous focusable and enabled button to the left
            nextFocusIndex = -1
            for i = m.focusedButtonIndex - 1 to 0 step -1
                button = buttonGroup.getChild(i)
                if isButtonFocusable(button)
                    nextFocusIndex = i
                    exit for
                end if
            end for
            if nextFocusIndex <> -1
                focusedButton = buttonGroup.getChild(m.focusedButtonIndex)
                if isValid(focusedButton) and isValid(focusedButton.focus)
                    focusedButton.focus = false
                end if
                m.focusedButtonIndex = nextFocusIndex
                focusedButton = buttonGroup.getChild(m.focusedButtonIndex)
                buttonGroup.buttonFocused = m.focusedButtonIndex
                focusedButton.focus = true
                if m.videoControls.isInFocusChain() then
                    focusedButtonID = focusedButton.id
                else
                    focusedButtonID = ""
                end if
                checkDisplaySiblingItem(focusedButtonID)
            end if
            return true
        end if
    end if
    ' Move up from videoControls to progressBarGroup
    if key = "up" and m.videoControls.hasfocus()
        if m.videoControls.isInFocusChain() then
            setOsdStatus("progressBarGroup")
        end if
        return true
    end if
    ' Move up from progressBarGroup to optionControls
    if key = "up" and m.progressBarGroup.hasfocus()
        if m.progressBarGroup.isInFocusChain() then
            setOsdStatus("optionControls")
        end if
        return true
    end if
    ' Move down from optionControls to progressBarGroup
    if key = "down" and m.optionControls.hasfocus()
        if m.optionControls.isInFocusChain() then
            setOsdStatus("progressBarGroup")
        end if
        return true
    end if
    ' Move down from progressBarGroup to videoControls
    if key = "down" and m.progressBarGroup.hasFocus()
        if m.progressBarGroup.isInFocusChain() then
            setOsdStatus("videoControls")
        end if
        return true
    end if
    ' Look for video seek buttons being pressed and execute the seek action
    if key = "right" or key = "left" or key = "fastforward" or key = "rewind" or key = "OK" or key = "play"
        if not m.progressBarGroup.isInFocusChain() then
            setOsdStatus("progressBarGroup")
        end if
        m.top.osdSeekKeyValue = key
        m.top.action = "handleseekkey"
        return true
    end if
    ' All other keys hide the menu
    m.top.isSeeking = false
    checkDisplaySiblingItem("")
    m.top.action = "hide"
    return true
end function

' setOsdStatus: Sets the focus and visibility of OSD elements based on which section of the OSD should be in focus.
'
' @param {string} whichfocus - the section of the OSD that should be in focus.  Expected values are "optionControls", "videoControls", and "progressBarGroup".
sub setOsdStatus(whichfocus as string)
    if whichfocus = "optionControls"
        m.scrubber.visible = false
        m.progressBarGroup.setFocus(false)
        m.focusedButtonIndex = m.optionControls.buttonFocused
        focusedButton = m.optionControls.getChild(m.focusedButtonIndex)
        focusedButton.focus = true
        m.optionControls.setFocus(true)
        m.top.action = "stopfastforwardorrewind"
    else if whichfocus = "videoControls"
        m.scrubber.visible = false
        m.progressBarGroup.setFocus(false)
        m.focusedButtonIndex = m.videoControls.buttonFocused
        focusedButton = m.videoControls.getChild(m.focusedButtonIndex)
        focusedButton.focus = true
        m.videoControls.setFocus(true)
        m.top.action = "stopfastforwardorrewind"
        resetFocusToDefaultButton()
    else if whichfocus = "progressBarGroup"
        m.scrubber.visible = true
        m.scrubberOldPosition.visible = true
        checkDisplaySiblingItem("")
        resetFocusToDefaultButton()
        m.videoControls.getChild(m.focusedButtonIndex).focus = false
        m.optionControls.getChild(m.focusedButtonIndex).focus = false
        m.videoControls.setFocus(false)
        m.optionControls.setFocus(false)
        m.progressBarGroup.setFocus(true)
    end if
end sub

' reloadUI: Recalculates and sets the positions of the scrubber and old position indicator on the progress bar.
'
sub reloadUI()
    scrubberYTranslation = (m.progressBar.height - m.scrubber.height) / 2
    scrubberXTranslation = (m.scrubber.width) / 2
    m.scrubber.translation = [
        -scrubberXTranslation
        scrubberYTranslation
    ]
    m.scrubberOldPosition.translation = [
        m.progressBarBackground.translation[0] - m.scrubberOldPosition.width / 2
        scrubberYTranslation
    ]
end sub

' updateProgressBar: Update the scrubber and current position indicators during seeking or normal playback, depending on whether the content is live TV or not.
'
' @param {boolean} live - whether the content is live TV
' @param {integer} updatePosition - the position to update the progress bar to
sub updateProgressBar(live as boolean, updatePosition as integer)
    if live
        if m.top.isRecording
            m.videoRemainingTime.text = m.clock.callFunc("getFormattedTime", (m.top.liveTvStartTime + m.top.liveTvRewindLimit), true, false)
        else
            m.videoRemainingTime.text = ""
        end if
        m.videoPositionTime.text = m.clock.callFunc("getFormattedTime", (m.top.liveTvStartTime + m.top.liveTvStartOffset), true, false)
        m.liveTvPos.text = m.clock.callFunc("getFormattedTime", (m.top.recordingOffset + m.top.liveTvStartTime + updatePosition), true, true)
        m.progressBar.width = m.progressBarBackground.width * ((m.top.progressDuration - m.top.liveTvStartOffset) / m.top.liveTvRewindLimit)
        progressBarHorizTrans = m.progressBarBackground.width * (m.top.recordingOffset / m.top.liveTvRewindLimit)
        m.progressBar.translation = [
            progressBarHorizTrans
            m.progressBar.translation[1]
        ]
        scrubberHorizTrans = (m.progressBarBackground.width * ((m.top.recordingOffset + updatePosition - m.top.liveTvStartOffset) / m.top.liveTvRewindLimit)) - m.scrubber.width / 2
        m.liveTvPos.translation = [
            m.progressBarGroup.translation[0] + scrubberHorizTrans
            m.liveTvPos.translation[1]
        ]
        if m.top.positionTime < m.top.liveTvStartOffset
            scrubberOldPositionTime = 0
        else
            scrubberOldPositionTime = Int(m.top.positionTime) - m.top.liveTvStartOffset
        end if
        scrubberOldPositionTrans = (m.progressBarBackground.width * ((m.top.recordingOffset + scrubberOldPositionTime) / m.top.liveTvRewindLimit)) - m.scrubberOldPosition.width / 2
    else
        ' If we are actively seeking then use the preview position to update the progress bar, otherwise use the current position
        if m.top.isSeeking
            m.videoRemainingTime.text = secondsToHuman(m.top.progressDuration - updatePosition, true)
            m.videoPositionTime.text = secondsToHuman(updatePosition, true)
            scrubberHorizTrans = m.progressBarBackground.width * updatePosition / m.top.progressDuration - m.scrubber.width / 2
        else
            m.videoRemainingTime.text = secondsToHuman(m.top.progressDuration - m.top.positionTime, true)
            m.videoPositionTime.text = secondsToHuman(m.top.positionTime, true)
            scrubberHorizTrans = m.progressBarBackground.width * m.top.positionTime / m.top.progressDuration - m.scrubber.width / 2
        end if
        progressBarWidth = m.progressBarBackground.width * m.top.positionTime / m.top.progressDuration
        m.progressBar.width = progressBarWidth
        scrubberOldPositionTrans = progressBarWidth - m.scrubberOldPosition.width / 2
    end if
    m.scrubber.translation = [
        scrubberHorizTrans
        m.scrubber.translation[1]
    ]
    m.scrubberOldPosition.translation = [
        scrubberOldPositionTrans
        m.scrubberOldPosition.translation[1]
    ]
    placeSpeedBadge()
end sub

' Everflix: "4×" pill that follows the scrubber while fast forwarding or rewinding
sub onSeekSpeedLabelChanged()
    badge = m.top.findNode("speedBadge")
    if m.top.seekSpeedLabel = ""
        badge.visible = false
        return
    end if
    icon = m.top.findNode("speedBadgeIcon")
    text = m.top.findNode("speedBadgeText")
    if m.top.seekForward then
        icon.uri = "pkg:/images/icons/fastforward.png"
    else
        icon.uri = "pkg:/images/icons/rewind.png"
    end if
    text.text = m.top.seekSpeedLabel
    text.width = 0
    textWidth = text.boundingRect().width
    text.width = textWidth + 2
    m.top.findNode("speedBadgeBg").width = 40 + textWidth
    badge.visible = true
    placeSpeedBadge()
end sub

' Everflix: name of the focused top icon, centred under it
sub onOptionFocusChanged()
    for each button in m.optionControls.getChildren(-1, 0)
        if button.focus = true
            rect = button.sceneBoundingRect()
            m.optionHint.text = button.text
            m.optionHint.translation = [
                rect.x + rect.width / 2 - 130
                rect.y + rect.height + 10
            ]
            m.optionHint.visible = true
            return
        end if
    end for
    m.optionHint.visible = false
end sub

sub placeSpeedBadge()
    badge = m.top.findNode("speedBadge")
    if not isValid(badge) or not badge.visible then
        return
    end if
    width = m.top.findNode("speedBadgeBg").width
    x = m.progressBarGroup.translation[0] + m.scrubber.translation[0] + m.scrubber.width / 2 - width / 2
    if x < 60 then
        x = 60
    end if
    if x > 1860 - width then
        x = 1860 - width
    end if
    badge.translation = [
        x
        m.progressBarGroup.translation[1] - 66
    ]
end sub
'//# sourceMappingURL=./OSD.brs.map