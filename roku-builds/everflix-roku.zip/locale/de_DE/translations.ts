<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE" sourcelanguage="en_US">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>default</name>
    <message>
        <source>192.168.1.100:8096 or https://example.com/jellyfin</source>
        <translation>192.168.1.100:8096 oder https://example.com/jellyfin</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Connect to Server</source>
        <translation>Verbinde zu Server</translation>
    </message>
    <message>
        <source>Ends at %1</source>
        <translation>Endet bei %1</translation>
    </message>
    <message>
        <source>Enter Configuration</source>
        <translation>Konfiguration eingeben</translation>
    </message>
    <message>
        <source>Favorite</source>
        <translation>Favorit</translation>
    </message>
    <message>
        <source>Loading...</source>
        <translation>Lädt…</translation>
    </message>
    <message>
        <source>Login attempt failed.</source>
        <translation>Login-Versuch fehlgeschlagen.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Optionen</translation>
    </message>
    <message>
        <source>Play</source>
        <translation>Abspielen</translation>
    </message>
    <message>
        <source>Please sign in</source>
        <translation>Bitte anmelden</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Suche</translation>
    </message>
    <message>
        <source>Server not found, is it online?</source>
        <translation>Server nicht gefunden, ist er online?</translation>
    </message>
    <message>
        <source>Shuffle</source>
        <translation>Zufällige Wiedergabe</translation>
    </message>
    <message>
        <source>Sign In</source>
        <translation>Anmelden</translation>
    </message>
    <message>
        <source>Submit</source>
        <translation>Absenden</translation>
    </message>
    <message>
        <source>Watched</source>
        <translation>Gesehen</translation>
    </message>
    <message>
        <source>Change server</source>
        <translation>Wechsel Server</translation>
    </message>
    <message>
        <source>Sign out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Add User</source>
        <translation>Benutzer hinzufügen</translation>
    </message>
    <message>
        <source>Profile</source>
        <translation>Profil</translation>
    </message>
    <message>
        <source>My Media</source>
        <translation>Meine Medien</translation>
    </message>
    <message>
        <source>Continue Watching</source>
        <translation>Weiterschauen</translation>
    </message>
    <message>
        <source>Next Up</source>
        <translation>Als Nächstes</translation>
    </message>
    <message>
        <source>Latest in</source>
        <translation>Zuletzt in</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <source>Enter a username</source>
        <translation>Benutzernamen eingeben</translation>
    </message>
    <message>
        <source>Enter a password</source>
        <translation>Passwort eingeben</translation>
    </message>
    <message>
        <source>Enter a value...</source>
        <translation>Wert eingeben…</translation>
    </message>
    <message>
        <source>Sort Field</source>
        <translation>Sortiert nach</translation>
    </message>
    <message>
        <source>Date Added</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>Release Date</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Sort Order</source>
        <translation>Sortierung</translation>
    </message>
    <message>
        <source>Descending</source>
        <translation>Absteigend</translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation>Aufsteigend</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Passwort</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Benutzername</translation>
    </message>
    <message>
        <source>Genres</source>
        <translation>Genres</translation>
    </message>
    <message>
        <source>Director</source>
        <translation>Regisseur</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Server</source>
        <translation>Server</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Anmeldedaten speichern?</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>Läuft jetzt</translation>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler während der Wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Beim Abrufen der Daten für dieses Element vom Server ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeicherte löschen</translation>
    </message>
    <message>
        <source>Extras</source>
        <translation>Extras</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Beim Abspielen dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Kanaldaten werden geladen</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanaldaten können nicht vom Server geladen werden</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Dieses %1 enthält keine Elemente</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerbewertung</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>Episodes</source>
        <translation>Folgen</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Anzahl der Wiedergaben</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Wiedergegeben am</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen von Inhalten</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>Born</source>
        <translation>Geboren</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Besetzung &amp; Mitwirkende</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Ähnliches</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Besondere Merkmale</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Fing an bei</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholen</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal anzeigen</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation>Filme (Raster)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>Died</source>
        <translation>Gestorben</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Drücke &apos;OK&apos; zum schließen</translation>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Gestartet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>Fernsehserien</translation>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Startet um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Medienraster-Optionen.</translation>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Anzahl der Elemente</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serien Aufnehmen</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Zusätzliche Teile</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Movies (Presentation)</source>
        <translation>Filme (Präsentation)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Denn Server Namen oder die IP eingeben</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wähle einen verfügbaren Jellyfin-Server aus Ihrem lokalen Netzwerk aus:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>Wenn oben kein Server aufgeführt ist, kann die Server-URL auch manuell eingeben werden:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Abrufen der Wiedergabeinformationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Codec Support</source>
        <translation>Codec-Support</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>Fernsehprogramm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Wiedergabe</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serienaufnahme abbrechen</translation>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbinde mit Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Bei der Wiedergabe trat ein Fehler auf. Der Server hat die benötigten Transcodinginformationen nicht übermittelt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Enable or disable Direct Play for optional codecs</source>
        <translation>Direkte Wiedergabe für optionale Codecs aktivieren oder deaktivieren</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>MPEG-2</source>
        <translation>MPEG-2</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Unterstützung für das direkte Abspielen von MPEG-2-Inhalten (z.B. Live-TV). Dadurch wird das Transcodieren von MPEG-2-Inhalten vermieden, es wird jedoch erheblich mehr Bandbreite verwendet.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>MPEG-4</source>
        <translation>MPEG-4</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</source>
        <translation>Unterstützung für das direkte Abspielen von MPEG-4-Inhalten. Dies muss möglicherweise deaktiviert werden, um DIVX-codierte Videodateien abzuspielen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der angefragte Inhalt konnte auf dem Server nicht gefunden werden</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktiviert</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Benutzeroberfläche</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Als angesehen markieren</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Favorit festlegen</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deaktiviert</translation>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Zur Serie gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Mediengitter</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Schnellverbindung</translation>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Hier ist der Schnellverbindungscode:</translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Der Dialog wird automatisch geschlossen)</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Zeige die Anzahl der Elemente in der Bibliothek und den Index des ausgewählten Elements.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Zur Folge gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Sprachfernbedienung zur Suche verwenden</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 von %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>Search now</source>
        <translation>Jetzt suchen</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>Networks</source>
        <translation>Netzwerke</translation>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>Es kann nach Titeln, Personen, Live-TV-Sendern und mehr gesucht werden</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Gehe zu Staffel</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Designelemente</translation>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Optionen für TV-Serien.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation>Einstellungen zur Wiedergabe und zu unterstützten Codec- und Medientypen.</translation>
    </message>
    <message>
        <source>Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Beim Drücken der Wiederholen-Taste langsam zum ersten Element im Ordner scrollen. (Wenn deaktiviert, wird sofort zum ersten Element gesprungen).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Ungesehene Episoden verschleiern</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Direktes Abspielen von HEVC-Medien mit nicht unterstützten Profilebenen versuchen, bevor auf Transkodierung zurückgegriffen wird, falls dies fehlschlägt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Go directly to the episode list if a TV series has only one season.</source>
        <translation>Direkt die Episodenliste anzeigen, wenn eine TV-Serie nur eine Staffel hat.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Blur images of unwatched episodes.</source>
        <translation>Bilder von noch nicht angesehenen Folgen unscharf darstellen.</translation>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Splashscreen als Starthintergrund verwenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s home background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Verwende das generierte Startbildschirm-Bild als Hintergrund für die Jellyfin-Startseite. Jellyfin muss geschlossen und erneut geöffnet werden, damit die Änderung wirksam wird.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Bring the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Bringen Sie das Kinoerlebnis direkt in Ihr Wohnzimmer mit der Möglichkeit, benutzerdefinierte Intros vor dem Hauptfilm abzuspielen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hide all clocks in Jellyfin. Jellyfin will need to be closed and reopened for changes to take effect.</source>
        <translation>Alle Uhren in Jellyfin ausblenden. Jellyfin muss geschlossen und erneut geöffnet werden, damit die Änderungen wirksam werden.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>HEVC</source>
        <translation>HEVC</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Direktes Abspielen von H.264-Medien mit nicht unterstützten Profilebenen versuchen, bevor auf Transkodierung zurückgegriffen wird, falls dies fehlschlägt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation>Einstellungen zum Aussehen der Anwendung.</translation>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Schlagwörter ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Blendet den Text von Schlagwörtern auf Detailansichten aus.</translation>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Kinomodus</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Next episode</source>
        <translation>Nächste Folge</translation>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Trailer abspielen</translation>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Uhr ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>H.264</source>
        <translation>H.264</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Options that alter the design of Jellyfin.</source>
        <translation>Optionen, die das Design von Jellyfin verändern.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Skip Details for Single Seasons</source>
        <translation>Details für einzelne Staffeln überspringen</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>Es gab einen Fehler bei der Authentifizierung mit Quick Connect.</translation>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Zurück nach oben</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>direct</source>
        <translation>direkt</translation>
    </message>
    <message>
        <source>Audio Channels</source>
        <translation>Audiokanäle</translation>
    </message>
    <message>
        <source>Custom Subtitles</source>
        <translation>Benutzerdefinierte Untertitel</translation>
        <extracomment>Name of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Reason</source>
        <translation>Grund</translation>
    </message>
    <message>
        <source>WxH</source>
        <translation>BxH</translation>
        <extracomment>Video width x height</extracomment>
    </message>
    <message>
        <source>Playback Information</source>
        <translation>Wiedergabeinformationen</translation>
    </message>
    <message>
        <source>Only display text subtitles to minimize transcoding.</source>
        <translation>Nur Text-Untertitel anzeigen, um die Transkodierung zu minimieren.</translation>
        <extracomment>Description of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</source>
        <translation>Setzen Sie die maximale Anzahl von Tagen, die eine noch nicht angesehene Sendung in der &apos;Als nächstes&apos;-Liste bleiben soll.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Transcoding Information</source>
        <translation>Transkodierungsinformationen</translation>
    </message>
    <message>
        <source>Total Bitrate</source>
        <translation>Gesamtbitrate</translation>
    </message>
    <message>
        <source>Stream Information</source>
        <translation>Streaminformationen</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <source>Codec Tag</source>
        <translation>Codec-Tag</translation>
    </message>
    <message>
        <source>Level</source>
        <translation>Stufe</translation>
        <extracomment>Video profile level</extracomment>
    </message>
    <message>
        <source>Bit Rate</source>
        <translation>Bitrate</translation>
        <extracomment>Video streaming bit rate</extracomment>
    </message>
    <message>
        <source>Container</source>
        <translation>Container</translation>
        <extracomment>Video streaming container</extracomment>
    </message>
    <message>
        <source>Size</source>
        <translation>Grösse</translation>
        <extracomment>Video size</extracomment>
    </message>
    <message>
        <source>Video range type</source>
        <translation>Video-Dynamikumfang</translation>
    </message>
    <message>
        <source>Unable to find any albums or songs belonging to this artist</source>
        <translation>Keine Alben oder Lieder dieses Künstlers gefunden</translation>
        <extracomment>Popup message when we find no audio data for an artist</extracomment>
    </message>
    <message>
        <source>Replace Roku&apos;s default subtitle functions with custom functions that support CJK fonts. Fallback fonts must be configured and enabled on the server for CJK rendering to work.</source>
        <translation>Ersetzt die standardmässigen Untertitelfunktionen von Roku mit benutzerdefinierten Funktionen, die CJK-Schriftarten unterstützen. Ersatzschriftarten müssen auf dem Server konfiguriert und aktiviert sein, damit die CJK-Darstellung funktioniert.</translation>
        <extracomment>Description of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Video Codec</source>
        <translation>Videocodec</translation>
    </message>
    <message>
        <source>Audio Codec</source>
        <translation>Audiocoded</translation>
    </message>
    <message>
        <source>Text Subtitles Only</source>
        <translation>Nur Text-Untertitel</translation>
        <extracomment>Name of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>all</source>
        <translation>alle</translation>
        <extracomment>all will reset the searchTerm so all data will be availible</extracomment>
    </message>
    <message>
        <source>Aired</source>
        <translation>Ausgestrahlt</translation>
        <extracomment>Aired date label</extracomment>
    </message>
    <message>
        <source>Slideshow Off</source>
        <translation>Diashow aus</translation>
    </message>
    <message>
        <source>Pixel format</source>
        <translation>Pixelformat</translation>
        <extracomment>Video pixel format</extracomment>
    </message>
    <message>
        <source>Max Days Next Up</source>
        <translation>Maximale Tage in &quot;Als Nächstes&quot;</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Slideshow Paused</source>
        <translation>Slideshow Pausiert</translation>
    </message>
    <message>
        <source>Slideshow Resumed</source>
        <translation>Slideshow Fortgesetzt</translation>
    </message>
    <message>
        <source>MPEG-4 Support</source>
        <translation>MPEG-4 Unterstützung</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Parental Ratings</source>
        <translation>Elterliche Bewertung</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Years</source>
        <translation>Jahre</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Slideshow On</source>
        <translation>Slideshow An</translation>
    </message>
    <message>
        <source>Random Off</source>
        <translation>Zufällig Aus</translation>
    </message>
    <message>
        <source>Random On</source>
        <translation>Zufällig An</translation>
    </message>
    <message>
        <source>Played</source>
        <translation>Gespielt</translation>
    </message>
    <message>
        <source>Albums</source>
        <translation>Alben</translation>
    </message>
    <message>
        <source>Select when to show titles.</source>
        <translation>Auswählen, wann Titel angezeigt werden sollen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Always Show</source>
        <translation>Immer anzeigen</translation>
    </message>
    <message>
        <source>Show What&apos;s New Popup</source>
        <translation>Pop-Up &quot;Was ist neu&quot; anzeigen</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Show What&apos;s New popup when Jellyfin is updated to a new version.</source>
        <translation>Popup mit Neuigkeiten anzeigen, wenn Jellyfin auf eine neue Version aktualisiert wird.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Unplayed</source>
        <translation>Ungespielt</translation>
    </message>
    <message>
        <source>Resumable</source>
        <translation>Fortsetzbar</translation>
    </message>
    <message>
        <source>Default view for Movie Libraries.</source>
        <translation>Standardansicht für Filmbibliothek.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Artists (Grid)</source>
        <translation>Künstler (Raster)</translation>
    </message>
    <message>
        <source>Album Artists (Presentation)</source>
        <translation>Album-Künstler (Präsentation)</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <source>Disable Community Rating for Episodes</source>
        <translation>Community-Bewertung für Folgen deaktivieren</translation>
    </message>
    <message>
        <source>Songs</source>
        <translation>Lieder</translation>
    </message>
    <message>
        <source>Hide the star and community rating for episodes of a TV show. This is to prevent spoilers of an upcoming good/bad episode.</source>
        <translation>Sterne- und Community-Bewertung für Episoden einer Fernsehsendung ausblenden. Dies dient dazu, Spoiler über eine bevorstehende gute/schlechte Episode zu verhindern.</translation>
    </message>
    <message>
        <source>Biographical information for this person is not currently available.</source>
        <translation>Biographische Informationen zu dieser Person sind derzeit nicht verfügbar.</translation>
    </message>
    <message>
        <source>Enable Limit</source>
        <translation>Limit aktivieren</translation>
    </message>
    <message>
        <source>Enable or disable the &apos;Maximum Bitrate&apos; setting.</source>
        <translation>&quot;Maximale Bitrate&quot;-Einstellung aktivieren oder deaktivieren.</translation>
    </message>
    <message>
        <source>Bitrate Limit</source>
        <translation>Bitratenlimit</translation>
    </message>
    <message>
        <source>Always Hide</source>
        <translation>Immer ausblenden</translation>
    </message>
    <message>
        <source>Show On Hover</source>
        <translation>Bei Hover anzeigen</translation>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Elementtitel</translation>
        <extracomment>Title of a setting - when should we show the title text of a grid item</extracomment>
    </message>
    <message>
        <source>Artists (Presentation)</source>
        <translation>Künstler (Präsentation)</translation>
    </message>
    <message>
        <source>Song</source>
        <translation>Lied</translation>
    </message>
    <message>
        <source>Configure the maximum playback bitrate.</source>
        <translation>Maximale Wiedergabe Bitrate festlegen.</translation>
    </message>
    <message>
        <source>Maximum Bitrate</source>
        <translation>Maximale Bitrate</translation>
    </message>
    <message>
        <source>Movie Library Default View</source>
        <translation>Filmbibliothek Standardansicht</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Album Artists (Grid)</source>
        <translation>Album-Künstler (Raster)</translation>
    </message>
    <message>
        <source>View All</source>
        <translation>Alle anzeigen</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of the Home screen and the program in general.</source>
        <translation>Einstellungen, die sich auf das Aussehen des Startbildschirms und von Jellyfin im Allgemeinen beziehen.</translation>
    </message>
    <message>
        <source>Settings that apply when Grid views are enabled.</source>
        <translation>Einstellungen, die gelten, wenn Rasteransichten aktiviert sind.</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of Library pages</source>
        <translation>Einstellungen für das Erscheinungsbild der Bibliotheksseiten</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Allgemein</translation>
    </message>
    <message>
        <source>Grid View Settings</source>
        <translation>Einstellungen der Rasteransicht</translation>
    </message>
    <message>
        <source>Libraries</source>
        <translation>Bibliotheken</translation>
    </message>
    <message>
        <source>Set the maximum bitrate in Mbps. Set to 0 to use Roku&apos;s specifications. This setting must be enabled to take effect.</source>
        <translation>Legen Sie die maximale Bitrate in Mbps fest. Setzen Sie sie auf 0, um die Spezifikationen von Roku zu verwenden. Diese Einstellung muss aktiviert werden, um wirksam zu werden.</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in TV Libraries.</source>
        <translation>Einstellungen für das Erscheinungsbild von Seiten in TV-Bibliotheken.</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>Raster</translation>
        <extracomment>Title of an option - name of grid view</extracomment>
    </message>
    <message>
        <source>If enabled, the number of unwatched episodes in a series/season will be removed.</source>
        <translation>Wenn diese Option aktiviert ist, wird die Anzahl der ungesehenen Episoden einer Serie/Staffel entfernt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</source>
        <translation>Falls kein Outro-Mediensegment vorhanden ist, legen Sie fest, wie viele Sekunden vor dem Ende einer Folge die Schaltfläche „Outro überspringen“ erscheinen soll. Setzen Sie den Wert auf 0, um die Schaltfläche zu deaktivieren.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Ratings for how good a movie is</source>
        <translation>Community- und Kritikerbewertungen von Rotten Tomatoes.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Use the selected audio codec for transcodes. If the device or stream does not support it, a fallback codec will be used.</source>
        <translation>Verwende den ausgewählten Audio Codec für Transcodierungen. Wenn das Gerät oder der Stream ihn nicht unterstützt, wird ein Ausweich Codec verwendet.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Use system settings</source>
        <translation>Nutze System EInstellungen</translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Set the maximum resolution when playing video files on this device.</source>
        <translation>Legen Sie die maximale Auflösung für die Wiedergabe von Video-Dateien auf diesem Gerät fest.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>Auto - Use TV resolution</source>
        <translation>Auto - TV-Auflösung verwenden</translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Configure the maximum resolution when playing video files on this device.</source>
        <translation>Konfigurieren Sie die maximale Auflösung für die Wiedergabe von Video-Dateien auf diesem Gerät.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>Attempt to prevent playback failures.</source>
        <translation>Versuche Abspielfehler zu vermeiden.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Apply max resolution to all files or only transcoded files.</source>
        <translation>Maximale Auflösung auf alle Dateien oder nur auf transkodierte Dateien anwenden.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>Only transcoded files</source>
        <translation>Nur transkodierte Dateien</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Disable HEVC</source>
        <translation>HEVC deaktivieren</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Disable the HEVC codec on this device. This may improve playback for some devices (ultra).</source>
        <translation>Deaktiviere den HEVC-Codec auf diesem Gerät. Dies kann die Wiedergabe für einige Geräte verbessern (ultra).</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Global settings that affect everyone that uses this Roku device.</source>
        <translation>Globale Einstellungen, die jeden betreffen, der dieses Roku-Gerät verwendet.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Remember the currently logged in user and try to log them in again next time you start the Jellyfin app.</source>
        <translation>Merke den aktuell angemeldeten Benutzer und versuche, ihn beim nächsten Start von Jellyfin erneut anzumelden.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>No Chapter Data Found</source>
        <translation>Keine Kapiteldaten gefunden</translation>
        <extracomment>Message shown in OSD when no chapter data is returned by the API</extracomment>
    </message>
    <message>
        <source>Make the arrangement of the Roku home view sections match the web client&apos;s home screen. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Pass die Anordnung der Abschnitte der Roku-Startansicht an den Startbildschirm des Webclients an. Jellyfin muss geschlossen und erneut geöffnet werden, damit die Änderungen wirksam werden.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Random</source>
        <translation>Zufällig</translation>
        <extracomment>General use word when we want to randomize data</extracomment>
    </message>
    <message>
        <source>Community and Critical Ratings</source>
        <translation>Community und kritische Bewertungen</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>What&apos;s New?</source>
        <translation>Was ist neu?</translation>
        <extracomment>Popup title - Popup displays all the major changes to the app since the last version</extracomment>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in Movie Libraries.</source>
        <translation>Einstellungen für das Erscheinungsbild von Seiten in TV-Bibliotheken.</translation>
    </message>
    <message>
        <source>Presentation</source>
        <translation>Präsentation</translation>
        <extracomment>Title of an option - name of presentation view</extracomment>
    </message>
    <message>
        <source>Disable Unwatched Episode Count</source>
        <translation>Zählen der nicht gesehenen Episoden deaktivieren</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Next Episode Button Time</source>
        <translation>Nächste Folge Button Zeit</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Preferred Audio Codec</source>
        <translation>Bevorzugter Audio Codec</translation>
        <extracomment>Settings Menu - Title of option</extracomment>
    </message>
    <message>
        <source>Off - Attempt to play all resolutions</source>
        <translation>Aus - Versucht, alle Auflösungen abzuspielen</translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Mode</source>
        <translation>Modus</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Value</source>
        <translation>Wert</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>All files</source>
        <translation>Alle Dateien</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Use Web Client&apos;s Home Section Arrangement</source>
        <translation>Verwende die Anordnung der Home-Sektion des Webclients</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>... (Press * to read more)</source>
        <translation>... (Drück * um mehr zu lesen)</translation>
        <extracomment>Ellipsis Text for when text overflows its container</extracomment>
    </message>
    <message>
        <source>Maximum Resolution</source>
        <translation>Maximale Auflösung</translation>
        <extracomment>User Setting - Title</extracomment>
    </message>
    <message>
        <source>Compatibility</source>
        <translation>Kompatibilität</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Global</source>
        <translation>Global</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Remember Me?</source>
        <translation>An mich erinnern?</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Loading trailer</source>
        <translation>Trailer laden</translation>
        <extracomment>Dialog title in Main.brs</extracomment>
    </message>
    <message>
        <source>Direct playing</source>
        <translation>Direktes Abspielen</translation>
    </message>
    <message>
        <source>The source file is entirely compatible with this client and the session is receiving the file without modifications.</source>
        <translation>Die Quelldatei ist mit diesem Client vollständig kompatibel und die Sitzung empfängt die Datei ohne Änderungen.</translation>
        <extracomment>Direct play info box text in GetPlaybackInfoTask.brs</extracomment>
    </message>
    <message>
        <source>Welcome to version</source>
        <translation>Willkommen bei der Version</translation>
        <extracomment>WhatsNewDialog title - Welcome to version 2.0.0</extracomment>
    </message>
    <message>
        <source>To view a complete list of changes visit</source>
        <translation>Eine vollständige Liste der Änderungen findest du unter</translation>
        <extracomment>WhatsNewDialog body text preceding the changelog URL</extracomment>
    </message>
    <message>
        <source>Rewatching Next Up</source>
        <translation>Als nächstes noch einmal ansehen</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Show already watched episodes in &apos;Next Up&apos; sections.</source>
        <translation>Zeige bereits gesehene Episoden in der Rubrik &apos;Nächste Folge&apos; an.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>View All Next Up</source>
        <translation>Weiter oben alle anzeigen</translation>
        <extracomment>Title for viewing all episodes available in the Next Up section</extracomment>
    </message>
    <message>
        <source>Episode Images Next Up</source>
        <translation>Bilder der nächsten Episode</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Use Web Client Setting</source>
        <translation>Web Client-Einstellung verwenden</translation>
        <extracomment>User Setting - Setting option title</extracomment>
    </message>
    <message>
        <source>What type of images to use for Episodes shown in the &apos;Next Up&apos; and &apos;Continue Watching&apos; sections.</source>
        <translation>Welche Art von Bildern soll für die Episoden in den Abschnitten &quot;Weiter&quot; und &quot;Weiterschauen&quot; verwendet werden.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Use Episode Image</source>
        <translation>Episodenbild verwenden</translation>
        <extracomment>User Setting - Setting option title</extracomment>
    </message>
    <message>
        <source>Use Show Image</source>
        <translation>Serienbild verwenden</translation>
        <extracomment>User Setting - Setting option title</extracomment>
    </message>
    <message>
        <source>Autoplay Episode Limit</source>
        <translation>Episoden Limit für die automatische Wiedergabe</translation>
    </message>
    <message>
        <source>Return to server select screen</source>
        <translation>Zurück zum Serverauswahl Bildschirm</translation>
    </message>
    <message>
        <source>Community Rating</source>
        <translation>Community Bewertung</translation>
    </message>
    <message>
        <source>Album Artist</source>
        <translation>Album Interpret</translation>
    </message>
    <message>
        <source>The selected Jellyfin server uses version</source>
        <translation>Der gewählte Jellyfin-Server nutzt Version</translation>
    </message>
    <message>
        <source>The number of episodes that will play automatically after the selected episode. Requires &apos;Play next episode automatically&apos; server setting to be enabled.</source>
        <translation>Die Anzahl an Episoden die automatisch nach der gewählten Episode abgespielt werden. Benötigt, das die Option &quot;Nächste Episode automatisch abspielen&quot; auf dem Server aktiviert ist.</translation>
    </message>
    <message>
        <source>or newer to use this app or install and use the Jellyfin Legacy app from Roku&apos;s Streaming Store</source>
        <translation>oder neuer um diese App zu nutzen oder installiere und nutze die App &quot;Jellyfin Legacy&quot; von Roku&apos;s Streaming Store</translation>
    </message>
    <message>
        <source>which is not supported by this app. Please update the server to</source>
        <translation>was nicht von dieser App unterstützt wird. Bitte aktualisiere den Server zu</translation>
    </message>
    <message>
        <source>Recently Added in</source>
        <translation>Kürzlich hinzugefügt in</translation>
    </message>
    <message>
        <source>CH</source>
        <translation>CH</translation>
    </message>
    <message>
        <source>Use Fallback Font Across App</source>
        <translation>Die Rückfallschriftart in der App benutzen</translation>
    </message>
    <message>
        <source>Changes the font used in the app to the server&apos;s configured fallback font.</source>
        <translation>Verändert die Schriftart, die in der App benutzt wird, zur Rückfallschruftart des Server&apos;s.</translation>
    </message>
    <message>
        <source>Highlighted Color</source>
        <translation>Markierte Farbe</translation>
    </message>
    <message>
        <source>Folders</source>
        <translation>Ordner</translation>
    </message>
    <message>
        <source>Go To Artist</source>
        <translation>Zum Künstler</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <source>Unable to get playback information</source>
        <translation>Konnte Wiedergabeinformationen nicht abrufen</translation>
    </message>
    <message>
        <source>Mark As Favorite</source>
        <translation>Zu Favoriten hinzufügen</translation>
    </message>
    <message>
        <source>Playback Options</source>
        <translation>Wiedergabeoptionen</translation>
    </message>
    <message>
        <source>Force Transcoding setting is enabled</source>
        <translation>Erzwungene Transkodierung ist aktiv</translation>
    </message>
    <message>
        <source>No items found. Try adjusting your selected filters.</source>
        <translation>Keine Einträge gefunden. Versuche deine Filter anzupassen.</translation>
    </message>
    <message>
        <source>Attempt Direct Play of potentially unsupported profile levels</source>
        <translation>Direct Play für potenziell nicht unterstützte Profile versuchen</translation>
    </message>
    <message>
        <source>Change User</source>
        <translation>Benutzer wechseln</translation>
    </message>
    <message>
        <source>Favorited</source>
        <translation>Zu Favoriten hinzugefügt</translation>
    </message>
    <message>
        <source>Resume playing at </source>
        <translation>Wiedergabe fortsetzen bei </translation>
    </message>
    <message>
        <source>Force Transcode option is enabled</source>
        <translation>Erzwungene Transkodierung ist aktiviert</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <source>(Favorites)</source>
        <translation>(Favoriten)</translation>
    </message>
    <message>
        <source>Favorites</source>
        <translation>Favoriten</translation>
    </message>
    <message>
        <source>Delete Playlist</source>
        <translation>Playlist löschen</translation>
    </message>
    <message>
        <source>Artists</source>
        <translation>Künstler</translation>
    </message>
    <message>
        <source>Collections</source>
        <translation>Sammlung</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Wiedergabelisten</translation>
    </message>
    <message>
        <source>Enable or disable Direct Play support for certain codecs.</source>
        <translation>Direct Play Unterstützung für bestimmte Codecs aktivieren oder deaktivieren.</translation>
    </message>
    <message>
        <source>Shuffle Play Collection</source>
        <translation>Shuffle Play-Sammlung</translation>
    </message>
    <message>
        <source>Date Show Added</source>
        <translation>Show hinzugefügt am</translation>
    </message>
    <message>
        <source>Date Episode Added</source>
        <translation>Episode hinzugefügt am</translation>
    </message>
    <message>
        <source>Force Transcoding</source>
        <translation>Erzwinge Transkodierung</translation>
    </message>
    <message>
        <source>Display custom trickplay images even if this Roku says it&apos;s displaying its own. This may cause the two images to overlay on top of each other.</source>
        <translation>Zeigen Sie benutzerdefinierte Trickplay-Bilder an, auch wenn dieser Roku sagt, dass er seine eigenen anzeigt. Dies kann dazu führen, dass die beiden Bilder übereinander liegen.</translation>
    </message>
    <message>
        <source>Custom Trickplay</source>
        <translation>Benutzerdefiniertes Trickplay</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <source>Start over from the beginning.</source>
        <translation>Von vorne beginnen.</translation>
    </message>
    <message>
        <source>Settings relating to how Jellyfin should handle media segments.</source>
        <translation>Einstellungen, wie Jellyfin mit Mediensegmenten umgehen sollte.</translation>
    </message>
    <message>
        <source>No Results Found</source>
        <translation>Keine Ergebnisse gefunden</translation>
    </message>
    <message>
        <source>downloads</source>
        <translation>Downloads</translation>
    </message>
    <message>
        <source>Series</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Play / Resume from</source>
        <translation>Abspielen von</translation>
    </message>
    <message>
        <source>Play or Resume from</source>
        <translation>Abspielen oder Fortfahren von</translation>
    </message>
    <message>
        <source>Part</source>
        <translation>Teil</translation>
    </message>
    <message>
        <source>Skip</source>
        <translation>Überspringen</translation>
    </message>
    <message>
        <source>What&apos;s New</source>
        <translation>Was ist Neu</translation>
    </message>
    <message>
        <source>Video Codec Support</source>
        <translation>Unterstützung für Video Codec</translation>
    </message>
    <message>
        <source>Force all playable media to be transcoded.</source>
        <translation>Erzwinge das alle abspielbaren Medien transkodiert werden.</translation>
    </message>
    <message>
        <source>Ask To Skip</source>
        <translation>Überspringen</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Keine</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in all Libraries.</source>
        <translation>Einstellungen zum Erscheinungsbild von Seiten in allen Bibliotheken.</translation>
    </message>
    <message>
        <source>Playback Info</source>
        <translation>Wiedergabe Informationen</translation>
    </message>
    <message>
        <source>In My List</source>
        <translation>In meiner Liste</translation>
    </message>
    <message>
        <source>Manual Login</source>
        <translation>Manueller Login</translation>
    </message>
    <message>
        <source>as</source>
        <translation>als</translation>
    </message>
    <message>
        <source>Select User</source>
        <translation>Benutzer auswählen</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>No, Cancel</source>
        <translation>Nein, abbrechen</translation>
    </message>
    <message>
        <source>Seasons</source>
        <translation>Staffeln</translation>
    </message>
    <message>
        <source>Season</source>
        <translation>Staffel</translation>
    </message>
    <message>
        <source>Episode</source>
        <translation>Episode</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of Library pages.</source>
        <translation>Einstellungen zum Erscheinungsbild von Bibliotheken.</translation>
    </message>
    <message>
        <source>Forget Filters</source>
        <translation>Filter verwerfen</translation>
    </message>
    <message>
        <source>Forget applied library filters when Jellyfin is closed.</source>
        <translation>Verwerfen von angewendeten Filter auf Bibliotheken beim Beenden von Jellyfin.</translation>
    </message>
    <message>
        <source>Mark As Played</source>
        <translation>Als gesehen markieren</translation>
    </message>
    <message>
        <source>Mark As Unplayed</source>
        <translation>Als ungesehen markieren</translation>
    </message>
    <message>
        <source>Add To Playlist</source>
        <translation>Zur Wiedergabeliste hinzufügen</translation>
    </message>
    <message>
        <source>Remove From My List</source>
        <translation>Von meiner Liste entfernen</translation>
    </message>
    <message>
        <source>Add To My List</source>
        <translation>Zu meiner Liste hinzufügen</translation>
    </message>
    <message>
        <source>Select Audio</source>
        <translation>Audio auswählen</translation>
    </message>
    <message>
        <source>Select Subtitles</source>
        <translation>Untertitel auswählen</translation>
    </message>
    <message>
        <source>Select Language</source>
        <translation>Sprache auswählen</translation>
    </message>
    <message>
        <source>Sort by</source>
        <translation>Sortieren nach</translation>
    </message>
    <message>
        <source>Press OK to type</source>
        <translation>OK drücken für Eingabe</translation>
    </message>
    <message>
        <source>Search this library</source>
        <translation>Diese Bibliothek durchsuchen</translation>
    </message>
    <message>
        <source>Released</source>
        <translation>Veröffentlicht</translation>
    </message>
    <message>
        <source>My List</source>
        <translation>Meine Liste</translation>
    </message>
    <message>
        <source>Recently Added Media</source>
        <translation>Kürzlich hinzugefügte Medien</translation>
    </message>
    <message>
        <source>Colors</source>
        <translation>Farben</translation>
    </message>
    <message>
        <source>Background</source>
        <translation>Hintergrund</translation>
    </message>
    <message>
        <source>Video Profile Level Support</source>
        <translation>Video Profil Level Support</translation>
    </message>
    <message>
        <source>Media Segment Actions</source>
        <translation>Mediensegment Aktionen</translation>
    </message>
    <message>
        <source>Commercial Segments</source>
        <translation>Werbe-Abschnitte</translation>
    </message>
    <message>
        <source>What action should Jellyfin take for commercial segments?</source>
        <translation>Welche Maßnahmen sollte Jellyfin für kommerzielle Segmente ergreifen?</translation>
    </message>
    <message>
        <source>Intro Segments</source>
        <translation>Intro-Segmente</translation>
    </message>
    <message>
        <source>What action should Jellyfin take for intro segments?</source>
        <translation>Welche Maßnahmen sollte Jellyfin für Intro-Segmente ergreifen?</translation>
    </message>
    <message>
        <source>Outro Segments</source>
        <translation>Outro-Segmente</translation>
    </message>
    <message>
        <source>What action should Jellyfin take for outro segments?</source>
        <translation>Welche Maßnahmen sollte Jellyfin für die Outro-Segmente ergreifen?</translation>
    </message>
    <message>
        <source>Preview Segments</source>
        <translation>Vorschau-Segmente</translation>
    </message>
    <message>
        <source>What action should Jellyfin take for preview segments?</source>
        <translation>Welche Maßnahmen sollte Jellyfin für die Vorschau-Segmente ergreifen?</translation>
    </message>
    <message>
        <source>Saved Profile</source>
        <translation>Gespeichertes Profil</translation>
    </message>
    <message>
        <source>Public Profile</source>
        <translation>Sichtbares Profil</translation>
    </message>
    <message>
        <source>Manage Hidden Users</source>
        <translation>Verwalte versteckte Benutzer</translation>
    </message>
    <message>
        <source>Are you sure you want to forget this user?</source>
        <translation>Bist du dir sicher, dass du den Benutzer vergessen möchtest?</translation>
    </message>
    <message>
        <source>Unhide Users</source>
        <translation>Benutzer sichtbar machen</translation>
    </message>
    <message>
        <source>Add To Favorites</source>
        <translation>Zu Favoriten hinzufügen</translation>
    </message>
    <message>
        <source>Remove From Favorites</source>
        <translation>Von Favoriten entfernen</translation>
    </message>
    <message>
        <source>Maximum Audio Channels</source>
        <translation>Maximale Anzahl Audiokanäle</translation>
    </message>
    <message>
        <source>Configure the maximum audio channels when playing video files on this device.</source>
        <translation>Konfigurieren Sie die maximale Anzahl an Audiokanälen für die Wiedergabe von Videodateien auf diesem Gerät.</translation>
    </message>
    <message>
        <source>Off - Attempt to play all channels</source>
        <translation>Aus – Versuch, alle Kanäle abzuspielen</translation>
    </message>
    <message>
        <source>Recap Segments</source>
        <translation>Zusammenfassungssegmente</translation>
    </message>
    <message>
        <source>What action should Jellyfin take for recap segments?</source>
        <translation>Welche Maßnahmen sollte Jellyfin in Bezug auf die Zusammenfassungssegmente ergreifen?</translation>
    </message>
    <message>
        <source>Item Detail Screen</source>
        <translation>Artikeldetailseite</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of the item detail screen.</source>
        <translation>Einstellungen bezüglich des Erscheinungsbilds der Artikeldetailseite.</translation>
    </message>
    <message>
        <source>Overview Content</source>
        <translation>Inhaltsübersicht</translation>
    </message>
    <message>
        <source>A quick overview of the item selected - typically a short plot outline.</source>
        <translation>Eine kurze Übersicht über den ausgewählten Eintrag – typischerweise eine kurze Inhaltsangabe.</translation>
    </message>
    <message>
        <source>Library Landscape Column Count</source>
        <translation>Spaltenanzahl im Bibliotheks-Querformat</translation>
    </message>
    <message>
        <source>Number of columns in library view when showing landscape (wide) images</source>
        <translation>Anzahl der Spalten in der Bibliotheksansicht bei Anzeige von Querformatbildern (breit)</translation>
    </message>
    <message>
        <source>Library Portrait Column Count</source>
        <translation>Anzahl der Spalten im Bibliotheksporträt</translation>
    </message>
    <message>
        <source>Number of columns in library view when showing portrait (tall) images</source>
        <translation>Anzahl der Spalten in der Bibliotheksansicht bei Anzeige von Hochformatbildern</translation>
    </message>
    <message>
        <source>Library Square Column Count</source>
        <translation>Spaltenanzahl im Bibliotheksplatz</translation>
    </message>
    <message>
        <source>Number of columns in library view when showing square images</source>
        <translation>Anzahl der Spalten in der Bibliotheksansicht bei Anzeige quadratischer Bilder</translation>
    </message>
    <message>
        <source>Search is unavailable because the API does not support searching inside boxsets.</source>
        <translation>Die Suche ist nicht verfügbar, da die API das Durchsuchen innerhalb von Boxsets nicht unterstützt.</translation>
    </message>
    <message>
        <source>Search is unavailable because the API does not support searching inside My List.</source>
        <translation>Die Suche ist nicht verfügbar, da die API das Durchsuchen innerhalb von „Meine Liste“ nicht unterstützt.</translation>
    </message>
    <message>
        <source>Library Settings</source>
        <translation>Bibliothekseinstellungen</translation>
    </message>
    <message>
        <source>Display Watched Checkmark</source>
        <translation>Überwachte Anzeige (Häkchen)</translation>
    </message>
    <message>
        <source>Tracks</source>
        <translation>Tracks</translation>
    </message>
    <message>
        <source>min</source>
        <translation>min</translation>
    </message>
    <message>
        <source>mins</source>
        <translation>Minuten</translation>
    </message>
    <message>
        <source>Continue Listening</source>
        <translation>Hören Sie weiter zu</translation>
    </message>
    <message>
        <source>AppearsOn</source>
        <translation>ErscheintAuf</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this subtitle?</source>
        <translation>Möchten Sie diesen Untertitel wirklich löschen?</translation>
    </message>
    <message>
        <source>Play Normally - disabled because of selected force transcoding setting</source>
        <translation>Normal wiedergeben – deaktiviert aufgrund der ausgewählten Einstellung „Transkodierung erzwingen“</translation>
    </message>
    <message>
        <source>Section 1</source>
        <translation>Abschnitt 1</translation>
    </message>
    <message>
        <source>Section 2</source>
        <translation>Abschnitt 2</translation>
    </message>
    <message>
        <source>Section 3</source>
        <translation>Abschnitt 3</translation>
    </message>
    <message>
        <source>Section 4</source>
        <translation>Abschnitt 4</translation>
    </message>
    <message>
        <source>Section 5</source>
        <translation>Abschnitt 5</translation>
    </message>
    <message>
        <source>Section 6</source>
        <translation>Abschnitt 6</translation>
    </message>
    <message>
        <source>Section 7</source>
        <translation>Abschnitt 7</translation>
    </message>
    <message>
        <source>Section 8</source>
        <translation>Abschnitt 8</translation>
    </message>
    <message>
        <source>Select what to show in section 1. This setting has no effect if \&quot;Use Web Client&apos;s Home Section Arrangement\&quot; is enabled. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Auswahl für Abschnitt 1. Diese Einstellung hat keinen Effekt wenn &quot;Verwende die Anordnung der Home-Sektion des Webclients&quot; aktiv ist. Um die Änderungen zu übernehmen muss Jellyfin geschlossen und neu geöffnet werden.</translation>
    </message>
    <message>
        <source>Select what to show in section 2. This setting has no effect if \&quot;Use Web Client&apos;s Home Section Arrangement\&quot; is enabled. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Auswahl für Abschnitt 2. Diese Einstellung hat keinen Effekt wenn &quot;Verwende die Anordnung der Home-Sektion des Webclients&quot; aktiv ist. Um die Änderungen zu übernehmen muss Jellyfin geschlossen und neu geöffnet werden.</translation>
    </message>
    <message>
        <source>Select what to show in section 3. This setting has no effect if \&quot;Use Web Client&apos;s Home Section Arrangement\&quot; is enabled. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Auswahl für Abschnitt 3. Diese Einstellung hat keinen Effekt wenn &quot;Verwende die Anordnung der Home-Sektion des Webclients&quot; aktiv ist. Um die Änderungen zu übernehmen muss Jellyfin geschlossen und neu geöffnet werden.</translation>
    </message>
    <message>
        <source>Select what to show in section 4. This setting has no effect if \&quot;Use Web Client&apos;s Home Section Arrangement\&quot; is enabled. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Auswahl für Abschnitt 4. Diese Einstellung hat keinen Effekt wenn &quot;Verwende die Anordnung der Home-Sektion des Webclients&quot; aktiv ist. Um die Änderungen zu übernehmen muss Jellyfin geschlossen und neu geöffnet werden.</translation>
    </message>
    <message>
        <source>Select what to show in section 5. This setting has no effect if \&quot;Use Web Client&apos;s Home Section Arrangement\&quot; is enabled. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Auswahl für Abschnitt 5. Diese Einstellung hat keinen Effekt wenn &quot;Verwende die Anordnung der Home-Sektion des Webclients&quot; aktiv ist. Um die Änderungen zu übernehmen muss Jellyfin geschlossen und neu geöffnet werden.</translation>
    </message>
    <message>
        <source>Select what to show in section 6. This setting has no effect if \&quot;Use Web Client&apos;s Home Section Arrangement\&quot; is enabled. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Auswahl für Abschnitt 6. Diese Einstellung hat keinen Effekt wenn &quot;Verwende die Anordnung der Home-Sektion des Webclients&quot; aktiv ist. Um die Änderungen zu übernehmen muss Jellyfin geschlossen und neu geöffnet werden.</translation>
    </message>
    <message>
        <source>Select what to show in section 7. This setting has no effect if \&quot;Use Web Client&apos;s Home Section Arrangement\&quot; is enabled. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Auswahl für Abschnitt 7. Diese Einstellung hat keinen Effekt wenn &quot;Verwende die Anordnung der Home-Sektion des Webclients&quot; aktiv ist. Um die Änderungen zu übernehmen muss Jellyfin geschlossen und neu geöffnet werden.</translation>
    </message>
    <message>
        <source>Select what to show in section 8. This setting has no effect if \&quot;Use Web Client&apos;s Home Section Arrangement\&quot; is enabled. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Auswahl für Abschnitt 8. Diese Einstellung hat keinen Effekt wenn &quot;Verwende die Anordnung der Home-Sektion des Webclients&quot; aktiv ist. Um die Änderungen zu übernehmen muss Jellyfin geschlossen und neu geöffnet werden.</translation>
    </message>
    <message>
        <source>Live TV</source>
        <translation>Live-TV</translation>
    </message>
    <message>
        <source>Customize the home screen sections</source>
        <translation>Bearbeite die Homescreen-Abschnitte</translation>
    </message>
    <message>
        <source>Home Rows</source>
        <translation>Home-Zeilen</translation>
    </message>
    <message>
        <source>Change the colors of elements in the app.</source>
        <translation>Ändere die Elementfarben in der App.</translation>
    </message>
    <message>
        <source>All Screens</source>
        <translation>Alle Bildschirme</translation>
    </message>
    <message>
        <source>Colors used across multiple screens.</source>
        <translation>Farben, die über mehrere Bildschirme verwendet werden.</translation>
    </message>
    <message>
        <source>The base background color. Background images are layered on top of this color.</source>
        <translation>Die Basis-Hintergrundfarbe. Hintergrundbilder werden über diese Farbe gelegt.</translation>
    </message>
    <message>
        <source>Cursor</source>
        <translation>Zeiger</translation>
    </message>
    <message>
        <source>The color of the remote control&apos;s cursor.</source>
        <translation>Farbe des Fernbedienung-Zeigers.</translation>
    </message>
    <message>
        <source>Primary Text</source>
        <translation>Primärer Text</translation>
    </message>
    <message>
        <source>The primary text color.</source>
        <translation>Die Primärtextfarbe.</translation>
    </message>
    <message>
        <source>Secondary Text</source>
        <translation>Sekundärer Text</translation>
    </message>
    <message>
        <source>The secondary text color.</source>
        <translation>Die Sekundärtextfarbe.</translation>
    </message>
    <message>
        <source>Text Color</source>
        <translation>Textfarbe</translation>
    </message>
    <message>
        <source>My List Icon</source>
        <translation>Meine Liste Icon</translation>
    </message>
    <message>
        <source>Grid View Item Titles</source>
        <translation>Rasteransicht Titeltext</translation>
    </message>
    <message>
        <source>Select when to show titles in grid view.</source>
        <translation>Auswählen um Titeltexte in der Rasteransicht anzuzeigen.</translation>
    </message>
    <message>
        <source>Watched Check Mark &amp; Unplayed Count</source>
        <translation>Zähler für Gesehen &amp; Ungesehen</translation>
    </message>
    <message>
        <source>Colors specific to the watched check mark &amp; unplayed count box.</source>
        <translation>Farbe der Zählerumrandung für Gesehen &amp; Ungesehen.</translation>
    </message>
    <message>
        <source>The background color of the check mark &amp; unplayed count shown in the top right corner of items.</source>
        <translation>Hintergrundfarbe der Zählerumrandung für Gesehen &amp; Ungesehen in der rechten oberen Elementecke.</translation>
    </message>
    <message>
        <source>Unplayed Count</source>
        <translation>Zähler für Ungesehen</translation>
    </message>
    <message>
        <source>The color of the unplayed count number.</source>
        <translation>Textfarbe des Zählers für Ungesehen.</translation>
    </message>
    <message>
        <source>Watched Check Mark</source>
        <translation>Gesehen-Markierung</translation>
    </message>
    <message>
        <source>The color of the watched check mark.</source>
        <translation>Farbe der Gesehen-Markierung.</translation>
    </message>
    <message>
        <source>Dialog Popups</source>
        <translation>Pop-Up Dialog</translation>
    </message>
    <message>
        <source>Go To Genre</source>
        <translation>Gehe zu Genre</translation>
    </message>
    <message>
        <source>Colors specific to dialog popups</source>
        <translation>Farben (spezifisch für Dialog-Popups)</translation>
    </message>
    <message>
        <source>The background color for all dialog popups.</source>
        <translation>Die Hintergrundfarbe für alle Dialog-Popups.</translation>
    </message>
    <message>
        <source>Bold Text</source>
        <translation>Fettgedruckter Text</translation>
    </message>
    <message>
        <source>The text color for bold text.</source>
        <translation>Die Textfarbe für fettgedruckten Text.</translation>
    </message>
    <message>
        <source>Horizontal Border line</source>
        <translation>Horizontale Rahmenlinie</translation>
    </message>
    <message>
        <source>The color of the thin border line under the header text.</source>
        <translation>Die Farbe der schmalen Rahmenlinie unter dem Überschrifttext.</translation>
    </message>
    <message>
        <source>Selected Text</source>
        <translation>Markierter Text</translation>
    </message>
    <message>
        <source>The text color for the item the cursor is over.</source>
        <translation>Die Textfarbe für das Element, auf welchem der Cursor liegt.</translation>
    </message>
    <message>
        <source>The text color for title and items the cursor is not over.</source>
        <translation>Die Textfarbe für Titel und Elemente, über die kein Cursor liegt.</translation>
    </message>
    <message>
        <source>What&apos;s New Author</source>
        <translation>&quot;Was ist neu&quot;-Autor</translation>
    </message>
    <message>
        <source>The text color for the author in the What&apos;s New popup.</source>
        <translation>Die Textfarbe für den Autor im &quot;Was ist neu&quot;-Popup.</translation>
    </message>
    <message>
        <source>Home Screen</source>
        <translation>Startbildschirm</translation>
    </message>
    <message>
        <source>Colors specific to the home screen</source>
        <translation>Farben (spezifisch für den Startbildschirm)</translation>
    </message>
    <message>
        <source>The color of the star icon in the My List library item.</source>
        <translation>Die Farbe des Sternchen-Icons bei Elementen der &quot;Meine Liste&quot;-Bibliothek.</translation>
    </message>
    <message>
        <source>Row Headers</source>
        <translation>Zeilenüberschriften</translation>
    </message>
    <message>
        <source>The text color of the headers of each row.</source>
        <translation>Die Textfarbe der Überschriften jeder Zeile.</translation>
    </message>
    <message>
        <source>Row Item Background</source>
        <translation>Zeilenhintergrund</translation>
    </message>
    <message>
        <source>The background color of items. Only seen if no image loads on top of it.</source>
        <translation>Die Hintergrundfarbe von Elementen. Nur sichtbar, wenn keine Bilder dadrüber geladen werden.</translation>
    </message>
    <message>
        <source>Row Item Progress</source>
        <translation>Zeilenelement-Fortschritt</translation>
    </message>
    <message>
        <source>The color of the watched portion of the progress bar.</source>
        <translation>Die Farbe des angesehenen Anteils des Fortschrittsbalken.</translation>
    </message>
    <message>
        <source>Row Item Progress Background</source>
        <translation>Zeilenelement-Fortschrittshintergrund</translation>
    </message>
    <message>
        <source>The background color of the progress bar.</source>
        <translation>Die Hintergrundfarbe des Fortschrittbalkens.</translation>
    </message>
    <message>
        <source>Row Item Subtitle</source>
        <translation>Zeilenelement-Untertitel</translation>
    </message>
    <message>
        <source>The text color of the second line displayed under items.</source>
        <translation>Die Textfarbe der zweiten Zeile, welche unter Elementen angezeigt wird.</translation>
    </message>
    <message>
        <source>Row Item Title</source>
        <translation>Zeilenelement-Titel</translation>
    </message>
    <message>
        <source>The text color of the first line displayed under items.</source>
        <translation>Die Textfarbe der ersten Zeile, welche unter Elementen angezeigt wird.</translation>
    </message>
    <message>
        <source>Username In Header</source>
        <translation>Benutzername in Überschrift</translation>
    </message>
    <message>
        <source>The text color of the user&apos;s name in the header.</source>
        <translation>Die Textfarbe des Benutzernamens in der Überschrift.</translation>
    </message>
    <message>
        <source>Note: Force transcode option automatically enabled due to video rotation</source>
        <translation>Hinweis: Erzwungene Transkodierung wurde automatisch aktiviert wegen Videorotation</translation>
    </message>
    <message>
        <source>Start Episode List From First Unwatched Episode</source>
        <translation>Starte Folgenliste bei der ersten ungesehenen Folge</translation>
    </message>
    <message>
        <source>When opening a season&apos;s list of episodes, automatically scroll down and start the cursor on the first unwatched episode.</source>
        <translation>Beim Öffnen der Folgenliste einer Staffel automatisch nach unten Scrollen und den ursor auf die erste noch nicht gesehene Folge setzen.</translation>
    </message>
    <message>
        <source>Play Normally</source>
        <translation>Normal abspielen</translation>
    </message>
    <message>
        <source>Force Transcode (Allow Remux)</source>
        <translation>Transkodierung erzwingen (Remux zulassen)</translation>
    </message>
    <message>
        <source>Force Transcode (Allow Remux) - disabled because of selected force transcoding setting</source>
        <translation>Transkodierung erzwingen (Remux erlauben) - deaktiviert wegen ausgewählter erzwungener Transkodierung-Einstellung</translation>
    </message>
    <message>
        <source>Force Transcode (Remux Disabled)</source>
        <translation>Transkodierung erzwingen (Remux nicht zulassen)</translation>
    </message>
    <message>
        <source>Force Transcode (Remux Disabled) - disabled because of selected force transcoding setting</source>
        <translation>Transkodierung erzwingen (Remux nicht erlauben) - deaktiviert wegen ausgewählter erzwungener Transkodierung-Einstellung</translation>
    </message>
    <message>
        <source>No channels found matching your search criteria</source>
        <translation>Keine Kanäle gefunden, die den Suchkriterien entsprechen</translation>
    </message>
    <message>
        <source>Are You Still Watching Popup</source>
        <translation>&quot;Schaust du noch&quot;-Popup</translation>
    </message>
    <message>
        <source>How many minutes of inactivity before playback is stopped between items and a popup is shown to continue? Set to 0 to disable.</source>
        <translation>Nach wie vielen Minuten Inaktivität soll die Wiedergabe zwischen Elementen pausiert werden und ein Popup zum Fortsetzen angezeigt werden? Setze auf 0 zum Deaktivieren.</translation>
    </message>
    <message>
        <source>Are You Still Watching?</source>
        <translation>Schaust du noch?</translation>
    </message>
    <message>
        <source>Yes, continue</source>
        <translation>Ja, fortfahren</translation>
    </message>
    <message>
        <source>No, stop playback</source>
        <translation>Nein, Wiedergabe stoppen</translation>
    </message>
    <message>
        <source>Playback will automatically stop in 1 minute if no buttons are pressed.</source>
        <translation>Wiedergabe wird automatisch in 1 Minute gestoppt, wenn keine Buttons gedrückt werden.</translation>
    </message>
    <message>
        <source>Burn in subtitle when transcoding</source>
        <translation>Untertitel einbrennen beim Transkodieren</translation>
    </message>
    <message>
        <source>Burn in all subtitles when transcoding is triggered. This ensures subtitle synchronization after transcoding at the cost of reduced transcoding speed.</source>
        <translation>Alle Untertitel einbrennen wenn eine Transkodierung startet. Dies ermöglicht Untertitel-Synchronisation nach der Transkodierung, verringert aber die Transkodierung-Geschwindigkeit.</translation>
    </message>
    <message>
        <source>Library Image Orientation</source>
        <translation>Bibliotheksbilder-Orientierung</translation>
    </message>
    <message>
        <source>Select the poster image orientation for the library views.</source>
        <translation>Wähle die Poster-Bilderorientierung für Bibliotheksansichten aus.</translation>
    </message>
    <message>
        <source>Default (Varies By Media Type)</source>
        <translation>Standard (variiert je nach Medientyp)</translation>
    </message>
    <message>
        <source>Landscape (Wide)</source>
        <translation>Landschaft (Weit)</translation>
    </message>
    <message>
        <source>Portrait (Vertical)</source>
        <translation>Porträt (Vertikal)</translation>
    </message>
    <message>
        <source>Skip Unknown</source>
        <translation>Abschnitt überspringen</translation>
    </message>
    <message>
        <source>Skip Commercial</source>
        <translation>Werbung überspringen</translation>
    </message>
    <message>
        <source>Skip Preview</source>
        <translation>Vorschau überspringen</translation>
    </message>
    <message>
        <source>Skip Recap</source>
        <translation>Zusammenfassung überspringen</translation>
    </message>
    <message>
        <source>Skip Outro</source>
        <translation>Outro überspringen</translation>
    </message>
    <message>
        <source>Skip Intro</source>
        <translation>Intro überspringen</translation>
    </message>
    <message>
        <source>Play Instant Mix</source>
        <translation>Instant Mix spielen</translation>
    </message>
    <message>
        <source>Show Next Episode Details After Finish</source>
        <translation>Nach Wiedergabe Details der nächsten Folge anzeigen</translation>
    </message>
    <message>
        <source>If auto play next episode is disabled, display the next episode&apos;s detail screen after an episode finishes playing. If no next up episode is found, return to the just-played episode&apos;s page.</source>
        <translation>Wenn die automatische Wiedergabe der nächsten Folge deaktiviert ist, wird nach dem Abspielen die Detailseite der nächsten Episode angezeigt. Ist keine weitere Folge vorhanden, wird zur Seite der gerade abgespielten Episode zurückgekehrt.</translation>
    </message>
    <message>
        <source>Adjust Subtitle Timing</source>
        <translation>Untertitel-Timing anpassen</translation>
    </message>
    <message>
        <source>Favorites Row</source>
        <translation>Favoritenzeile</translation>
    </message>
    <message>
        <source>Settings relating to the favorites row on the home screen.</source>
        <translation>Einstellungen zu der Favoritenzeile auf dem Startbildschirm.</translation>
    </message>
    <message>
        <source>Sort By Field</source>
        <translation>Nach Feld sortieren</translation>
    </message>
    <message>
        <source>Field to sort the row by.</source>
        <translation>Feld, nach dem sortiert werden soll.</translation>
    </message>
    <message>
        <source>Date Created</source>
        <translation>Erstellungsdatum</translation>
    </message>
    <message>
        <source>Is Unplayed</source>
        <translation>Ist ungespielt</translation>
    </message>
    <message>
        <source>Sort Order for the row - Ascending,Descending.</source>
        <translation>Sortierreihenfolge für die Zeile - Aufsteigend,Absteigend.</translation>
    </message>
    <message>
        <source>Current Offset</source>
        <translation>Aktueller Offset</translation>
    </message>
    <message>
        <source>Screen Settings</source>
        <translation>Bildschirmeinstellungen</translation>
    </message>
    <message>
        <source>Display Episodes In Two Columns</source>
        <translation>Folgen in zwei Spalten anzeigen</translation>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it. Maximum value is 1000 days.</source>
        <translation>Lege die maximale Anzahl an Tagen fest, die eine Serie in &quot;Als Nächstes&quot; ungesehen verbleiben kann. Maximaler Wert ist 1000 Tage.</translation>
    </message>
    <message>
        <source>Newer devices may support direct play of anamorphic video.</source>
        <translation>Neuere Geräte unterstützen möglicherweise das direkte Abspielen von anamorphotischen Videos.</translation>
    </message>
    <message>
        <source>Attempt Direct Play Anamorphic Video</source>
        <translation>Versuchen, Anamorphotische Videos direkt abzuspielen</translation>
    </message>
    <message>
        <source>Channel Title</source>
        <translation>Kanaltitel</translation>
    </message>
    <message>
        <source>Load Items Limit</source>
        <translation>Limitierung geladener Elemente</translation>
    </message>
    <message>
        <source>Number of items to load together on library screens.</source>
        <translation>Anzahl der Elemente, die zusammen auf Bibliotheksseiten geladen werden.</translation>
    </message>
    <message>
        <source>Settings relating to Live TV.</source>
        <translation>Einstellungen bezüglich Live-TV.</translation>
    </message>
    <message>
        <source>Channel Title Info</source>
        <translation>Kanaltitel-Info</translation>
    </message>
    <message>
        <source>Channel Number and Name</source>
        <translation>Kanalnummer und -name</translation>
    </message>
    <message>
        <source>Channel Number</source>
        <translation>Kanalnummer</translation>
    </message>
    <message>
        <source>Channel Name</source>
        <translation>Kanalname</translation>
    </message>
    <message>
        <source>Select what information to use as a channel&apos;s title.</source>
        <translation>Wähle aus, welche Information als Kanaltitel verwendet werden soll.</translation>
    </message>
    <message>
        <source>Channel Logo and Title</source>
        <translation>Kanallogo und -titel</translation>
    </message>
    <message>
        <source>Search Unavailable</source>
        <translation>Suche nicht verfügbar</translation>
    </message>
    <message>
        <source>Trickplay Display</source>
        <translation>Trickplay-Anzeige</translation>
    </message>
    <message>
        <source>Select trickplay display format.</source>
        <translation>Wählen Sie das Trickplay-Anzeigeformat aus.</translation>
    </message>
    <message>
        <source>Five trickplay images</source>
        <translation>Fünf Trickplay-Bilder</translation>
    </message>
    <message>
        <source>Single trickplay image that moves</source>
        <translation>Einzelnes Trickplay-Bild, das sich bewegt</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Untertitel</translation>
    </message>
    <message>
        <source>tracks</source>
        <translation>Tracks</translation>
    </message>
    <message>
        <source>No Default</source>
        <translation>Kein Standard</translation>
    </message>
    <message>
        <source>Replace Roku&apos;s default subtitle functions with custom functions. If fallback fonts are configured and enabled on the server, those fonts will be used. A CJK fallback font is required for CJK rendering. To support bold and italics, you must have additional font files with the words &quot;bold&quot;, &quot;italic&quot;, and &quot;bolditalic&quot; in the filename.</source>
        <translation>Ersetze Rokus Standard-Untertitelmechanismen mit benutzerdefinierten Mechanismen. Falls Ersatz-Schriftarten konfiguriert und auf dem Server aktiviert sind, werden diese Schriftarten verwendet. Eine CJK-Ersatz-Schriftart wird zur CJK-Anzeige benötigt. Um Fett- und Kursivschrift zu unterstützen, müssen zusätzliche Schriftart-Dateien mit den Wörtern &quot;bold&quot;, &quot;italic&quot;, und &quot;bolditalic&quot; im Dateinamen existieren.</translation>
    </message>
    <message>
        <source>Force media to be transcoded.</source>
        <translation>Erzwinge Transkodierung von Medien.</translation>
    </message>
    <message>
        <source>All Playable Media</source>
        <translation>Alle abspielbaren Medien</translation>
    </message>
    <message>
        <source>Force live TV to be transcoded. If All Playable Media is already set to Force Transcode (Remux Disabled), this setting is ignored.</source>
        <translation>Erzwinge Transkodierung bei Live TV. Falls alle abspielbaren Medien bereits zwingend Transkodiert werden wird diese Einstellung keine Auswirkungen haben.</translation>
    </message>
    <message>
        <source>Select how to display a channel in the Live TV guide.</source>
        <translation>Wähle aus, wie ein Kanal in der Live-TV-Übersicht angezeigt werden soll.</translation>
    </message>
    <message>
        <source>Roku&apos;s video player threw the following error</source>
        <translation>Rokus Videoplayer hat folgenden Fehler gemeldet</translation>
    </message>
    <message>
        <source>Roku&apos;s video player got stuck buffering video</source>
        <translation>Rokus Videoplayer hat ist beim Puffern des Videos eingefroren</translation>
    </message>
    <message>
        <source>Roku thought it could direct play this media, but playback never started.</source>
        <translation>Roku dachte, dass es das Medium direkt abspielen könnte, jedoch hat die Wiedergabe nie begonnen.</translation>
    </message>
    <message>
        <source>Always Attempt Direct Playing Video Media</source>
        <translation>Immer versuchen, Videodateien direkt abzuspielen</translation>
    </message>
    <message>
        <source>Forces Jellyfin to try direct playing video media, Live TV excluded. Enabling this ignores all other playback support settings and will always first attempt direct playback. It also changes how transcode reason is displayed.</source>
        <translation>Erzwingt Jellyfin Videodateien direkt abzuspielen, inklusive Live-TV. Das Aktivieren ignoriert alle anderen Wiedergabe-Unterstützungseinstellungen und sorgt dafür, dass die direkte Wiedergabe immer zuerst versucht wird. Außerdem ändert es, wie Transkodierungsgründe angezeigt werden.</translation>
    </message>
    <message>
        <source>Channel Logo</source>
        <translation>Kanallogo</translation>
    </message>
    <message>
        <source>Play from beginning</source>
        <translation>Von Beginn starten</translation>
    </message>
    <message>
        <source>No cast data available.</source>
        <translation>Keine Angaben zur Besetzung verfügbar.</translation>
    </message>
    <message>
        <source>as %1</source>
        <translation>als %1</translation>
    </message>
    <message>
        <source>More with %1 in Your Library</source>
        <translation>Mehr mit %1 in deiner Bibliothek</translation>
    </message>
    <message>
        <source>No other titles found in your library.</source>
        <translation>Keine weiteren Titel in deiner Bibliothek gefunden.</translation>
    </message>
    <message>
        <source>Resume from</source>
        <translation>Fortfahren von</translation>
    </message>
    <message>
        <source>Playback Controls Inactivity Timeout</source>
        <translation>Wiedergabesteuerung Inaktivitäts-Timeout</translation>
    </message>
    <message>
        <source>Set the length of time in seconds that the playback control overlay will remain visible when no buttons are pressed. Set to 0 to disable.</source>
        <translation>Lege die Zeitspanne in Sekunden fest, die die Wiedergabesteuerungsanzeige sichtbar bleibt, wenn keine Tasten gedrückt werden. Stelle den Wert auf 0, um sie zu deaktivieren.</translation>
    </message>
    <message>
        <source>TV Guide Channel Display</source>
        <translation>TV Guide Kanalanzeige</translation>
    </message>
    <message>
        <source>Playback Speed Controls (Experimental)</source>
        <translation>Wiedergabegeschwindigkeit-Steuerung (Experimentell)</translation>
    </message>
    <message>
        <source>Use at your own risk. We make no guarantees this will work for you. \n 1. This feature may not work on this device, yet work on others \n 2. Some speed options may not work on this device, yet work on others \n 3. Roku may block this feature without warning; even if the Jellyfin client doesn&apos;t update</source>
        <translation>Die Nutzung erfolgt auf eigene Gefahr. Wir übernehmen keine Garantie für die Funktionsfähigkeit. \n 1. Diese Funktion funktioniert möglicherweise nicht auf diesem Gerät, aber auf anderen. \n 2. Einige Geschwindigkeitsoptionen funktionieren möglicherweise nicht auf diesem Gerät, aber auf anderen. \n 3. Roku kann diese Funktion ohne Vorwarnung blockieren, selbst wenn der Jellyfin-Client nicht aktualisiert wird.</translation>
    </message>
    <message>
        <source>Roku thought it could direct play this media, but the playback duration was incorrect.</source>
        <translation>Roku ging davon aus, dass es diese Medien direkt abspielen könnte, aber die Wiedergabedauer war falsch.</translation>
    </message>
    <message>
        <comment>Last played time of media item</comment>
        <source>RECENTLY_WATCHED</source>
        <translation>Kürzlich angesehen</translation>
    </message>
    <message>
        <source>Videos</source>
        <translation>Videos</translation>
    </message>
    <message>
        <source>Press Stop again to close player</source>
        <translation>Nochmal Stop drücken um den Player zu schliessen</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <source>More from</source>
        <translation>Mehr von</translation>
    </message>
    <message>
        <source>Playback Mode</source>
        <translation>Wiedergabemodus</translation>
    </message>
    <message>
        <source>Unknown Artist</source>
        <translation>Unbekannter Künstler</translation>
    </message>
    <message>
        <source>Unknown Album</source>
        <translation>Unbekanntes Album</translation>
    </message>
    <message>
        <source>Confirm Exit</source>
        <translation>Beenden bestätigen</translation>
    </message>
    <message>
        <source>Show a confirmation prompt before exiting Jellyfin from the home screen.</source>
        <translation>Bestätigungsabfrage vor dem Schließen von Jellyfin vom Homescreen anzeigen.</translation>
    </message>
    <message>
        <source>Are you sure you want to exit Jellyfin?</source>
        <translation>Möchtest Du Jellyfin wirklich beenden?</translation>
    </message>
    <message>
        <source>Radio Stations</source>
        <translation>Radiosender</translation>
    </message>
    <message>
        <source>Most Played Tracks</source>
        <translation>Am häufigsten gespielte Lieder</translation>
    </message>
    <message>
        <source>Least Played Tracks</source>
        <translation>Am wenigsten gespielte Lieder</translation>
    </message>
    <message>
        <source>Shuffle play your most played tracks</source>
        <translation>Die meistabgespielten Lieder gemischt wiedergeben</translation>
    </message>
    <message>
        <source>Shuffle play your least played tracks</source>
        <translation>Die am wenigsten abgespielten Lieder gemischt wiedergeben</translation>
    </message>
    <message>
        <source>Press Play/Pause to jump to OK button</source>
        <translation>Drücke Wiedergabe/Pause um zum OK Knopf zu springen</translation>
    </message>
    <message>
        <source>Station Name</source>
        <translation>Sendername</translation>
    </message>
    <message>
        <source>Name to identify radio station</source>
        <translation>Name um Radiosender zu identifizieren</translation>
    </message>
    <message>
        <source>List of years to include in station content</source>
        <translation>Liste von Jahren die für Senderinhalte eingeschlossen werden soll</translation>
    </message>
    <message>
        <source>Field to sort media by before cutting off at limit</source>
        <translation>Feld um Medien zu sortieren bevor sie bei einer Begrenzung abgeschnitten werden</translation>
    </message>
    <message>
        <source>Item Limit</source>
        <translation>Elementebegrenzung</translation>
    </message>
    <message>
        <source>Maximum number of items to load</source>
        <translation>Maximale Anzahl an Elementen die geladen werden</translation>
    </message>
    <message>
        <source>Create Station</source>
        <translation>Sender anlegen</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Untertitel</translation>
    </message>
    <message>
        <source>A short description of the radio station</source>
        <translation>Eine kurze Beschreibung für den Radiosender</translation>
    </message>
    <message>
        <source>List of genres to include in station content</source>
        <translation>Genreliste die für Senderinhalte eingeschlossen werden soll</translation>
    </message>
    <message>
        <source>Direction to sort media before cutting off at limit</source>
        <translation>Richtung in die Medien sortiert werden bevor sie bei einer Begrenzung abschnitten werden</translation>
    </message>
    <message>
        <source>Background Color</source>
        <translation>Hintergrundfarbe</translation>
    </message>
    <message>
        <source>Background color to use on home screen block</source>
        <translation>Hintergrundfarbe die auf dem Homescreen-Block verwendet wird</translation>
    </message>
    <message>
        <source>The server found no media matching the filter criteria for this radio station.</source>
        <translation>Der Server hat keine Medien gefunden, die den Filterkriterien für diesen Radiosender entsprechen.</translation>
    </message>
    <message>
        <source>No media matched radio station criteria</source>
        <translation>Keine Medien passten zum Radiosenderkriterium</translation>
    </message>
</context>
<context>
    <name></name>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Nicht in der Lage Kanaldaten vom Server zu laden</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Error beim laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanal Daten</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Wechsel Server</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanaldaten können nicht vom Server geladen werden</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden von Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Laden von Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Bei der Wiedergabe dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es ist ein Fehler beim Abfragen dieses Elements vom Server aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler bei der Wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abfragen von Inhalten</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server ändern</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanaldaten können nicht vom Server geladen werden</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden von Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Laden von Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Bei der Wiedergabe dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es ist ein Fehler beim Abfragen dieses Elements vom Server aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler bei der Wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Anrufen des Inhaltes</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Diese %1 enthält keine Elemente</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 enthält keine Elemente</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortierung</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Erscheinungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Anzahl der Wiedergaben</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Alterseinstufung</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritiker-Bewertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb-Bewertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Diese %1 enthält keine Elemente</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanal-Daten können nicht vom Server geladen werden</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden von Kanal-Daten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Kanal-Daten laden</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Bei der Wiedergabe dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es gab einen Fehler beim Abrufen der Daten für dieses Element vom Server.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler bei der Wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Ausloggen</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server ändern</translation>
    </message>
    <message>
        <source>Started</source>
        <translation>Seit</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerwertung</translation>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endete</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Läuft seit</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortierung</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Dauer</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergaben</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersbeschränkung</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Wiedergegeben am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb-Wertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 enthält keine Elemente</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanaldaten vom Server war nicht möglich</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Bei der Wiedergabe ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Beim Laden der Daten dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Wiedergabefehler</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Laden des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Ausloggen</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindung zum Server wird hergestellt</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endete</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Seit</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Läuft seit</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortierung</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergaben</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersbeschränkung</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Wiedergegeben am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerwertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb-Wertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 enthält keine Elemente</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanaldaten vom Server war nicht möglich</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Bei der Wiedergabe dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Beim Laden der Daten dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Wiedergabefehler</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Laden des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Ausloggen</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der aufgerufene Inhalt existiert nicht auf dem Server</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindung zum Server wird hergestellt</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endete</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Seit</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Läuft seit</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortierung</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergaben</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Wiedergegeben am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerwertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Diese %1 enthält keine Elemente</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanaldaten vom Server war nicht möglich</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Bei der Wiedergabe dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Beim Laden der Daten dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Wiedergabefehler</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Laden des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der aufgerufene Inhalt existiert nicht auf dem Server</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindung zum Server wird hergestellt</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endete</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Seit</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Läuft seit</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortierung</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergaben</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Wiedergegeben am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerwertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Diese %1 enthält keine Elemente</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanaldaten vom Server war nicht möglich</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Bei der Wiedergabe dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Beim Laden der Daten dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Wiedergabefehler</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen von Inhalten</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...oder geben Sie die Server-URL manuell ein:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wählen Sie einen Jellyfin-Server aus dem lokalen Netzwerk</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Geben Sie den Servernamen oder die IP-Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der aufgerufene Inhalt existiert nicht auf dem Server</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindung zum Server wird hergestellt</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endete</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Seit</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Läuft seit</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortierung</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabezähler</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Wiedergegeben am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerwertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Diese %1 enthält keine Elemente</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanaldaten vom Server war nicht möglich</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Bei der Wiedergabe dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Beim Laden der Daten dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Wiedergabefehler</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen von Inhalten</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Wiedergabefehler</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Aufrufen von Inhalten</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Beim Laden der Daten dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation type="unfinished">Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation type="unfinished">Sortierung</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation type="unfinished">Ansicht</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation type="unfinished">Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungs-Datum</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation type="unfinished">Altersfreigabe</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation type="unfinished">Kritikerwertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation type="unfinished">IMDb-Bewertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation type="unfinished">Laden der Kanal-Daten vom Server war nicht möglich</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation type="unfinished">Fehler beim Laden von Kanal-Daten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation type="unfinished">Kanal-Daten werden geladen</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation type="unfinished">Während des Abspielens dieses Eintrags trat ein Fehler auf.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wählen Sie einen Jellyfin-Server aus dem lokalen Netzwerk</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Geben Sie den Servernamen oder die IP-Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der aufgerufene Inhalt existiert nicht auf dem Server</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindung zum Server wird hergestellt</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endete</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Seit</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Läuft seit</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortierung</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabezähler</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Wiedergegeben am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerbewertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb-Bewertung</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Diese %1 enthält keine Elemente</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanal-Daten vom Server war nicht möglich</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden von Kanal-Daten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Kanal-Daten werden geladen</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Während des Abspielens dieses Eintrags trat ein Fehler auf.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation type="unfinished">Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...oder geben Sie die Server-URL manuell ein:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerbewertung</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...oder geben Sie die Server-URL manuell ein:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wählen Sie einen Jellyfin-Server aus dem lokalen Netzwerk</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Geben Sie den Servernamen oder die IP-Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der aufgerufene Inhalt existiert nicht auf dem Server</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindung zum Server wird hergestellt</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholen</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endete</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Seit</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Läuft seit</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabezähler</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritiker Bewertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Diese %1 enthält keine Elemente</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanal-Daten vom Server war nicht möglich</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden von Kanal-Daten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Kanal-Daten werden geladen</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Während des Abspielens dieses Eintrags trat ein Fehler auf.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Beim Laden der Daten dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Wiedergabefehler</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Aufrufen von Inhalten</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Beim Abspielen dieses Titels ist ein Fehler aufgetreten. Server lieferte keine erforderlichen Transcodierungsdaten.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Erhalten von Wiedergabe-Informationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Beim Abspielen dieses Titels ist ein Fehler aufgetreten. Der Server lieferte nicht die erforderlichen Transcodierungsdaten.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Abrufen von Wiedergabe-Informationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...oder gebe die Server-URL manuell ein:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wähle einen Jellyfin-Server aus dem lokalen Netzwerk</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Gib den Servernamen oder die IP-Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der aufgerufene Inhalt existiert nicht auf dem Server</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindung zum Server wird hergestellt</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholen</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endete</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Seit</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Läuft seit</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabezähler</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritiker-Bewertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb-Bewertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Diese %1 enthält keine Elemente</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanal-Daten vom Server war nicht möglich</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanal-Daten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Kanal-Daten werden geladen</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Beim Abspielen dieses Elements trat ein Fehler auf.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Beim Laden der Daten dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Wiedergabefehler</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen von Inhalten</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanal-Daten vom Server war nicht möglich</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanal-Daten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Kanal-Daten werden geladen</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Beim Abspielen dieses Elements trat ein Fehler auf.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Beim Laden der Daten dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Wiedergabefehler</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen von Inhalten</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation type="unfinished">Löschen</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server ändern</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Beim Abspielen dieses Titels ist ein Fehler aufgetreten. Der Server hat keine URL für das Transkodieren zur Verfügung gestellt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Abrufen von Wiedergabe-Informationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...oder gebe die Server-URL manuell ein:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wähle einen Jellyfin-Server aus dem lokalen Netzwerk aus</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Gib den Servernamen oder die IP-Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der angeforderte Inhalt existiert nicht auf dem Server</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbinde mit Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholen</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Läuft seit</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Läuft seit</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabezähler</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerwertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>Bewertung auf IMDb</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Diese %1 enthält keine Elemente</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>Gerade Läuft</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeicherte Löschen</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Anmeldedaten speichern?</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritiker Bewertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Rating</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanaldaten vom Server nicht möglich</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Es ist ein Fehler beim Abspielen aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es ist ein Fehler beim Abrufen der Daten vom Server für diesen Eintrag aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler beim Abspielen</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>Läuft gerade</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Löschen gespeichert</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Zugangsdaten speichern?</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Ausloggen</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Started at</source>
        <translation>Läuft seit</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...oder gebe die Server-URL manuell ein:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wähle einen Jellyfin-Server aus dem lokalen Netzwerk aus</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Gib den Servernamen oder die IP-Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endete</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Läuft seit</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Wertung</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Beim Abspielen dieses Titels ist ein Fehler aufgetreten. Der Server hat keine URL für das Transkodieren zur Verfügung gestellt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Abrufen von Wiedergabe-Informationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der angeforderte Inhalt existiert nicht auf dem Server</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbinde mit Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholen</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabezähler</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Diese %1 enthält keine Elemente</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Erscheinungsdatum</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 enthält keine Einträge</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen der Inhalte</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeichertes Löschen</translation>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...oder die URL per hand eingeben:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation type="unfinished">Datum hinzugefügt</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation type="unfinished">Aufrufzeitpunkt</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Aufrufe</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Zeige Kanal</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Eintrag</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Ein Fehler ist beim Abspielen der Inhalte aufgetreten. Der server hat keine transcodierten Daten bereitgestellt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Erhalten der Playback Informationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Jellyfin server aus dem lokalen Netzwerk auswählen</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Server name oder IP-Adresse eingeben</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der angefragte Inhalt konnte auf dem Server nicht gefunden werden</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindungsaufbau mit dem Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Stoppe Serienaufnahme</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Stoppe Aufnahme</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Aufgenommene Serie</translation>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV Guide</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholen</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation type="unfinished">Beendet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation type="unfinished">Beendet gegen</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Begonnen</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Begonnen um</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filtern</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Anzeigen</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Alterseinstufung</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation type="unfinished">Kritikbewertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanaldaten vom Server nicht möglich</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Es ist ein Fehler beim Abspielen dieses Eintrags aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es ist ein Fehler beim Abrufen der Daten vom Server für diesen Eintrag aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler beim Abspielen</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>Läuft gerade</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Zugangsdaten speichern?</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Ausloggen</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerwertung</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation type="unfinished">Läuft zurzeit</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeichertes Löschen</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Zugangsdaten speichern?</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es ist ein Fehler beim Abrufen der Daten vom Server für diesen Eintrag aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler beim Abspielen</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen der Inhalte</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation type="unfinished">Läuft gerade</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Beim Abspielen des Titels ist ein Fehler aufgetreten. Der Server hat zur Transkodierung erforderliche Daten nicht zur Verfügung gestellt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Abruf von Wiedergabe-Informationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...oder gebe die URL per Hand ein:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wähle einen Jellyfin-Server aus dem lokalen Netzwerk</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Gebe den Servernamen oder die IP-Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der angefragte Inhalt konnte auf dem Server nicht gefunden werden</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindungsaufbau mit dem Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serienaufnahme abbrechen</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie aufnehmen</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal anzeigen</translation>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Startet</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Startet um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Gestartet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Gestartet um</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Drücke &apos;OK&apos; um zu Schließen</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Besonderheiten</translation>
        <message>
            <source>Press &apos;OK&apos; to Close</source>
            <translation>Press &apos;OK&apos; to Close</translation>
        </message>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Ähnliches</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Besetzung &amp; Mitwirkende</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Gestorben</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Geboren</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filtern</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Anzeigen</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Erscheinungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabeanzahl</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Alterseinstufung</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerwertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 enthält keine Einträge</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanaldaten vom Server nicht möglich</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Es ist ein Fehler beim Abspielen dieses Eintrags aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>Läuft gerade</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Beim Abspielen dieses Elements trat ein Fehler auf.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deaktiviert</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktiviert</translation>
    </message>
    <message>
        <source>Support direct play of MPEG 2 content (e.g. Live TV). This will prevent transcoding of MPEG 2 content, but uses significantly more bandwidth</source>
        <translation>Unterstützung der direkten Wiedergabe von MPEG-2-Inhalten (z. B. Live-TV). Dies verhindert die Transkodierung von MPEG-2-Inhalten, verbraucht aber deutlich mehr Bandbreite</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>MPEG 2 Support</source>
        <translation>MPEG-2-Support</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Wiedergabe</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Beim Abspielen des Titels ist ein Fehler aufgetreten. Der Server hat zur Transkodierung erforderliche Daten nicht zur Verfügung gestellt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Abruf von Wiedergabe-Informationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...oder gebe die URL per Hand ein:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wähle einen Jellyfin-Server aus dem lokalen Netzwerk</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Gebe den Servernamen oder die IP-Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der angefragte Inhalt konnte auf dem Server nicht gefunden werden</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindungsaufbau mit dem Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serienaufnahme abbrechen</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie aufnehmen</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal anzeigen</translation>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Startet</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Startet um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Gestartet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Gestartet um</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Besonderheiten</translation>
        <message>
            <source>Press &apos;OK&apos; to Close</source>
            <translation>Press &apos;OK&apos; to Close</translation>
        </message>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Ähnliches</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Besetzung &amp; Mitwirkende</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Gestorben</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Geboren</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filtern</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Anzeigen</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Erscheinungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabeanzahl</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Alterseinstufung</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerwertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 enthält keine Einträge</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanaldaten vom Server nicht möglich</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Beim Abspielen dieses Elements trat ein Fehler auf.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es ist ein Fehler beim Abrufen der Daten vom Server für diesen Eintrag aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler beim Abspielen</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen der Inhalte</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>Läuft gerade</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeichertes Löschen</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Zugangsdaten speichern?</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Zur Episode gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Zur Staffel gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Zur Serie gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Als Favoriten markieren</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Als Gesehen markieren</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deaktiviert</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktiviert</translation>
    </message>
    <message>
        <source>Support direct play of MPEG 2 content (e.g. Live TV). This will prevent transcoding of MPEG 2 content, but uses significantly more bandwidth</source>
        <translation>Unterstützung der direkten Wiedergabe von MPEG-2-Inhalten (z. B. Live-TV). Dies verhindert die Transkodierung von MPEG-2-Inhalten, verbraucht aber deutlich mehr Bandbreite</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>MPEG 2 Support</source>
        <translation>MPEG-2-Support</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Wiedergabe</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Beim Abspielen des Titels ist ein Fehler aufgetreten. Der Server hat zur Transkodierung erforderliche Daten nicht zur Verfügung gestellt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Abruf von Wiedergabe-Informationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...oder gebe die URL per Hand ein:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wähle einen Jellyfin-Server aus dem lokalen Netzwerk</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Gebe den Servernamen oder die IP-Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der angefragte Inhalt konnte auf dem Server nicht gefunden werden</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindungsaufbau mit dem Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serienaufnahme abbrechen</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie aufnehmen</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal anzeigen</translation>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Startet</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Startet um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Gestartet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Gestartet um</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Besonderheiten</translation>
        <message>
            <source>Press &apos;OK&apos; to Close</source>
            <translation>Press &apos;OK&apos; to Close</translation>
        </message>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Ähnliches</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Besetzung &amp; Mitwirkende</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Gestorben</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Geboren</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filtern</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Anzeigen</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Erscheinungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabeanzahl</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Alterseinstufung</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerwertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 enthält keine Einträge</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanaldaten vom Server nicht möglich</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Beim Abspielen dieses Elements trat ein Fehler auf.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es ist ein Fehler beim Abrufen der Daten vom Server für diesen Eintrag aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler beim Abspielen</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen der Inhalte</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>Läuft gerade</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeichertes Löschen</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Zugangsdaten speichern?</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 enthält keine Einträge</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanaldaten vom Server nicht möglich</translation>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler beim Abspielen</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen der Inhalte</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es ist ein Fehler beim Abrufen der Daten vom Server für diesen Eintrag aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Beim Abspielen des Inhalts ist ein Problem aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>Läuft gerade</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeicherte Löschen</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Login-Daten speichern?</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Anzeigen</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Erscheinungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabeanzahl</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Alterseinstufung</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerwertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deaktiviert</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktiviert</translation>
    </message>
    <message>
        <source>Support direct play of MPEG 2 content (e.g. Live TV). This will prevent transcoding of MPEG 2 content, but uses significantly more bandwidth</source>
        <translation>Unterstützung der direkten Wiedergabe von MPEG-2-Inhalten (z. B. Live-TV). Dies verhindert die Transkodierung von MPEG-2-Inhalten, verbraucht aber deutlich mehr Bandbreite</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>MPEG 2 Support</source>
        <translation>MPEG-2-Support</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Wiedergabe</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Beim Abspielen des Titels ist ein Fehler aufgetreten. Der Server hat zur Transkodierung erforderliche Daten nicht zur Verfügung gestellt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Abruf von Wiedergabe-Informationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...oder gebe die URL per Hand ein:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wähle einen Jellyfin-Server aus dem lokalen Netzwerk</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Gebe den Servernamen oder die IP-Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der angefragte Inhalt konnte auf dem Server nicht gefunden werden</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindungsaufbau mit dem Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serienaufnahme abbrechen</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie aufnehmen</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal anzeigen</translation>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Startet</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Startet um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Gestartet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Gestartet um</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV-Sendungen</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Besonderheiten</translation>
        <message>
            <source>Press &apos;OK&apos; to Close</source>
            <translation>Press &apos;OK&apos; to Close</translation>
        </message>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Ähnliches</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Besetzung &amp; Mitwirkende</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Gestorben</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Geboren</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Anzeigen</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Erscheinungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabeanzahl</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerwertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 enthält keine Einträge</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanaldaten vom Server nicht möglich</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Beim Abspielen des Inhalts ist ein Problem aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es ist ein Fehler beim Abrufen der Daten vom Server für diesen Eintrag aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler beim Abspielen</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen der Inhalte</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>Läuft gerade</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeicherte Löschen</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Login-Daten speichern?</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin home background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Verwenden Sie das generierte Splashscreen-Bild als Jellyfin-Hintergrund. Jellyfin muss geschlossen und erneut geöffnet werden, damit die Änderung wirksam wird.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Splashscreen als Hintergrund für die Startseite verwenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options that alter the design of Jellyfin.</source>
        <translation>Optionen, die das Design von Jellyfin verändern.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Designelemente</translation>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s screensaver background.</source>
        <translation>Verwenden Sie das generierte Splashscreen-Bild als Hintergrund für Jellyfin&apos;s Bildschirmschoner.</translation>
    </message>
    <message>
        <source>Options for Jellyfin&apos;s screensaver.</source>
        <translation>Optionen für Jellyfin&apos;s Bildschirmschoner.</translation>
        <extracomment>Description for Screensaver user settings.</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Screensaver Background</source>
        <translation>Splashscreen als Bildschirmschoner-Hintergrund verwenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Screensaver</source>
        <translation>Bildschirmschoner</translation>
    </message>
    <message>
        <source>If enabled, images for unwatched episodes will be blurred.</source>
        <translation>Wenn diese Option aktiviert ist, werden die Bilder von nicht angesehenen Episoden unscharf dargestellt.</translation>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Optionen für Serien.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Options for details pages.</source>
        <translation>Optionen für Detailseiten.</translation>
        <extracomment>Description for Detail Page user settings.</extracomment>
    </message>
    <message>
        <source>Detail Page</source>
        <translation>Detailseite</translation>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, The folder will reset to the first item immediately)</source>
        <translation>Verwenden Sie die Schaltfläche &quot;Wiederholen&quot;, um langsam zum ersten Element im Ordner zu animieren. (Wenn diese Funktion deaktiviert ist, wird der Ordner sofort auf das erste Element zurückgesetzt)</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Zurück zum Seitenanfang</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>Bei der Authentifizierung über Quick Connect ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialog wird automatisch geschlossen)</translation>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Hier ist dein Quick Connect Code:</translation>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Quick Connect</translation>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 von %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Zur Episode gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Zur Staffel gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Zur Serie gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Als Gesehen markieren</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Als Favoriten markieren</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Show item count in the library, and index of selected item.</source>
        <translation>Zeigt die Anzahl der Objekte in der Bibliothek und den Index des ausgewählten Objekts an.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Always show the titles below the poster images. (If disabled, title will be shown under hilighted item only)</source>
        <translation>Die Titel werden immer unter den Plakatbildern angezeigt. (Wenn deaktiviert, wird der Titel nur unter dem hervorgehobenen Element angezeigt)</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Benutzeroberfläche</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deaktiviert</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktiviert</translation>
    </message>
    <message>
        <source>Support direct play of MPEG 2 content (e.g. Live TV). This will prevent transcoding of MPEG 2 content, but uses significantly more bandwidth</source>
        <translation>Unterstützung der direkten Wiedergabe von MPEG-2-Inhalten (z. B. Live-TV). Dies verhindert die Transkodierung von MPEG-2-Inhalten, verbraucht aber deutlich mehr Bandbreite</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>MPEG 2 Support</source>
        <translation>MPEG-2-Support</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Wiedergabe</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Beim Abspielen des Titels ist ein Fehler aufgetreten. Der Server hat zur Transkodierung erforderliche Daten nicht zur Verfügung gestellt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Abruf von Wiedergabe-Informationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...oder gebe die URL per Hand ein:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wähle einen Jellyfin-Server aus dem lokalen Netzwerk</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Gebe den Servernamen oder die IP-Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der angefragte Inhalt konnte auf dem Server nicht gefunden werden</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindungsaufbau mit dem Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serienaufnahme abbrechen</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie aufnehmen</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal anzeigen</translation>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Startet</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Startet um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Gestartet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Gestartet um</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV-Sendungen</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Ähnliches</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Besetzung &amp; Mitwirkende</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Gestorben</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Geboren</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Anzeigen</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Erscheinungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabeanzahl</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerwertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 enthält keine Einträge</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanaldaten vom Server nicht möglich</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Beim Abspielen des Inhalts ist ein Problem aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es ist ein Fehler beim Abrufen der Daten vom Server für diesen Eintrag aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler beim Abspielen</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen der Inhalte</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>Läuft gerade</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeicherte Löschen</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Login-Daten speichern?</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerbewertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kann keine Kanaldaten laden</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden von Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Ein Fehler wurde während der Wiedergabe festgestellt</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es gab einen Fehler für dieses Objekt, Daten vom Server zu holen</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler bei der Wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Laden von Inhalten</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeicherte löschen</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Ausloggen</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Ein Fehler wurde während der Wiedergabe festgestellt.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es gab einen Fehler für dieses Objekt, Daten vom Server zu holen.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Zurück zum Seitenanfang</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Netzwerke</translation>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>Bei der Authentifizierung über Quick Connect ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialog wird automatisch geschlossen)</translation>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Hier ist dein Quick Connect Code:</translation>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Quick Connect</translation>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 von %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Zur Episode gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Zur Staffel gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Zur Serie gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Als gesehen markieren</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Als Favorit markieren</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Show item count in the library, and index of selected item.</source>
        <translation>Zeigt die Anzahl der Objekte in der Bibliothek und den Index des ausgewählten Objekts an.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Stückzahl</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Always show the titles below the poster images. (If disabled, title will be shown under hilighted item only)</source>
        <translation>Die Titel werden immer unter den Plakatbildern angezeigt. (Wenn deaktiviert, wird der Titel nur unter dem hervorgehobenen Element angezeigt)</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Artikel Namen</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Media Grid Options</source>
        <translation>Medienraster Optionen</translation>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Medienraster</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Benutzeroberfläche</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deaktiviert</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktiviert</translation>
    </message>
    <message>
        <source>Support direct play of MPEG 2 content (e.g. Live TV). This will prevent transcoding of MPEG 2 content, but uses significantly more bandwidth</source>
        <translation>Unterstützung der direkten Wiedergabe von MPEG-2-Inhalten (z. B. Live-TV). Dies verhindert die Transkodierung von MPEG-2-Inhalten, verbraucht aber deutlich mehr Bandbreite</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>MPEG 2 Support</source>
        <translation>MPEG 2 Support</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Wiedergabe</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Beim Abspielen des Titels ist ein Fehler aufgetreten. Der Server hat zur Transkodierung erforderliche Daten nicht zur Verfügung gestellt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Abruf von Wiedergabe-Informationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...oder gebe die URL per Hand ein:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wähle einen Jellyfin-Server aus dem lokalen Netzwerk</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Gebe den Servernamen oder die IP-Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der angefragte Inhalt konnte auf dem Server nicht gefunden werden</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindungsaufbau mit dem Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serienaufnahme abbrechen</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie aufnehmen</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal anzeigen</translation>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Startet</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Startet um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Gestartet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Gestartet um</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV Serien</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Mehr davon</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>gestorben</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>geboren</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>sortieren</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Anmeldedaten speichern?</translation>
    </message>
    <message>
        <source>Hides all clocks in Jellyfin. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Blendet alle Uhren in Jellyfin aus. Jellyfin muss geschlossen und wieder geöffnet werden, damit die Änderung wirksam wird.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Uhr ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Cinema mode brings the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Der Kinomodus bringt das Kinoerlebnis direkt in dein Wohnzimmer und bietet die Möglichkeit, benutzerdefinierte Trailer vor dem Hauptfilm abzuspielen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Cinema mode</source>
        <translation>Kino-Modus</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin home background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Verwenden Sie das generierte Startbildschirm-Bild als Jellyfin-Hintergrund. Jellyfin muss geschlossen und erneut geöffnet werden, damit die Änderung wirksam wird.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Splashscreen als Hintergrund für die Startseite verwenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options that alter the design of Jellyfin.</source>
        <translation>Optionen, die das Design von Jellyfin verändern.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Designelemente</translation>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s screensaver background.</source>
        <translation>Verwenden Sie das generierte Splashscreen-Bild als Hintergrund für Jellyfin&apos;s Bildschirmschoner.</translation>
    </message>
    <message>
        <source>Use Splashscreen as Screensaver Background</source>
        <translation>Splashscreen als Bildschirmschoner-Hintergrund verwenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options for Jellyfin&apos;s screensaver.</source>
        <translation>Optionen für Jellyfin&apos;s Bildschirmschoner.</translation>
        <extracomment>Description for Screensaver user settings.</extracomment>
    </message>
    <message>
        <source>Screensaver</source>
        <translation>Bildschirmschoner</translation>
    </message>
    <message>
        <source>If enabled, images for unwatched episodes will be blurred.</source>
        <translation>Wenn diese Option aktiviert ist, werden die Bilder von nicht angesehenen Episoden unscharf dargestellt.</translation>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Optionen für Serien.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Blendet Schlagwörter auf den Detailseiten aus.</translation>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Schlagwörter ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options for details pages.</source>
        <translation>Optionen für Detailseiten</translation>
        <extracomment>Description for Detail Page user settings.</extracomment>
    </message>
    <message>
        <source>Detail Page</source>
        <translation>Detailseite</translation>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, The folder will reset to the first item immediately)</source>
        <translation>Verwenden Sie die Schaltfläche &quot;Wiederholen&quot;, um langsam zum ersten Element im Ordner zu wechseln. (Wenn diese Funktion deaktiviert ist, wird der Ordner sofort auf das erste Element zurückgesetzt)</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Zurück zum Seitenanfang</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Shows</source>
        <translation>Shows</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Netzwerke</translation>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>Bei der Authentifizierung über Quick Connect ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Der Dialog wird automatisch geschlossen)</translation>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Hier ist dein Quick Connect Code:</translation>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Qick Connect</translation>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 von %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Zur Episode gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Zur Staffel gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Zur Serie gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Als gesehen markieren</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Als Favorit markieren</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Show item count in the library, and index of selected item.</source>
        <translation>Zeigt die Anzahl der Objekte in der Bibliothek und den Index des ausgewählten Objekts an.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Support direct play of MPEG 2 content (e.g. Live TV). This will prevent transcoding of MPEG 2 content, but uses significantly more bandwidth</source>
        <translation>Unterstützt die direkte Wiedergabe von MPEG-2-Inhalten (z. B. Live-TV). Dies verhindert die Transkodierung von MPEG-2-Inhalten, verbraucht aber deutlich mehr Bandbreite</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Stückzahl</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Always show the titles below the poster images. (If disabled, title will be shown under hilighted item only)</source>
        <translation>Die Titel werden immer unter den Plakatbildern angezeigt. (Wenn deaktiviert, wird der Titel nur unter dem hervorgehobenen Element angezeigt</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Media Grid Options</source>
        <translation>Medienraster Optionen</translation>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Medienraster</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Benutzeroberfläche</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deaktiviert</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktiviert</translation>
    </message>
    <message>
        <source>MPEG 2 Support</source>
        <translation>MPEG 2 Support</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Wiedergabe</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Beim Abspielen des Titels ist ein Fehler aufgetreten. Der Server hat zur Transkodierung erforderliche Daten nicht zur Verfügung gestellt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Abrufen von Wiedergabe-Informationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...oder gebe die URL per Hand ein:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wählen Sie einen Jellyfin-Server aus dem lokalen Netzwerk aus</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Gebe den Servernamen oder die IP-Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der angefragte Inhalt konnte auf dem Server nicht gefunden werden</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindungsaufbau zum Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serienaufnahme abbrechen</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie aufnehmen</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal anzeigen</translation>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Startet</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Startet um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Gestartet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Gestartet am</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV Serien</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Besonderheiten</translation>
        <message>
            <source>Press &apos;OK&apos; to Close</source>
            <translation>Drücke &apos;OK&apos; zum schließen</translation>
        </message>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Mehr davon</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Besetzung &amp; Mitwirkende</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>gestorben</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>geboren</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>sortieren</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Erscheinungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabeanzahl</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerbewertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 enthält keine Einträge</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanaldaten können nicht vom Server geladen werden</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden von Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Beim Abspielen dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es gab einen Fehler für dieses Objekt, Daten vom Server zu holen.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler bei der Wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Laden von Inhalten</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>Läuft gerade</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeichertes verwerfen</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Anmeldedaten speichern?</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Options for details pages.</source>
        <translation>Optionen für Detailseiten.</translation>
        <extracomment>Description for Detail Page user settings.</extracomment>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie aufnehmen</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal anzeigen</translation>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Extras</translation>
        <message>
            <source>Press &apos;OK&apos; to Close</source>
            <translation>Drücke &apos;OK&apos; zum Schliessen</translation>
        </message>
    </message>
    <message>
        <source>Died</source>
        <translation>gestorben</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>geboren</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 enthält keine Einträge</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanaldaten können nicht vom Server geladen werden</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden von Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>Läuft gerade</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeichertes verwerfen</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Besetzung &amp; Mitwirkende</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt am</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Begann am</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Begann um</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Mehr wie dieses</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerbewertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Beim Abspielen dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Beim Abrufen der Daten für dieses Element vom Server ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler während der Wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Anmeldedaten speichern?</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie aufnehmen</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal anzeigen</translation>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet am</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt am</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Begann am</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Begonnen um</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Extras</translation>
        <message>
            <source>Press &apos;OK&apos; to Close</source>
            <translation>Drücke &quot;OK&quot; um zuschließen</translation>
        </message>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Mehr wie dieses</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Besetzung &amp; Mitwirkende</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>gestorben</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>geboren</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabeanzahl</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerbewertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 enthält keine Elemente</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanaldaten können nicht vom Server geladen werden</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden von Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Beim Abspielen dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Beim Abrufen der Daten für dieses Element vom Server ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler während der Wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>Läuft gerade</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeichertes verwerfen</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Anmeldedaten speichern?</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wähle einen Jellyfin-Server aus dem lokalen Netzwerk aus:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der gefragte Inhalt existiert nicht</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 Besitzt keine Elemente</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Die Kanaldaten könnten nicht abgerufen werden</translation>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler während der Wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen des Inhaltes</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s home background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Nutze Jellyfin&apos;s Generierten Splashscreen als Bildschirmschoner Hintergrund. Jellyfin muss geschlossen und wieder geöffnet werden damit die Änderung in Kraft treten.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Nutze die Wiederholungstaste um langsam das erste Element in dem Ordner zu animieren. (Falls deaktiviert, Wird der Ordner sofort zum ersten Element zurückgesetzt).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Always show the titles below the poster images. (If disabled, the title will be shown under the highlighted item only).</source>
        <translation>Zeige immer die Title der Poster an. (Falls deaktiviert, der Title wird nur dem ausgewählten Element angezeigt).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeichertes verwerfen</translation>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</source>
        <translation>Legen Sie die maximale Anzahl an Tagen fest, an denen eine Sendung in der „Nächste Sendung“-Liste bleiben soll, ohne sie anzusehen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Options for Home Page.</source>
        <translation>Einstellungen für die Startseite.</translation>
        <extracomment>Description for Home Page user settings.</extracomment>
    </message>
    <message>
        <source>Home Page</source>
        <translation>Startseite</translation>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation>Einstellungen zum Aussehen der Anwendung.</translation>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation>Einstellungen in Bezug auf Wiedergabe und unterstützte Codecs und Medientypen.</translation>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Trailer abspielen</translation>
    </message>
    <message>
        <source>Skip Intro</source>
        <translation>Überspringe Intro</translation>
    </message>
    <message>
        <source>Hides all clocks in Jellyfin. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Blendet alle Uhren in Jellyfin aus. Jellyfin muss geschlossen und wieder geöffnet werden, damit die Änderung wirksam wird.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Uhr ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Cinema Mode brings the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Kino Modus bringt dir ein Kinoerlebnis direkt zu dir in dein Wohnzimmer, mit der Fähigkeit eigene Intros abzuspielen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Kino Modus</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Splashscreen als Hintergrund für die Startseite verwenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options that alter the design of Jellyfin.</source>
        <translation>Optionen, die das Design von Jellyfin verändern.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Designelemente</translation>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s screensaver background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Nutze Jellyfin&apos;s Generierten Splashscreen als Bildschirmschoner Hintergrund. Jellyfin muss geschlossen und wieder geöffnet werden damit die Änderung in Kraft treten.</translation>
    </message>
    <message>
        <source>Use Splashscreen as Screensaver Background</source>
        <translation>Splashscreen als Bildschirmschoner-Hintergrund verwenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options for Jellyfin&apos;s screensaver.</source>
        <translation>Optionen für Jellyfin&apos;s Bildschirmschoner.</translation>
        <extracomment>Description for Screensaver user settings.</extracomment>
    </message>
    <message>
        <source>Screensaver</source>
        <translation>Bildschirmschoner</translation>
    </message>
    <message>
        <source>If enabled, images of unwatched episodes will be blurred.</source>
        <translation>Falls aktiviert, werden Bilder von nicht geschauten Folgen unkenntlich gemacht.</translation>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Nicht geschaute Folgen unkenntlich machen</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Optionen für Serien.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Blendet Slogan-Text auf Detailseiten aus.</translation>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Slogan ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options for Details pages.</source>
        <translation>Optionen für Detailseiten.</translation>
        <extracomment>Description for Details page user settings.</extracomment>
    </message>
    <message>
        <source>Details Page</source>
        <translation>Detailseite</translation>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Zurück nach oben</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Netzwerke</translation>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>Fehler beim Authentifizierung über Quick Connect.</translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Der Dialog wird automatisch geschlossen)</translation>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Hier ist dein Quick Connect Code:</translation>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Quick Connect</translation>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 von %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>Du kannst nach Titeln, Leuten, Live Fernsehen Känale und mehr suchen</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>Search now</source>
        <translation>Suche jetzt</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Verwenden Sie die Sprachfernbedienung, um zu suchen</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Zur Episode gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Zur Staffel gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Zur Serie gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Als gesehen markieren</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Als Favorit markieren</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Zeigt die Anzahl der Elemente in der Bibliothek und den Index des ausgewählten Elements an.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Anzahl</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Artikel Namen</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Medienraster Einstellungen.</translation>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Medienraster</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Benutzeroberfläche</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deaktiviert</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktiviert</translation>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation type="unfinished">Unterstützung von Direkt Abspielen von MPEG-2 Inhalte (z.B., Live Fernsehen). Dadurch wird die Transcodierung von MPEG-2-Inhalten verhindert, aber es nutzt bedeutend mehr Bandbreite.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>MPEG-2 Support</source>
        <translation>MPEG-2 Unterstützung</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Wiedergabe</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Beim Abspielen des Titels ist ein Fehler aufgetreten. Der Server hat zur Transkodierung erforderliche Daten nicht zur Verfügung gestellt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Abrufen von Wiedergabe-Informationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>Falls kein Server angezeigt wird, versuche die URL per Hand einzugeben:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Gebe den Servernamen oder die IP-Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindung zum Server wird hergestellt</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serienaufnahme abbrechen</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie aufnehmen</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal anzeigen</translation>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>Fernsehprogramm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet am</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt am</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Gestartet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Begonnen um</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Extras Features</translation>
        <message>
            <source>Press &apos;OK&apos; to Close</source>
            <translation>Zum Schließen &apos;OK&apos; drücken</translation>
        </message>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Mehr wie dieses</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Besetzung &amp; Mitwirkende</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>gestorben</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>geboren</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabeanzahl</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerbewertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden von Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Ein Fehler ist aufgetreten beim Wiedergeben des Elementes.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Beim Abrufen der Daten ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>Läuft gerade</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Anmeldedaten speichern?</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>WxH</source>
        <translation>Breite x Höhe</translation>
        <extracomment>Video width x height</extracomment>
    </message>
    <message>
        <source>Stream Information</source>
        <translation>Stream Informationen</translation>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</source>
        <translation>Legt fest, wie viele Tage eine Sendung maximal in der Liste &apos;Als Nächstes&apos; bleiben soll, ohne dass sie angesehen wird.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Max Days Next Up</source>
        <translation>Maximale Anzahl Tage für &quot;Als Nächstes&quot;</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Cinema Mode brings the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Der Kinomodus bringt mit der Fähigkeit, Trailer und benutzerdefinierte Intros vor dem Hauptfilm abzuspielen, das Kinoerlebnis direkt in dein Wohnzimmer.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s screensaver background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Nutze generiertes Splashscreen-Bild als Hintergrund für den Bildschirmschoner von Jellyfin. Jellyfin muss geschlossen und wieder geöffnet werden, damit die Änderung wirksam wird.</translation>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s home background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Nutze generiertes Splashscreen-Bild als Hintergrund für die Startseite von Jellyfin. Jellyfin muss geschlossen und wieder geöffnet werden, damit die Änderung wirksam wird.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Pixel format</source>
        <translation>Pixelformat</translation>
        <extracomment>Video pixel format</extracomment>
    </message>
    <message>
        <source>Video range type</source>
        <translation>Spektrum</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Größe</translation>
        <extracomment>Video size</extracomment>
    </message>
    <message>
        <source>Container</source>
        <translation>Container</translation>
        <extracomment>Video streaming container</extracomment>
    </message>
    <message>
        <source>Bit Rate</source>
        <translation>Bitrate</translation>
        <extracomment>Video streaming bit rate</extracomment>
    </message>
    <message>
        <source>Level</source>
        <translation>Level</translation>
        <extracomment>Video profile level</extracomment>
    </message>
    <message>
        <source>Codec Tag</source>
        <translation>Codec-Tag</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <source>Audio Channels</source>
        <translation>Audiokanäle</translation>
    </message>
    <message>
        <source>Total Bitrate</source>
        <translation>Gesamte Bitrate</translation>
    </message>
    <message>
        <source>direct</source>
        <translation>direkt</translation>
    </message>
    <message>
        <source>Audio Codec</source>
        <translation>Audio-Codec</translation>
    </message>
    <message>
        <source>Video Codec</source>
        <translation>Video-Codec</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Grund</translation>
    </message>
    <message>
        <source>Transcoding Information</source>
        <translation>Informationen zur Transkodierung</translation>
    </message>
    <message>
        <source>Playback Information</source>
        <translation>Wiedergabe-Informationen</translation>
    </message>
    <message>
        <source>Options for Home Page.</source>
        <translation>Einstellungen für die Startseite.</translation>
        <extracomment>Description for Home Page user settings.</extracomment>
    </message>
    <message>
        <source>Home Page</source>
        <translation>Startseite</translation>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation>Einstellungen zum Aussehen der Anwendung.</translation>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation>Einstellungen in Bezug auf Wiedergabe und unterstützte Codecs und Medientypen.</translation>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Trailer abspielen</translation>
    </message>
    <message>
        <source>Hides all clocks in Jellyfin. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Blendet alle Uhren in Jellyfin aus. Jellyfin muss geschlossen und wieder geöffnet werden, damit die Änderung wirksam wird.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Uhr ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Kinomodus</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Splashscreen als Hintergrund für die Startseite verwenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options that alter the design of Jellyfin.</source>
        <translation>Optionen, die das Design von Jellyfin verändern.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Designelemente</translation>
    </message>
    <message>
        <source>Use Splashscreen as Screensaver Background</source>
        <translation>Splashscreen als Bildschirmschoner-Hintergrund verwenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options for Jellyfin&apos;s screensaver.</source>
        <translation>Optionen für Jellyfins Bildschirmschoner.</translation>
        <extracomment>Description for Screensaver user settings.</extracomment>
    </message>
    <message>
        <source>Screensaver</source>
        <translation>Bildschirmschoner</translation>
    </message>
    <message>
        <source>If enabled, images of unwatched episodes will be blurred.</source>
        <translation>Falls aktiviert, werden Bilder von nicht geschauten Episoden unkenntlich gemacht.</translation>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Nicht geschaute Episoden unkenntlich machen</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Optionen für Serien.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Blendet Schlagwörter auf den Detailseiten aus.</translation>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Schlagwörter ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options for Details pages.</source>
        <translation>Optionen für Detailseiten.</translation>
        <extracomment>Description for Details page user settings.</extracomment>
    </message>
    <message>
        <source>Details Page</source>
        <translation>Detailseite</translation>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Verwenden Sie die Schaltfläche &quot;Wiederholen&quot;, um langsam zum ersten Element im Ordner zu wechseln. (Wenn diese Funktion deaktiviert ist, wird der Ordner sofort auf das erste Element zurückgesetzt).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Element-Titel</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Zurück nach oben</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Netzwerke</translation>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>Bei der Authentifizierung über Quick Connect ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialog wird automatisch geschlossen)</translation>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Hier ist dein Quick Connect Code:</translation>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Quick Connect</translation>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 von %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>Du kannst nach Titeln, Leuten, Live-TV Kanälen und mehr suchen</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>Search now</source>
        <translation>Suche jetzt</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Verwenden Sie die Sprachfernbedienung, um zu suchen</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Zur Episode gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Zur Staffel gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Zur Serie gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Als gesehen markieren</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Als Favorit markieren</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Zeige die Anzahl der Elemente in der Bibliothek und den Index des ausgewählten Elements an.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Anzahl</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Always show the titles below the poster images. (If disabled, the title will be shown under the highlighted item only).</source>
        <translation>Zeige immer die Titel unter den Postern. (Falls deaktiviert, wird der Titel nur unter dem ausgewählten Element angezeigt).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Medienraster Einstellungen.</translation>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Medienraster</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Benutzeroberfläche</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deaktiviert</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktiviert</translation>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Unterstützung der Direktwiedergabe von MPEG-2-Inhalten (z. B. Live-TV). Dadurch wird die Transcodierung von MPEG-2-Inhalten verhindert, aber es nutzt deutlich mehr Bandbreite.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>MPEG-2 Support</source>
        <translation>MPEG-2 Unterstützung</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Wiedergabe</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Beim Abspielen des Titels ist ein Fehler aufgetreten. Der Server hat zur Transkodierung erforderliche Daten nicht zur Verfügung gestellt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Abrufen von Wiedergabe-Informationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>Falls kein Server angezeigt wird, versuche die URL per Hand einzugeben:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wähle einen Jellyfin-Server aus dem lokalen Netzwerk aus:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Gebe den Servernamen oder die IP-Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der angefragte Inhalt existiert nicht</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindung zum Server wird hergestellt</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serienaufnahme abbrechen</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie aufnehmen</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal anzeigen</translation>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>Fernsehprogramm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet am</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt am</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Gestartet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Begonnen um</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Extras Features</translation>
        <message>
            <source>Press &apos;OK&apos; to Close</source>
            <translation>Drücken Sie auf &apos;OK&apos; zum Schließen</translation>
        </message>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Mehr wie dieses</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Besetzung &amp; Mitwirkende</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>gestorben</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>geboren</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabeanzahl</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerbewertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 Besitzt keine Elemente</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Die Kanaldaten könnten nicht abgerufen werden</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden von Kanaldaten</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Ein Fehler ist aufgetreten beim Wiedergeben des Elementes.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Beim Abrufen der Daten ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler während der Wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen des Inhaltes</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>Läuft gerade</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeichertes verwerfen</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Anmeldedaten speichern?</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Options for Jellyfin&apos;s screensaver.</source>
        <translation>Einstellungen für Jellyfin&apos;s Bildschirmschoner.</translation>
        <extracomment>Description for Screensaver user settings.</extracomment>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Serien-Einstellungen.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Markierungs-Text auf der Detailseite verstecken.</translation>
    </message>
    <message>
        <source>Options for Details pages.</source>
        <translation>Detail-Seiten Einstellungen.</translation>
        <extracomment>Description for Details page user settings.</extracomment>
    </message>
    <message>
        <source>MPEG-2 Support</source>
        <translation>MPEG-2 Unterstützung</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wählen Sie einen bereits verfügbaren Jellyfin Server aus Ihrem Netzwerk aus:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <source>Unable to find any albums or songs belonging to this artist</source>
        <translation>Es konnten keine Alben oder Lieder dieses Künstlers gefunden werden</translation>
        <extracomment>Popup message when we find no audio data for an artist</extracomment>
    </message>
    <message>
        <source>WxH</source>
        <translation>Breite x Höhe</translation>
        <extracomment>Video width x height</extracomment>
    </message>
    <message>
        <source>Pixel format</source>
        <translation>Pixelformat</translation>
        <extracomment>Video pixel format</extracomment>
    </message>
    <message>
        <source>Video range type</source>
        <translation>Video-Spektrum</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Größe</translation>
        <extracomment>Video size</extracomment>
    </message>
    <message>
        <source>Container</source>
        <translation>Container</translation>
        <extracomment>Video streaming container</extracomment>
    </message>
    <message>
        <source>Bit Rate</source>
        <translation>Bitrate</translation>
        <extracomment>Video streaming bit rate</extracomment>
    </message>
    <message>
        <source>Level</source>
        <translation>Level</translation>
        <extracomment>Video profile level</extracomment>
    </message>
    <message>
        <source>Codec Tag</source>
        <translation>Codec-Tag</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <source>Stream Information</source>
        <translation>Stream Informationen</translation>
    </message>
    <message>
        <source>Audio Channels</source>
        <translation>Audiokanäle</translation>
    </message>
    <message>
        <source>Total Bitrate</source>
        <translation>Gesamte Bitrate</translation>
    </message>
    <message>
        <source>direct</source>
        <translation>direkt</translation>
    </message>
    <message>
        <source>Audio Codec</source>
        <translation>Audio-Codec</translation>
    </message>
    <message>
        <source>Video Codec</source>
        <translation>Video-Codec</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Grund</translation>
    </message>
    <message>
        <source>Transcoding Information</source>
        <translation>Transcoding-Information</translation>
    </message>
    <message>
        <source>Playback Information</source>
        <translation>Wiedergabeinformation</translation>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</source>
        <translation>Legen Sie die maximale Anzahl von Tagen fest, die eine Serie in der Liste &quot;Als Nächstes&quot; verbleiben soll, ohne dass sie angesehen wird.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Max Days Next Up</source>
        <translation>Max. Tage im &quot;Als Nächstes&quot; Bereich</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options for Home Page.</source>
        <translation>Einstellungen für Home Seite.</translation>
        <extracomment>Description for Home Page user settings.</extracomment>
    </message>
    <message>
        <source>Home Page</source>
        <translation>Home Seite</translation>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation>Einstellungen zum Aussehen des Programms.</translation>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation>Einstellungen für die Wiedergabe und unterstützte Codec- und Medientypen.</translation>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Trailer abspielen</translation>
    </message>
    <message>
        <source>Hides all clocks in Jellyfin. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Blendet alle Uhren in Jellyfin aus. Jellyfin muss neu geöffnet werden, damit die Änderung wirksam wird.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Uhr ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Cinema Mode brings the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Der Kinomodus bringt das Kinoerlebnis direkt in Ihr Wohnzimmer und bietet die Möglichkeit, benutzerdefinierte Intros vor dem Hauptfilm abzuspielen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Kinomodus</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s home background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Generierten Splashscreen als Jellyfin&apos;s Hintergrund verwenden. Jellyfin muss neu geöffnet werden, damit die Änderung wirksam wird.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Splashscreen als Hintergrund verwenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options that alter the design of Jellyfin.</source>
        <translation>Einstellungen für das Aussehen Jellyfin&apos;s.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Designelemente</translation>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s screensaver background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Generierten Splashscreen als Jellyfin&apos;s Bildschirmschoner verwenden. Jellyfin muss neu geöffnet werden, damit die Änderung wirksam wird.</translation>
    </message>
    <message>
        <source>Use Splashscreen as Screensaver Background</source>
        <translation>Splashscreen als Bildschirmschoner verwenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Screensaver</source>
        <translation>Bildschirmschoner</translation>
    </message>
    <message>
        <source>If enabled, images of unwatched episodes will be blurred.</source>
        <translation>Wenn diese Option aktiviert ist, werden Bilder von nicht angesehenen Folgen unscharf dargestellt.</translation>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Ungesehene Folgen verpixeln</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Markierungen verstecken</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Details Page</source>
        <translation>Detailseite</translation>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Verwenden Sie &quot;Wiederholen&quot;, um langsam zum ersten Element im Ordner zu überblenden. (Wenn diese Funktion deaktiviert ist, wird der Ordner sofort zum ersten Element zurückgesetzt).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Zurück nach oben</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Netzwerke</translation>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>Bei der Authentifizierung über Quick Connect ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialog wird automatisch geschlossen)</translation>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Ihr Quick Connect Code lautet:</translation>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Quick Connect</translation>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 von %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>Sie können nach Titeln, Personen, Live-TV-Kanälen und noch mehr suchen</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>Search now</source>
        <translation>Jetzt Suchen</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Mit Sprachfernbedienung suchen</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Zur Folge</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Zur Staffel</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Zur Serie</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Zu Favoriten hinzufügen</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>markieren als &quot;gesehen&quot;</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Zeige die Anzahl der Elemente in der Bibliothek und den Index des ausgewählten Elements an.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Dateien-Anzahl</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Always show the titles below the poster images. (If disabled, the title will be shown under the highlighted item only).</source>
        <translation>Titel werden immer unter den Plakatbildern angezeigt. (Wenn aus, wird der Titel nur unter dem hervorgehobenen Element angezeigt).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Dateien-Titel</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Medien-Raster Einstellungen.</translation>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Medien-Raster</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Benutzeroberfläsche</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Aus</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>An</translation>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Direkte Wiedergabe von MPEG-2-Inhalten (z. B. Live-TV). Dies verhindert die Transkodierung von MPEG-2-Inhalten, verbraucht aber deutlich mehr Bandbreite.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Wiedergabe</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Bei der Wiedergabe dieses Elements ist ein Fehler aufgetreten. Der Server hat die erforderlichen Transkodierungsdaten nicht bereitgestellt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Einsehen der Abspielinformation</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>Sollte der Server nicht aufgelistet sein, fügen Sie bitte die URL manuell ein:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Geben Sie den Servernamen oder die IP Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der gewünschte Inhalt exisitiert nicht auf dem Server</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbinde zum Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serien-Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie aufnehmen</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal einschalten</translation>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>TV-Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholen</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Beendet um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Startet</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Startet um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Angefangen</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Begonnen am</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Spezialbesetzung</translation>
        <message>
            <source>Press &apos;OK&apos; to Close</source>
            <translation>Press &apos;OK&apos; to Close</translation>
        </message>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Ähnliches</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Besetzung &amp; Mitwirkende</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Gestorben am</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Geboren am</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Sortierung</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabezähler</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Freigabe</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritik Rating</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Dieser %1 enthält keine Dateien</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>KanalDaten können nicht vom Server geladen werden</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanalinformationen</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Kanalinformationen werden geladen</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Es ist ein Fehler beim Abspielen dieser Datei aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es ist ein Fehler beim Abrufen der Daten vom Server aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Wiedergabefehler</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler bei der Wiedergabe</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>Jetzt verfügbar</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeichertes löschen</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Passwort speichern?</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Zugangsdaten speichern?</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen des Inhaltes</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler bei der Wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es ist ein Fehler beim Abrufen der Daten vom Server aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Bei der Wiedergabe dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanaldaten können nicht vom Server geladen werden</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Dieser %1 enthält keine Dateien</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerbewertung</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortierung</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Geboren am</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Besetzung &amp; Mitwirkende</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Gestorben am</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>Jetzt verfügbar</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanalinformationen</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Übersicht</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Ähnliches</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Daten des Kanals</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabezähler</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Zugangsdaten speichern?</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeicherte löschen</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Zugangsdaten speichern?</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen des Inhaltes</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler bei der Wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es ist ein Fehler beim Abrufen der Daten vom Server aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Bei der Wiedergabe dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Daten des Kanals</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Dieser %1 enthält keine Dateien</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerbewertung</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Übersicht</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Gestorben am</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Besetzung &amp; Mitwirkende</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>&apos;OK&apos; klicken zum Schließen</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Ausloggen</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeicherte löschen</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>Jetzt verfügbar</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanalinformationen</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Ähnliches</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanaldaten können nicht vom Server geladen werden</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortierung</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Geboren am</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Spezialbesetzung</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Zusätzliche Inhalte</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>Gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>Heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>Morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Gestartet um</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabezähler</translation>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Sender</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal anschauen</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie aufnehmen</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der gewünschte Inhalt exisitiert nicht auf dem Server</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serien-Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Started</source>
        <translation>Gestartet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Startet um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Startet</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endete</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbinde zum Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Geben Sie den Servernamen oder die IP Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wählen Sie einen verfügbaren Jellyfin Server aus ihrem Lokalen Netzwerk aus:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 beinhaltet keine Elemente</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Lösche Gespeicherte</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanaldaten können nicht vom Server geladen werden</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Anmeldedaten speichern?</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim laden des Inhaltes vom Server</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Laden des Inhalts nicht möglich</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Fehler bei der Wiedergabe</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Übersicht</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabeanzahl</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Datum hinzugefügt</translation>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>Movies (Presentation)</source>
        <translation>Filme (Präsentation)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeicherte löschen</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>Jetzt live</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Ähnliches</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Ein Fehler ist beim Abspielen des Gegenstands aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanaldaten können nicht vom Server geladen werden</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Diese(s) %1 enthält keine Gegenstände</translation>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation>Filme (Raster)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Extras</translation>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Logindaten speichern?</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler während des Abspielens</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Ein Fehler ist beim Aufrufen der Daten für diesen Gegenstand vom Server aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerbewertung</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortierung</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Geboren am</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Gestorben am</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Besetzung &amp; Mitwirkende</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>&apos;OK&apos; zum Schließen klicken</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Zusätzliche Inhalte</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb-Bewertung</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabeanzahl</translation>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Datum hinzugefügt</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeicherte löschen</translation>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Ein Fehler ist beim Aufrufen der Daten für diesen Gegenstand vom Server aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wählen Sie einen verfügbaren Jellyfin Server aus ihrem Lokalen Netzwerk aus:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Bei der Wiedergabe dieses Elements ist ein Fehler aufgetreten. Der Server hat die erforderlichen Transkodierungsdaten nicht bereitgestellt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Logindaten speichern?</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler während des Abspielens</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortierung</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Geboren am</translation>
    </message>
    <message>
        <source>Movies (Presentation)</source>
        <translation>Filme (Präsentation)</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>Jetzt live</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Ähnliches</translation>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>Sollte der Server nicht aufgelistet sein, fügen Sie bitte die URL manuell ein:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Wiedergabe</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Ein Fehler ist beim Abspielen des Gegenstands aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanaldaten können nicht vom Server geladen werden</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Diese(s) %1 enthält keine Gegenstände</translation>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation>Filme (Raster)</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Gestartet um</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Extras</translation>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Einsehen der Abspielinformation</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerbewertung</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Gestorben am</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Besetzung &amp; Mitwirkende</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>&apos;OK&apos; zum Schließen klicken</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Zusätzliche Inhalte</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Gestartet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endete</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Sender</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal anschauen</translation>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie aufnehmen</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der gewünschte Inhalt exisitiert nicht auf dem Server</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serien-Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb-Bewertung</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabeanzahl</translation>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Startet um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbinde zum Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Geben Sie den Servernamen oder die IP Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>Starts</source>
        <translation>Startet</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abgespielt am</translation>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Enable or disable Direct Play for optional codecs</source>
        <translation>Aktiviere oder deaktiviere Direkte Wiedergabe für optionale Codecs</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>MPEG-2</source>
        <translation>MPEG-2</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>MPEG-4</source>
        <translation>MPEG-4</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Unterstütze Direkte Wiedergabe von MPEG-2-Inhalten (z. B. Live-TV). Dies verhindert die Transkodierung von MPEG-2-Inhalten, verbraucht aber deutlich mehr Bandbreite.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Codec Support</source>
        <translation>Codec Unterstützung</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</source>
        <translation>Unterstützt direktes Abspielen von MPEG-4 Inhalten. Das muss ggf. deaktiviert werden um DIVX-Dateien abzuspielen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>AV1</source>
        <translation>AV1</translation>
        <extracomment>Name of a setting - should we try to direct play experimental av1 codec</extracomment>
    </message>
    <message>
        <source>Always show the titles below the poster images. (If disabled, the title will be shown under the highlighted item only).</source>
        <translation>Titel werden immer unter den Posterbildern angezeigt. (Wenn deaktiviert, wird der Titel nur unter dem hervorgehobenen Element angezeigt).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Anzahl der Elemente in der Bibliothek und im Index des gewählten Elements anzeigen.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Springe zur Serie</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>Sie können nach Titeln, Personen, Live-TV-Kanälen und noch mehr suchen</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Zurück nach oben</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Options for Details pages.</source>
        <translation>Detail-Seiten Einstellungen.</translation>
        <extracomment>Description for Details page user settings.</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Screensaver Background</source>
        <translation>Splashscreen als Bildschirmschoner verwenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Schnellverbindung</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktiviert</translation>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Als Favorit festlegen</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Springe zur Staffel</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Benutze Sprachfernbedienung zum Suchen</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>Search now</source>
        <translation>Jetzt suchen</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 von %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>Networks</source>
        <translation>Netzwerke</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>Bei der Authentifizierung über Quick Connect ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <source>Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Details Page</source>
        <translation>Detailseite</translation>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Markierungen verstecken</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Markierungs-Text auf der Detailseite verstecken.</translation>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Ungesehene Folgen verpixeln</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Skip Details for Single Seasons</source>
        <translation>Details für einzelne Staffeln überspringen</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>If enabled, images of unwatched episodes will be blurred.</source>
        <translation>Wenn diese Option aktiviert ist, werden Bilder von nicht angesehenen Folgen unscharf dargestellt.</translation>
    </message>
    <message>
        <source>Screensaver</source>
        <translation>Bildschirmschoner</translation>
    </message>
    <message>
        <source>Options for Jellyfin&apos;s screensaver.</source>
        <translation>Einstellungen für Jellyfins Bildschirmschoner.</translation>
        <extracomment>Description for Screensaver user settings.</extracomment>
    </message>
    <message>
        <source>** EXPERIMENTAL** Support Direct Play of AV1 content if this Roku device supports it.</source>
        <translation>**EXPERIMENTELL** Unterstützt direktes Abspielen von AV1 Inhalten falls das Roku-Gerät das unterstützt.</translation>
        <extracomment>Description of a setting - should we try to direct play experimental av1 codec</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Benutzerschnittstelle</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Als gesehen markieren</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Springe zur Folge</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Ihr Schnellverbindungscode lautet:</translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialog schließt sich automatisch)</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deaktiviert</translation>
    </message>
    <message>
        <source>Default view for Movie Libraries.</source>
        <translation>Standard Ansicht für Film Sammlungen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Movie Library Grid Titles</source>
        <translation>Film Sammlung Grid Titel</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Select when to show titles.</source>
        <translation>Wähle aus wann Serientitel gezeigt werden sollen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Show On Hover</source>
        <translation>Beim Hovern anzeigen</translation>
    </message>
    <message>
        <source>Always Show</source>
        <translation>Immer zeigen</translation>
    </message>
    <message>
        <source>Always Hide</source>
        <translation>Niemals anzeigen</translation>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Medien Anordnung</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Verwenden Sie &quot;Wiederholen&quot;, um langsam zum ersten Element im Ordner zu überblenden. (Wenn diese Funktion deaktiviert ist, wird der Ordner sofort zum ersten Element zurückgesetzt).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>If enabled, selecting a TV series with only one season will go straight to the episode list rather than the show details and season list.</source>
        <translation>Wenn diese Option aktiviert ist, führt die Auswahl einer TV-Serie mit nur einer Staffel direkt zur Episodenliste und nicht zu den Showdetails und der Staffelliste.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s screensaver background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Generierten Splashscreen als Jellyfin&apos;s Bildschirmschoner verwenden. Jellyfin muss neu geöffnet werden, damit die Änderung wirksam wird.</translation>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Startbildschirm als Hintergrund verwenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s home background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Generierten Startbildschirm als Jellyfins Hintergrund verwenden. Jellyfin muss neu geöffnet werden, damit die Änderung wirksam wird.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Next episode</source>
        <translation>Nächste Folge</translation>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</source>
        <translation>Legen Sie die maximale Anzahl von Tagen fest, die eine Serie in der Liste &quot;Als Nächstes&quot; verbleiben soll, ohne dass sie angesehen wird.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Text Subtitles Only</source>
        <translation>Nur Text Untertitel</translation>
        <extracomment>Name of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>Show What&apos;s New popup when Jellyfin is updated to a new version.</source>
        <translation>Zeige Was ist neu Popup nach einem Jellyfin update.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Resumable</source>
        <translation>fortsetzen</translation>
    </message>
    <message>
        <source>Movie Library Default View</source>
        <translation>Film Sammlung standard Ansicht</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>If enabled, the star and community rating for episodes of a TV show will be removed. This is to prevent spoilers of an upcoming good/bad episode.</source>
        <translation>Wenn ausgewählt, wird das Sterne und Benutzerbewertungssystem entfernt. Dies ist um spoilern vorzubeugen.</translation>
    </message>
    <message>
        <source>Options that alter the design of Jellyfin.</source>
        <translation>Einstellungen für das Aussehen Jellyfins.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Kinomodus</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Cinema Mode brings the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Der Kinomodus bringt das Kinoerlebnis direkt in Ihr Wohnzimmer und bietet die Möglichkeit, benutzerdefinierte Intros vor dem Hauptfilm abzuspielen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Uhr ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Hides all clocks in Jellyfin. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Blendet alle Uhren in Jellyfin aus. Jellyfin muss neu gestartet werden, damit die Änderung wirksam wird.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Trailer abspielen</translation>
    </message>
    <message>
        <source>H.264</source>
        <translation>H.264</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>HEVC</source>
        <translation>HEVC</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Transcoding Information</source>
        <translation>Transkodierung-Information</translation>
    </message>
    <message>
        <source>Video Codec</source>
        <translation>Video-Codec</translation>
    </message>
    <message>
        <source>Audio Codec</source>
        <translation>Audio-Codec</translation>
    </message>
    <message>
        <source>direct</source>
        <translation>direkt</translation>
    </message>
    <message>
        <source>Audio Channels</source>
        <translation>Audiokanäle</translation>
    </message>
    <message>
        <source>Codec Tag</source>
        <translation>Codec-Tag</translation>
    </message>
    <message>
        <source>Bit Rate</source>
        <translation>Bitrate</translation>
        <extracomment>Video streaming bit rate</extracomment>
    </message>
    <message>
        <source>Container</source>
        <translation>Container</translation>
        <extracomment>Video streaming container</extracomment>
    </message>
    <message>
        <source>Video range type</source>
        <translation>Video-Spektrum</translation>
    </message>
    <message>
        <source>Pixel format</source>
        <translation>Pixelformat</translation>
        <extracomment>Video pixel format</extracomment>
    </message>
    <message>
        <source>Unable to find any albums or songs belonging to this artist</source>
        <translation>Es konnten keine Alben oder Lieder dieses Künstlers gefunden werden</translation>
        <extracomment>Popup message when we find no audio data for an artist</extracomment>
    </message>
    <message>
        <source>Only display text subtitles to minimize transcoding.</source>
        <translation>Zeige nur Text Untertitel um Transkodierungen zu minimieren.</translation>
        <extracomment>Description of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>Slideshow Off</source>
        <translation>Diashow aus</translation>
    </message>
    <message>
        <source>Slideshow On</source>
        <translation>Diashow an</translation>
    </message>
    <message>
        <source>Slideshow Paused</source>
        <translation>Diashow pausiert</translation>
    </message>
    <message>
        <source>Slideshow Resumed</source>
        <translation>Diashow fortgesetzt</translation>
    </message>
    <message>
        <source>MPEG-4 Support</source>
        <translation>MPEG-4 Unterstützung</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Show What&apos;s New Popup</source>
        <translation>Serie Was ist neu Popup</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Serien-Einstellungen.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Home Page</source>
        <translation>Startseite</translation>
    </message>
    <message>
        <source>Max Days Next Up</source>
        <translation>Max. Tage im &quot;Als Nächstes&quot; Bereich</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Playback Information</source>
        <translation>Wiedergabeinformation</translation>
    </message>
    <message>
        <source>Stream Information</source>
        <translation>Stream Informationen</translation>
    </message>
    <message>
        <source>WxH</source>
        <translation>Breite x Höhe</translation>
        <extracomment>Video width x height</extracomment>
    </message>
    <message>
        <source>all</source>
        <translation>Alle</translation>
        <extracomment>all will reset the searchTerm so all data will be availible</extracomment>
    </message>
    <message>
        <source>Aired</source>
        <translation>Ausgestrahlt</translation>
        <extracomment>Aired date label</extracomment>
    </message>
    <message>
        <source>Artists (Presentation)</source>
        <translation>Künstlerinnenvorstellung</translation>
    </message>
    <message>
        <source>Song</source>
        <translation>Musiktitel</translation>
    </message>
    <message>
        <source>Songs</source>
        <translation>Lieder</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <source>Albums</source>
        <translation>Alben</translation>
    </message>
    <message>
        <source>View All</source>
        <translation>Alle anzeigen</translation>
    </message>
    <message>
        <source>Disable Community Rating for Episodes</source>
        <translation>Deaktiviere Community Bewertungen für Episoden</translation>
    </message>
    <message>
        <source>Artists (Grid)</source>
        <translation>Künstler (Gitter)</translation>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Dateien-Anzahl</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Medien Anordnung Optionen.</translation>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Designelemente</translation>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation>Einstellungen zum Aussehen des Programms.</translation>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation>Einstellungen für die Wiedergabe und unterstützte Codec- und Medientypen.</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Grund</translation>
    </message>
    <message>
        <source>Total Bitrate</source>
        <translation>Gesamte Bitrate</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Größe</translation>
        <extracomment>Video size</extracomment>
    </message>
    <message>
        <source>Random On</source>
        <translation>Zufällig an</translation>
    </message>
    <message>
        <source>Random Off</source>
        <translation>Zufällig aus</translation>
    </message>
    <message>
        <source>Played</source>
        <translation>gespielt</translation>
    </message>
    <message>
        <source>Unplayed</source>
        <translation>nicht gespielt</translation>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Dateien-Titel</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Level</source>
        <translation>Level</translation>
        <extracomment>Video profile level</extracomment>
    </message>
    <message>
        <source>Options for Home Page.</source>
        <translation>Einstellungen für die Startseite.</translation>
        <extracomment>Description for Home Page user settings.</extracomment>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler bei der wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Fehler beim laden der Daten vom Server</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Dieses %1 hat keine Inhalte</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Beim Abspielen ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Schlüssel speichern?</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim laden des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritiker Bewertung</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabeanzahl</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Zuletzt abgespielt</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Zugangsdaten speichern?</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Löschen gespeichert</translation>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler bei der Wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Fehler beim Laden der Daten vom Server</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Bei der Wiedergabe trat ein Fehler auf</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Zugangsdaten speichern?</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Laden des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanaldaten können nicht vom Server geladen werden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server ändern</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanaldaten konnten nicht vom Server geladen werden</translation>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Fehler beim Laden der Daten vom Server</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Geboren am</translation>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Gestartet um</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Ausloggen</translation>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler beim Abspielen</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Bei der Wiedergabe trat ein Fehler auf</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Dieses %1 hat keine Inhalte</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Anmeldedaten merken?</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Laden des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortierung</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Ähnliches</translation>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation>Filme (Raster)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritiker Bewertung</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Gestorben am</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Besetzung &amp; Mitwirkende</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>klicke &apos;OK&apos; zum Schließen</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Zusätzliche Inhalte</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Gestartet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Sender</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabeanzahl</translation>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Startet um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Startet</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abspieldatum</translation>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzufügedatum</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Sender ansehen</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</source>
        <translation>Unterstützung der direkten Wiedergabe von MPEG-4-Inhalten. Für die Wiedergabe von DIVX-codierten Videodateien muss diese Funktion möglicherweise deaktiviert werden.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Gehe zur Staffel</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Verwenden Sie die Schaltfläche &quot;Wiederholen&quot;, um langsam zum ersten Element im Ordner zu animieren. (Wenn diese Funktion deaktiviert ist, wird der Ordner sofort auf das erste Element zurückgesetzt).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Startbildschirm als Hintergrund verwenden.</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s home background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Benutzen Sie den generierten Startbildschirm als Jellyfin&apos;s Start-Hintergrund. Jellyfin muss geschlossen und erneut geöffnet werden, damit die Änderung wirksam wird.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Replace Roku&apos;s default subtitle functions with custom functions that support CJK fonts. Fallback fonts must be configured and enabled on the server for CJK rendering to work.</source>
        <translation>Ersetzen Sie die Standard-Untertitelfunktionen von Roku durch benutzerdefinierte Funktionen, die CJK-Schriftarten unterstützen. Fallback-Schriften müssen auf dem Server konfiguriert und aktiviert werden, damit die CJK-Wiedergabe funktioniert.</translation>
        <extracomment>Description of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Set the maximum bitrate in Mbps. Set to 0 to use Roku&apos;s specifications. This setting must be enabled to take effect.</source>
        <translation>Legen Sie die maximale Bitrate in Mbps fest. Setzen Sie sie auf 0, um die Spezifikationen von Roku zu verwenden. Diese Einstellung muss aktiviert werden, um wirksam zu werden.</translation>
    </message>
    <message>
        <source>Settings that apply when Grid views are enabled.</source>
        <translation>Einstellungen, die gelten, wenn Rasteransichten aktiviert sind.</translation>
    </message>
    <message>
        <source>If enabled, the number of unwatched episodes in a series/season will be removed.</source>
        <translation>Wenn aktiv, wird die Anzahl der ungesehenen Episoden in Serie/Staffel entfernt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</source>
        <translation>Legen Sie fest, wie viele Sekunden vor dem Ende einer Episode die Schaltfläche &quot;Nächste Episode&quot; erscheinen soll. Zum Deaktivieren auf 0 setzen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der gewünschte Inhalt existiert nicht auf dem Server</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Grid</source>
        <translation>Raster</translation>
        <extracomment>Title of an option - name of grid view</extracomment>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>Bei der Authentifizierung über Quick Connect ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Blendet Schlagworte auf Detailseiten aus.</translation>
    </message>
    <message>
        <source>Custom Subtitles</source>
        <translation>Benutzerdefinierte Untertitel</translation>
        <extracomment>Name of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Slideshow Paused</source>
        <translation>Diashow pausiert</translation>
    </message>
    <message>
        <source>Slideshow Resumed</source>
        <translation>Diashow fortgesetzt</translation>
    </message>
    <message>
        <source>Played</source>
        <translation>Abgespielt</translation>
    </message>
    <message>
        <source>Movies (Presentation)</source>
        <translation>Filme (Präsentation)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>Always Show</source>
        <translation>Immer anzeigen</translation>
    </message>
    <message>
        <source>Albums</source>
        <translation>Alben</translation>
    </message>
    <message>
        <source>Album Artists (Presentation)</source>
        <translation>Album Künstler (Vorstellung)</translation>
    </message>
    <message>
        <source>Album Artists (Grid)</source>
        <translation>Album Künstler (Raster)</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <source>Disable Community Rating for Episodes</source>
        <translation>Community-Bewertung für Episoden deaktivieren</translation>
    </message>
    <message>
        <source>Configure the maximum playback bitrate.</source>
        <translation>Festlegung der maximalen Wiedergabe-Bitrate.</translation>
    </message>
    <message>
        <source>Biographical information for this person is not currently available.</source>
        <translation>Biographische Informationen zu dieser Person sind derzeit nicht verfügbar.</translation>
    </message>
    <message>
        <source>Enable or disable  the &apos;Maximum Bitrate&apos; setting.</source>
        <translation>Aktivieren oder deaktivieren der &quot;Maximale Bitrate&quot; Einstellung.</translation>
    </message>
    <message>
        <source>Bitrate Limit</source>
        <translation>Bitraten Limit</translation>
    </message>
    <message>
        <source>Libraries</source>
        <translation>Bibliotheken</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of Library pages</source>
        <translation>Einstellungen für das Erscheinungsbild der Bibliotheksseiten</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of the Home screen and the program in general.</source>
        <translation>Einstellungen, die sich auf das Aussehen des Startbildschirms und des Programms im Allgemeinen beziehen.</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in Movie Libraries.</source>
        <translation>Einstellungen, die sich auf die Darstellung von Seiten in Filmbibliotheken beziehen.</translation>
    </message>
    <message>
        <source>Presentation</source>
        <translation>Vorstellung</translation>
        <extracomment>Title of an option - name of presentation view</extracomment>
    </message>
    <message>
        <source>Loading trailer</source>
        <translation>Lade Trailer</translation>
        <extracomment>Dialog title in Main.brs</extracomment>
    </message>
    <message>
        <source>Next Episode Button Time</source>
        <translation>Anzeigedauer &quot;Nächste Episode&quot;</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>Jetzt live</translation>
    </message>
    <message>
        <source>Next episode</source>
        <translation>Nächste Folge</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeicherte löschen</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>MPEG-2</source>
        <translation>MPEG-2</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>MPEG-4</source>
        <translation>MPEG-4</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Medienraster</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Schlagworte ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>General</source>
        <translation>Allgemein</translation>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Kinomodus</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Video Codec</source>
        <translation>Video Codec</translation>
    </message>
    <message>
        <source>Audio Codec</source>
        <translation>Audio Codec</translation>
    </message>
    <message>
        <source>direct</source>
        <translation>direkt</translation>
    </message>
    <message>
        <source>Audio Channels</source>
        <translation>Audiokanäle</translation>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Trailer abspielen</translation>
    </message>
    <message>
        <source>Codec Tag</source>
        <translation>Codec Tag</translation>
    </message>
    <message>
        <source>Artists (Grid)</source>
        <translation>Künstler (Raster)</translation>
    </message>
    <message>
        <source>Slideshow Off</source>
        <translation>Diashow aus</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wählen Sie einen verfügbaren Jellyfin-Server in Ihrem lokalen Netzwerk aus:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>Sollte der Server nicht aufgelistet sein, fügen Sie bitte die URL manuell ein:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Bei der Wiedergabe dieses Elements ist ein Fehler aufgetreten. Der Server hat die erforderlichen Transcodierungsdaten nicht bereitgestellt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Wiedergabe</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Enable or disable Direct Play for optional codecs</source>
        <translation>Aktivieren oder Deaktivieren von Direct Play für optionale Codecs</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Unterstützung der direkten Wiedergabe von MPEG-2-Inhalten (z. B. Live-TV). Dies verhindert die Transkodierung von MPEG-2-Inhalten, verbraucht aber deutlich mehr Bandbreite.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>AV1</source>
        <translation>AV1</translation>
        <extracomment>Name of a setting - should we try to direct play experimental av1 codec</extracomment>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktiviert</translation>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Zeigt die Anzahl der Objekte in der Bibliothek und den Index des ausgewählten Objekts an.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Als Favorit festlegen</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Gehe zur Serie</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Verwenden Sie die Sprachfernbedienung für die Suche</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>Search now</source>
        <translation>Jetzt suchen</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>Sie können nach Titeln, Personen, Live-TV-Kanälen und mehr suchen</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 von %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Schnellverbindung</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Netzwerke</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Zurück nach oben</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Ungesehene Folgen verpixeln</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Skip Details for Single Seasons</source>
        <translation>Details für einzelne Staffeln überspringen</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Options that alter the design of Jellyfin.</source>
        <translation>Einstellungen die das Aussehen von Jellyfin verändern.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Uhr ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>H.264</source>
        <translation>H.264</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Transcoding Information</source>
        <translation>Transkodierungsinformationen</translation>
    </message>
    <message>
        <source>Container</source>
        <translation>Container</translation>
        <extracomment>Video streaming container</extracomment>
    </message>
    <message>
        <source>Text Subtitles Only</source>
        <translation>Nur Text Untertitel</translation>
        <extracomment>Name of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in TV Libraries.</source>
        <translation>Einstellungen für das Erscheinungsbild der Seiten in den TV-Bibliotheken.</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Extras</translation>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Abrufen von Wiedergabeinformationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>** EXPERIMENTAL** Support Direct Play of AV1 content if this Roku device supports it.</source>
        <translation>** EXPERIMENTELL** Unterstützt die direkte Wiedergabe von AV1-Inhalten, wenn dieses Roku-Gerät dies unterstützt.</translation>
        <extracomment>Description of a setting - should we try to direct play experimental av1 codec</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Benutzeroberfläche</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Als gesehen markieren</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Gehe zur Folge</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Ihr Schnellverbindungscode lautet:</translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialog schließt sich automatisch)</translation>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Einstellungen für Serien</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Go directly to the episode list if a TV series has only one season.</source>
        <translation>Gehen Sie direkt zur Episodenliste, wenn eine Fernsehserie nur eine Staffel hat.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Blur images of unwatched episodes.</source>
        <translation>Verpixeln von Bildern von nicht gesehenen Episoden.</translation>
    </message>
    <message>
        <source>Bring the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Bringen Sie das Kinoerlebnis direkt in Ihr Wohnzimmer mit der Möglichkeit, vor dem Hauptprogramm benutzerdefinierte Intros abzuspielen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hide all clocks in Jellyfin. Jellyfin will need to be closed and reopened for changes to take effect.</source>
        <translation>Alle Uhren in Jellyfin ausblenden. Jellyfin muss geschlossen und wieder geöffnet werden, damit die Änderungen wirksam werden.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Versuche Direct Play für H.264-Medien mit nicht unterstützten Profilebenen zu nutzen, bevor Sie auf die Transkodierung zurückgreifen, wenn dies fehlschlägt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>HEVC</source>
        <translation>HEVC</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Versuche Direct Play für HEVC Medien mit nicht unterstützten Profilebenen zu nutzen, bevor Sie auf die Transkodierung zurückgreifen, wenn dies fehlschlägt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Max Days Next Up</source>
        <translation>Max. Tage im &quot;Als Nächstes&quot; Bereich</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</source>
        <translation>Legen Sie die maximale Anzahl von Tagen fest, die eine Serie in der Liste &quot;Als Nächstes&quot; verbleiben soll, ohne dass sie angesehen wird.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Bit Rate</source>
        <translation>Bitrate</translation>
        <extracomment>Video streaming bit rate</extracomment>
    </message>
    <message>
        <source>Playback Information</source>
        <translation>Wiedergabeinformationen</translation>
    </message>
    <message>
        <source>Stream Information</source>
        <translation>Stream Informationen</translation>
    </message>
    <message>
        <source>Video range type</source>
        <translation>Videobereichstyp</translation>
    </message>
    <message>
        <source>Pixel format</source>
        <translation>Pixelformat</translation>
        <extracomment>Video pixel format</extracomment>
    </message>
    <message>
        <source>Unable to find any albums or songs belonging to this artist</source>
        <translation>Es konnten keine Alben oder Songs dieses Künstlers gefunden werden</translation>
        <extracomment>Popup message when we find no audio data for an artist</extracomment>
    </message>
    <message>
        <source>Only display text subtitles to minimize transcoding.</source>
        <translation>Nur Textuntertitel anzeigen, um die Transkodierung zu minimieren.</translation>
        <extracomment>Description of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>WxH</source>
        <translation>Breite x Höhe</translation>
        <extracomment>Video width x height</extracomment>
    </message>
    <message>
        <source>all</source>
        <translation>Alle</translation>
        <extracomment>all will reset the searchTerm so all data will be availible</extracomment>
    </message>
    <message>
        <source>Aired</source>
        <translation>Ausgestrahlt</translation>
        <extracomment>Aired date label</extracomment>
    </message>
    <message>
        <source>Slideshow On</source>
        <translation>Diashow an</translation>
    </message>
    <message>
        <source>MPEG-4 Support</source>
        <translation>MPEG-4 Unterstützung</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Parental Ratings</source>
        <translation>Elterliche Bewertung</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Years</source>
        <translation>Jahre</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Show What&apos;s New Popup</source>
        <translation>Popup-Fenster mit Neuigkeiten anzeigen</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Show What&apos;s New popup when Jellyfin is updated to a new version.</source>
        <translation>Popup-Fenster mit Neuigkeiten anzeigen wenn Jellyfin auf eine neue Version aktualisiert wurde.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Resumable</source>
        <translation>Fortsetzbar</translation>
    </message>
    <message>
        <source>Movie Library Default View</source>
        <translation>Standardansicht der Filmbibliothek</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Default view for Movie Libraries.</source>
        <translation>Standardansicht für Filmbibliotheken.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Select when to show titles.</source>
        <translation>Auswählen wann Titel angezeigt werden sollen</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Show On Hover</source>
        <translation>Anzeigen beim Hovern</translation>
    </message>
    <message>
        <source>Always Hide</source>
        <translation>Niemals anzeigen</translation>
    </message>
    <message>
        <source>View All</source>
        <translation>Alle anzeigen</translation>
    </message>
    <message>
        <source>Hide the star and community rating for episodes of a TV show. This is to prevent spoilers of an upcoming good/bad episode.</source>
        <translation>Blenden Sie die Sterne- und Community-Bewertung für Episoden einer Fernsehsendung aus. Dies dient dazu, Spoiler über eine bevorstehende gute/schlechte Episode zu verhindern.</translation>
    </message>
    <message>
        <source>Enable Limit</source>
        <translation>Limit aktivieren</translation>
    </message>
    <message>
        <source>Maximum Bitrate</source>
        <translation>Maximale Bitrate</translation>
    </message>
    <message>
        <source>Grid View Settings</source>
        <translation>Einstellungen der Rasteransicht</translation>
    </message>
    <message>
        <source>Disable Unwatched Episode Count</source>
        <translation>Deaktivierung der Anzahl ungesehener Episoden</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Artists (Presentation)</source>
        <translation>Künstler (Vorstellung)</translation>
    </message>
    <message>
        <source>Song</source>
        <translation>Lied</translation>
    </message>
    <message>
        <source>Songs</source>
        <translation>Lieder</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie aufnehmen</translation>
    </message>
    <message>
        <source>Codec Support</source>
        <translation>Codec Unterstützung</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Medienraster-Optionen.</translation>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Anzahl der Objekte</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Designelemente</translation>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation>Einstellungen, die das Aussehen der Anwendung betreffen.</translation>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation>Einstellungen für die Wiedergabe und unterstützte Codec- und Medientypen.</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Grund</translation>
    </message>
    <message>
        <source>Total Bitrate</source>
        <translation>Gesamte Bitrate</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Größe</translation>
        <extracomment>Video size</extracomment>
    </message>
    <message>
        <source>Random Off</source>
        <translation>Zufällig aus</translation>
    </message>
    <message>
        <source>Random On</source>
        <translation>Zufällig an</translation>
    </message>
    <message>
        <source>Unplayed</source>
        <translation>Nicht abgespielt</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serienaufnahme abbrechen</translation>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Dateinamen</translation>
        <extracomment>Title of a setting - when should we show the title text of a grid item</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbinde zu Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Geben Sie den Servernamen oder die IP-Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Level</source>
        <translation>Level</translation>
        <extracomment>Video profile level</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deaktiviert</translation>
    </message>
    <message>
        <source>Select when to show titles.</source>
        <translation>Auswählen, wann Titel angezeigt werden sollen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Startbildschirm als Hintergrund verwenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Fehler beim Laden der Daten vom Server.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Bei der Wiedergabe trat ein Fehler auf.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Container</source>
        <translation>Container</translation>
        <extracomment>Video streaming container</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Einstellungen für Serien.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Bei der Wiedergabe trat ein Fehler auf.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Ausloggen</translation>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler während des abspielens</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Fehler beim Laden dieses Eintrags vom Server.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeicherte löschen</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Anmeldedaten speichern?</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim empfangen des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler während der Wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Geboren am</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Bei der Wiedergabe dieses Eintrags ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanaldaten konnten nicht vom Server geladen werden</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 enthält keine Einträge</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortierung</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerbewertung</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Gestorben am</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb-Bewertung</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abspieldatum</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Empfangen des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>Jetzt läuft</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabezähler</translation>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Ähnliches</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Besetzung &amp; Mitwirkende</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Klicke &apos;OK&apos; zum Schließen</translation>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie aufnehmen</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serienaufnahme abbrechen</translation>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbinde zum Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>Always Hide</source>
        <translation>Immer verstecken</translation>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Played</source>
        <translation>Abgespielt</translation>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Unable to find any albums or songs belonging to this artist</source>
        <translation>Es konnten keine Alben oder Songs von diesem Künstler gefunden werden.</translation>
        <extracomment>Popup message when we find no audio data for an artist</extracomment>
    </message>
    <message>
        <source>WxH</source>
        <translation>BxH</translation>
        <extracomment>Video width x height</extracomment>
    </message>
    <message>
        <source>all</source>
        <translation>Alle</translation>
        <extracomment>all will reset the searchTerm so all data will be availible</extracomment>
    </message>
    <message>
        <source>Aired</source>
        <translation>Gesendet</translation>
        <extracomment>Aired date label</extracomment>
    </message>
    <message>
        <source>Artists (Presentation)</source>
        <translation>Künstler (Präsentation)</translation>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Size</source>
        <translation>Größe</translation>
        <extracomment>Video size</extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Pixel format</source>
        <translation>Pixelformat</translation>
        <extracomment>Video pixel format</extracomment>
    </message>
    <message>
        <source>Years</source>
        <translation>Jahre</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Select when to show titles.</source>
        <translation>Auswählen, wann Titel angezeigt werden sollen</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Movies (Presentation)</source>
        <translation>Filme (Präsentation)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Gestartet um</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation>Filme (Raster)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Bei der Wiedergabe dieses Elements ist ein Fehler aufgetreten. Der Server hat die erforderlichen Transcodierungsdaten nicht bereitgestellt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Unterstützung der direkten Wiedergabe von MPEG-2-Inhalten (z. B. Live-TV). Dies verhindert die Transkodierung von MPEG-2-Inhalten, verbraucht aber deutlich mehr Bandbreite</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>MPEG-2</source>
        <translation>MPEG-2</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>MPEG-4</source>
        <translation>MPEG-4</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Wiedergabe</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Extras</translation>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Abrufen der Wiedergabeinformationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Zusätzliche Inhalte</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Gestartet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Sender</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Sender ansehen</translation>
    </message>
    <message>
        <source>Codec Support</source>
        <translation>Codec Unterstützung</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Geben Sie den Servernamen oder die IP-Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der angeforderte Inhalt existiert nicht auf dem Server</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wählen Sie einen verfügbaren Jellyfin-Server in Ihrem lokalen Netzwerk aus:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>Fügen Sie bitte die Server-URL manuell ein, falls kein Server vorhanden ist:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Enable or disable Direct Play for optional codecs</source>
        <translation>Aktivieren oder Deaktivieren von Direct Play für optionale Codecs</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler während der Wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Fehler beim Laden dieses Eintrags vom Server.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>Jetzt läuft</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Bei der Wiedergabe dieses Eintrags ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanaldaten konnten nicht vom Server geladen werden</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeicherte löschen</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 enthält keine Einträge</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Anmeldedaten speichern?</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerbewertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb-Bewertung</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abspieldatum</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Empfangen des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>Jetzt läuft</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Empfangen des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler während der wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeicherte löschen</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Zugangsdaten Speichern?</translation>
    </message>
    <message>
        <source>Search now</source>
        <translation>Suche jetzt</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation type="unfinished">Schnell verbinden</translation>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Setze auf angesehen</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Gehe zur Episode</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation type="unfinished">Hier ist dein Schnellverbindungs Code:</translation>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Medien Gitter Optionen</translation>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Stückzahl</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Zeige die Gegenstandsanzahl in der Bibliothek und den Index von dem ausgewählten Gegenstand</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Setze Favoriten</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Gehe zu den Serien</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Gehe zur Saison</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>Sie können nach Titeln, Personen, Fernseher Kanälen und mehr suchen</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 von %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>Movies (Presentation)</source>
        <translation>Filme (Präsentation)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Sonnabend</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Geburtsdatum</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Lade Kanaldaten</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation>Filme (Gitter)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Bei der Wiedergabe trat ein Fehler auf.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Konnte die Kanaldaten nicht vom Server laden</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Empfehlungen</translation>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Enable or disable Direct Play for optional codecs</source>
        <translation>Direkte Wiedergabe für optionale Codecs aktivieren oder deaktivieren</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Diese(r) %1 enthält keine Elemente</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>MPEG-2</source>
        <translation>MPEG-2</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>MPEG-4</source>
        <translation>MPEG-4</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Während der Übertragung vom Server trat ein Fehler auf.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Special Features</translation>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Gestartet um</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet am</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Playback</source>
        <translation>Wiedergabe</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>AV1</source>
        <translation>AV1</translation>
        <extracomment>Name of a setting - should we try to direct play experimental av1 codec</extracomment>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktiviert</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Übertragen der Wiedergabeinformationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Benutzeroberfläche</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Died</source>
        <translation>Sterbedatum</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Mitwirkende</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>&apos;OK&apos; drücken zum Schließen</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Weitere Teile</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Gestartet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal ansehen</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie aufnehmen</translation>
    </message>
    <message>
        <source>Codec Support</source>
        <translation>Codec-Support</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serienaufnahme abbrechen</translation>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>Wenn kein Server angeführt wird, kann die Serveradresse auch manuell angegeben werden:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Bei der Wiedergabe trat ein Fehler auf. Der Server hat die benötigten Transcodinginformationen nicht übermittelt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Direkte Wiedergabe von MPEG-2 Inhalten unterstützen (z.B. Live-TV). Dies verhindert Transcoding von MPEG-2 Inhalten, benötigt aber erheblich mehr Bandbreite.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>** EXPERIMENTAL** Support Direct Play of AV1 content if this Roku device supports it.</source>
        <translation>** EXPERIMENTELL ** Direkte Wiedergabe von AV1 Inhalten wenn dieses Roku-Gerät es unterstützt.</translation>
        <extracomment>Description of a setting - should we try to direct play experimental av1 codec</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV-Serien</translation>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbinde mit Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Hostnamen oder IP-Adresse des Servers angeben</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deaktiviert</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der gewünschte  Inhalt existiert nicht auf dem Server</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Einen Jellyfin-Server im lokalen Netzwerk auswählen:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</source>
        <translation>Direkte Wiedergabe von MPEG-4 Inhalten unterstützen. Dies muss unter Umständen für die Wiedergabe von DIVX-kodierten Dateien deaktiviert werden.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Mediengitter</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Sprachfernbedienung zum Suchen verwenden</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerbewertung</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb-Bewertung</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabezähler</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abspieldatum</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Netzwerke</translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialog wird automatisch geschlossen)</translation>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Schlagwörter auf der Detailansicht verbergen.</translation>
    </message>
    <message>
        <source>Next episode</source>
        <translation>Nächste Episode</translation>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Schlagwörter verbergen</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Kinomodus</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Trailer abspielen</translation>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Schnellverbindung</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Shows</source>
        <translation>Sendungen</translation>
    </message>
    <message>
        <source>Options that alter the design of Jellyfin.</source>
        <translation>Optionen die das Aussehen von Jellyfin ändern.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Uhr verstecken</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>H.264</source>
        <translation>H.264</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Optionen für Fernsehsendungen.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>HEVC</source>
        <translation>HEVC</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Designelemente</translation>
    </message>
    <message>
        <source>Go directly to the episode list if a TV series has only one season.</source>
        <translation>Direkt zur Episodenliste springen, wenn die Sendung nur eine Staffel hat.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Splashscreen als Starthintergrund verwenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>Es gab einen Fehler beim Authentifizieren mittels Schnellverbindung.</translation>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Zum Anfang springen</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Nutze den Wiedergabe-Button um das erste Objekt im Ordner langsam wiederzugeben. (Ist diese Option deaktiviert, wird der Ordner sofort zum ersten Objekt zurückspringen).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Nicht-Gesehene Episoden ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Skip Details for Single Seasons</source>
        <translation>Details für einzelne Staffel überspringen</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Blur images of unwatched episodes.</source>
        <translation>Bilder von ungesehenen Episoden ausblenden.</translation>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s home background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Generiertes Splashscreen-Bild als Jellyfins Starthintergrund verwenden. Jellyfin muss geschlossen und neu geöffnet werden, damit die Änderungen übernommen werden.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Bring the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Bringe das Kinoerlebnis direkt in dein Wohnzimmer, indem du benutzerdefinierte Intros vor dem Hauptfilm abspielst.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hide all clocks in Jellyfin. Jellyfin will need to be closed and reopened for changes to take effect.</source>
        <translation>Sämtliche Uhren in Jellyfin ausblenden. Jellyfin muss geschlossen und neu geöffnet werden, damit die Änderungen übernommen werden.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Das wiedergeben von H.264-Medien mit nicht unterstützten Profilebenen per Direct Play versuchen, bevor auf die Transkodierung zurückgegriffen wird, falls dies fehlschlägt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Das wiedergeben von HEVC-Medien mit nicht unterstützten Profilebenen versuchen, bevor auf die Transkodierung zurückgegriffen wird, falls dies fehlschlägt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Medienübersicht</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Als angesehen markieren</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Gehe zu Folge</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Medienübersichtoptionen</translation>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Anzahl Elemente</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Zeige die Anzahl der Elemente in der Bibliothek und den Index des ausgewählten Gegenstands.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>Du kannst nach Titeln, Personen, Fernsehsendern und mehr suchen</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Gehe zu Staffel</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Als Favorit markieren</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Settings that apply when Grid views are enabled.</source>
        <translation>Einstellungen für Rasteransichten.</translation>
    </message>
    <message>
        <source>Bitrate Limit</source>
        <translation>Bitraten-Grenze</translation>
    </message>
    <message>
        <source>Global</source>
        <translation>Global</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Remember Me?</source>
        <translation>Angemeldet bleiben?</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Grid</source>
        <translation>Raster</translation>
        <extracomment>Title of an option - name of grid view</extracomment>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Schlagwörter in der Detailansicht verbergen.</translation>
    </message>
    <message>
        <source>Custom Subtitles</source>
        <translation>Benutzerdefinierte Untertitel</translation>
        <extracomment>Name of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Slideshow Paused</source>
        <translation>Slideshow pausiert</translation>
    </message>
    <message>
        <source>Always Show</source>
        <translation>Immer anzeigen</translation>
    </message>
    <message>
        <source>Albums</source>
        <translation>Alben</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <source>Disable Community Rating for Episodes</source>
        <translation>Deaktiviere Community-Bewertungen für Folgen</translation>
    </message>
    <message>
        <source>Configure the maximum playback bitrate.</source>
        <translation>Konfigurier die maximale Wiedergabe-Bitrate.</translation>
    </message>
    <message>
        <source>Libraries</source>
        <translation>Bibliotheken</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of Library pages</source>
        <translation>Einstellungen die das Aussehen von Bibliotheksseiten beeinflussen</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in Movie Libraries.</source>
        <translation>Einstellungen die das Aussehen von Seiten in Filmbibliotheken beeinflussen.</translation>
    </message>
    <message>
        <source>Loading trailer</source>
        <translation>Lade Trailer</translation>
        <extracomment>Dialog title in Main.brs</extracomment>
    </message>
    <message>
        <source>Enable or disable the &apos;Maximum Bitrate&apos; setting.</source>
        <translation>Aktivier oder Deaktivier die &quot;Maximale Bitrate&quot;-Einstellung.</translation>
    </message>
    <message>
        <source>Pixel format</source>
        <translation>Pixelformat</translation>
        <extracomment>Video pixel format</extracomment>
    </message>
    <message>
        <source>Years</source>
        <translation>Jahre</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Choose your preferred audio codec when transcoding multichannel audio.</source>
        <translation>Wähl deinen bevorzugten Audiocodec wenn Mehrkanalaudio transkodiert wird.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Audio Codec Support</source>
        <translation>Audiocodec-Unterstützung</translation>
        <extracomment>Settings Menu - Title of option</extracomment>
    </message>
    <message>
        <source>Maximum Resolution</source>
        <translation>Maximale Auflösung</translation>
        <extracomment>User Setting - Title</extracomment>
    </message>
    <message>
        <source>Set the maximum resolution when playing video files on this device.</source>
        <translation>Bestimme die maximale Auflösung für die Videowiedergabe auf diesem Gerät.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>Off - Attempt to play all resolutions</source>
        <translation>Aus - Versuche alle Auflösungen wiederzugeben</translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Auto - Use TV resolution</source>
        <translation>Automatisch - Verwende TV-Auflösung</translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Mode</source>
        <translation>Modus</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Value</source>
        <translation>Wert</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Configure the maximum resolution when playing video files on this device.</source>
        <translation>Konfigurier die maximale Auflösung für die Videowiedergabe auf diesem Gerät.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>Apply max resolution to all files or only transcoded files.</source>
        <translation>Wende maximale Auflösung auf alle oder nur transkodierte Dateien an.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>All files</source>
        <translation>Alle Dateien</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Only transcoded files</source>
        <translation>Nur transkodierte Dateien</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Compatibility</source>
        <translation>Kompatibilität</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Attempt to prevent playback failures.</source>
        <translation>Versuche Wiedergabefehler zu verhindern.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Disable HEVC</source>
        <translation>HEVC deaktivieren</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Next episode</source>
        <translation>Nächste Folge</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Allgemein</translation>
    </message>
    <message>
        <source>Video Codec</source>
        <translation>Video-Codec</translation>
    </message>
    <message>
        <source>Audio Codec</source>
        <translation>Audio-Codec</translation>
    </message>
    <message>
        <source>direct</source>
        <translation>direkt</translation>
    </message>
    <message>
        <source>Audio Channels</source>
        <translation>Audiokanäle</translation>
    </message>
    <message>
        <source>Codec Tag</source>
        <translation>Codec-Schlagwort</translation>
    </message>
    <message>
        <source>Artists (Grid)</source>
        <translation>Künstler:innen (Raster)</translation>
    </message>
    <message>
        <source>Slideshow Off</source>
        <translation>Slideshow aus</translation>
    </message>
    <message>
        <source>Played</source>
        <translation>Abgespielt</translation>
    </message>
    <message>
        <source>Always Hide</source>
        <translation>Immer verbergen</translation>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Quick Connect</translation>
    </message>
    <message>
        <source>Shows</source>
        <translation>Serien</translation>
    </message>
    <message>
        <source>Transcoding Information</source>
        <translation>Transcoding-Informationen</translation>
    </message>
    <message>
        <source>Container</source>
        <translation>Container</translation>
        <extracomment>Video streaming container</extracomment>
    </message>
    <message>
        <source>Text Subtitles Only</source>
        <translation>Nur Text-Untertitel</translation>
        <extracomment>Name of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in TV Libraries.</source>
        <translation>Einstellungen die das Aussehen der Seiten in TV-Bibliotheken beeinflussen.</translation>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Hier ist dein Quick Connect-Code:</translation>
    </message>
    <message>
        <source>Playback Information</source>
        <translation>Wiedergabeinformationen</translation>
    </message>
    <message>
        <source>Stream Information</source>
        <translation>Stream-Informationen</translation>
    </message>
    <message>
        <source>Bit Rate</source>
        <translation>Bitrate</translation>
        <extracomment>Video streaming bit rate</extracomment>
    </message>
    <message>
        <source>Video range type</source>
        <translation>Videobereichstyp</translation>
    </message>
    <message>
        <source>Unable to find any albums or songs belonging to this artist</source>
        <translation>Es wurden keine Alben oder Lieder dieser Künstler:in gefunden</translation>
        <extracomment>Popup message when we find no audio data for an artist</extracomment>
    </message>
    <message>
        <source>WxH</source>
        <translation>Breite und Höhe</translation>
        <extracomment>Video width x height</extracomment>
    </message>
    <message>
        <source>all</source>
        <translation>alle</translation>
        <extracomment>all will reset the searchTerm so all data will be availible</extracomment>
    </message>
    <message>
        <source>Aired</source>
        <translation>Veröffentlicht</translation>
        <extracomment>Aired date label</extracomment>
    </message>
    <message>
        <source>Slideshow On</source>
        <translation>Slideshow ein</translation>
    </message>
    <message>
        <source>MPEG-4 Support</source>
        <translation>MPEG-4 Unterstützung</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Parental Ratings</source>
        <translation>Altersfreigabe</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Resumable</source>
        <translation>fortsetzbar</translation>
    </message>
    <message>
        <source>Default view for Movie Libraries.</source>
        <translation>Standardansicht für  Filmbibliotheken.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Show On Hover</source>
        <translation>Anzeigen wenn ausgewählt</translation>
    </message>
    <message>
        <source>Enable Limit</source>
        <translation>Begrenzung aktivieren</translation>
    </message>
    <message>
        <source>Maximum Bitrate</source>
        <translation>Maximale Bitrate</translation>
    </message>
    <message>
        <source>Grid View Settings</source>
        <translation>Einstellungen für die Rasteransicht</translation>
    </message>
    <message>
        <source>Disable Unwatched Episode Count</source>
        <translation>Deaktiviere ungeguckte Folgenanzahl</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Artists (Presentation)</source>
        <translation>Künstler:innen (Präsentation)</translation>
    </message>
    <message>
        <source>Song</source>
        <translation>Lied</translation>
    </message>
    <message>
        <source>Songs</source>
        <translation>Lieder</translation>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation>Einstellungen für die Wiedergabe und unterstützte Codecs und Medientypen.</translation>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation>Einstellungen die das Aussehen der Anwendung betreffen.</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Grund</translation>
    </message>
    <message>
        <source>Total Bitrate</source>
        <translation>Bitrate gesamt</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Größe</translation>
        <extracomment>Video size</extracomment>
    </message>
    <message>
        <source>Random On</source>
        <translation>Zufall ein</translation>
    </message>
    <message>
        <source>Unplayed</source>
        <translation>Noch nicht abgespielt</translation>
    </message>
    <message>
        <source>Go directly to the episode list if a TV series has only one season.</source>
        <translation>Direkt zur Episodenliste springen, wenn die Serie nur eine Staffel hat.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Blur images of unwatched episodes.</source>
        <translation>Bilder von noch nicht gesehenen Episoden zensieren.</translation>
    </message>
    <message>
        <source>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Direct Play für H.264-Medien mit nicht unterstützten Profilebenen versuchen, bevor auf die Transkodierung zurückgegriffen wird, falls dies fehlschlägt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Nutze den Wiedergabe-Button um langsam zum ersten Element im Ordner zu wechseln. (Ist diese Option deaktiviert, wird der Ordner sofort zum ersten Objekt zurückspringen).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Noch nicht gesehene Episoden zensieren</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Direct Play von HEVC-Medien mit nicht unterstützten Profilebenen versuchen, bevor auf die Transkodierung zurückgegriffen wird, falls dies fehlschlägt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</source>
        <translation>Definiere die maximale Anzahl Tage die eine Serie in &quot;Als nächstes&quot; angezeigt wird ohne sie anzusehen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Only display text subtitles to minimize transcoding.</source>
        <translation>Stelle nur Text-Untertitel dar um Transcoding zu minimieren</translation>
        <extracomment>Description of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>Slideshow Resumed</source>
        <translation>Slideshow wieder gestartet</translation>
    </message>
    <message>
        <source>Random Off</source>
        <translation>Zufall aus</translation>
    </message>
    <message>
        <source>Show What&apos;s New popup when Jellyfin is updated to a new version.</source>
        <translation>Zeige &quot;Als nächstes&quot; Popup nachdem Jellyfin auf eine neue Version aktualisiert wurde.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Select when to show titles.</source>
        <translation>Auswählen wann Titel angezeigt werden.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hide the star and community rating for episodes of a TV show. This is to prevent spoilers of an upcoming good/bad episode.</source>
        <translation>Verberge die Sterne und Community-Bewertungen für Folgen einer TV-Serie. Dies soll Spoiler einer kommenden guten/schlechten Folge verhindern.</translation>
    </message>
    <message>
        <source>If enabled, the number of unwatched episodes in a series/season will be removed.</source>
        <translation>Die Anzahl der ungeguckten Folgen einer Serie-Staffel wird ausgeblendet, wenn diese Einstellung aktiviert ist.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Force all transcodes to use DTS instead of the default EAC3. The device must support DTS for this setting to have an effect.</source>
        <translation>Erzwinge DTS für alle Transkodierungen anstelle des Standards EAC3. Das Gerät muss DTS unterstützen damit diese Einstellung funktioniert.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Disable the HEVC codec on this device. This may improve playback for some devices (ultra).</source>
        <translation>Deaktiviere den HEVC-Codec auf diesem Gerät. Dies kann die Wiedergabe auf einigen Geräten verbessern (ultra).</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Global settings that affect everyone that uses this Roku device.</source>
        <translation>Globale Einstellungen die alle Nutzer dieses Roku-Geräts betreffen.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Remember the currently logged in user and try to log them in again next time you start the Jellyfin app.</source>
        <translation>Anmeldung des aktuellen Nutzers erhalten und beim nächsten Start der Jellyfin-App automatisch anmelden.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Elementtitel</translation>
        <extracomment>Title of a setting - when should we show the title text of a grid item</extracomment>
    </message>
    <message>
        <source>Level</source>
        <translation>Level</translation>
        <extracomment>Video profile level</extracomment>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>Es gab einen Fehler bei der Authentifizierung über Quick Connect.</translation>
    </message>
    <message>
        <source>Max Days Next Up</source>
        <translation>Tage in &quot;Als nächstes&quot;</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Replace Roku&apos;s default subtitle functions with custom functions that support CJK fonts. Fallback fonts must be configured and enabled on the server for CJK rendering to work.</source>
        <translation>Ersetze Rokus Standard-Untertitelfunktion mit speziellen Funktionen die CJK-Fonts unterstützen. Ersatzfonts müssen auf den Server konfiguriert und aktiviert sein, damit CJK dargestellt werden kann.</translation>
        <extracomment>Description of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Show What&apos;s New Popup</source>
        <translation>Zeige &quot;Als nächstes&quot; Popup</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Movie Library Default View</source>
        <translation>Standardansicht der Filmbibliothek</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>The source file is entirely compatible with this client and the session is receiving the file without modifications.</source>
        <translation>Die Quellendatei ist vollständig kompatibel mit diesem Gerät und erhält die Datei unverändert.</translation>
        <extracomment>Direct play info box text in GetPlaybackInfoTask.brs</extracomment>
    </message>
    <message>
        <source>Album Artists (Presentation)</source>
        <translation>Album-Künstler:innen (Präsentation)</translation>
    </message>
    <message>
        <source>Album Artists (Grid)</source>
        <translation>Albumkünstler:innen (Raster)</translation>
    </message>
    <message>
        <source>View All</source>
        <translation>Alle anzeigen</translation>
    </message>
    <message>
        <source>Biographical information for this person is not currently available.</source>
        <translation>Biographische Informationen für diese Person sind aktuell nicht verfügbar.</translation>
    </message>
    <message>
        <source>Set the maximum bitrate in Mbps. Set to 0 to use Roku&apos;s specifications. This setting must be enabled to take effect.</source>
        <translation>Setz die maximale Bitrate in Mpbs. Verwende 0 um Rokus Standard zu verwenden. Diese Einstellung muss aktiviert werden um Auswirkungen zu haben.</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of the Home screen and the program in general.</source>
        <translation>Einstellungen die das Aussehen des Startbildschirms und der Anwendung allgemein beeinflussen.</translation>
    </message>
    <message>
        <source>Presentation</source>
        <translation>Präsentation</translation>
        <extracomment>Title of an option - name of presentation view</extracomment>
    </message>
    <message>
        <source>Next Episode Button Time</source>
        <translation>Zeit für &quot;Nächste Folge&quot;-Button</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</source>
        <translation>Wie viele Sekunden vor Ende einer Episode der &quot;Nächste Folge&quot;-Button angezeigt werden soll. Auf 0 setzen zum deaktivieren.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Direct playing</source>
        <translation>Direkte Wiedergabe</translation>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Schnellverbindung</translation>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Medienübersichtsoptionen</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Sonderfunktionen</translation>
    </message>
    <message>
        <source>Default view for Movie Libraries.</source>
        <translation>Standardansicht für Filmbibliotheken.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der gewünschte Inhalt existiert nicht auf dem Server</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Zugangsdaten Speichern?</translation>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation type="unfinished">Fehler während dem Playback</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeicherte Löschen</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Empfang der Inhalte</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>H.264</source>
        <translation type="unfinished">H.264</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Versuchen Sie, HEVC-Medien mit nicht unterstützten Profilebenen direkt wiederzugeben, bevor Sie auf die Transkodierung zurückgreifen, wenn diese fehlschlägt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Servern ändern</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>Jetzt aktiv</translation>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler bei der Wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Wiedergabezeit</translation>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Kinomodus</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Trailer abspielen</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeichertes löschen</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Berechtigungen speichern?</translation>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Uhrzeit verstecken</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichsdatum</translation>
    </message>
    <message>
        <source>HEVC</source>
        <translation>HEVC</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritiker:innen Bewertung</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Jugendschutz-Bewertung</translation>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es ist ein Fehler beim Abrufen der Daten für dieses Element vom Server aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Beim Abspielen dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Laden von Kanaldaten</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanaldaten können nicht vom Server geladen werden</translation>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s home background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Benutz das generierte Splashscreen-Bild als Jellyfin&apos;s Home-Hintergrundbild. Jellyfin muss geschlossen und erneut geöffnet werden, damit die Änderung wirksam wird.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Bring the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Bringen Sie das Kinoerlebnis direkt in Ihr Wohnzimmer, indem Sie benutzerdefinierte Intros vor dem Hauptfilm abspielen lassen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Next episode</source>
        <translation>Nächste Episode</translation>
    </message>
    <message>
        <source>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Versucht H.264-Medien mit nicht unterstützten Profilebenen direkt wiederzugeben, bevor es auf die Transkodierung zurückgreifen, wenn dies fehlschlägt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hide all clocks in Jellyfin. Jellyfin will need to be closed and reopened for changes to take effect.</source>
        <translation>Alle Uhren in Jellyfin ausblenden. Jellyfin muss geschlossen und wieder geöffnet werden, damit die Änderungen wirksam werden.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertungen</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabezähler</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abspieldatum</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation type="unfinished">Hinzufügedatum</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Anmeldedaten speichern?</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>Gerade läuft</translation>
    </message>
    <message>
        <source>Episodes</source>
        <translation>Folgen</translation>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Wiedergabefehler</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Extras</source>
        <translation>Extras</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Diese(r) %1 enthält keine Elemente</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortierung</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Empfehlungen</translation>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation>Filme (Kachelansicht)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeichertes löschen</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Mitwirkende</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>&apos;OK&apos; drücken zum Schließen</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Zusätzliche Teile</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Died</source>
        <translation>Sterbedatum</translation>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal ansehen</translation>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet am</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Besonderheiten</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Jugendschutz-Bewertung</translation>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es ist ein Fehler beim Abrufen der Daten für dieses Element vom Server aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Beim Abspielen dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Laden von Kanaldaten</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanaldaten können nicht vom Server geladen werden</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Geburtsdatum</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertungen</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Wiedergabezähler</translation>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV-Serien</translation>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Abspieldatum</translation>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzufügedatum</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen des Inhalts vom Server</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Extras</source>
        <translation>Extras</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Ausloggen</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Anmeldedaten speichern?</translation>
    </message>
    <message>
        <source>Episodes</source>
        <translation>Episoden</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Diese(r) %1 enthält keine Elemente</translation>
    </message>
    <message>
        <source>Extras</source>
        <translation>Extras</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Ausloggen</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Anmeldeinformationen speichern?</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>Gerade läuft</translation>
    </message>
    <message>
        <source>Episodes</source>
        <translation>Episoden</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Spieldauer</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Empfehlungen</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Gestorben am</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim laden von Kanaldaten</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeicherte löschen</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filtern</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Wiedergabefehler</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritiker:innen Bewertung</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Mitwirkende</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>&apos;OK&apos; drücken zum Schließen</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Jugendfreigabe</translation>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es gab einen Fehler beim Laden dieses Inhalts von dem Server.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Ein Fehler bei der Wiedergabe dieses Inhalts ist aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Laden von Kanaldaten</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanaldaten vom Server nicht möglich</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Geburtsdatum</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Anzahl der Wiedergaben</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Wiedergegeben am</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Laden</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Gestartet um</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation>Filme (Kachelansicht)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Zusätzliche Teile</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Gestartet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Besonderheiten</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Movies (Presentation)</source>
        <translation>Filme (Präsentation)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV-Serien</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endete am</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serienaufnahme abbrechen</translation>
    </message>
    <message>
        <source>MPEG-2</source>
        <translation>MPEG-2</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Playback</source>
        <translation>Wiedergabe</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie aufnehmen</translation>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Einen Jellyfin-Server im lokalen Netzwerk auswählen:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Übertragen der Wiedergabeinformationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal ansehen</translation>
    </message>
    <message>
        <source>Codec Support</source>
        <translation>Codec-Support</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>Wenn kein Server angeführt wird, kann die Serveradresse auch manuell angegeben werden:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Bei der Wiedergabe trat ein Fehler auf. Der Server hat die benötigten Transcodinginformationen nicht übermittelt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Enable or disable Direct Play for optional codecs</source>
        <translation>Direkte Wiedergabe für optionale Codecs aktivieren oder deaktivieren</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbinde mit Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Hostnamen oder IP-Adresse des Servers angeben</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der gewünschte Inhalt existiert nicht auf dem Server</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Unterstützung für das direkte Abspielen von MPEG-2-Inhalten (z.B. Live-TV). Dadurch wird das Transcodieren von MPEG-2-Inhalten vermieden, es wird jedoch erheblich mehr Bandbreite verwendet.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>MPEG-4</source>
        <translation>MPEG-4</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</source>
        <translation>Unterstützung für das direkte Abspielen von MPEG-4-Inhalten. Dies muss möglicherweise deaktiviert werden, um DIVX-codierte Videodateien abzuspielen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Benutzeroberfläche</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Gesehen setzen</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Sprachfernbedienung zur Suche verwenden</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>Search now</source>
        <translation>Jetzt suchen</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 von %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>Networks</source>
        <translation>Netzwerke</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Slogans ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Blendet Slogan-Text auf Detailseiten aus.</translation>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Mediengitter</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Shows</source>
        <translation>Sendungen</translation>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s home background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Verwende das generierte Splashscreen-Bild als Hintergrund für die Startseite von Jellyfin. Jellyfin muss geschlossen und erneut geöffnet werden, damit die Änderung wirksam wird.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Reason</source>
        <translation>Grund</translation>
    </message>
    <message>
        <source>Video Codec</source>
        <translation>Video-Codec</translation>
    </message>
    <message>
        <source>direct</source>
        <translation>direkt</translation>
    </message>
    <message>
        <source>Bring the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Holen Sie sich das Theatererlebnis direkt ins Wohnzimmer mit der Möglichkeit, individuelle Einleitungen vor dem Hauptfilm abzuspielen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Aired</source>
        <translation>Ausgestrahlt</translation>
        <extracomment>Aired date label</extracomment>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Kinomodus</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Trailer abspielen</translation>
    </message>
    <message>
        <source>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Versuche, Direct Play für H.264-Medien mit nicht unterstützten Profilleveln zu nutzen, bevor auf Transkodierung zurückgegriffen wird, falls dies fehlschlägt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Versuche, Direct Play für HEVC-Medien mit nicht unterstützten Profilleveln zu nutzen, bevor auf Transkodierung zurückgegriffen wird, falls dies fehlschlägt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Audio Codec</source>
        <translation>Audio-Code</translation>
    </message>
    <message>
        <source>Total Bitrate</source>
        <translation>Gesamtbitrate</translation>
    </message>
    <message>
        <source>Audio Channels</source>
        <translation>Audiokanäle</translation>
    </message>
    <message>
        <source>WxH</source>
        <translation>Breite mal Höhe</translation>
        <extracomment>Video width x height</extracomment>
    </message>
    <message>
        <source>Unable to find any albums or songs belonging to this artist</source>
        <translation>Es konnten keine Alben oder Lieder dieses Künstlers gefunden werden.</translation>
        <extracomment>Popup message when we find no audio data for an artist</extracomment>
    </message>
    <message>
        <source>Custom Subtitles</source>
        <translation>Benutzerdefinierte Untertitel</translation>
        <extracomment>Name of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Replace Roku&apos;s default subtitle functions with custom functions that support CJK fonts. Fallback fonts must be configured and enabled on the server for CJK rendering to work.</source>
        <translation>Ersetzen Sie die standardmäßigen Untertitelfunktionen von Roku durch benutzerdefinierte Funktionen, die CJK-Schriftarten unterstützen. Ersatzschriftarten müssen auf dem Server konfiguriert und aktiviert sein, damit die CJK-Darstellung funktioniert.</translation>
        <extracomment>Description of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Slideshow Off</source>
        <translation>Diashow aus</translation>
    </message>
    <message>
        <source>Slideshow On</source>
        <translation>Diashow an</translation>
    </message>
    <message>
        <source>Slideshow Paused</source>
        <translation>Diashow pausiert</translation>
    </message>
    <message>
        <source>Parental Ratings</source>
        <translation>Altersfreigaben</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Years</source>
        <translation>Jahre</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Show What&apos;s New Popup</source>
        <translation>Zeige Popup für Neue Funktionen</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktiviert</translation>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Uhr ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Zur Folge gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Optionen für TV-Sendungen</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>HEVC</source>
        <translation>HEVC</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>H.264</source>
        <translation>H.264</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Mediengitter-Optionen</translation>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Gestaltungselemente</translation>
    </message>
    <message>
        <source>Random On</source>
        <translation>Zufall an</translation>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Zeige die Anzahl der Elemente in der Bibliothek und den Index des ausgewählten Elements.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Anzahl der Elemente</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialog wird automatisch geschlossen)</translation>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Schnellverbindung</translation>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Verwenden Sie die Wiederholungstaste, um langsam zum ersten Element im Ordner zu animieren. (Wenn deaktiviert, wird der Ordner sofort auf das erste Element zurückgesetzt).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Verwende den Splashscreen als Hintergrund für die Startseite</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Go directly to the episode list if a TV series has only one season.</source>
        <translation>Gehen Sie direkt zur Episodenliste, wenn eine TV-Serie nur eine Staffel hat.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Next episode</source>
        <translation>Nächste Episode</translation>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation>Einstellungen im Zusammenhang mit der Wiedergabe und unterstützten Codecs und Medientypen.</translation>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</source>
        <translation>Setzen Sie die maximale Anzahl von Tagen, die eine Sendung in der &apos;Als nächstes&apos; Liste bleiben soll, ohne sie anzusehen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation>Einstellungen, die sich darauf beziehen, wie die Anwendung aussieht.</translation>
    </message>
    <message>
        <source>Playback Information</source>
        <translation>Wiedergabeinformationen</translation>
    </message>
    <message>
        <source>Transcoding Information</source>
        <translation>Transkodierungsinformationen</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <source>Codec Tag</source>
        <translation>Codec-Tag</translation>
    </message>
    <message>
        <source>Bit Rate</source>
        <translation>Bitrate</translation>
        <extracomment>Video streaming bit rate</extracomment>
    </message>
    <message>
        <source>Stream Information</source>
        <translation>Stream-Informationen</translation>
    </message>
    <message>
        <source>Container</source>
        <translation>Container</translation>
        <extracomment>Video streaming container</extracomment>
    </message>
    <message>
        <source>Size</source>
        <translation>Größe</translation>
        <extracomment>Video size</extracomment>
    </message>
    <message>
        <source>Video range type</source>
        <translation>Videobereichstyp</translation>
    </message>
    <message>
        <source>Pixel format</source>
        <translation>Pixel-Forma</translation>
        <extracomment>Video pixel format</extracomment>
    </message>
    <message>
        <source>Text Subtitles Only</source>
        <translation>Nur Text-Untertitel</translation>
        <extracomment>Name of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>all</source>
        <translation>alle</translation>
        <extracomment>all will reset the searchTerm so all data will be availible</extracomment>
    </message>
    <message>
        <source>Random Off</source>
        <translation>Zufall aus</translation>
    </message>
    <message>
        <source>MPEG-4 Support</source>
        <translation>MPEG-4-Unterstützung</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Slideshow Resumed</source>
        <translation>Diashow fortgesetzt</translation>
    </message>
    <message>
        <source>Unplayed</source>
        <translation>Unabgespielt</translation>
    </message>
    <message>
        <source>Played</source>
        <translation>Abgespielt</translation>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>Sie können nach Titeln, Personen, Live-TV-Kanälen und mehr suchen.</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>Options that alter the design of Jellyfin.</source>
        <translation>Optionen, die das Design von Jellyfin verändern.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Skip Details for Single Seasons</source>
        <translation>Details für einzelne Staffeln überspringen</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Hide all clocks in Jellyfin. Jellyfin will need to be closed and reopened for changes to take effect.</source>
        <translation>Alle Uhren in Jellyfin ausblenden. Jellyfin muss geschlossen und erneut geöffnet werden, damit die Änderungen wirksam werden.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Zur Staffel gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Favorit festlegen</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Level</source>
        <translation>Niveau</translation>
        <extracomment>Video profile level</extracomment>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Hier ist Ihr Schnellverbindungscode:</translation>
    </message>
    <message>
        <source>Blur images of unwatched episodes.</source>
        <translation>Bilder von nicht angesehenen Episoden verwischen.</translation>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Unangesehene Episoden verwischen</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Only display text subtitles to minimize transcoding.</source>
        <translation>Nur Text-Untertitel anzeigen, um die Transkodierung zu minimieren.</translation>
        <extracomment>Description of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>Show What&apos;s New popup when Jellyfin is updated to a new version.</source>
        <translation>Zeige Popup für Neue Funktionen, wenn Jellyfin auf eine neue Version aktualisiert wird.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deaktiviert</translation>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Zur Serie gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>Bei der Authentifizierung über Quick Connect ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Zurück zum Anfang</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Max Days Next Up</source>
        <translation>Maximale Tage bis zum Nächsten</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Movie Library Default View</source>
        <translation>Standardansicht für Filmbibliothek</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Default view for Movie Libraries.</source>
        <translation>Standardansicht für Filmbibliotheken</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Titel der Elemente</translation>
        <extracomment>Title of a setting - when should we show the title text of a grid item</extracomment>
    </message>
    <message>
        <source>Select when to show titles.</source>
        <translation>Wählen Sie aus, wann die Titel angezeigt werden sollen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Always Show</source>
        <translation>Immer anzeigen</translation>
    </message>
    <message>
        <source>Configure the maximum playback bitrate.</source>
        <translation>Die maximale Wiedergabe-Bitrate konfigurieren.</translation>
    </message>
    <message>
        <source>Resumable</source>
        <translation>Fortsetzbar</translation>
    </message>
    <message>
        <source>Show On Hover</source>
        <translation>Bei Hover anzeigen</translation>
    </message>
    <message>
        <source>Artists (Presentation)</source>
        <translation>Künstler (Präsentation)</translation>
    </message>
    <message>
        <source>Album Artists (Presentation)</source>
        <translation>Album-Künstler (Präsentation)</translation>
    </message>
    <message>
        <source>Artists (Grid)</source>
        <translation>Künstler (Raster)</translation>
    </message>
    <message>
        <source>Song</source>
        <translation>Lied</translation>
    </message>
    <message>
        <source>Always Hide</source>
        <translation>Immer ausblenden</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <source>Albums</source>
        <translation>Alben</translation>
    </message>
    <message>
        <source>Disable Community Rating for Episodes</source>
        <translation>Gemeinschaftsbewertung für Episoden deaktivieren</translation>
    </message>
    <message>
        <source>Songs</source>
        <translation>Lieder</translation>
    </message>
    <message>
        <source>Enable Limit</source>
        <translation>Limits aktivieren</translation>
    </message>
    <message>
        <source>Enable or disable the &apos;Maximum Bitrate&apos; setting.</source>
        <translation>Maximale Bitrate&apos; Einstellung aktivieren oder deaktivieren.</translation>
    </message>
    <message>
        <source>Biographical information for this person is not currently available.</source>
        <translation>Biografische Informationen zu dieser Person stehen derzeit nicht zur Verfügung.</translation>
    </message>
    <message>
        <source>Bitrate Limit</source>
        <translation>Bitratenlimit</translation>
    </message>
    <message>
        <source>Hide the star and community rating for episodes of a TV show. This is to prevent spoilers of an upcoming good/bad episode.</source>
        <translation>Die Sterne- und Gemeinschaftsbewertung für Episoden einer TV-Serie ausblenden. Dies dient dazu, Spoiler für eine kommende gute/schlechte Episode zu vermeiden.</translation>
    </message>
    <message>
        <source>Album Artists (Grid)</source>
        <translation>Album-Künstler (Raster)</translation>
    </message>
    <message>
        <source>View All</source>
        <translation>Alle anzeigen</translation>
    </message>
    <message>
        <source>Disable HEVC</source>
        <translation>HEVC deaktivieren</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Default view for Movie Libraries.</source>
        <translation>Standardansicht für Film-Bibliotheken.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Settings relating to the appearance of Library pages</source>
        <translation>Einstellungen im Zusammenhang mit dem Erscheinungsbild der Bibliotheksseiten</translation>
    </message>
    <message>
        <source>Presentation</source>
        <translation>Präsentation</translation>
        <extracomment>Title of an option - name of presentation view</extracomment>
    </message>
    <message>
        <source>Grid</source>
        <translation>Raster</translation>
        <extracomment>Title of an option - name of grid view</extracomment>
    </message>
    <message>
        <source>If enabled, the number of unwatched episodes in a series/season will be removed.</source>
        <translation>Wenn aktiviert, wird die Anzahl der unangesehenen Episoden in einer Serie/Staffel entfernt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Choose your preferred audio codec when transcoding multichannel audio.</source>
        <translation>Wählen Sie Ihren bevorzugten Audiocodec, wenn Mehrkanal-Audio transcodiert wird.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Audio Codec Support</source>
        <translation>Unterstützung für Audiocodecs</translation>
        <extracomment>Settings Menu - Title of option</extracomment>
    </message>
    <message>
        <source>Maximum Resolution</source>
        <translation>Maximale Auflösung</translation>
        <extracomment>User Setting - Title</extracomment>
    </message>
    <message>
        <source>Only transcoded files</source>
        <translation>Nur transkodierte Dateien</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Remember the currently logged in user and try to log them in again next time you start the Jellyfin app.</source>
        <translation>Merke dir den aktuell angemeldeten Benutzer und versuche, ihn beim nächsten Start der Jellyfin-App erneut anzumelden.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s home background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Verwende das generierte Splashscreen-Bild als Hintergrund für Jellyfin&apos;s Startseite. Jellyfin muss geschlossen und erneut geöffnet werden, damit die Änderung wirksam wird.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Unable to find any albums or songs belonging to this artist</source>
        <translation>Es konnten keine Alben oder Lieder dieses Künstlers gefunden werden</translation>
        <extracomment>Popup message when we find no audio data for an artist</extracomment>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Optionen für TV-Sendungen.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>No Chapter Data Found</source>
        <translation>Keine Kapiteldaten gefunden</translation>
        <extracomment>Message shown in OSD when no chapter data is returned by the API</extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation type="unfinished">Media Grid options.</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Allgemein</translation>
    </message>
    <message>
        <source>Maximum Bitrate</source>
        <translation>Maximale Bitrate</translation>
    </message>
    <message>
        <source>Grid View Settings</source>
        <translation>Einstellungen für Rasteransicht</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of the Home screen and the program in general.</source>
        <translation>Einstellungen, die sich auf das Erscheinungsbild des Startbildschirms und des Programms im Allgemeinen beziehen.</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in TV Libraries.</source>
        <translation>Einstellungen im Zusammenhang mit dem Erscheinungsbild von Seiten in TV-Bibliotheken.</translation>
    </message>
    <message>
        <source>Settings that apply when Grid views are enabled.</source>
        <translation>Einstellungen, die gelten, wenn Rasteransichten aktiviert sind.</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in Movie Libraries.</source>
        <translation>Einstellungen im Zusammenhang mit dem Erscheinungsbild von Seiten in Film-Bibliotheken.</translation>
    </message>
    <message>
        <source>Disable Unwatched Episode Count</source>
        <translation>Unangesehene Episodenanzahl deaktivieren</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Next Episode Button Time</source>
        <translation>Zeit für die Schaltfläche &apos;Nächste Episode</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Force all transcodes to use DTS instead of the default EAC3. The device must support DTS for this setting to have an effect.</source>
        <translation>Erzwingen Sie, dass alle Transcodierungen DTS anstelle von dem Standard EAC3 verwenden. Das Gerät muss DTS unterstützen, damit diese Einstellung wirksam wird.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Set the maximum resolution when playing video files on this device.</source>
        <translation>Legen Sie die maximale Auflösung fest, wenn Videodateien auf diesem Gerät abgespielt werden.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>Auto - Use TV resolution</source>
        <translation>Auto - Verwende TV-Auflösung</translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Off - Attempt to play all resolutions</source>
        <translation>Aus - Versuche, alle Auflösungen abzuspielen</translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Value</source>
        <translation>Wert</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Mode</source>
        <translation>Modus</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Configure the maximum resolution when playing video files on this device.</source>
        <translation>Konfigurieren Sie die maximale Auflösung beim Abspielen von Videodateien auf diesem Gerät.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>Apply max resolution to all files or only transcoded files.</source>
        <translation>Wenden Sie die maximale Auflösung auf alle Dateien oder nur auf transkodierte Dateien an.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>All files</source>
        <translation>Alle Dateien</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Attempt to prevent playback failures.</source>
        <translation>Versuch, Wiedergabeausfälle zu verhindern.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Compatibility</source>
        <translation>Kompatibilität</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Global</source>
        <translation>Global</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Disable the HEVC codec on this device. This may improve playback for some devices (ultra).</source>
        <translation>Deaktivieren Sie den HEVC-Codec auf diesem Gerät. Dies kann die Wiedergabe für einige Geräte (ultra) verbessern.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Remember Me?</source>
        <translation>Angemeldet bleiben?</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Global settings that affect everyone that uses this Roku device.</source>
        <translation>Globale Einstellungen, die jeden beeinflussen, der dieses Roku-Gerät verwendet.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>Sie können nach Titeln, Personen, Live-TV-Sendern und mehr suchen</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>Libraries</source>
        <translation>Bibliotheken</translation>
    </message>
    <message>
        <source>Loading trailer</source>
        <translation>Trailer wird geladen</translation>
        <extracomment>Dialog title in Main.brs</extracomment>
    </message>
    <message>
        <source>Set the maximum bitrate in Mbps. Set to 0 to use Roku&apos;s specifications. This setting must be enabled to take effect.</source>
        <translation>Setzen Sie die maximale Bitrate in Mbps. Setzen Sie auf 0, um Rokus Spezifikationen zu verwenden. Diese Einstellung muss aktiviert sein, um wirksam zu werden.</translation>
    </message>
    <message>
        <source>Direct playing</source>
        <translation>Direkte Wiedergabe</translation>
    </message>
    <message>
        <source>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</source>
        <translation>Festlegen, wie viele Sekunden vor dem Ende einer Episode die Schaltfläche &apos;Nächste Episode&apos; erscheinen soll. Auf 0 setzen, um zu deaktivieren.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>The source file is entirely compatible with this client and the session is receiving the file without modifications.</source>
        <translation>Die Quelldatei ist vollständig kompatibel mit diesem Client, und die Sitzung empfängt die Datei ohne Änderungen.</translation>
        <extracomment>Direct play info box text in GetPlaybackInfoTask.brs</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>Läuft gerade</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Gestartet bei</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Geendet bei</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholung</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindung zum Server wird hergestellt</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wähle einen verfügbaren Jellyfin Server aus deinem localen Netzwerk</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serie Aufnehmen</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Ausloggen</translation>
    </message>
    <message>
        <source>Episodes</source>
        <translation>Episoden</translation>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Gestartet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Sender</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>Wenn oben kein Server angezeigt wird, kannst du auch eine Server URL manuell eingeben:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Ein Fehler bei der Wiedergabe dieses Inhalts ist aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Wurde nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler biem laden des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Wiedergabefehler</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Es gab einen Fehler beim Laden dieses Inhalts von dem Server.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Kanaldaten werden geladen</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Laden der Kanaldaten vom Server nicht möglich</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerbewertung</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Spieldauer</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation type="unfinished">Mitwirkende</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation type="unfinished">Empfehlungen</translation>
    </message>
    <message>
        <source>Movies (Presentation)</source>
        <translation>Filme (Präsentation)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endete am</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV-Programm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal ansehen</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Hostnamen oder IP-Adresse des Servers angeben</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Übertragen der Wiedergabeinformationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Wiedergabe</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Enable or disable Direct Play for optional codecs</source>
        <translation>Direkte Wiedergabe für optionale Codecs aktivieren oder deaktivieren</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Unterstützung für das direkte Abspielen von MPEG-2-Inhalten (z.B. Live-TV). Dadurch wird das Transcodieren von MPEG-2-Inhalten vermieden, es wird jedoch erheblich mehr Bandbreite verwendet.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktiviert</translation>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Mediengitter-Optionen</translation>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Anzahl der Elemente</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Zeige die Anzahl der Elemente in der Bibliothek und den Index des ausgewählten Elements.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Zur Folge gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Schnellverbindung</translation>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Hier ist der Schnellverbindungscode:</translation>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Unangesehene Episoden verschleiern</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Go directly to the episode list if a TV series has only one season.</source>
        <translation>Direkt zur Episodenliste gehen, wenn eine TV-Serie nur eine Staffel hat.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Design Elements</source>
        <translation type="unfinished">Gestaltungselemente</translation>
    </message>
    <message>
        <source>Extras</source>
        <translation>Extras</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Diese(r) %1 enthält keine Elemente</translation>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation>Filme (Kachelansicht)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serienaufnahme abbrechen</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation type="unfinished">Bei der Wiedergabe trat ein Fehler auf. Der Server hat die benötigten Transcodinginformationen nicht übermittelt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</source>
        <translation>Unterstützung für das direkte Abspielen von MPEG-4-Inhalten. Dies muss möglicherweise deaktiviert werden, um DIVX-codierte Videodateien abzuspielen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Als gesehen markieren</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Search now</source>
        <translation>Jetzt suchen</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 von %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Verwenden Sie die Wiederholungstaste, um langsam zum ersten Element im Ordner zu animieren. (Wenn deaktiviert, wird der Ordner sofort auf das erste Element zurückgesetzt).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Blur images of unwatched episodes.</source>
        <translation>Verschleiere Bilder von unangesehenen Folgen.</translation>
    </message>
    <message>
        <source>MPEG-4</source>
        <translation>MPEG-4</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Benutzeroberfläche</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Sprachfernbedienung zur Suche verwenden</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation type="unfinished">Slogans ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>MPEG-2</source>
        <translation>MPEG-2</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Mediengitter</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Shows</source>
        <translation>Sendungen</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Anmeldedaten speichern?</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <source>Died</source>
        <translation type="unfinished">Gestorben am</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden von Kanaldaten</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeicherte löschen</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Netzwerke</translation>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation type="unfinished">Blendet Slogan-Text auf Detailseiten aus.</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filtern</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Optionen für TV-Sendungen.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Drücke &apos;OK&apos; zum Schließen</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Zusätzliche Teile</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Codec Support</source>
        <translation type="unfinished">Codec-Support</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Special Features</source>
        <translation type="unfinished">Besonderheiten</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Dialog wird automatisch geschlossen)</translation>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Verwende den Splashscreen als Hintergrund für die Startseite</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>Es kann nach Titeln, Personen, Live-TV-Sendern und mehr gesucht werden</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>Options that alter the design of Jellyfin.</source>
        <translation>Optionen, die das Design von Jellyfin verändern.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Skip Details for Single Seasons</source>
        <translation>Details für einzelne Staffeln überspringen</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Favorit festlegen</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Zur Staffel gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Anzahl der Wiedergaben</translation>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>TV-Serien</translation>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Beginnt um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Wiedergegeben am</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deaktiviert</translation>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Der gewünschte Inhalt existiert nicht auf dem Server</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Zur Serie gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>Bei der Authentifizierung der Schnellverbindung ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Zurück zum Anfang</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Beim Laden des Inhalts vom Server ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Bei der Wiedergabe dieses Inhalts ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Laden des Inhalts</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Taglines ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Mitwirkende</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Emp­feh­lungen</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Beim Abspielen dieses Elements ist ein Fehler aufgetreten. Der Server hat die erforderlichen Transkodierungsdaten nicht bereitgestellt</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Codec Support</source>
        <translation>Codec-Unterstützung</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Blendet den Tagline-Text auf Detailseiten aus.</translation>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Designelemente</translation>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s home background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Verwenden Sie das generierte Startbildschirm-Bild als Hintergrund für die Jellyfin-Startseite. Jellyfin muss geschlossen und erneut geöffnet werden, damit die Änderung wirksam wird.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Bring the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Bringen Sie das Kinoerlebnis direkt in Ihr Wohnzimmer mit der Möglichkeit, benutzerdefinierte Intros vor dem Hauptfilm abzuspielen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Next episode</source>
        <translation>Nächste Folge</translation>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Kino-Modus</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Died</source>
        <translation>Gestorben am</translation>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Trailer abspielen</translation>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Uhr ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>HEVC</source>
        <translation>HEVC</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>H.264</source>
        <translation>H.264</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Born</source>
        <translation>Geboren am</translation>
    </message>
    <message>
        <source>Hide all clocks in Jellyfin. Jellyfin will need to be closed and reopened for changes to take effect.</source>
        <translation>Alle Uhren in Jellyfin ausblenden. Jellyfin muss geschlossen und erneut geöffnet werden, damit die Änderungen wirksam werden.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Versuchen Sie Direktwiedergabe für H.264-Medien mit nicht unterstützten Profilniveaus, bevor Sie auf Transkodierung zurückgreifen, falls es fehlschlägt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Versuchen Sie Direktwiedergabe für HEVC-Medien mit nicht unterstützten Profilniveaus, bevor Sie auf Transkodierung zurückgreifen, falls es fehlschlägt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation>Einstellungen bezüglich der Wiedergabe und unterstützten Codec- und Medientypen.</translation>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation>Einstellungen bezüglich des Aussehens der Anwendung.</translation>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</source>
        <translation>Legen Sie die maximale Anzahl von Tagen fest, die eine Sendung in der &apos;Nächste&apos; Liste bleiben soll, ohne sie anzusehen</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Playback Information</source>
        <translation>Wiedergabeinformationen</translation>
    </message>
    <message>
        <source>Transcoding Information</source>
        <translation>Transkodierungsinformationen</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Grund</translation>
    </message>
    <message>
        <source>Video Codec</source>
        <translation>Videocodec</translation>
    </message>
    <message>
        <source>direct</source>
        <translation>direkt</translation>
    </message>
    <message>
        <source>Audio Codec</source>
        <translation>Audiocodec</translation>
    </message>
    <message>
        <source>Total Bitrate</source>
        <translation>Gesamtbitrate</translation>
    </message>
    <message>
        <source>Audio Channels</source>
        <translation>Audiokanäle</translation>
    </message>
    <message>
        <source>Stream Information</source>
        <translation>Streaminformationen</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <source>Codec Tag</source>
        <translation>Codec-Tag</translation>
    </message>
    <message>
        <source>Level</source>
        <translation>Level</translation>
        <extracomment>Video profile level</extracomment>
    </message>
    <message>
        <source>Container</source>
        <translation>Behälter</translation>
        <extracomment>Video streaming container</extracomment>
    </message>
    <message>
        <source>Size</source>
        <translation>Größe</translation>
        <extracomment>Video size</extracomment>
    </message>
    <message>
        <source>Video range type</source>
        <translation>Videobereichstyp</translation>
    </message>
    <message>
        <source>Pixel format</source>
        <translation>Pixelformat</translation>
        <extracomment>Video pixel format</extracomment>
    </message>
    <message>
        <source>WxH</source>
        <translation>Videobreite x -höhe</translation>
        <extracomment>Video width x height</extracomment>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Besondere Merkmale</translation>
    </message>
    <message>
        <source>Bit Rate</source>
        <translation>Bitrate</translation>
        <extracomment>Video streaming bit rate</extracomment>
    </message>
    <message>
        <source>Max Days Next Up</source>
        <translation>Maximale Tage bis zum Nächsten</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Unable to find any albums or songs belonging to this artist</source>
        <translation>Keine Alben oder Lieder dieses Künstlers gefunden</translation>
        <extracomment>Popup message when we find no audio data for an artist</extracomment>
    </message>
    <message>
        <source>Custom Subtitles</source>
        <translation>Benutzerdefinierte Untertitel</translation>
        <extracomment>Name of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Fehler während der Wiedergabe</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Beim Abrufen der Daten für dieses Element vom Server ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Kanaldaten werden geladen</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Kanaldaten können nicht vom Server geladen werden</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>Dieses %1 enthält keine Elemente</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Server wechseln</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Beim Abspielen dieses Elements ist ein Fehler aufgetreten.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Anmeldedaten speichern?</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>Jetzt Live</translation>
    </message>
    <message>
        <source>Extras</source>
        <translation>Extras</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Episodes</source>
        <translation>Folgen</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Fehler beim Laden der Kanaldaten</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Gespeicherte löschen</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Fehler beim Abrufen von Inhalten</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Kritikerbewertung</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Veröffentlichungsdatum</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Laufzeit</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Altersfreigabe</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb Bewertung</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Anzahl der Wiedergaben</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Wiedergegeben am</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filter</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>Zusätzliche Teile</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>gestern</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Wiederholen</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Record</source>
        <translation>Aufnehmen</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Serien Aufnehmen</translation>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Verbindungsaufnahme zum Server</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nicht gefunden</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation>Beim Abspielen dieses Artikels ist ein Fehler aufgetreten. Der Server hat die erforderlichen Transkodierungsdaten nicht bereitgestellt.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</source>
        <translation>Unterstützt die direkte Wiedergabe von MPEG-4-Inhalten. Für die Wiedergabe von DIVX-kodierten Videodateien muss dies möglicherweise deaktiviert werden.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>Mediengitter</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Mediengitter-Optionen</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>An</translation>
    </message>
    <message>
        <source>Enable or disable Direct Play for optional codecs</source>
        <translation>Aktiviere oder deaktiviere „Direct Play“ für optionale Codecs</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dienstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Serien-Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Als angesehen markieren</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Codec Support</source>
        <translation>Codec-Unterstützung</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Age</source>
        <translation>Alter</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Mehr wie das</translation>
    </message>
    <message>
        <source>Movies (Presentation)</source>
        <translation>Filme (Präsentation)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>Mitwirkende</translation>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation>Filme (Raster)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>heute</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>morgen</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Sonntag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Montag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mittwoch</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Donnerstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Fing an bei</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Gestartet</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Beginnt</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Endete um</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Endet um</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>Fernsehprogramm</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Kanal anzeigen</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Aufnahme abbrechen</translation>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation>Gib den Servernamen oder die IP-Adresse ein</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Wähle einen verfügbaren Jellyfin-Server aus Ihrem lokalen Netzwerk aus:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>Wenn oben kein Server aufgeführt ist, kann die Server-URL auch manuell eingeben werden:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Fehler beim Abrufen der Wiedergabeinformationen</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>Playback</source>
        <translation>Wiedergabe</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>MPEG-2</source>
        <translation>MPEG-2</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation>Unterstützt die direkte Wiedergabe von MPEG-2-Inhalten (z. B. Live-TV). Dadurch wird die Transkodierung von MPEG-2-Inhalten verhindert, es wird jedoch deutlich mehr Bandbreite beansprucht.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>MPEG-4</source>
        <translation>MPEG-4</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Benutzeroberfläche</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation>Anzahl der Elemente</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation>Zeige die Anzahl der Elemente in der Bibliothek und den Index des ausgewählten Elements.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Zur Folge gehen</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation>Sprachfernbedienung zur Suche verwenden</translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>Search now</source>
        <translation>Jetzt suchen</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 von %2</translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>schnelle Verbindung</translation>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Hier ist der Schnellverbindungscode:</translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation>(Der Dialog wird automatisch geschlossen)</translation>
    </message>
    <message>
        <source>Shows</source>
        <translation>Sendungen</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Gestorben</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Netzwerke</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Drücke zum Schließen auf &quot;OK&quot;</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Freitag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Besondere Merkmale</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Geboren</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samstag</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation>Es kann nach Titeln, Personen, Live-TV-Sendern und mehr gesucht werden</translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Favorit festlegen</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Gehe zu Staffel</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>Fernsehshows</translation>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Startet um</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Aus</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Die angeforderte Medien-Datei ist auf dem Server nicht vorhanden</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Zur Serie</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation>Bei der Authentifizierung der Schnellverbindung ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <source>Return to Top</source>
        <translation>Zurück zum Anfang</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation>Ungesehene Episoden verschleiern</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation>Optionen für TV-Serien.</translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation>Medienraster-Optionen.</translation>
    </message>
    <message>
        <source>Default view for Movie Libraries.</source>
        <translation>Standardansicht für Filmbibliotheken.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Elementtitel</translation>
        <extracomment>Title of a setting - when should we show the title text of a grid item</extracomment>
    </message>
    <message>
        <source>Select when to show titles.</source>
        <translation>Auswählen, wann Titel angezeigt werden sollen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s home background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Verwenden Sie das generierte Startbildschirm-Bild als Hintergrund für die Jellyfin-Startseite. Jellyfin muss geschlossen und erneut geöffnet werden, damit die Änderung wirksam wird.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Bring the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation>Bringen Sie das Kinoerlebnis direkt in Ihr Wohnzimmer mit der Möglichkeit, benutzerdefinierte Intros vor dem Hauptfilm abzuspielen.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hide all clocks in Jellyfin. Jellyfin will need to be closed and reopened for changes to take effect.</source>
        <translation>Alle Uhren in Jellyfin ausblenden. Jellyfin muss geschlossen und erneut geöffnet werden, damit die Änderungen wirksam werden.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Direktes Abspielen von HEVC-Medien mit nicht unterstützten Profilebenen versuchen, bevor auf Transkodierung zurückgegriffen wird, falls dies fehlschlägt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it.</source>
        <translation>Setzen Sie die maximale Anzahl von Tagen, die eine noch nicht angesehene Sendung in der &apos;Als nächstes&apos;-Liste bleiben soll.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <source>Replace Roku&apos;s default subtitle functions with custom functions that support CJK fonts. Fallback fonts must be configured and enabled on the server for CJK rendering to work.</source>
        <translation>Ersetzt die Roku Standard Untertitelfunktionen mit benutzerdefinierten Funktionen, die CJK Schriftarten unterstützen. Ersatzschriftarten müssen auf dem Server konfiguriert und aktiviert sein, damit die CJK-Darstellung funktioniert.</translation>
        <extracomment>Description of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Parental Ratings</source>
        <translation>Altersbeschränkung</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Show What&apos;s New Popup</source>
        <translation>Neuigkeiten Popup anzeigen</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Disable Unwatched Episode Count</source>
        <translation>Zahl ungesehener Folgen deaktivieren</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Slideshow On</source>
        <translation>Diashow an</translation>
    </message>
    <message>
        <source>Slideshow Paused</source>
        <translation>Diashow pausiert</translation>
    </message>
    <message>
        <source>Years</source>
        <translation>Jahre</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</source>
        <translation>Legen Sie fest, wie viele Sekunden vor dem Ende einer Folge der &quot;Nächste Folge&quot;-Button erscheinen soll. Setzen Sie den Wert auf 0 um den Button zu deaktivieren.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Always Hide</source>
        <translation>Immer ausblenden</translation>
    </message>
    <message>
        <source>Choose your preferred audio codec when transcoding multichannel audio.</source>
        <translation>Wählen Sie Ihren bevorzugten Audiocodec, wenn Mehrkanal-Audio transcodiert wird.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Configure the maximum playback bitrate.</source>
        <translation>Legen Sie die maximale Wiedergabe-Bitrate fest.</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of the Home screen and the program in general.</source>
        <translation>Einstellungen zum Erscheinungsbild der Startseite und dem Programm allgemein.</translation>
    </message>
    <message>
        <source>Settings that apply when Grid views are enabled.</source>
        <translation>Einstellungen für aktivierte Rasteransichten.</translation>
    </message>
    <message>
        <source>Presentation</source>
        <translation>Präsentation</translation>
        <extracomment>Title of an option - name of presentation view</extracomment>
    </message>
    <message>
        <source>Force all transcodes to use DTS instead of the default EAC3. The device must support DTS for this setting to have an effect.</source>
        <translation>Für alle Transkodierungen DTS anstelle des Standards EAC3 erzwingen. Das Gerät muss DTS unterstützen damit diese Einstellung funktioniert.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>If enabled, the number of unwatched episodes in a series/season will be removed.</source>
        <translation>Wenn aktiviert, wir die Zahl der noch nicht angesehenen Folgen einer Serie/Staffel ausgeblendet.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Set the maximum resolution when playing video files on this device.</source>
        <translation>Legen Sie die maximale Auflösung für das Abspielen von Videodateien auf diesem Gerät fest.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>All files</source>
        <translation>Alle Dateien</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Configure the maximum resolution when playing video files on this device.</source>
        <translation>Legen Sie die maximale Auflösung für das Abspielen von Videodateien auf diesem Gerät fest.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>Disable the HEVC codec on this device. This may improve playback for some devices (ultra).</source>
        <translation>Den HEVC Codec auf diesem Gerät deaktivieren. Dies kann die Wiedergabe auf manchen Geräten (z.B. Ultra) verbessern.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Global settings that affect everyone that uses this Roku device.</source>
        <translation>Einstellungen die alle Nutzer dieses Roku Geräts betreffen.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Remember the currently logged in user and try to log them in again next time you start the Jellyfin app.</source>
        <translation>Den aktuell angemeldeten Nutzer merken und beim nächsten Start der Jellyfin App versuchen, diesen erneut einzuloggen.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>No Chapter Data Found</source>
        <translation>Keine Kapiteldaten gefunden</translation>
        <extracomment>Message shown in OSD when no chapter data is returned by the API</extracomment>
    </message>
    <message>
        <source>Use Web Client&apos;s Home Section Arrangement</source>
        <translation>Home-Aufteilung des Webclients verwenden</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Make the arrangement of the Roku home view sections match the web client&apos;s home screen. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation>Die Anordnung und Abschnitte der Roku-Startansicht an den Startbildschirm des Webclients anpassen. Die Jellyfin-App muss neu gestartet werden damit diese Änderung wirksam wird.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>What&apos;s New?</source>
        <translation>Neuigkeiten in dieser Version</translation>
        <extracomment>Popup title - Popup displays all the major changes to the app since the last version</extracomment>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>Designelemente</translation>
    </message>
    <message>
        <source>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation>Direktes Abspielen von H.264-Medien mit nicht unterstützten Profilebenen versuchen, bevor auf Transkodierung zurückgegriffen wird, falls dies fehlschlägt.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation>Einstellungen zum Aussehen der Anwendung.</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Grund</translation>
    </message>
    <message>
        <source>Video Codec</source>
        <translation>Videocodec</translation>
    </message>
    <message>
        <source>direct</source>
        <translation>direkt</translation>
    </message>
    <message>
        <source>Audio Codec</source>
        <translation>Audiocodec</translation>
    </message>
    <message>
        <source>Codec Tag</source>
        <translation>Codec-Tag</translation>
    </message>
    <message>
        <source>Pixel format</source>
        <translation>Pixelformat</translation>
        <extracomment>Video pixel format</extracomment>
    </message>
    <message>
        <source>WxH</source>
        <translation>BxH</translation>
        <extracomment>Video width x height</extracomment>
    </message>
    <message>
        <source>Stream Information</source>
        <translation>Streaminformationen</translation>
    </message>
    <message>
        <source>Aired</source>
        <translation>Ausgestrahlt</translation>
        <extracomment>Aired date label</extracomment>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation>Beim Drücken der Wiederholen-Taste langsam zum ersten Element im Ordner scrollen. (Wenn deaktiviert, wird sofort zum ersten Element gesprungen).</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>Schlagwörter ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation>Blendet den Text von Schlagwörtern auf Detailansichten aus.</translation>
    </message>
    <message>
        <source>Go directly to the episode list if a TV series has only one season.</source>
        <translation>Direkt zur Episodenliste gehen, wenn eine TV-Serie nur eine Staffel hat.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Blur images of unwatched episodes.</source>
        <translation>Bilder von noch nicht angesehenen Folgen unscharf darstellen.</translation>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>Kinomodus</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Disable HEVC</source>
        <translation>HEVC deaktivieren</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Next episode</source>
        <translation>Nächste Folge</translation>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation>Einstellungen zur Wiedergabe und zu unterstützten Codec- und Medientypen.</translation>
    </message>
    <message>
        <source>Playback Information</source>
        <translation>Wiedergabeinformationen</translation>
    </message>
    <message>
        <source>Transcoding Information</source>
        <translation>Transkodierungsinformationen</translation>
    </message>
    <message>
        <source>Total Bitrate</source>
        <translation>Gesamtbitrate</translation>
    </message>
    <message>
        <source>Audio Channels</source>
        <translation>Audiokanäle</translation>
    </message>
    <message>
        <source>Bit Rate</source>
        <translation>Bitrate</translation>
        <extracomment>Video streaming bit rate</extracomment>
    </message>
    <message>
        <source>Container</source>
        <translation>Container</translation>
        <extracomment>Video streaming container</extracomment>
    </message>
    <message>
        <source>Size</source>
        <translation>Größe</translation>
        <extracomment>Video size</extracomment>
    </message>
    <message>
        <source>Video range type</source>
        <translation>Video-Dynamikumfang</translation>
    </message>
    <message>
        <source>Random</source>
        <translation>Zufällig</translation>
        <extracomment>General use word when we want to randomize data</extracomment>
    </message>
    <message>
        <source>Slideshow Off</source>
        <translation>Diashow aus</translation>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>Trailer abspielen</translation>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>Uhr ausblenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Movie Library Default View</source>
        <translation>Standardansicht für Filmbibliothek</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Always Show</source>
        <translation>Immer anzeigen</translation>
    </message>
    <message>
        <source>Biographical information for this person is not currently available.</source>
        <translation>Biografische Informationen zu dieser Person stehen derzeit nicht zur Verfügung.</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of Library pages</source>
        <translation>Einstellungen zum Erscheinungsbild von Bibliotheksseiten</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>Raster</translation>
        <extracomment>Title of an option - name of grid view</extracomment>
    </message>
    <message>
        <source>Audio Codec Support</source>
        <translation>Unterstützte Audio Codecs</translation>
        <extracomment>Settings Menu - Title of option</extracomment>
    </message>
    <message>
        <source>Maximum Resolution</source>
        <translation>Maximale Auflösung</translation>
        <extracomment>User Setting - Title</extracomment>
    </message>
    <message>
        <source>Only transcoded files</source>
        <translation>Nur transkodierte Dateien</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>HEVC</source>
        <translation>HEVC</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>H.264</source>
        <translation>H.264</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Random On</source>
        <translation>Zufällig an</translation>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation>Splashscreen als Starthintergrund verwenden</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Text Subtitles Only</source>
        <translation>Nur Text-Untertitel</translation>
        <extracomment>Name of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>all</source>
        <translation>alle</translation>
        <extracomment>all will reset the searchTerm so all data will be availible</extracomment>
    </message>
    <message>
        <source>Slideshow Resumed</source>
        <translation>Diashow fortgesetzt</translation>
    </message>
    <message>
        <source>Random Off</source>
        <translation>Zufällig aus</translation>
    </message>
    <message>
        <source>MPEG-4 Support</source>
        <translation>MPEG-4 Unterstützung</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Resumable</source>
        <translation>Fortsetzbar</translation>
    </message>
    <message>
        <source>Show On Hover</source>
        <translation>Bei Hover anzeigen</translation>
    </message>
    <message>
        <source>Artists (Presentation)</source>
        <translation>Künstler (Präsentation)</translation>
    </message>
    <message>
        <source>Album Artists (Presentation)</source>
        <translation>Album-Künstler (Präsentation)</translation>
    </message>
    <message>
        <source>Artists (Grid)</source>
        <translation>Künstler (Raster)</translation>
    </message>
    <message>
        <source>Song</source>
        <translation>Lied</translation>
    </message>
    <message>
        <source>Songs</source>
        <translation>Lieder</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <source>Albums</source>
        <translation>Alben</translation>
    </message>
    <message>
        <source>Disable Community Rating for Episodes</source>
        <translation>Community-Bewertungen für Folgen deaktivieren</translation>
    </message>
    <message>
        <source>Enable Limit</source>
        <translation>Limit aktivieren</translation>
    </message>
    <message>
        <source>Enable or disable the &apos;Maximum Bitrate&apos; setting.</source>
        <translation>&apos;Maximale Bitrate&apos;-Einstellung ein- oder ausschalten.</translation>
    </message>
    <message>
        <source>Bitrate Limit</source>
        <translation>Bitratenlimit</translation>
    </message>
    <message>
        <source>Maximum Bitrate</source>
        <translation>Maximale Bitrate</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Allgemein</translation>
    </message>
    <message>
        <source>Grid View Settings</source>
        <translation>Einstellungen zur Rasteransicht</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in TV Libraries.</source>
        <translation>Einstellung zum Erscheinungsbild von Seiten in TV-Bibliotheken.</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in Movie Libraries.</source>
        <translation>Einstellungen zum Erscheinungsbild von Seiten in Filmbibliotheken.</translation>
    </message>
    <message>
        <source>Next Episode Button Time</source>
        <translation>Button &quot;Nächste Episode&quot; anzeigen</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Off - Attempt to play all resolutions</source>
        <translation>Aus - Versuchen, alle Auflösungen abzuspielen</translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Auto - Use TV resolution</source>
        <translation>Auto - TV-Auflösung verwenden</translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Mode</source>
        <translation>Modus</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Value</source>
        <translation>Wert</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Apply max resolution to all files or only transcoded files.</source>
        <translation>Die maximale Auflösung auf alle Dateien oder nur transkodierte Dateien anwenden.</translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>Compatibility</source>
        <translation>Kompatibilität</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Attempt to prevent playback failures.</source>
        <translation>Wiedergabefehler versuchen zu verhindern.</translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Global</source>
        <translation>Global</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Remember Me?</source>
        <translation>Angemeldet bleiben?</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Options that alter the design of Jellyfin.</source>
        <translation>Optionen, die das Design von Jellyfin verändern.</translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Skip Details for Single Seasons</source>
        <translation>Details für einzelne Staffeln überspringen</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Libraries</source>
        <translation>Bibliotheken</translation>
    </message>
    <message>
        <source>Loading trailer</source>
        <translation>Trailer wird geladen</translation>
        <extracomment>Dialog title in Main.brs</extracomment>
    </message>
    <message>
        <source>Show What&apos;s New popup when Jellyfin is updated to a new version.</source>
        <translation>Popup mit Neuigkeiten anzeigen, wenn Jellyfin auf eine neue Version aktualisiert wird.</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hide the star and community rating for episodes of a TV show. This is to prevent spoilers of an upcoming good/bad episode.</source>
        <translation>Sterne- und Community-Bewertung für Folgen einer Serie ausblenden. Somit können Spoiler von demnächst erscheinenden guten bzw. schlechten Folgen vermieden werden.</translation>
    </message>
    <message>
        <source>Album Artists (Grid)</source>
        <translation>Album-Künstler (Raster)</translation>
    </message>
    <message>
        <source>View All</source>
        <translation>Alle anzeigen</translation>
    </message>
    <message>
        <source>Set the maximum bitrate in Mbps. Set to 0 to use Roku&apos;s specifications. This setting must be enabled to take effect.</source>
        <translation>Legen Sie die maximale Bitrate in Mbps fest. Setzen Sie den Wert auf 0 um die Standardeinstellung des Roku&apos;s zu verwenden. Diese Einstellung muss aktiviert sein um wirksam zu werden.</translation>
    </message>
    <message>
        <source>Direct playing</source>
        <translation>Direktes Abspielen</translation>
    </message>
    <message>
        <source>The source file is entirely compatible with this client and the session is receiving the file without modifications.</source>
        <translation>Die Quelldatei ist vollständig mit diesem Client kompatibel und die Sitzung empfängt die Datei ohne Änderungen.</translation>
        <extracomment>Direct play info box text in GetPlaybackInfoTask.brs</extracomment>
    </message>
    <message>
        <source>Level</source>
        <translation>Level</translation>
        <extracomment>Video profile level</extracomment>
    </message>
    <message>
        <source>Unplayed</source>
        <translation>Ungespielt</translation>
    </message>
    <message>
        <source>Played</source>
        <translation>Gespielt</translation>
    </message>
    <message>
        <source>Only display text subtitles to minimize transcoding.</source>
        <translation>Nur Text-Untertitel anzeigen, um die Transkodierung zu minimieren.</translation>
        <extracomment>Description of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>Max Days Next Up</source>
        <translation>Max. Tage für &quot;Als nächstes&quot;</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
</context>
</TS>
