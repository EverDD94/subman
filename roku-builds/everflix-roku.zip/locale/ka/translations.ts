<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ka" sourcelanguage="en_US">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>default</name>
    <message>
        <source>192.168.1.100:8096 or https://example.com/jellyfin</source>
        <translation>192.168.1.100:8096 ან https://example.com/jellyfin</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>გაუქმება</translation>
    </message>
    <message>
        <source>Connect to Server</source>
        <translation>სერვერთან კავშირი</translation>
    </message>
    <message>
        <source>Ends at %1</source>
        <translation>დასრულების დრო %1</translation>
    </message>
    <message>
        <source>Enter Configuration</source>
        <translation>მორგებაზე გადასვლა</translation>
    </message>
    <message>
        <source>Favorite</source>
        <translation>რჩეული</translation>
    </message>
    <message>
        <source>Loading...</source>
        <translation>ჩატვირთვა…</translation>
    </message>
    <message>
        <source>Login attempt failed.</source>
        <translation>შესვლის მცდელობა ჩავარდა.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>დიახ</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>მორგება</translation>
    </message>
    <message>
        <source>Play</source>
        <translation>დაკვრა</translation>
    </message>
    <message>
        <source>Please sign in</source>
        <translation>გთხოვთ შეხვიდეთ სისტემაში</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>ძებნა</translation>
    </message>
    <message>
        <source>Server not found, is it online?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shuffle</source>
        <translation>შემთხვევით</translation>
    </message>
    <message>
        <source>Sign In</source>
        <translation>შესვლა</translation>
    </message>
    <message>
        <source>Submit</source>
        <translation>გაგზავნა</translation>
    </message>
    <message>
        <source>Watched</source>
        <translation>ვუყურებ</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>მორგება</translation>
    </message>
    <message>
        <source>Change User</source>
        <translation>მომხმარებლის შეცვლა</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>სერვერის შეცვლა</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>გასვლა</translation>
    </message>
    <message>
        <source>Add User</source>
        <translation>მომხმარებლის დამატება</translation>
    </message>
    <message>
        <source>Profile</source>
        <translation>პროფილი</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>შევინახო ავტორიზაციის დეტალები?</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>შენახულის წაშლა</translation>
    </message>
    <message>
        <source>My Media</source>
        <translation>ჩემი მედია</translation>
    </message>
    <message>
        <source>Continue Watching</source>
        <translation>ყურების გაგრძელება</translation>
    </message>
    <message>
        <source>Next Up</source>
        <translation>შემდეგი</translation>
    </message>
    <message>
        <source>Recently Added in</source>
        <translation>ახლახან დამატებული</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation>ეთერშია</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>საწყისი</translation>
    </message>
    <message>
        <source>Enter a username</source>
        <translation>შეიყვანეთ მომხმარებლის სახელი</translation>
    </message>
    <message>
        <source>Enter a password</source>
        <translation>შეიყვანეთ პაროლი</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>სახელი</translation>
    </message>
    <message>
        <source>Sort Order</source>
        <translation>დალაგების წესი</translation>
    </message>
    <message>
        <source>Descending</source>
        <translation>კლებადობით</translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation>მატებით</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>პაროლი</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>მომხმარებლის სახელი</translation>
    </message>
    <message>
        <source>Genres</source>
        <translation>ჟანრები</translation>
    </message>
    <message>
        <source>Director</source>
        <translation>რეჟისორი</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>ვიდეო</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>აუდიო</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>სუბტიტრები</translation>
    </message>
    <message>
        <source>tracks</source>
        <translation>ტრეკები</translation>
    </message>
    <message>
        <source>No Default</source>
        <translation>ნაგულისხმევის გარეშე</translation>
    </message>
    <message>
        <source>Server</source>
        <translation>სერვერი</translation>
    </message>
    <message>
        <source>Extras</source>
        <translation>დამატებით</translation>
    </message>
    <message>
        <source>Episodes</source>
        <translation>ეპიზოდები</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation type="unfinished"></translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation type="unfinished"></translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Unable to get playback information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation type="unfinished"></translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation type="unfinished"></translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>სახელი</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>IMDb-ის რეიტინგი</translation>
    </message>
    <message>
        <source>Community Rating</source>
        <translation>საზოგადოებრივი რეიტინგი</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>კრიტიკოსების რეიტინგი</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>დამატების თარიღი</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>დაკვრის თარიღი</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>ასაკობრივი რეიტინგი</translation>
    </message>
    <message>
        <source>Date Show Added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date Episode Added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>დაკვრების რაოდენობა</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>გამოსვლის თარიღი</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>გაშვების გარემო</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>ხედი</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>დალაგება</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>ფილტრი</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>დაიბადა</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>გარდაიცვალა</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>ასაკი</translation>
    </message>
    <message>
        <source>Cast &amp; Crew</source>
        <translation>მსახიობები და გადამღები ჯგუფი</translation>
    </message>
    <message>
        <source>More Like This</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>სპეციალური ფუნქციები</translation>
    </message>
    <message>
        <source>Additional Parts</source>
        <translation>დამატებითი ნაწილები</translation>
        <extracomment>Additional parts of a video</extracomment>
    </message>
    <message>
        <source>Movies</source>
        <translation>ფილმები</translation>
    </message>
    <message>
        <source>Movies (Presentation)</source>
        <translation>ფილმები (პრეზენტაცია)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>Movies (Grid)</source>
        <translation>ფილმები (ბადე)</translation>
        <extracomment>Movie library view option</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>ტელესერიალები</translation>
    </message>
    <message>
        <source>today</source>
        <translation>დღეს</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>გუშინ</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>ხვალ</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>კვირა</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>ორშაბათი</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>სამშაბათი</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>ოთხშაბათი</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>ხუთშაბათი</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>პარასკევი</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>შაბათი</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>დაწყების დრო</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g. Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>დაწყებულია</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g. Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>დაწყების დროა</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g. Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>იწყება</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g. Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>დასრულდა</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g. Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>სრულდება</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended (e.g. Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>პირდაპირი ეთერი</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>გამეორება</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>არხები</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>TV გიდი</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>View Channel</source>
        <translation>არხის ნახვა</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>ჩაწერა</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>სერიების ჩაწერა</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>ჩაწერის გაუქმება</translation>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation>დახურვა</translation>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation type="unfinished"></translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>აღმოჩენილი არაა</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Unknown</source>
        <translation>უცნობი</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation type="unfinished"></translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Enter the server name or IP address</source>
        <translation type="unfinished"></translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation type="unfinished"></translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation type="unfinished"></translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation type="unfinished"></translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item. Server did not provide required transcoding data.</source>
        <translation type="unfinished"></translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>ვერსია</translation>
    </message>
    <message>
        <source>Playback</source>
        <translation>დაკვრა</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Codec Support</source>
        <translation>კოდეკის მხარდაჭერა</translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>Enable or disable Direct Play for optional codecs</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Title for settings group related to codec support</extracomment>
    </message>
    <message>
        <source>MPEG-2</source>
        <translation>MPEG-2</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-2 content (e.g., Live TV). This will prevent transcoding of MPEG-2 content, but uses significantly more bandwidth.</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>MPEG-4</source>
        <translation>MPEG-4</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Support Direct Play of MPEG-4 content. This may need to be disabled for playback of DIVX encoded video files.</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Enabled</source>
        <translation>ჩართულია</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>გამორთული</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation>მომხმარებლის ინტერფეისი</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Media Grid</source>
        <translation>მედიის ბადე</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Media Grid options.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Item Count</source>
        <translation>ელემენტების რაოდენობა</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Show item count in the library and index of selected item.</source>
        <translation type="unfinished"></translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>რჩეულობის დაყენება</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Favorited</source>
        <translation>რჩეულებშია</translation>
    </message>
    <message>
        <source>Mark As Favorite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>ნანახობის დაყენება</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Resume playing at </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start over from the beginning.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Playback Options</source>
        <translation>დაკვრის მორგება</translation>
    </message>
    <message>
        <source>Go to series</source>
        <translation type="unfinished"></translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation type="unfinished"></translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation type="unfinished"></translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Use voice remote to search</source>
        <translation type="unfinished"></translation>
        <extracomment>Help text in search voice text box</extracomment>
    </message>
    <message>
        <source>Search now</source>
        <translation>ახლა ძებნა</translation>
        <extracomment>Help text in search Box</extracomment>
    </message>
    <message>
        <source>You can search for Titles, People, Live TV Channels and more</source>
        <translation type="unfinished"></translation>
        <extracomment>Help text in search results</extracomment>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation type="unfinished"></translation>
        <extracomment>Item position and count. %1 = current item. %2 = total number of items</extracomment>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>სწრაფი კავშირი</translation>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>ქსელი</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>სტუდიები</translation>
    </message>
    <message>
        <source>Shows</source>
        <translation>სერიალები</translation>
    </message>
    <message>
        <source>Return to Top</source>
        <translation type="unfinished"></translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Use the replay button to slowly animate to the first item in the folder. (If disabled, the folder will reset to the first item immediately).</source>
        <translation type="unfinished"></translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Hide Taglines</source>
        <translation>ჭდის ხაზების დამალვა</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Hides tagline text on details pages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options for TV Shows.</source>
        <translation type="unfinished"></translation>
        <extracomment>Description for TV Shows user settings.</extracomment>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation type="unfinished"></translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Skip Details for Single Seasons</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Go directly to the episode list if a TV series has only one season.</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Blur images of unwatched episodes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Design Elements</source>
        <translation>დიზაინის ელემენტები</translation>
    </message>
    <message>
        <source>Options that alter the design of Jellyfin.</source>
        <translation type="unfinished"></translation>
        <extracomment>Description for Design Elements user settings.</extracomment>
    </message>
    <message>
        <source>Use Splashscreen as Home Background</source>
        <translation type="unfinished"></translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Use generated splashscreen image as Jellyfin&apos;s home background. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation type="unfinished"></translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Cinema Mode</source>
        <translation>კინოს რეჟიმი</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Bring the theater experience straight to your living room with the ability to play custom intros before the main feature.</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Hide Clock</source>
        <translation>საათის დამალვა</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Hide all clocks in Jellyfin. Jellyfin will need to be closed and reopened for changes to take effect.</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Next episode</source>
        <translation>შემდეგი ეპიზოდი</translation>
    </message>
    <message>
        <source>Play Trailer</source>
        <translation>ტრეილერის დაკვრა</translation>
    </message>
    <message>
        <source>H.264</source>
        <translation>H.264</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for H.264 media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>HEVC</source>
        <translation>HEVC</translation>
        <extracomment>Name of codec used in settings menu</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play for HEVC media with unsupported profile levels before falling back to transcoding if it fails.</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Settings relating to playback and supported codec and media types.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings relating to how the application looks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max Days Next Up</source>
        <translation type="unfinished"></translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Set the maximum amount of days a show should stay in the &apos;Next Up&apos; list without watching it. Maximum value is 1000 days.</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Playback Information</source>
        <translation>დაკვრის ინფორმაცია</translation>
    </message>
    <message>
        <source>Transcoding Information</source>
        <translation>ტრანსკოდირების ინფორმაცია</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>მიზეზი</translation>
    </message>
    <message>
        <source>Force Transcoding setting is enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Force Transcode option is enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video Codec</source>
        <translation>ვიდეოკოდეკი</translation>
    </message>
    <message>
        <source>Audio Codec</source>
        <translation>აუდიოკოდეკი</translation>
    </message>
    <message>
        <source>direct</source>
        <translation>პირდაპირი</translation>
    </message>
    <message>
        <source>Total Bitrate</source>
        <translation>ჯამური ბიტური სიხშირე</translation>
    </message>
    <message>
        <source>Audio Channels</source>
        <translation>აუდიოარხები</translation>
    </message>
    <message>
        <source>Stream Information</source>
        <translation>ნაკადის ინფორმაცია</translation>
    </message>
    <message>
        <source>Codec</source>
        <translation>კოდეკი</translation>
    </message>
    <message>
        <source>Codec Tag</source>
        <translation>კოდეკის ჭდე</translation>
    </message>
    <message>
        <source>Level</source>
        <translation>დონე</translation>
        <extracomment>Video profile level</extracomment>
    </message>
    <message>
        <source>Bit Rate</source>
        <translation>ბიტური სიხშირე</translation>
        <extracomment>Video streaming bit rate</extracomment>
    </message>
    <message>
        <source>Container</source>
        <translation>კონტერინერი</translation>
        <extracomment>Video streaming container</extracomment>
    </message>
    <message>
        <source>Size</source>
        <translation>ზომა</translation>
        <extracomment>Video size</extracomment>
    </message>
    <message>
        <source>Video range type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pixel format</source>
        <translation>პიქსელის ფორმატი</translation>
        <extracomment>Video pixel format</extracomment>
    </message>
    <message>
        <source>WxH</source>
        <translation>სიგ x სმღლ</translation>
        <extracomment>Video width x height</extracomment>
    </message>
    <message>
        <source>Unable to find any albums or songs belonging to this artist</source>
        <translation type="unfinished"></translation>
        <extracomment>Popup message when we find no audio data for an artist</extracomment>
    </message>
    <message>
        <source>Custom Subtitles</source>
        <translation>მორგებული სუბტიტრები</translation>
        <extracomment>Name of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Replace Roku&apos;s default subtitle functions with custom functions. If fallback fonts are configured and enabled on the server, those fonts will be used. A CJK fallback font is required for CJK rendering. To support bold and italics, you must have additional font files with the words &quot;bold&quot;, &quot;italic&quot;, and &quot;bolditalic&quot; in the filename.</source>
        <translation type="unfinished"></translation>
        <extracomment>Description of a setting - custom subtitles that support CJK fonts</extracomment>
    </message>
    <message>
        <source>Text Subtitles Only</source>
        <translation type="unfinished"></translation>
        <extracomment>Name of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>Only display text subtitles to minimize transcoding.</source>
        <translation type="unfinished"></translation>
        <extracomment>Description of a setting - should we hide subtitles that might transcode</extracomment>
    </message>
    <message>
        <source>all</source>
        <translation>ყველა</translation>
        <extracomment>all will reset the searchTerm so all data will be availible</extracomment>
    </message>
    <message>
        <source>All</source>
        <translation>ყველა</translation>
        <extracomment>All in filter</extracomment>
    </message>
    <message>
        <source>Aired</source>
        <translation>ეთერში გავიდა</translation>
        <extracomment>Aired date label</extracomment>
    </message>
    <message>
        <source>Slideshow Off</source>
        <translation>სლაიდშოუ გამორთულია</translation>
    </message>
    <message>
        <source>Slideshow On</source>
        <translation>სლაიდშოუ ჩართულია</translation>
    </message>
    <message>
        <source>Slideshow Paused</source>
        <translation>სლაიდშოუ შეჩერებულია</translation>
    </message>
    <message>
        <source>(Favorites)</source>
        <translation>(რჩეულები)</translation>
    </message>
    <message>
        <source>Favorites</source>
        <translation>რჩეულები</translation>
    </message>
    <message>
        <source>Artists</source>
        <translation>შემსრულებლები</translation>
    </message>
    <message>
        <source>Slideshow Resumed</source>
        <translation>სლაიდშოუ გაგრძელდა</translation>
    </message>
    <message>
        <source>Random Off</source>
        <translation>შემთხვევითობა გამორთულია</translation>
    </message>
    <message>
        <source>Random On</source>
        <translation>შემთხვევითობა ჩართულია</translation>
    </message>
    <message>
        <source>Delete Playlist</source>
        <translation>დასაკრავი სიის წაშლა</translation>
    </message>
    <message>
        <source>MPEG-4 Support</source>
        <translation>MPEG-4-ის მხარდაჭერა</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Parental Ratings</source>
        <translation>მშობლის რეიტინგები</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>Collections</source>
        <translation>კოლექციები</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>დასაკრავი სიები</translation>
    </message>
    <message>
        <source>Years</source>
        <translation>წლები</translation>
        <extracomment>Used in Filter menu</extracomment>
    </message>
    <message>
        <source>No items found. Try adjusting your selected filters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show What&apos;s New Popup</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Show What&apos;s New popup when Jellyfin is updated to a new version.</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Unplayed</source>
        <translation>დაუკრავი</translation>
    </message>
    <message>
        <source>Played</source>
        <translation>დაკრული</translation>
    </message>
    <message>
        <source>Resumable</source>
        <translation>გაგრძელებადი</translation>
    </message>
    <message>
        <source>Movie Library Default View</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Default view for Movie Libraries.</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Grid View Item Titles</source>
        <translation type="unfinished"></translation>
        <extracomment>Title of a setting - when should we show the title text of a grid item</extracomment>
    </message>
    <message>
        <source>Select when to show titles in grid view.</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Show On Hover</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Always Show</source>
        <translation>ყოველთვის ჩვენება</translation>
    </message>
    <message>
        <source>Always Hide</source>
        <translation>ყოველთვის დამალვა</translation>
    </message>
    <message>
        <source>Artists (Presentation)</source>
        <translation>შემსრულებლები (პრეზენტაცია)</translation>
    </message>
    <message>
        <source>Album Artist</source>
        <translation>ალბომის შემსრულებელი</translation>
    </message>
    <message>
        <source>Album Artists (Presentation)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Artists (Grid)</source>
        <translation>შემსრულებლები (ბადე)</translation>
    </message>
    <message>
        <source>Album Artists (Grid)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Song</source>
        <translation>სიმღერა</translation>
    </message>
    <message>
        <source>Songs</source>
        <translation>სიმღერები</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>ალბომი</translation>
    </message>
    <message>
        <source>Albums</source>
        <translation>ალბომები</translation>
    </message>
    <message>
        <source>Autoplay Episode Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The number of episodes that will play automatically after the selected episode. Requires &apos;Play next episode automatically&apos; server setting to be enabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View All</source>
        <translation>ყველას ნახვა</translation>
    </message>
    <message>
        <source>Disable Community Rating for Episodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide the star and community rating for episodes of a TV show. This is to prevent spoilers of an upcoming good/bad episode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configure the maximum playback bitrate.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Biographical information for this person is not currently available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Limit</source>
        <translation>ლიმიტის ჩართვა</translation>
    </message>
    <message>
        <source>Enable or disable the &apos;Maximum Bitrate&apos; setting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bitrate Limit</source>
        <translation>ბიტური სიხშირის ლიმიტი</translation>
    </message>
    <message>
        <source>Maximum Bitrate</source>
        <translation>მაქს. ბიტური სიხშირე</translation>
    </message>
    <message>
        <source>Set the maximum bitrate in Mbps. Set to 0 to use Roku&apos;s specifications. This setting must be enabled to take effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Libraries</source>
        <translation>ბიბლიოთეკები</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of Library pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General</source>
        <translation>ზოგადი</translation>
    </message>
    <message>
        <source>Settings relating to the appearance of the Home screen and the program in general.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grid View Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings that apply when Grid views are enabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in TV Libraries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings relating to the appearance of pages in Movie Libraries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Presentation</source>
        <translation>პრეზენტაცია</translation>
        <extracomment>Title of an option - name of presentation view</extracomment>
    </message>
    <message>
        <source>Grid</source>
        <translation>ბადე</translation>
        <extracomment>Title of an option - name of grid view</extracomment>
    </message>
    <message>
        <source>Disable Unwatched Episode Count</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>If enabled, the number of unwatched episodes in a series/season will be removed.</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Loading trailer</source>
        <translation>ტრეილერის ჩატვირთვა</translation>
        <extracomment>Dialog title in Main.brs</extracomment>
    </message>
    <message>
        <source>Next Episode Button Time</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Set how many seconds before the end of an episode the Next Episode button should appear. Set to 0 to disable.</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Preferred Audio Codec</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Title of option</extracomment>
    </message>
    <message>
        <source>Use the selected audio codec for transcodes. If the device or stream does not support it, a fallback codec will be used.</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Video Codec Support</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Enable or disable Direct Play support for certain codecs.</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Video Profile Level Support</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Attempt Direct Play of potentially unsupported profile levels</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Use system settings</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Direct playing</source>
        <translation>პირდაპირი დაკვრა</translation>
    </message>
    <message>
        <source>The source file is entirely compatible with this client and the session is receiving the file without modifications.</source>
        <translation type="unfinished"></translation>
        <extracomment>Direct play info box text in GetPlaybackInfoTask.brs</extracomment>
    </message>
    <message>
        <source>Maximum Resolution</source>
        <translation>მაქს. გაფართოება</translation>
        <extracomment>User Setting - Title</extracomment>
    </message>
    <message>
        <source>Set the maximum resolution when playing video files on this device.</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>Off - Attempt to play all resolutions</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Auto - Use TV resolution</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Mode</source>
        <translation>რეჟიმი</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Value</source>
        <translation>მნიშვნელობა</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Maximum Audio Channels</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Title</extracomment>
    </message>
    <message>
        <source>Configure the maximum audio channels when playing video files on this device.</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>Off - Attempt to play all channels</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Option title</extracomment>
    </message>
    <message>
        <source>Configure the maximum resolution when playing video files on this device.</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>Apply max resolution to all files or only transcoded files.</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Description</extracomment>
    </message>
    <message>
        <source>All files</source>
        <translation>ყველა ფაილი</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Only transcoded files</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Compatibility</source>
        <translation>თავსებადობა</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Attempt to prevent playback failures.</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Disable HEVC</source>
        <translation>HEVC-ის გამორთვა</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Disable the HEVC codec on this device. This may improve playback for some devices (ultra).</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Global</source>
        <translation>გლობალური</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Global settings that affect everyone that uses this Roku device.</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Remember Me?</source>
        <translation>გახსოვართ?</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Remember the currently logged in user and try to log them in again next time you start the Jellyfin app.</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Trickplay Display</source>
        <translation>Trickplay-ის ჩვენება</translation>
        <extracomment>User Setting - Title for option</extracomment>
    </message>
    <message>
        <source>Select trickplay display format.</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Description for option</extracomment>
    </message>
    <message>
        <source>Force Transcoding</source>
        <translation>ნაძალადევი ტრანსკოდირება</translation>
        <extracomment>User Setting - Title for option</extracomment>
    </message>
    <message>
        <source>Force media to be transcoded.</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Description for option</extracomment>
    </message>
    <message>
        <source>All Playable Media</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Title for option</extracomment>
    </message>
    <message>
        <source>Force all playable media to be transcoded.</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Description for option</extracomment>
    </message>
    <message>
        <source>Live TV</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Title for option</extracomment>
    </message>
    <message>
        <source>Force live TV to be transcoded. If All Playable Media is already set to Force Transcode (Remux Disabled), this setting is ignored.</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Description for option</extracomment>
    </message>
    <message>
        <source>Media Segment Actions</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Title for option</extracomment>
    </message>
    <message>
        <source>Settings relating to how Jellyfin should handle media segments.</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Description for option</extracomment>
    </message>
    <message>
        <source>Commercial Segments</source>
        <translation>რეკლამის სეგმენტები</translation>
        <extracomment>User Setting - Title for option</extracomment>
    </message>
    <message>
        <source>What action should Jellyfin take for commercial segments?</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Description for option</extracomment>
    </message>
    <message>
        <source>Intro Segments</source>
        <translation>შესავლის სეგმენტები</translation>
        <extracomment>User Setting - Title for option</extracomment>
    </message>
    <message>
        <source>What action should Jellyfin take for intro segments?</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Description for option</extracomment>
    </message>
    <message>
        <source>Outro Segments</source>
        <translation>ბოლო ნაწილის სეგმენტები</translation>
        <extracomment>User Setting - Title for option</extracomment>
    </message>
    <message>
        <source>What action should Jellyfin take for outro segments?</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Description for option</extracomment>
    </message>
    <message>
        <source>Preview Segments</source>
        <translation>გადახედვის სეგმენტები</translation>
        <extracomment>User Setting - Title for option</extracomment>
    </message>
    <message>
        <source>What action should Jellyfin take for preview segments?</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Description for option</extracomment>
    </message>
    <message>
        <source>Recap Segments</source>
        <translation>გამეორების ფრაგმენტები</translation>
        <extracomment>User Setting - Title for option</extracomment>
    </message>
    <message>
        <source>What action should Jellyfin take for recap segments?</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Description for option</extracomment>
    </message>
    <message>
        <source>Ask To Skip</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Options</extracomment>
    </message>
    <message>
        <source>Skip</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Options</extracomment>
    </message>
    <message>
        <source>None</source>
        <translation>არცერთი</translation>
        <extracomment>User Setting - Options</extracomment>
    </message>
    <message>
        <source>No Chapter Data Found</source>
        <translation type="unfinished"></translation>
        <extracomment>Message shown in OSD when no chapter data is returned by the API</extracomment>
    </message>
    <message>
        <source>Use Web Client&apos;s Home Section Arrangement</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Make the arrangement of the Roku home view sections match the web client&apos;s home screen. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Welcome to version</source>
        <translation type="unfinished"></translation>
        <extracomment>WhatsNewDialog title - Welcome to version 2.0.0</extracomment>
    </message>
    <message>
        <source>To view a complete list of changes visit</source>
        <translation type="unfinished"></translation>
        <extracomment>WhatsNewDialog body text preceding the changelog URL</extracomment>
    </message>
    <message>
        <source>Random</source>
        <translation>შემთხვევითი</translation>
        <extracomment>General use word when we want to randomize data</extracomment>
    </message>
    <message>
        <source>... (Press * to read more)</source>
        <translation type="unfinished"></translation>
        <extracomment>Ellipsis Text for when text overflows its container</extracomment>
    </message>
    <message>
        <source>Item Detail Screen</source>
        <translation type="unfinished"></translation>
        <extracomment>User interface Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Settings relating to the appearance of the item detail screen.</source>
        <translation type="unfinished"></translation>
        <extracomment>User interface Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Community and Critical Ratings</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Ratings for how good a movie is</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Overview Content</source>
        <translation>შემცველობის მიმოხილვა</translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>A quick overview of the item selected - typically a short plot outline.</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Settings relating to the appearance of Library pages.</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Forget Filters</source>
        <translation>ფილტრების დავიწყება</translation>
        <extracomment>Libraries Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Forget applied library filters when Jellyfin is closed.</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Library Landscape Column Count</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Number of columns in library view when showing landscape (wide) images</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Library Portrait Column Count</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Number of columns in library view when showing portrait (tall) images</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Library Square Column Count</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Number of columns in library view when showing square images</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Load Items Limit</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Number of items to load together on library screens.</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting description</extracomment>
    </message>
    <message>
        <source>View All Next Up</source>
        <translation type="unfinished"></translation>
        <extracomment>Title for viewing all episodes available in the Next Up section</extracomment>
    </message>
    <message>
        <source>Rewatching Next Up</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Show already watched episodes in &apos;Next Up&apos; sections.</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Episode Images Next Up</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Setting title</extracomment>
    </message>
    <message>
        <source>What type of images to use for Episodes shown in the &apos;Next Up&apos; and &apos;Continue Watching&apos; sections.</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Use Web Client Setting</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Setting option title</extracomment>
    </message>
    <message>
        <source>Use Episode Image</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Setting option title</extracomment>
    </message>
    <message>
        <source>Use Show Image</source>
        <translation type="unfinished"></translation>
        <extracomment>User Setting - Setting option title</extracomment>
    </message>
    <message>
        <source>The selected Jellyfin server uses version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>which is not supported by this app. Please update the server to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>or newer to use this app or install and use the Jellyfin Legacy app from Roku&apos;s Streaming Store</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Return to server select screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CH</source>
        <translation>არხ</translation>
        <extracomment>Abbreviation for Channel</extracomment>
    </message>
    <message>
        <source>Use Fallback Font Across App</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Changes the font used in the app to the server&apos;s configured fallback font.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Highlighted Color</source>
        <translation>გამოკვეთილის ფერი</translation>
    </message>
    <message>
        <source>Folders</source>
        <translation>საქაღალდეები</translation>
    </message>
    <message>
        <source>Go To Artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No Results Found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format</source>
        <translation>ფორმატი</translation>
    </message>
    <message>
        <source>downloads</source>
        <translation>გადმოწერები</translation>
    </message>
    <message>
        <source>Series</source>
        <translation>სერიები</translation>
    </message>
    <message>
        <source>Part</source>
        <translation>ნაწილი</translation>
    </message>
    <message>
        <source>Play / Resume from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play or Resume from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>What&apos;s New</source>
        <translation>რა არის ახალი</translation>
    </message>
    <message>
        <source>Skip</source>
        <translation>გამოტოვება</translation>
    </message>
    <message>
        <source>Sort by</source>
        <translation>დალაგების პირობა</translation>
    </message>
    <message>
        <source>Search is unavailable because the API does not support searching inside boxsets.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search is unavailable because the API does not support searching inside My List.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search this library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mark As Unplayed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mark As Played</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add To Playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove From My List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add To My List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Press OK to type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Library Settings</source>
        <translation>ბიბლიოთეკის მორგება</translation>
    </message>
    <message>
        <source>Display Watched Checkmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Playback Info</source>
        <translation>დაკვრის ინფორმაცია</translation>
    </message>
    <message>
        <source>Select Audio</source>
        <translation>აუდიოს არჩევა</translation>
    </message>
    <message>
        <source>Select Subtitles</source>
        <translation>სუბტიტრების არჩევა</translation>
    </message>
    <message>
        <source>Select Language</source>
        <translation>ენის არჩევა</translation>
    </message>
    <message>
        <source>Tracks</source>
        <translation>ტრეკები</translation>
    </message>
    <message>
        <source>Released</source>
        <translation>გამოვიდა</translation>
    </message>
    <message>
        <source>min</source>
        <translation>წთ</translation>
    </message>
    <message>
        <source>mins</source>
        <translation>წთ</translation>
    </message>
    <message>
        <source>Continue Listening</source>
        <translation>მოსმენის გაგრძელება</translation>
    </message>
    <message>
        <source>In My List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AppearsOn</source>
        <translation>ჩანს</translation>
    </message>
    <message>
        <source>Public Profile</source>
        <translation>საჯარო პროფილი</translation>
    </message>
    <message>
        <source>Saved Profile</source>
        <translation>შენახული პროფილი</translation>
    </message>
    <message>
        <source>Manage Hidden Users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to forget this user?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete this subtitle?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>დიახ</translation>
    </message>
    <message>
        <source>No, Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unhide Users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unhide Users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play Normally - disabled because of selected force transcoding setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>as</source>
        <translation>როგორც</translation>
        <extracomment>Used in ExtrasRowList.bs to show the role of a person in a movie or TV show</extracomment>
    </message>
    <message>
        <source>Seasons</source>
        <translation>სეზონები</translation>
        <extracomment>Used in TVSeasonRow.bs to show the title of a row containing seasons</extracomment>
    </message>
    <message>
        <source>Season</source>
        <translation>სეზონი</translation>
    </message>
    <message>
        <source>Episode</source>
        <translation>ეპიზოდი</translation>
    </message>
    <message>
        <source>Section 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Section 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Section 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Section 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Section 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Section 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Section 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Section 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select what to show in section 1. This setting has no effect if \&quot;Use Web Client&apos;s Home Section Arrangement\&quot; is enabled. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select what to show in section 2. This setting has no effect if \&quot;Use Web Client&apos;s Home Section Arrangement\&quot; is enabled. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select what to show in section 3. This setting has no effect if \&quot;Use Web Client&apos;s Home Section Arrangement\&quot; is enabled. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select what to show in section 4. This setting has no effect if \&quot;Use Web Client&apos;s Home Section Arrangement\&quot; is enabled. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select what to show in section 5. This setting has no effect if \&quot;Use Web Client&apos;s Home Section Arrangement\&quot; is enabled. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select what to show in section 6. This setting has no effect if \&quot;Use Web Client&apos;s Home Section Arrangement\&quot; is enabled. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select what to show in section 7. This setting has no effect if \&quot;Use Web Client&apos;s Home Section Arrangement\&quot; is enabled. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select what to show in section 8. This setting has no effect if \&quot;Use Web Client&apos;s Home Section Arrangement\&quot; is enabled. Jellyfin will need to be closed and reopened for change to take effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Live TV</source>
        <translation>პირდაპირი ეთერი</translation>
    </message>
    <message>
        <source>My List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recently Added Media</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customize the home screen sections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Home Rows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colors</source>
        <translation>ფერები</translation>
    </message>
    <message>
        <source>Change the colors of elements in the app.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Screens</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colors used across multiple screens.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Background</source>
        <translation>ფონი</translation>
    </message>
    <message>
        <source>The base background color. Background images are layered on top of this color.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cursor</source>
        <translation>კურსორი</translation>
    </message>
    <message>
        <source>The color of the remote control&apos;s cursor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Primary Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The primary text color.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Secondary Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The secondary text color.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Watched Check Mark &amp; Unplayed Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colors specific to the watched check mark &amp; unplayed count box.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The background color of the check mark &amp; unplayed count shown in the top right corner of items.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unplayed Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The color of the unplayed count number.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Watched Check Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The color of the watched check mark.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dialog Popups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colors specific to dialog popups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The background color for all dialog popups.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bold Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The text color for bold text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horizontal Border line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The color of the thin border line under the header text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The text color for the item the cursor is over.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The text color for title and items the cursor is not over.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>What&apos;s New Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The text color for the author in the What&apos;s New popup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Home Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colors specific to the home screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My List Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The color of the star icon in the My List library item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Row Headers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The text color of the headers of each row.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Row Item Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The background color of items. Only seen if no image loads on top of it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Row Item Progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The color of the watched portion of the progress bar.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Row Item Progress Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The background color of the progress bar.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Row Item Subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The text color of the second line displayed under items.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Row Item Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The text color of the first line displayed under items.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username In Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The text color of the user&apos;s name in the header.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shuffle Play Collection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note: Force transcode option automatically enabled due to video rotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start Episode List From First Unwatched Episode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>When opening a season&apos;s list of episodes, automatically scroll down and start the cursor on the first unwatched episode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add To Favorites</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove From Favorites</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Five trickplay images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Single trickplay image that moves</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play Normally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Force Transcode (Allow Remux)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Force Transcode (Allow Remux) - disabled because of selected force transcoding setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Force Transcode (Remux Disabled)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Force Transcode (Remux Disabled) - disabled because of selected force transcoding setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No channels found matching your search criteria</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are You Still Watching Popup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attempt Direct Play Anamorphic Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newer devices may support direct play of anamorphic video.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>How many minutes of inactivity before playback is stopped between items and a popup is shown to continue? Set to 0 to disable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are You Still Watching?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes, continue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No, stop playback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Playback will automatically stop in 1 minute if no buttons are pressed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Burn in subtitle when transcoding</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Burn in all subtitles when transcoding is triggered. This ensures subtitle synchronization after transcoding at the cost of reduced transcoding speed.</source>
        <translation type="unfinished"></translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>Library Image Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the poster image orientation for the library views.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default (Varies By Media Type)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Landscape (Wide)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portrait (Vertical)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skip Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skip Commercial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skip Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skip Recap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skip Outro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skip Intro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Go To Genre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play Instant Mix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Next Episode Details After Finish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If auto play next episode is disabled, display the next episode&apos;s detail screen after an episode finishes playing. If no next up episode is found, return to the just-played episode&apos;s page.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Favorites Row</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings relating to the favorites row on the home screen.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sort By Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Field to sort the row by.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date Created</source>
        <translation>შექმნის თარიღი</translation>
    </message>
    <message>
        <source>Is Unplayed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sort Order for the row - Ascending,Descending.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current Offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Adjust Subtitle Timing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display Episodes In Two Columns</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Screen Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings relating to Live TV.</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting Category description</extracomment>
    </message>
    <message>
        <source>Channel Title Info</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Select what information to use as a channel&apos;s title.</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Settings relating to Live TV.</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Channel Number and Name</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting option</extracomment>
    </message>
    <message>
        <source>Channel Number</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting option</extracomment>
    </message>
    <message>
        <source>Channel Name</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting option</extracomment>
    </message>
    <message>
        <source>TV Guide Channel Display</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting title</extracomment>
    </message>
    <message>
        <source>Select how to display a channel in the Live TV guide.</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting description</extracomment>
    </message>
    <message>
        <source>Channel Logo and Title</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting option</extracomment>
    </message>
    <message>
        <source>Channel Logo</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting option</extracomment>
    </message>
    <message>
        <source>Channel Title</source>
        <translation type="unfinished"></translation>
        <extracomment>Libraries Setting - Setting option</extracomment>
    </message>
    <message>
        <source>Playback Speed Controls (Experimental)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use at your own risk. We make no guarantees this will work for you. \n 1. This feature may not work on this device, yet work on others \n 2. Some speed options may not work on this device, yet work on others \n 3. Roku may block this feature without warning; even if the Jellyfin client doesn&apos;t update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search Unavailable</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
