' Everflix: opens the Everflix screens and starts playback for them (see ef.go in EfCommon.bs).
'import "pkg:/source/enums/SubtitleSelection.bs"
'import "pkg:/source/utils/misc.bs"

sub onEverflixJump(data as object)
    target = (function(data)
            __bsConsequent = data.LookupCI("target")
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return ""
            end if
        end function)(data)
    sceneManager = m.global.sceneManager
    if target = "play"
        everflixPlay(data)
        return
    end if
    if target = "changeUser"
        m.efChangeUser = true
        return
    end if
    if target = "settings"
        sceneManager.callFunc("settings")
        return
    end if
    if target = "details"
        group = CreateObject("roSGNode", "EfDetails")
        group.itemId = data.id
        sceneManager.callFunc("pushScene", group)
        return
    end if
    ' Menu entries replace whatever was open, so Back always leads home
    goHome()
    if target = "home" then
        return
    end if
    group = invalid
    if target = "search"
        group = CreateObject("roSGNode", "EfSearch")
    else if target = "movies" or target = "series"
        group = CreateObject("roSGNode", "EfLibrary")
        group.setup = {
            kind: target
        }
    else if target.left(4) = "lib:"
        group = CreateObject("roSGNode", "EfLibrary")
        group.setup = {
            kind: "library"
            libraryId: target.mid(4)
        }
    else if target = "requests"
        group = CreateObject("roSGNode", "EfRequests")
    else if target = "profile"
        group = CreateObject("roSGNode", "EfProfile")
    end if
    if isValid(group) then
        sceneManager.callFunc("pushScene", group)
    end if
end sub

sub goHome()
    sceneManager = m.global.sceneManager
    while sceneManager.callFunc("getSceneCount") > 1
        active = sceneManager.callFunc("getActiveScene")
        if isValid(active) and active.isSubType("Home") then
            exit while
        end if
        sceneManager.callFunc("popScene")
    end while
end sub

' Plays an item with the audio and subtitle chosen in the Everflix detail screen
sub everflixPlay(data as object)
    item = data.LookupCI("item")
    if not isValid(item) then
        return
    end if
    kind = item.LookupCI("Type")
    ' A series plays its next (or half-watched) episode
    if kind = "Series" or kind = "BoxSet" or kind = "Season"
        onEverflixJump({
            target: "details"
            id: item.Id
        })
        return
    end if
    json = {}
    json.Append(item)
    if data.LookupCI("fromStart") = true and isValid(json.UserData)
        userData = {}
        userData.Append(json.UserData)
        userData.PlaybackPositionTicks = 0
        json.UserData = userData
    end if
    node = CreateObject("roSGNode", "HomeData")
    node.json = json
    audioIndex = data.LookupCI("audioIndex")
    if isValid(audioIndex) and audioIndex > 0 then
        node.selectedAudioStreamIndex = audioIndex
    end if
    startLoadingSpinner()
    queue = m.global.queueManager
    queue.callFunc("clear")
    queue.callFunc("resetShuffle")
    quickplay_video(node)
    subIndex = data.LookupCI("subIndex")
    if isValid(subIndex)
        queue.callFunc("setPreferredSubtitleTrack", {
            StreamIndex: subIndex
        })
    end if
    queue.callFunc("playQueue")
end sub

' ---- Mensajes desde Videotecario ----
' La Roku no recibe las órdenes de Jellyfin (no tiene su canal), así que cada 5 s pregunta a Videotecario
' si le has mandado un mensaje o «Parar» desde la pestaña Jellyfin, y lo enseña con el cartel de Everflix.
sub efInboxStart()
    if m.efInboxTimer <> invalid then
        return
    end if
    m.efNotice = CreateObject("roSGNode", "EfNotice")
    m.scene.appendChild(m.efNotice)
    m.efInboxTimer = CreateObject("roSGNode", "Timer")
    m.efInboxTimer.duration = 5
    m.efInboxTimer.repeat = true
    m.efInboxTimer.observeField("fire", m.port)
    m.efInboxTimer.control = "start"
    m.efInboxTask = invalid
end sub

sub efInboxCheck()
    if m.efInboxTask <> invalid and m.efInboxTask.state = "run" then
        return
    end if
    user = m.global.session.user
    if not isValid(user) or not isValidAndNotEmpty(user.authToken) then
        return
    end if
    device = m.global.device.serverDeviceName
    if not isValidAndNotEmpty(device) then
        return
    end if
    task = CreateObject("roSGNode", "EfTask")
    task.job = "vt"
    task.args = {
        path: "/api/pedir/inbox?device=" + CreateObject("roUrlTransfer").Escape(device)
    }
    task.observeField("result", m.port)
    task.control = "RUN"
    m.efInboxTask = task
end sub

sub efInboxResult(msg as object)
    r = msg.getData()
    if not isValid(r) or not isValid(r.LookupCI("data")) then
        return
    end if
    items = r.data.LookupCI("items")
    if not isValid(items) then
        return
    end if
    for each item in items
        if item.LookupCI("kind") = "stop"
            efStopPlayback()
        else if item.LookupCI("kind") = "message"
            efShowNotice((function(item)
                    __bsConsequent = item.LookupCI("header")
                    if __bsConsequent <> invalid then
                        return __bsConsequent
                    else
                        return ""
                    end if
                end function)(item), (function(item)
                    __bsConsequent = item.LookupCI("text")
                    if __bsConsequent <> invalid then
                        return __bsConsequent
                    else
                        return ""
                    end if
                end function)(item))
        end if
    end for
end sub

sub efShowNotice(header as string, text as string)
    if m.efNotice = invalid then
        return
    end if
    ' siempre encima de todo (también del reproductor)
    m.scene.removeChild(m.efNotice)
    m.scene.appendChild(m.efNotice)
    m.efNotice.message = {
        header: header
        text: text
    }
end sub

sub efStopPlayback()
    sceneManager = m.global.sceneManager
    active = sceneManager.callFunc("getActiveScene")
    if isValid(active) and active.isSubType("VideoPlayerView")
        active.control = "stop"
        sceneManager.callFunc("popScene")
        efShowNotice("Everflix", "Han parado lo que estabas viendo.")
    end if
end sub
'//# sourceMappingURL=./Everflix.brs.map