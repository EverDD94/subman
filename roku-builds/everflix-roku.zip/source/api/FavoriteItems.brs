'import "pkg:/source/api/sdk.bs"
'import "pkg:/source/enums/FavoriteStatus.bs"
'import "pkg:/source/enums/String.bs"
'import "pkg:/source/utils/misc.bs"
' Split large favorite-status lookups into manageable requests while still loading every track.


function GetFavoriteAudioItemStatuses(items as object, userID as string) as object
    itemIDs = []
    favoriteItemStatuses = {}
    for each item in items
        itemID = chainLookupReturn(item, "id", "")
        if isValidAndNotEmpty(itemID)
            itemIDs.push(itemID)
            favoriteItemStatuses.AddReplace(itemID, "unknown")
        end if
    end for
    if itemIDs.count() = 0 then
        return favoriteItemStatuses
    end if
    for batchOffset = 0 to itemIDs.count() - 1 step 50
        batchIDs = itemIDs.slice(batchOffset, batchOffset + 50)
        favoriteData = api_items_Get({
            UserId: userID
            Ids: batchIDs.join(",")
            enableUserData: true
        })
        ' Leave only this batch unknown when its ID-scoped lookup fails.
        if isChainValid(favoriteData, "Items")
            for each itemID in batchIDs
                favoriteItemStatuses.AddReplace(itemID, "notFavorite")
            end for
            for each item in favoriteData.Items
                itemID = chainLookupReturn(item, "id", "")
                if isValidAndNotEmpty(itemID) and chainLookupReturn(item, "UserData.IsFavorite", false)
                    favoriteItemStatuses.AddReplace(itemID, "favorite")
                end if
            end for
        end if
    end for
    return favoriteItemStatuses
end function
'//# sourceMappingURL=./FavoriteItems.brs.map