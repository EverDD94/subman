' @fileoverview Bounds for requested images, passed as params to ItemImageURL.
' The server keeps each image's aspect ratio inside the bounds, so one size serves
' every shape of image (poster, square, wide) shown in the same space.
' Home row tiles (see homeRowItemSizes)

' Rows on detail screens: cast, episodes, extras and similar items

' Main poster on detail screens: people, playlists

' Episode list on season screens

' Album art and playlist covers in music views and the audio player

' Title logo over the backdrop on library and detail screens

' Title logo in the video player

'//# sourceMappingURL=./ImageSizes.brs.map