' Set global constants
sub setConstants()
    globals = m.screen.getGlobalNode()
    ' Set Global Constants
    globals.addFields({
        constants: {
            jellyfin_server: "jellyfin server"
            poster_bg_pallet: [
                "#00455c"
                "#44bae1"
                "#00a4db"
                "#1c4c5c"
                "#007ea8"
            ]
            colors: {
                button: "#006fab"
                blue: "#3D63E0FF"
            }
            icons: {
                ascending_black: "pkg:/images/icons/up_black.png"
                ascending_white: "pkg:/images/icons/up_white.png"
                descending_black: "pkg:/images/icons/down_black.png"
                descending_white: "pkg:/images/icons/down_white.png"
                check_black: "pkg:/images/icons/check_black.png"
                check_white: "pkg:/images/icons/check_white.png"
            }
            cssColorDict: {
                "aliceblue": "#f0f8ff"
                "antiquewhite": "#faebd7"
                "aqua": "#00ffff"
                "aquamarine": "#7fffd4"
                "azure": "#f0ffff"
                "beige": "#f5f5dc"
                "bisque": "#ffe4c4"
                "black": "#000000"
                "blanchedalmond": "#ffebcd"
                "blue": "#0000ff"
                "blueviolet": "#8a2be2"
                "brown": "#a52a2a"
                "burlywood": "#deb887"
                "cadetblue": "#5f9ea0"
                "chartreuse": "#7fff00"
                "chocolate": "#d2691e"
                "coral": "#ff7f50"
                "cornflowerblue": "#6495ed"
                "cornsilk": "#fff8dc"
                "crimson": "#dc143c"
                "cyan": "#00ffff"
                "darkblue": "#00008b"
                "darkcyan": "#008b8b"
                "darkgoldenrod": "#b8860b"
                "darkgray": "#a9a9a9"
                "darkgreen": "#006400"
                "darkgrey": "#a9a9a9"
                "darkkhaki": "#bdb76b"
                "darkmagenta": "#8b008b"
                "darkolivegreen": "#556b2f"
                "darkorange": "#ff8c00"
                "darkorchid": "#9932cc"
                "darkred": "#8b0000"
                "darksalmon": "#e9967a"
                "darkseagreen": "#8fbc8f"
                "darkslateblue": "#483d8b"
                "darkslategray": "#2f4f4f"
                "darkslategrey": "#2f4f4f"
                "darkturquoise": "#00ced1"
                "darkviolet": "#9400d3"
                "deeppink": "#ff1493"
                "deepskyblue": "#00bfff"
                "dimgray": "#696969"
                "dimgrey": "#696969"
                "dodgerblue": "#1e90ff"
                "firebrick": "#b22222"
                "floralwhite": "#fffaf0"
                "forestgreen": "#228b22"
                "fuchsia": "#ff00ff"
                "gainsboro": "#dcdcdc"
                "ghostwhite": "#f8f8ff"
                "gold": "#ffd700"
                "goldenrod": "#daa520"
                "gray": "#808080"
                "green": "#008000"
                "greenyellow": "#adff2f"
                "grey": "#808080"
                "honeydew": "#f0fff0"
                "hotpink": "#ff69b4"
                "indianred": "#cd5c5c"
                "indigo": "#4b0082"
                "ivory": "#fffff0"
                "khaki": "#f0e68c"
                "lavender": "#e6e6fa"
                "lavenderblush": "#fff0f5"
                "lawngreen": "#7cfc00"
                "lemonchiffon": "#fffacd"
                "lightblue": "#add8e6"
                "lightcoral": "#f08080"
                "lightcyan": "#e0ffff"
                "lightgoldenrodyellow": "#fafad2"
                "lightgray": "#d3d3d3"
                "lightgreen": "#90ee90"
                "lightgrey": "#d3d3d3"
                "lightpink": "#ffb6c1"
                "lightsalmon": "#ffa07a"
                "lightseagreen": "#20b2aa"
                "lightskyblue": "#87cefa"
                "lightslategray": "#778899"
                "lightslategrey": "#778899"
                "lightsteelblue": "#b0c4de"
                "lightyellow": "#ffffe0"
                "lime": "#00ff00"
                "limegreen": "#32cd32"
                "linen": "#faf0e6"
                "magenta": "#ff00ff"
                "maroon": "#800000"
                "mediumaquamarine": "#66cdaa"
                "mediumblue": "#0000cd"
                "mediumorchid": "#ba55d3"
                "mediumpurple": "#9370db"
                "mediumseagreen": "#3cb371"
                "mediumslateblue": "#7b68ee"
                "mediumspringgreen": "#00fa9a"
                "mediumturquoise": "#48d1cc"
                "mediumvioletred": "#c71585"
                "midnightblue": "#191970"
                "mintcream": "#f5fffa"
                "mistyrose": "#ffe4e1"
                "moccasin": "#ffe4b5"
                "navajowhite": "#ffdead"
                "navy": "#000080"
                "oldlace": "#fdf5e6"
                "olive": "#808000"
                "olivedrab": "#6b8e23"
                "orange": "#ffa500"
                "orangered": "#ff4500"
                "orchid": "#da70d6"
                "palegoldenrod": "#eee8aa"
                "palegreen": "#98fb98"
                "paleturquoise": "#afeeee"
                "palevioletred": "#db7093"
                "papayawhip": "#ffefd5"
                "peachpuff": "#ffdab9"
                "peru": "#cd853f"
                "pink": "#ffc0cb"
                "plum": "#dda0dd"
                "powderblue": "#b0e0e6"
                "purple": "#800080"
                "red": "#ff0000"
                "rosybrown": "#bc8f8f"
                "royalblue": "#4169e1"
                "saddlebrown": "#8b4513"
                "salmon": "#fa8072"
                "sandybrown": "#f4a460"
                "seagreen": "#2e8b57"
                "seashell": "#fff5ee"
                "sienna": "#a0522d"
                "silver": "#c0c0c0"
                "skyblue": "#87ceeb"
                "slateblue": "#6a5acd"
                "slategray": "#708090"
                "slategrey": "#708090"
                "snow": "#fffafa"
                "springgreen": "#00ff7f"
                "steelblue": "#4682b4"
                "tan": "#d2b48c"
                "teal": "#008080"
                "thistle": "#d8bfd8"
                "tomato": "#ff6347"
                "turquoise": "#40e0d0"
                "violet": "#ee82ee"
                "wheat": "#f5deb3"
                "white": "#ffffff"
                "whitesmoke": "#f5f5f5"
                "yellow": "#ffff00"
                "yellowgreen": "#9acd32"
            }
        }
    })
end sub

' Save information from roAppInfo to m.global.app
sub SaveAppToGlobal()
    appInfo = CreateObject("roAppInfo")
    lastRunVersion = get_setting("LastRunVersion")
    m.global.addFields({
        app: {
            id: appInfo.GetID()
            isDev: appInfo.IsDev()
            version: appInfo.GetVersion()
            lastRunVersion: lastRunVersion
        }
    })
end sub

' Save information from roDeviceInfo to m.global.device
sub SaveDeviceToGlobal()
    deviceInfo = CreateObject("roDeviceInfo")
    ' remove special characters
    regex = CreateObject("roRegex", "[^a-zA-Z0-9\ \-\_]", "")
    filteredFriendly = regex.ReplaceAll(deviceInfo.getFriendlyName(), "")
    ' parse out serial
    displayName = deviceInfo.getModelDisplayName()
    deviceSerial = Mid(filteredFriendly, len(displayName) + 4)
    ' determine max playback resolution
    ' https://developer.roku.com/en-ca/docs/references/brightscript/interfaces/ifdeviceinfo.md#getvideomode-as-string
    videoMode = deviceInfo.GetVideoMode()
    iPos = Instr(1, videoMode, "i")
    pPos = Instr(1, videoMode, "p")
    videoHeight = invalid
    videoWidth = invalid
    refreshRate = "0"
    bitDepth = 8
    extraData = invalid
    heightToWidth = {
        "480": "720"
        "576": "720"
        "720": "1280"
        "1080": "1920"
        "2160": "3840"
        "4320": "7680"
    }
    if iPos > 0 and pPos = 0
        ' videMode = 000i
        videoHeight = mid(videoMode, 1, iPos - 1)
        ' save refresh rate
        if Len(videoMode) > iPos
            refreshRate = mid(videoMode, iPos + 1, 2)
        end if
        ' save whats left of string
        if Len(videoMode) > iPos + 2
            extraData = mid(videoMode, iPos + 3)
        end if
    else if iPos = 0 and pPos > 0
        ' videMode = 000p
        videoHeight = mid(videoMode, 1, pPos - 1)
        ' save refresh rate
        if Len(videoMode) > pPos
            refreshRate = mid(videoMode, pPos + 1, 2)
        end if
        ' save whats left of string
        if Len(videoMode) > pPos + 2
            extraData = mid(videoMode, pPos + 3)
        end if
    else
        'i and p not present in videoMode
        print "ERROR parsing deviceInfo.GetVideoMode()"
    end if
    videoWidth = heightToWidth[videoHeight]
    if videoHeight = "2160" and extraData = "b10"
        bitDepth = 10
    else if videoHeight = "4320"
        bitDepth = 12
    end if
    m.global.addFields({
        device: {
            id: deviceInfo.getChannelClientID()
            uuid: deviceInfo.GetRandomUUID()
            name: displayName
            friendlyName: filteredFriendly
            serverDeviceName: deviceInfo.getChannelClientID()
            model: deviceInfo.GetModel()
            modelType: deviceInfo.GetModelType()
            modelDetails: deviceInfo.GetModelDetails()
            serial: deviceSerial
            osVersion: deviceInfo.GetOSVersion()
            locale: deviceInfo.GetCurrentLocale()
            clockFormat: deviceInfo.GetClockFormat()
            isAudioGuideEnabled: deviceInfo.IsAudioGuideEnabled()
            hasVoiceRemote: deviceInfo.HasFeature("voice_remote")
            displayType: deviceInfo.GetDisplayType()
            displayMode: deviceInfo.GetDisplayMode()
            videoMode: videoMode
            videoHeight: videoHeight
            videoWidth: videoWidth
            videoRefresh: StrToI(refreshRate)
            videoBitDepth: bitDepth
            isHDDevice: deviceInfo.GetUIResolution().name = "HD"
        }
    })
end sub
'//# sourceMappingURL=./globals.brs.map